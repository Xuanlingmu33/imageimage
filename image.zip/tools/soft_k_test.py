# -*- coding: utf-8 -*-
"""
soft_k_test.py —— 验证"软腐蚀 k=5"到底留下多粗的边

测试图（640x160）：
  · 6 条竖线，宽度分别是 1/2/3/4/5/6 像素
  · 40 个孤立点（1px）
  · 一段 45° 1px 细斜线
跑 k = 3 / 4 / 5 三档，看每条线还剩多少 => 直接得出"k 值对应多粗的边"
"""
import os
import struct
import subprocess
import zlib

W, H = 640, 160
HERE = r'D:\dsh\m8_duochidu\sim'
IN_TXT = os.path.join(HERE, 'soft_in.txt')
OUT_TXT = os.path.join(HERE, 'soft_out.txt')
PNG = os.path.join(HERE, 'soft_k_compare.png')

# 6 条线的中心 x 与宽度
LINES = [(80, 1), (140, 2), (200, 3), (260, 4), (320, 5), (380, 6)]
DOTS = [(450 + (i % 8) * 8, 30 + (i // 8) * 12) for i in range(40)]
DIAG = [(440 + t, 100 + t) for t in range(30)]


def make_img():
    img = [[0] * W for _ in range(H)]
    for cx, w in LINES:
        for x in range(cx - w // 2, cx - w // 2 + w):
            for y in range(20, 120):
                img[y][x] = 1
    for (x, y) in DOTS:
        img[y][x] = 1
    for (x, y) in DIAG:
        if 0 <= x < W and 0 <= y < H:
            img[y][x] = 1
    return img


def save(img, p):
    with open(p, 'w', encoding='ascii', newline='\n') as f:
        for row in img:
            f.write(''.join('1' if v else '0' for v in row))
            f.write('\n')


def load(p):
    img = [[0] * W for _ in range(H)]
    with open(p, 'r', encoding='ascii') as f:
        lines = f.read().splitlines()
    for y in range(min(H, len(lines))):
        for x in range(min(W, len(lines[y]))):
            img[y][x] = 1 if lines[y][x] == '1' else 0
    return img


def align(a, b):
    best = (10 ** 9, 0, 0)
    for dy in range(-4, 5):
        for dx in range(-6, 7):
            lost = 0
            for y in range(H):
                ys = y - dy
                if not (0 <= ys < H):
                    continue
                for x in range(W):
                    xs = x - dx
                    if 0 <= xs < W and a[y][x] and not b[ys][xs]:
                        lost += 1
            if lost < best[0]:
                best = (lost, dy, dx)
    _, dy, dx = best
    out = [[0] * W for _ in range(H)]
    for y in range(H):
        ys = y - dy
        if 0 <= ys < H:
            for x in range(W):
                xs = x - dx
                if 0 <= xs < W:
                    out[y][x] = b[ys][xs]
    return out


def run(k):
    env = dict(os.environ)
    env['PATH'] = r'D:\FPGA\modlesim\win64;' + env.get('PATH', '')
    env['MODELSIM'] = r'D:\FPGA\modlesim\modelsim.ini'
    work = os.path.join(HERE, '_softk')
    os.makedirs(work, exist_ok=True)
    if not os.path.isdir(os.path.join(work, 'work')):
        subprocess.run(['vlib', 'work'], cwd=work, env=env, capture_output=True, text=True)
    r = subprocess.run(['vlog', '-quiet', '-work', 'work',
                        r'..\..\rtl\m4chain\shift_register_2taps.v',
                        r'..\..\rtl\m4chain\morph_close.v',
                        r'..\tb_soft_k.v'],
                       cwd=work, env=env, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-1500:], r.stderr[-1500:])
        raise SystemExit(1)
    r = subprocess.run(['vsim', '-c', '-quiet', '-gNBK=%d' % k,
                        '-do', 'run -all; quit -f', 'work.tb_soft_k'],
                       cwd=work, env=env, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-1500:], r.stderr[-1500:])
        raise SystemExit(1)


if __name__ == '__main__':
    img_in = make_img()
    save(img_in, IN_TXT)
    print('测试图：6 条竖线（宽 1~6）+ 40 个孤立点 + 一段 1px 斜线')
    print('')
    print(' k | 线宽1 | 线宽2 | 线宽3 | 线宽4 | 线宽5 | 线宽6 | 孤立点 | 斜线')
    print('---+-------+-------+-------+-------+-------+-------+--------+------')
    for k in (1, 2, 3, 4, 5):
        run(k)
        out = align(img_in, load(OUT_TXT))
        vals = []
        for cx, w in LINES:
            tot = 0
            kept = 0
            for x in range(cx - w // 2, cx - w // 2 + w):
                for y in range(20, 120):
                    tot += 1
                    if out[y][x]:
                        kept += 1
            vals.append(kept * 100 // tot if tot else 0)
        dots_kept = sum(1 for (x, y) in DOTS if out[y][x])
        diag_kept = sum(1 for (x, y) in DIAG if 0 <= y < H and out[y][x])
        print(' %d | ' % k + ' | '.join('%4d%% ' % v for v in vals)
              + '| %3d/40 | %2d/30' % (dots_kept, diag_kept))
