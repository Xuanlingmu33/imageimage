﻿# m5 与 m6 逐文件对比（只读，不改动任何一边）
# 只比"源码/配置"这类有意义的东西；编译产物、ModelSim 库目录单独归一类
$ErrorActionPreference = 'Stop'

$M5 = 'D:\dsh\m5'
$M6 = 'D:\dsh\m6'

# 这些目录是编译产物/仿真库，天然不同，不算差异
$skipDirs = @('outflow','work_syn','work_pnr','work_dbg','ooc','db','w','w3','w6','wfin','wfin2','wfin3','wfx','wkey','wkey2','wlast','wm4','work','wchk5','.dirscan','acl-recovery')

function Get-SrcFiles($root) {
    Get-ChildItem $root -Recurse -File -Force | Where-Object {
        $rel = $_.FullName.Substring($root.Length + 1)
        $top = ($rel -split '\\')[0]
        ($skipDirs -notcontains $top) -and ($_.Name -notlike '*.lock')
    } | ForEach-Object {
        $h = 'LOCKED'
        try { $h = (Get-FileHash $_.FullName -Algorithm MD5 -ErrorAction Stop).Hash } catch { }
        [PSCustomObject]@{
            Rel  = $_.FullName.Substring($root.Length + 1)
            Size = $_.Length
            Hash = $h
        }
    }
}

Write-Host "扫描中（只算源码/配置，跳过编译产物与仿真库）..."
$f5 = Get-SrcFiles $M5
$f6 = Get-SrcFiles $M6
Write-Host "  m5: $($f5.Count) 个    m6: $($f6.Count) 个"

$map5 = @{}; foreach ($f in $f5) { $map5[$f.Rel] = $f }
$map6 = @{}; foreach ($f in $f6) { $map6[$f.Rel] = $f }

$only5 = @(); $only6 = @(); $diff = @(); $same = 0
foreach ($k in $map5.Keys) {
    if (-not $map6.ContainsKey($k)) { $only5 += $map5[$k] }
    elseif ($map5[$k].Hash -ne $map6[$k].Hash) { $diff += [PSCustomObject]@{ Rel=$k; Size5=$map5[$k].Size; Size6=$map6[$k].Size } }
    else { $same++ }
}
foreach ($k in $map6.Keys) { if (-not $map5.ContainsKey($k)) { $only6 += $map6[$k] } }

Write-Host ""
Write-Host "===== 汇总 ====="
Write-Host ("  完全相同      : {0}" -f $same)
Write-Host ("  内容不同      : {0}" -f $diff.Count)
Write-Host ("  只在 m5 有    : {0}" -f $only5.Count)
Write-Host ("  只在 m6 有    : {0}" -f $only6.Count)

Write-Host ""
Write-Host "===== ① 内容不同的文件 ====="
$diff | Sort-Object Rel | ForEach-Object { Write-Host ("  {0,-58} m5={1,7}  m6={2,7}" -f $_.Rel, $_.Size5, $_.Size6) }

Write-Host ""
Write-Host "===== ② 只在 m5 有 ====="
$only5 | Sort-Object Rel | ForEach-Object { Write-Host ("  {0,-58} {1,7}" -f $_.Rel, $_.Size) }

Write-Host ""
Write-Host "===== ③ 只在 m6 有 ====="
$only6 | Sort-Object Rel | ForEach-Object { Write-Host ("  {0,-58} {1,7}" -f $_.Rel, $_.Size) }

# 结果存文件，方便后续整理
$out = @()
$out += "SAME=$same"
$out += "DIFF:`n"   + (($diff   | Sort-Object Rel | ForEach-Object { "$($_.Rel)|$($_.Size5)|$($_.Size6)" }) -join "`n")
$out += "ONLY5:`n"  + (($only5  | Sort-Object Rel | ForEach-Object { "$($_.Rel)|$($_.Size)" }) -join "`n")
$out += "ONLY6:`n"  + (($only6  | Sort-Object Rel | ForEach-Object { "$($_.Rel)|$($_.Size)" }) -join "`n")
[System.IO.File]::WriteAllText('D:\dsh\m6\tools\m5_vs_m6_raw.txt', ($out -join "`n"), (New-Object System.Text.UTF8Encoding($false)))
Write-Host ""
Write-Host "原始清单已存: tools\m5_vs_m6_raw.txt"
