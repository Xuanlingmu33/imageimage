@echo off
rem =====================================================================
rem  Force a full rebuild by deleting Efinity generated outputs.
rem  Use when the flow re-uses a stale netlist / elaboration cache
rem  (symptom: "Required pin cfg_CBSEL[0] is not found" while the
rem   Interface Designer template already lists cfg_CBSEL).
rem
rem  Usage:  clean_rebuild.bat "D:\path\to\project"
rem          (no argument -> defaults to the tuxing project)
rem
rem  IMPORTANT: close the project in Efinity first (do NOT save the
rem  Interface Designer session, the .peri.xml on disk is already correct).
rem =====================================================================
setlocal

set "P=%~1"
if "%P%"=="" set "P=D:\qiansai\six\shibei\tuxing"
if "%P:~-1%"=="\" set "P=%P:~0,-1%"

echo Project : %P%
if not exist "%P%\ti60f225_oob.xml" (
    echo [ABORT] %P% does not look like an Efinity project ^(no ti60f225_oob.xml^)
    exit /b 1
)
if not exist "%P%\rtl" (
    echo [ABORT] %P% has no rtl folder
    exit /b 1
)
echo.
echo Deleting work_syn / work_pnr / work_pt / work_dbg and outflow caches ...
for %%D in (work_syn work_pnr work_pt work_dbg) do (
    if exist "%P%\%%D" del /q "%P%\%%D\*.*" >nul 2>&1
)
if exist "%P%\outflow" (
    del /q "%P%\outflow\*.netlist"     >nul 2>&1
    del /q "%P%\outflow\*.vdb"         >nul 2>&1
    del /q "%P%\outflow\*.map.v"       >nul 2>&1
    del /q "%P%\outflow\*.lbf"         >nul 2>&1
    del /q "%P%\outflow\*.primplace"   >nul 2>&1
    del /q "%P%\outflow\*.net_proto"   >nul 2>&1
    del /q "%P%\outflow\*.bit"         >nul 2>&1
    del /q "%P%\outflow\*.hex"         >nul 2>&1
)
echo.
echo Done. Reopen the project in Efinity and run the full flow.
echo Check afterwards:
echo   - outflow\ti60f225_oob.netlist   (new timestamp)
echo   - EFX.info.log contains "ru_image_switch"
endlocal
