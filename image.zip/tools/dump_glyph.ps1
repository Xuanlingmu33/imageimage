﻿param(
    [string]$Verilog = "D:\dsh\m6\rtl\m6osd\osd_font_rom.v",
    [int]$Cell = 32,
    [string]$Ascii = "3,13,15,23",
    [string]$Cjk   = "0,1,5,6,13,22"
)
$txt = [System.IO.File]::ReadAllText($Verilog)
$m = [regex]::Matches($txt, 'ROM\[\s*(\d+)\]\s*=\s*32''h([0-9A-Fa-f]{8});')
$rom = @{}
foreach ($x in $m) { $rom[[int]$x.Groups[1].Value] = [uint32]("0x" + $x.Groups[2].Value) }
Write-Host ("parsed {0} words" -f $rom.Count)

function Show-Glyph {
    param([int]$Idx, [bool]$IsCjk, [int]$Cell, $rom)
    $base = if ($IsCjk) { 32 * $Cell } else { 0 }
    $addr = $base + $Idx * $Cell
    $code = $Idx + $(if ($IsCjk) { 0x40 } else { 0x00 })
    Write-Host ("---- {0} idx={1} code=0x{2:X2} addr={3} ----" -f $(if ($IsCjk) { "CJK" } else { "ASCII" }), $Idx, $code, $addr)
    for ($y = 0; $y -lt $Cell; $y++) {
        $w = $rom[$addr + $y]
        $s = ""
        for ($x = 0; $x -lt $Cell; $x++) { if ((($w -shr $x) -band 1) -eq 1) { $s += "#" } else { $s += "." } }
        Write-Host $s
    }
}
foreach ($t in ($Ascii -split ',')) { if ($t.Trim() -ne "") { Show-Glyph -Idx ([int]$t) -IsCjk $false -Cell $Cell -rom $rom } }
foreach ($t in ($Cjk   -split ',')) { if ($t.Trim() -ne "") { Show-Glyph -Idx ([int]$t) -IsCjk $true  -Cell $Cell -rom $rom } }
