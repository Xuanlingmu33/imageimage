# -*- coding: utf-8 -*-
"""
soft_k_cluster.py —— 关键测试：软腐蚀 k 对【点簇】和【不同宽度边】的区分能力

这才回答"为什么 k=2 干净不了、k=3 又砍线"。
测试图包含：
  · 1px / 2px / 3px / 4px 竖线
  · 孤立点（1x1）
  · 2x2 点簇、3x3 点簇（x8 放大后噪声常见的形态）
  · 1px 斜线
输出：k = 1..6 时每类结构的保留率
"""
import os
import subprocess

W, H = 640, 160
HERE = r'D:\dsh\m8_duochidu\sim'
IN_TXT = os.path.join(HERE, 'clu_in.txt')
OUT_TXT = os.path.join(HERE, 'clu_out.txt')

LINES = [(60, 1), (120, 2), (180, 3), (240, 4)]
# 孤立点
DOTS1 = [(320 + (i % 6) * 10, 25 + (i // 6) * 14) for i in range(24)]
# 2x2 点簇
DOTS2 = [(400 + (i % 5) * 12, 25 + (i // 5) * 16) for i in range(20)]
# 3x3 点簇
DOTS3 = [(480 + (i % 4) * 14, 25 + (i // 4) * 18) for i in range(16)]
# 1px 斜线
DIAG = [(560 + t, 40 + t) for t in range(28)]


def make_img():
    img = [[0] * W for _ in range(H)]
    for cx, w in LINES:
        for x in range(cx - w // 2, cx - w // 2 + w):
            for y in range(20, 130):
                img[y][x] = 1
    for (x, y) in DOTS1:
        img[y][x] = 1
    for (x, y) in DOTS2:
        for dy in range(2):
            for dx in range(2):
                if 0 <= y + dy < H and 0 <= x + dx < W:
                    img[y + dy][x + dx] = 1
    for (x, y) in DOTS3:
        for dy in range(3):
            for dx in range(3):
                if 0 <= y + dy < H and 0 <= x + dx < W:
                    img[y + dy][x + dx] = 1
    for (x, y) in DIAG:
        if 0 <= x < W and 0 <= y < H:
            img[y][x] = 1
    return img


def save(img, p):
    with open(p, 'w', encoding='ascii', newline='\n') as f:
        for row in img:
            f.write(''.join('1' if v else '0' for v in row))
            f.write('\n')


def load(p):
    img = [[0] * W for _ in range(H)]
    with open(p, 'r', encoding='ascii') as f:
        lines = f.read().splitlines()
    for y in range(min(H, len(lines))):
        for x in range(min(W, len(lines[y]))):
            img[y][x] = 1 if lines[y][x] == '1' else 0
    return img


def align(a, b):
    best = (10 ** 9, 0, 0)
    for dy in range(-4, 5):
        for dx in range(-6, 7):
            lost = 0
            for y in range(H):
                ys = y - dy
                if not (0 <= ys < H):
                    continue
                for x in range(W):
                    xs = x - dx
                    if 0 <= xs < W and a[y][x] and not b[ys][xs]:
                        lost += 1
            if lost < best[0]:
                best = (lost, dy, dx)
    _, dy, dx = best
    out = [[0] * W for _ in range(H)]
    for y in range(H):
        ys = y - dy
        if 0 <= ys < H:
            for x in range(W):
                xs = x - dx
                if 0 <= xs < W:
                    out[y][x] = b[ys][xs]
    return out


def run(k):
    env = dict(os.environ)
    env['PATH'] = r'D:\FPGA\modlesim\win64;' + env.get('PATH', '')
    env['MODELSIM'] = r'D:\FPGA\modlesim\modelsim.ini'
    work = os.path.join(HERE, '_clu')
    os.makedirs(work, exist_ok=True)
    if not os.path.isdir(os.path.join(work, 'work')):
        subprocess.run(['vlib', 'work'], cwd=work, env=env, capture_output=True, text=True)
    src = open(os.path.join(HERE, 'tb_soft_k.v'), encoding='utf-8').read()
    src = src.replace('soft_in.txt', 'clu_in.txt').replace('soft_out.txt', 'clu_out.txt')
    with open(os.path.join(work, 'tb_clu.v'), 'w', encoding='utf-8') as f:
        f.write(src)
    r = subprocess.run(['vlog', '-quiet', '-work', 'work',
                        r'..\..\rtl\m4chain\shift_register_2taps.v',
                        r'..\..\rtl\m4chain\ms_row_delay.v',
                        'tb_clu.v'],
                       cwd=work, env=env, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-2000:], r.stderr[-2000:])
        raise SystemExit(1)
    r = subprocess.run(['vsim', '-c', '-quiet', '-gNBK=%d' % k,
                        '-do', 'run -all; quit -f', 'work.tb_soft_k'],
                       cwd=work, env=env, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-2000:], r.stderr[-2000:])
        raise SystemExit(1)


def pct(out, coords, box):
    tot = kept = 0
    for (x, y) in coords:
        for dy in range(box):
            for dx in range(box):
                xx, yy = x + dx, y + dy
                if 0 <= yy < H and 0 <= xx < W:
                    tot += 1
                    if out[yy][xx]:
                        kept += 1
    return kept * 100 // tot if tot else 0


if __name__ == '__main__':
    img_in = make_img()
    save(img_in, IN_TXT)
    print('结构：1/2/3/4px 竖线 + 孤立点 + 2x2点簇 + 3x3点簇 + 1px斜线')
    print('')
    hdr = ' k | 线1px | 线2px | 线3px | 线4px | 孤立点 | 2x2簇 | 3x3簇 | 1px斜线'
    print(hdr)
    print('---+-------+-------+-------+-------+--------+-------+-------+--------')
    for k in (1, 2, 3, 4, 5, 6):
        run(k)
        out = align(img_in, load(OUT_TXT))
        row = []
        for cx, w in LINES:
            coords = [(cx - w // 2 + i, 20) for i in range(w)]
            # 竖线：逐列统计整段
            tot = kept = 0
            for x in range(cx - w // 2, cx - w // 2 + w):
                for y in range(20, 130):
                    tot += 1
                    if out[y][x]:
                        kept += 1
            row.append(kept * 100 // tot if tot else 0)
        d1 = pct(out, DOTS1, 1)
        d2 = pct(out, DOTS2, 2)
        d3 = pct(out, DOTS3, 3)
        dg = sum(1 for (x, y) in DIAG if 0 <= y < H and out[y][x]) * 100 // len(DIAG)
        print(' %d | %4d%% | %4d%% | %4d%% | %4d%% |  %3d%%  | %4d%% | %4d%% | %4d%%'
              % (k, row[0], row[1], row[2], row[3], d1, d2, d3, dg))
