﻿# 三方对比工具：m4 / m5 / m6
#   ① 文件级：哪些文件不同、哪些只在一边有
#   ② 对 RTL：剥掉注释/空行后再比 ⇒ 只留【真正的功能差异】（防止被注释噪音骗过）
$ErrorActionPreference = 'Stop'

$DIRS = @{ m4='D:\dsh\m4'; m5='D:\dsh\m5'; m6='D:\dsh\m6' }
$skipDirs = @('outflow','work_syn','work_pnr','work_dbg','ooc','db','w','w3','w6','wfin','wfin2','wfin3','wfx',
              'wkey','wkey2','wlast','wm4','work','wchk5','.dirscan','acl-recovery','_bitstream_backup','tools')

function Get-SrcFiles($root) {
    Get-ChildItem $root -Recurse -File -Force | Where-Object {
        $rel = $_.FullName.Substring($root.Length + 1)
        $top = ($rel -split '\\')[0]
        ($skipDirs -notcontains $top) -and ($_.Name -notlike '*.lock')
    } | ForEach-Object {
        $h = 'LOCKED'
        try { $h = (Get-FileHash $_.FullName -Algorithm MD5 -ErrorAction Stop).Hash } catch { }
        [PSCustomObject]@{ Rel = $_.FullName.Substring($root.Length + 1); Size = $_.Length; Hash = $h }
    }
}

function Compare-Trees($nameA, $nameB) {
    $A = @{}; foreach ($f in (Get-SrcFiles $DIRS[$nameA])) { $A[$f.Rel] = $f }
    $B = @{}; foreach ($f in (Get-SrcFiles $DIRS[$nameB])) { $B[$f.Rel] = $f }
    $diff = @(); $onlyA = @(); $onlyB = @(); $same = 0
    foreach ($k in $A.Keys) {
        if (-not $B.ContainsKey($k)) { $onlyA += $k }
        elseif ($A[$k].Hash -ne $B[$k].Hash) { $diff += $k }
        else { $same++ }
    }
    foreach ($k in $B.Keys) { if (-not $A.ContainsKey($k)) { $onlyB += $k } }
    Write-Host ""
    Write-Host "########## $nameA  vs  $nameB ##########"
    Write-Host ("  相同 {0}   不同 {1}   只在{2} {3}   只在{4} {5}" -f $same, $diff.Count, $nameA, $onlyA.Count, $nameB, $onlyB.Count)
    Write-Host "  ── 内容不同 ──"
    $diff | Sort-Object | ForEach-Object { Write-Host "     $_" }
    Write-Host "  ── 只在 $nameA ──"
    $onlyA | Sort-Object | ForEach-Object { Write-Host "     $_" }
    Write-Host "  ── 只在 $nameB ──"
    $onlyB | Sort-Object | ForEach-Object { Write-Host "     $_" }
    return @{ Diff=$diff; OnlyA=$onlyA; OnlyB=$onlyB }
}

# Verilog 归一化：去注释、去空行、去行首尾空白
function Normalize-V($path) {
    $out = @()
    $inBlock = $false
    foreach ($line in (Get-Content $path)) {
        $l = $line
        if ($inBlock) { if ($l -match '\*/') { $l = $l.Substring($l.IndexOf('*/') + 2); $inBlock = $false } else { continue } }
        while ($l -match '/\*') {
            $i = $l.IndexOf('/*')
            if ($l.IndexOf('*/', $i) -ge 0) { $l = $l.Remove($i, $l.IndexOf('*/', $i) - $i + 2) }
            else { $l = $l.Substring(0, $i); $inBlock = $true; break }
        }
        $i = $l.IndexOf('//'); if ($i -ge 0) { $l = $l.Substring(0, $i) }
        $l = $l.Trim()
        if ($l -ne '') { $out += $l }
    }
    return $out
}

function Compare-Func($nameA, $nameB, $files) {
    Write-Host ""
    Write-Host "########## 功能级对比（已剥注释）: $nameA vs $nameB ##########"
    foreach ($rel in $files) {
        $pa = Join-Path $DIRS[$nameA] $rel
        $pb = Join-Path $DIRS[$nameB] $rel
        if (-not (Test-Path $pa) -or -not (Test-Path $pb)) { Write-Host "  [$rel] 有一边缺文件，跳过"; continue }
        $na = Normalize-V $pa; $nb = Normalize-V $pb
        $d = Compare-Object $na $nb
        if (-not $d) { Write-Host "  [$rel]  ✅ 功能完全相同（只有注释/空行差异）"; continue }
        $oa = @($d | Where-Object SideIndicator -eq '<='); $ob = @($d | Where-Object SideIndicator -eq '=>')
        Write-Host "  [$rel]  ★只有 $nameA 有 $($oa.Count) 行 / 只有 $nameB 有 $($ob.Count) 行"
        $oa | Select-Object -First 20 | ForEach-Object { Write-Host "       $nameA ▸ $($_.InputObject)" }
        if ($oa.Count -gt 20) { Write-Host "       ...（还有 $($oa.Count-20) 行）" }
        $ob | Select-Object -First 20 | ForEach-Object { Write-Host "       $nameB ▸ $($_.InputObject)" }
        if ($ob.Count -gt 20) { Write-Host "       ...（还有 $($ob.Count-20) 行）" }
    }
}

$r45 = Compare-Trees 'm4' 'm5'
$r56 = Compare-Trees 'm5' 'm6'

$rtl = @('rtl\m4chain\m4_pipeline.v','rtl\ti60f225_oob_top.v',
         'rtl\cam_i2c_ctrl\i2c\i2c_master_reg_rom.v','rtl\cam_i2c_ctrl\i2c\i2c_master_ctrl_top.v')
Compare-Func 'm4' 'm5' $rtl
Compare-Func 'm5' 'm6' $rtl
