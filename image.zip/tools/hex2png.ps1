﻿# =============================================================================
# hex2png.ps1 —— 把仿真导出的"真帧"转成 PNG（★m6 工具）
#
#   输入：sim\dump\*.hex —— 每行 1280 个像素，每像素 6 位十六进制 RRGGBB；
#         仿真只导了含文字的行（默认 0-47 与 576-719），其余行用深灰补上（一眼能看出）
#   输出：同名 .png
#
#   用法：
#     powershell -NoProfile -ExecutionPolicy Bypass -File tools\hex2png.ps1 -In sim\dump\A_poweron.hex
#     powershell ... -File tools\hex2png.ps1 -Dir sim\dump        # 批量转换整个目录
# =============================================================================
param(
    [string]$In  = "",
    [string]$Out = "",
    [string]$Dir = "",
    [int]$W = 1280,
    [int]$H = 720,
    [string]$RowSpec = "0-47,576-719"
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing

# ---- 解析行规格 "0-47,576-719" → 升序行号数组 ----
$dumpRows = New-Object System.Collections.ArrayList
foreach ($part in ($RowSpec -split ',')) {
    $p = $part.Trim()
    if ($p -eq "") { continue }
    if ($p -match '^(\d+)-(\d+)$') {
        for ($i = [int]$Matches[1]; $i -le [int]$Matches[2]; $i++) { [void]$dumpRows.Add($i) }
    } elseif ($p -match '^(\d+)$') {
        [void]$dumpRows.Add([int]$p)
    }
}
$dumpRows = $dumpRows | Sort-Object

function Convert-Hex {
    param([string]$HexFile, [string]$PngFile)
    # ★ 必须绝对化：PowerShell 的 cd 不会同步给 .NET 的相对路径解析 ✗
    $HexFile = (Resolve-Path -LiteralPath $HexFile).ProviderPath
    $PngFile = [System.IO.Path]::GetFullPath($PngFile)
    $lines = [System.IO.File]::ReadAllLines($HexFile)
    $bmp = New-Object System.Drawing.Bitmap($W, $H, [System.Drawing.Imaging.PixelFormat]::Format24bppRgb)
    $rect = New-Object System.Drawing.Rectangle(0, 0, $W, $H)
    $data = $bmp.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::WriteOnly, [System.Drawing.Imaging.PixelFormat]::Format24bppRgb)
    $stride = $data.Stride
    $buf = New-Object byte[] ($stride * $H)
    # 未导出的行 = 深灰 (40,40,48)，BGR 顺序
    for ($i = 0; $i -lt $buf.Length; $i += 3) { $buf[$i] = 48; $buf[$i+1] = 40; $buf[$i+2] = 40 }

    $rowIdx = 0
    foreach ($ln in $lines) {
        if ($ln.Length -lt 6) { continue }
        if ($rowIdx -ge $dumpRows.Count) { break }
        $y = $dumpRows[$rowIdx]
        $rowIdx++
        $base = $y * $stride
        $n = [math]::Min($W, [int]($ln.Length / 6))
        for ($x = 0; $x -lt $n; $x++) {
            $o = $x * 6
            $r = [Convert]::ToInt32($ln.Substring($o,   2), 16)
            $g = [Convert]::ToInt32($ln.Substring($o+2, 2), 16)
            $b = [Convert]::ToInt32($ln.Substring($o+4, 2), 16)
            $p = $base + $x * 3
            $buf[$p]   = [byte]$b
            $buf[$p+1] = [byte]$g
            $buf[$p+2] = [byte]$r
        }
    }
    [System.Runtime.InteropServices.Marshal]::Copy($buf, 0, $data.Scan0, $buf.Length)
    $bmp.UnlockBits($data)
    $bmp.Save($PngFile, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-Host ("  {0}  ->  {1}  ({2} rows)" -f (Split-Path -Leaf $HexFile), (Split-Path -Leaf $PngFile), $rowIdx)
}

if ($Dir -ne "") {
    foreach ($f in (Get-ChildItem $Dir -Filter *.hex | Sort-Object Name)) {
        Convert-Hex -HexFile $f.FullName -PngFile ([System.IO.Path]::ChangeExtension($f.FullName, ".png"))
    }
} elseif ($In -ne "") {
    if ($Out -eq "") { $Out = [System.IO.Path]::ChangeExtension($In, ".png") }
    Convert-Hex -HexFile $In -PngFile $Out
} else {
    Write-Host "usage: hex2png.ps1 -In <hex> [-Out <png>] | -Dir <folder>"
}
