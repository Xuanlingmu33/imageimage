﻿param(
    [string]$In  = "D:\dsh\m6\sim\dump\osd_0_poweron.png",
    [string]$Out = "D:\dsh\m6\sim\dump\_zoom.png",
    [int]$X = 0, [int]$Y = 0, [int]$W = 640, [int]$H = 80, [int]$Scale = 2
)
Add-Type -AssemblyName System.Drawing
$src = [System.Drawing.Image]::FromFile((Resolve-Path -LiteralPath $In).ProviderPath)
$dst = New-Object System.Drawing.Bitmap(($W * $Scale), ($H * $Scale))
$g   = [System.Drawing.Graphics]::FromImage($dst)
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
$g.PixelOffsetMode   = [System.Drawing.Drawing2D.PixelOffsetMode]::Half
$srcRect = [System.Drawing.Rectangle]::new($X, $Y, $W, $H)
$dstRect = [System.Drawing.Rectangle]::new(0, 0, ($W * $Scale), ($H * $Scale))
$g.DrawImage($src, $dstRect, $srcRect, [System.Drawing.GraphicsUnit]::Pixel)
$g.Dispose()
$dst.Save([System.IO.Path]::GetFullPath($Out), [System.Drawing.Imaging.ImageFormat]::Png)
$dst.Dispose(); $src.Dispose()
Write-Host "saved $Out  (crop $X,$Y ${W}x${H} x$Scale)"
