@echo off
rem =====================================================================
rem  Build a 3-image SPI-flash image for Efinix Ti60F225 (internal RU)
rem    image 0 (CBSEL=00, golden) : D:\qiansai\DDR\m8_4
rem    image 1 (CBSEL=01)         : D:\qiansai\six\shibei\tuxing
rem    image 2 (CBSEL=10)         : D:\qiansai\DDR\1920x1080_deep_move
rem  Switch chain: 00 --K0--> 01 --K1--> 10 --K0--> 00
rem  Input : the .hex files produced by the Efinity flow (outflow folder)
rem  Output: three_image.bit  -> program to SPI flash (SPI Active x1)
rem =====================================================================
setlocal

set "EFX=C:\Efinity\2026.1"
set "IMG0=D:\qiansai\DDR\m8_4\outflow\ti60f225_oob.hex"
set "IMG1=D:\qiansai\six\shibei\tuxing\outflow\ti60f225_oob.hex"
set "IMG2=D:\qiansai\DDR\1920x1080_deep_move\outflow\ti60f225_oob.hex"
set "OUTDIR=D:\qiansai\DDR\dual_image"
set "OUT=%OUTDIR%\three_image.bit"

if not exist "%EFX%\pgm\bin\multi_image_merger.py" (
    echo [ERROR] Efinity not found at %EFX%
    goto :fail
)
if not exist "%IMG0%" ( echo [ERROR] missing %IMG0% & goto :fail )
if not exist "%IMG1%" ( echo [ERROR] missing %IMG1% & goto :fail )
if not exist "%IMG2%" ( echo [ERROR] missing %IMG2% & goto :fail )
if not exist "%OUTDIR%" mkdir "%OUTDIR%"

call "%EFX%\bin\setup.bat" >nul
python3 "%EFX%\pgm\bin\multi_image_merger.py" -m selectable_flash_image -t internal ^
  -ifile "%IMG0%" -ifile "%IMG1%" -ifile "%IMG2%" -o "%OUT%"
if errorlevel 1 goto :fail

echo.
echo ============ DONE ============
echo Output : %OUT%
echo Report : %OUTDIR%\three_image.rpt
for %%F in ("%OUT%") do echo Size   : %%~zF bytes
echo Next   : Efinity Programmer -^> SPI Active (x1) -^> select this file -^> Erase -^> Start
exit /b 0

:fail
echo.
echo ***** MERGE FAILED *****
exit /b 1
