@echo off
rem =====================================================================
rem  Build a dual-image SPI-flash image for Efinix Ti60F225
rem    image 0 (CBSEL=00, golden) : m8_4
rem    image 1 (CBSEL=01)         : 1920x1080_deep_move
rem  Mode  : Selectable Flash Image / Remote Update (internal reconfig)
rem  Input : the .hex files produced by the Efinity flow (outflow folder)
rem  Output: dual_image.bit  -> program it to SPI flash (SPI Active)
rem =====================================================================
setlocal

set "EFX=C:\Efinity\2026.1"
set "IMG0=D:\qiansai\DDR\m8_4\outflow\ti60f225_oob.hex"
set "IMG1=D:\qiansai\DDR\1920x1080_deep_move\outflow\ti60f225_oob.hex"
set "OUTDIR=D:\qiansai\DDR\dual_image"
set "OUT=%OUTDIR%\dual_image.bit"

if not exist "%EFX%\pgm\bin\multi_image_merger.py" (
    echo [ERROR] Efinity not found at %EFX%
    goto :fail
)
if not exist "%IMG0%" (
    echo [ERROR] missing %IMG0%
    goto :fail
)
if not exist "%IMG1%" (
    echo [ERROR] missing %IMG1%
    goto :fail
)
if not exist "%OUTDIR%" mkdir "%OUTDIR%"

call "%EFX%\bin\setup.bat" >nul
python3 "%EFX%\pgm\bin\multi_image_merger.py" -m selectable_flash_image -t internal -ifile "%IMG0%" -ifile "%IMG1%" -o "%OUT%"
if errorlevel 1 goto :fail

echo.
echo ============ DONE ============
echo Output : %OUT%
echo Report : %OUTDIR%\dual_image.rpt
for %%F in ("%OUT%") do echo Size   : %%~zF bytes
echo Next   : Efinity Programmer -^> SPI Active -^> select this file -^> Start Program
exit /b 0

:fail
echo.
echo ***** MERGE FAILED *****
exit /b 1
