﻿# 把测试台期望数字同步到新初值（阈值 8 / 步进档 0 = 步进 2）
# 用单引号 here-string 存放替换对：内部原样保留，Verilog 的单引号/双引号都不冲突
$ErrorActionPreference = 'Stop'
$enc = New-Object System.Text.UTF8Encoding($false)

$tbReal = @'
chk("POWERON", 11'd32, 1'b0, 3'd2, 2'd0); ==> chk("POWERON", 11'd8, 1'b0, 3'd0, 2'd0);
chk("CLICK1", 11'd40, 1'b0, 3'd2, 2'd0); ==> chk("CLICK1", 11'd10, 1'b0, 3'd0, 2'd0);
chk("CLICK2", 11'd48, 1'b0, 3'd2, 2'd0); ==> chk("CLICK2", 11'd12, 1'b0, 3'd0, 2'd0);
chk("CLICK3", 11'd56, 1'b0, 3'd2, 2'd0); ==> chk("CLICK3", 11'd14, 1'b0, 3'd0, 2'd0);
chk("CLICK4", 11'd64, 1'b0, 3'd2, 2'd0); ==> chk("CLICK4", 11'd16, 1'b0, 3'd0, 2'd0);
chk("LONG-SIGN", 11'd64, 1'b0, 3'd2, 2'd1); ==> chk("LONG-SIGN", 11'd16, 1'b0, 3'd0, 2'd1);
chk("SIGN", 11'd64, 1'b1, 3'd2, 2'd1); ==> chk("SIGN", 11'd16, 1'b1, 3'd0, 2'd1);
chk("LONG-STEP", 11'd64, 1'b1, 3'd2, 2'd2); ==> chk("LONG-STEP", 11'd16, 1'b1, 3'd0, 2'd2);
chk("STEP", 11'd64, 1'b1, 3'd3, 2'd2); ==> chk("STEP", 11'd16, 1'b1, 3'd1, 2'd2);
chk("LONG-THR", 11'd64, 1'b1, 3'd3, 2'd0); ==> chk("LONG-THR", 11'd16, 1'b1, 3'd1, 2'd0);
chk("BACK-CLICK", 11'd48, 1'b1, 3'd3, 2'd0); ==> chk("BACK-CLICK", 11'd12, 1'b1, 3'd1, 2'd0);
thr=32 加 步进8 ==> thr=8 加 步进2
(thr 应保持 64) ==> (thr 应保持 16)
thr=%0d（应 64） ==> thr=%0d（应 16）
步进档 8→16 ==> 步进档 2→4
按【减、步进16】：64-16=48 ==> 按【减、步进4】：16-4=12
'@

$tbOsd = @'
chk("POWERON", 11'd32, 1'b0, 3'd2, 2'd0); ==> chk("POWERON", 11'd8, 1'b0, 3'd0, 2'd0);
chk("CLICK1", 11'd40, 1'b0, 3'd2, 2'd0); ==> chk("CLICK1", 11'd10, 1'b0, 3'd0, 2'd0);
chk("CLICK2", 11'd48, 1'b0, 3'd2, 2'd0); ==> chk("CLICK2", 11'd12, 1'b0, 3'd0, 2'd0);
(1) 上电：thr=32 sign=加 step=8 ==> (1) 上电：thr=8 sign=加 step=2
(2) 单击 ×2 ⇒ 阈值 40 / 48 ==> (2) 单击 ×2 ⇒ 阈值 10 / 12
step=%0d（应 3=16） ==> step=%0d（应 1=4）
o_step === 3'd3 ==> o_step === 3'd1
osd_1_thr48.hex ==> osd_1_thr12.hex
'@

$tbPipe = @'
阈值 32 -> 40 ==> 阈值 8 -> 10
thr=%0d（期望 40） ==> thr=%0d（期望 10）
step=%0d（期望 3=16） ==> step=%0d（期望 1=4）
o_step_idx === 3'd3 ==> o_step_idx === 3'd1
步进档 8->16 ==> 步进档 2->4
按当前 减/步进16 生效 ==> 按当前 减/步进4 生效
'@

function Apply-Pairs($file, $block) {
    $t = [System.IO.File]::ReadAllText($file)
    $n = 0; $miss = 0
    foreach ($line in ($block -split "`r?`n")) {
        if ($line.Trim() -eq '') { continue }
        $parts = $line -split ' ==> '
        if ($parts.Count -ne 2) { Write-Host "  [格式错] $line"; continue }
        if ($t.Contains($parts[0])) { $t = $t.Replace($parts[0], $parts[1]); $n++ }
        else { Write-Host "  [未找到] $($parts[0])"; $miss++ }
    }
    [System.IO.File]::WriteAllText($file, $t, $enc)
    Write-Host "  $([System.IO.Path]::GetFileName($file)): 替换 $n 处, 未命中 $miss 处"
}

Write-Host "同步测试台期望值:"
Apply-Pairs 'D:\dsh\m6\sim\tb_key_real.v'     $tbReal
Apply-Pairs 'D:\dsh\m6\sim\tb_m6_osd.v'       $tbOsd
Apply-Pairs 'D:\dsh\m6\sim\tb_m6_pipeline.v'  $tbPipe
Write-Host "完成"
