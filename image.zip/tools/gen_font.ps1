﻿# =============================================================================
# gen_font.ps1  --  OSD bitmap font generator  (m6 project)
#
#   ★ v2 修正（2026-10-13）：v1 直接用 DrawString 往格子里画 ⇒ SimHei 墨迹
#     略微超出格子被裁掉（缺笔画）+ 纵向补偿切进邻行（乱点）。
#     现在改成正规点阵化流程：
#        ① 大字渲染（em = 3×Cell，画布留足余量，NoClip）
#        ② 量出该组字形的【墨迹并集包围盒】
#        ③ 按并集等比缩放到格子里（居中、留 Padding）
#        ④ 下采样用"块内命中即亮"（max-pool）⇒ 细笔画不会被采样漏掉
#     ⇒ 不再裁切、不再有跨行乱点，且同组字形相对大小一致 ✓
#
#   输出：rtl/m6osd/osd_font_rom.v （32 位宽 ROM；ASCII 半宽存在低 16 位）
#   用法：powershell -NoProfile -ExecutionPolicy Bypass -File tools\gen_font.ps1 -Cell 32
#
#   索引表（必须与 rtl/m6osd/osd_text.v 一致）：
#       0x00 ' '  0x01 ':'  0x02 '.'  0x03..0x0C '0'..'9'
#       0x0D 'F'  0x0E 'P'  0x0F 'S'  0x10 'o' 0x11 'b' 0x12 'e' 0x13 'l'
#       0x14 'C'  0x15 'a'  0x16 'n'  0x17 'y'
#       0x18 '-'  0x19 '/'  0x1A '('  0x1B ')'  0x1C 's'（v9：反向sobel 用）
#       0x40+n = tools/font_cjk.txt 里第 n 个汉字（一行一个）
#   ★ v9（2026-10-20）：中文字模槽 32 → 64（索引 0x40~0x7F），ROM 里 ASCII 占前 32 槽、
#     汉字占后 64 槽 ⇒ 老字模的地址与内容【一个字节都不变】，只是往后追加新字 ✓
# =============================================================================
param(
    [int]    $Cell      = 32,
    [string] $CjkFile   = "",
    [string] $OutVerilog= "",
    [string] $OutPng    = "",
    [string] $FontName  = "SimHei",
    [int]    $Threshold = 96,
    [int]    $Pad       = 1          # 字形四周留白（像素）
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing

$root = Split-Path -Parent $PSScriptRoot
if ($CjkFile    -eq "") { $CjkFile    = Join-Path $PSScriptRoot "font_cjk.txt" }
if ($OutVerilog -eq "") { $OutVerilog = Join-Path $root "rtl\m6osd\osd_font_rom.v" }
if ($OutPng     -eq "") { $OutPng     = Join-Path $root "tools\font_preview_cell$Cell.png" }

$half = [int]($Cell / 2)
$SS   = 3                                   # 超采样倍数
$Em   = $Cell * $SS
$Canvas = $Em + 32                          # 画布留足余量，绝不裁切

# ---------------------------------------------------------------- 字符集
$ascii = New-Object System.Collections.ArrayList
[void]$ascii.Add(' ')                                        # 0x00
[void]$ascii.Add(':')                                        # 0x01
[void]$ascii.Add('.')                                        # 0x02
foreach ($d in [char[]]'0123456789') { [void]$ascii.Add([string]$d) }   # 0x03..0x0C
foreach ($c in [char[]]'FPS')  { [void]$ascii.Add([string]$c) }         # 0x0D..0x0F
foreach ($c in [char[]]'obel') { [void]$ascii.Add([string]$c) }         # 0x10..0x13
foreach ($c in [char[]]'Cany') { [void]$ascii.Add([string]$c) }         # 0x14..0x17
[void]$ascii.Add('-')                                      # 0x18
[void]$ascii.Add('/')                                      # 0x19
[void]$ascii.Add('(')                                      # 0x1A
[void]$ascii.Add(')')                                      # 0x1B
[void]$ascii.Add('s')                                      # 0x1C  ★v9：反向sobel 的小写 s
$nAscii = $ascii.Count

$cjk = New-Object System.Collections.ArrayList
foreach ($ln in (Get-Content $CjkFile -Encoding UTF8)) {
    $t = ([string]$ln).Trim()
    if ($t.Length -eq 0) { continue }
    if ($t.StartsWith("#")) { continue }
    $ch = $t.Substring(0, 1)
    if ([int][char]$ch -le 127) { continue }
    [void]$cjk.Add($ch)
}
$nCjk = $cjk.Count
if ($nAscii -gt 32) { throw "ASCII glyphs too many ($nAscii > 32)" }
if ($nCjk   -gt 64) { throw "CJK glyphs too many ($nCjk > 64)" }
$nAsciiSlot = 32          # ★v9：ASCII 固定占前 32 槽（老地址不变）
$nCjkSlot   = 64          # ★v9：汉字槽 32 → 64（索引 0x40~0x7F）
$log2Cell   = [int][math]::Log($Cell, 2)
Write-Host ("ascii={0}  cjk={1}  cell={2}  (supersample {3}x, em={4})" -f $nAscii, $nCjk, $Cell, $SS, $Em)

# ------------------------------------------------------- ① big render + ink box
$bigCache = @{}
function Render-Big {
    param([string]$Ch)
    if ($bigCache.ContainsKey($Ch)) { return $bigCache[$Ch] }
    $W = $Canvas
    $bmp = New-Object System.Drawing.Bitmap($W, $W)
    $g   = [System.Drawing.Graphics]::FromImage($bmp)
    $g.Clear([System.Drawing.Color]::Black)
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    $g.SmoothingMode     = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $f  = New-Object System.Drawing.Font($FontName, $Em, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Pixel)
    $sf = New-Object System.Drawing.StringFormat
    $sf.Alignment     = [System.Drawing.StringAlignment]::Center
    $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
    $sf.FormatFlags   = [System.Drawing.StringFormatFlags]::NoClip
    $rect = New-Object System.Drawing.RectangleF(0, 0, $W, $W)
    $g.DrawString($Ch, $f, [System.Drawing.Brushes]::White, $rect, $sf)
    $pix = New-Object 'byte[]' ($W * $W)
    $minx = $W; $maxx = -1; $miny = $W; $maxy = -1
    for ($y = 0; $y -lt $W; $y++) {
        for ($x = 0; $x -lt $W; $x++) {
            if ($bmp.GetPixel($x, $y).R -gt $Threshold) {
                $pix[$y * $W + $x] = 1
                if ($x -lt $minx) { $minx = $x }
                if ($x -gt $maxx) { $maxx = $x }
                if ($y -lt $miny) { $miny = $y }
                if ($y -gt $maxy) { $maxy = $y }
            }
        }
    }
    $f.Dispose(); $g.Dispose(); $bmp.Dispose()
    $res = @{ Pix = $pix; W = $W; MinX = $minx; MaxX = $maxx; MinY = $miny; MaxY = $maxy }
    $bigCache[$Ch] = $res
    return $res
}

# ------------------------------------------------- ② union ink box of a group
function Get-UnionBox {
    param($chars)
    $minx = 1e9; $maxx = -1; $miny = 1e9; $maxy = -1
    foreach ($ch in $chars) {
        if ($ch -eq ' ') { continue }
        $r = Render-Big -Ch $ch
        if ($r.MaxX -lt 0) { continue }
        if ($r.MinX -lt $minx) { $minx = $r.MinX }
        if ($r.MaxX -gt $maxx) { $maxx = $r.MaxX }
        if ($r.MinY -lt $miny) { $miny = $r.MinY }
        if ($r.MaxY -gt $maxy) { $maxy = $r.MaxY }
    }
    return @{ MinX = [int]$minx; MinY = [int]$miny; W = [int]($maxx - $minx + 1); H = [int]($maxy - $miny + 1) }
}

# ------------------------- ③④ scale to fit + max-pool downsample into BoxW x Cell
function Fit-Glyph {
    param([string]$Ch, $box, [int]$BoxW, [int]$Cell, [int]$Pad)
    $rows = New-Object 'int[]' $Cell
    if ($Ch -eq ' ') { return $rows }
    $r = Render-Big -Ch $Ch
    if ($r.MaxX -lt 0) { return $rows }
    $tw = $BoxW - 2 * $Pad
    $th = $Cell - 2 * $Pad
    $s  = [math]::Min($tw / [double]$box.W, $th / [double]$box.H)
    $dw = [int][math]::Max(1, [math]::Round($box.W * $s))
    $dh = [int][math]::Max(1, [math]::Round($box.H * $s))
    $dx0 = [int][math]::Floor(($BoxW - $dw) / 2)
    $dy0 = [int][math]::Floor(($Cell - $dh) / 2)
    $W = $r.W
    for ($dy = 0; $dy -lt $dh; $dy++) {
        $y0 = $box.MinY + [int][math]::Floor($dy       * $box.H / $dh)
        $y1 = $box.MinY + [int][math]::Floor(($dy + 1) * $box.H / $dh) - 1
        if ($y1 -lt $y0) { $y1 = $y0 }
        for ($dx = 0; $dx -lt $dw; $dx++) {
            $x0 = $box.MinX + [int][math]::Floor($dx       * $box.W / $dw)
            $x1 = $box.MinX + [int][math]::Floor(($dx + 1) * $box.W / $dw) - 1
            if ($x1 -lt $x0) { $x1 = $x0 }
            $hit = 0
            for ($yy = $y0; $yy -le $y1 -and $hit -eq 0; $yy++) {
                if ($yy -lt 0 -or $yy -ge $W) { continue }
                for ($xx = $x0; $xx -le $x1; $xx++) {
                    if ($xx -lt 0 -or $xx -ge $W) { continue }
                    if ($r.Pix[$yy * $W + $xx] -ne 0) { $hit = 1; break }
                }
            }
            if ($hit -ne 0) {
                $px = $dx0 + $dx; $py = $dy0 + $dy
                if ($px -ge 0 -and $px -lt $BoxW -and $py -ge 0 -and $py -lt $Cell) {
                    $rows[$py] = $rows[$py] -bor (1 -shl $px)
                }
            }
        }
    }
    return $rows
}

$boxCjk   = Get-UnionBox -chars $cjk
$boxAscii = Get-UnionBox -chars ($ascii | Where-Object { $_ -ne ' ' })
Write-Host ("ink union: CJK {0}x{1}   ASCII {2}x{3}  (supersampled coords)" -f $boxCjk.W, $boxCjk.H, $boxAscii.W, $boxAscii.H)

# ------------------------------------------------------------------ build glyphs
$glyphs = New-Object System.Collections.ArrayList
for ($i = 0; $i -lt $nAsciiSlot; $i++) {
    if ($i -lt $nAscii) {
        $rows = Fit-Glyph -Ch $ascii[$i] -box $boxAscii -BoxW $half -Cell $Cell -Pad $Pad
        [void]$glyphs.Add(@{ Name = ("ASCII[{0}]='{1}'" -f $i, $ascii[$i]); Rows = $rows; Cjk = $false })
    } else {
        [void]$glyphs.Add(@{ Name = "ASCII[$i]=blank"; Rows = (New-Object 'int[]' $Cell); Cjk = $false })
    }
}
for ($i = 0; $i -lt $nCjkSlot; $i++) {
    if ($i -lt $nCjk) {
        $rows = Fit-Glyph -Ch $cjk[$i] -box $boxCjk -BoxW $Cell -Cell $Cell -Pad $Pad
        [void]$glyphs.Add(@{ Name = ("CJK[{0}]='{1}'" -f $i, $cjk[$i]); Rows = $rows; Cjk = $true })
    } else {
        [void]$glyphs.Add(@{ Name = "CJK[$i]=blank"; Rows = (New-Object 'int[]' $Cell); Cjk = $true })
    }
}

# ------------------------------------------------------------------ emit verilog
$sb = New-Object System.Text.StringBuilder
[void]$sb.AppendLine("//=============================================================================")
[void]$sb.AppendLine("// osd_font_rom.v  ——  OSD 字模 ROM（★m6 自动生成，请勿手改）")
[void]$sb.AppendLine("//")
[void]$sb.AppendLine("//   生成脚本 : tools/gen_font.ps1  （字体 $FontName，字格 $Cell x $Cell，超采样 ${SS}x + max-pool 下采样）")
[void]$sb.AppendLine("//   索引约定 : idx[6] = 0 → ASCII（半宽，数据在低 $half 位）")
[void]$sb.AppendLine("//              idx[6] = 1 → 中文（全宽，数据占满 $Cell 位）")
[void]$sb.AppendLine("//   地址     : ASCII 第 idx[4:0] 个；中文第 idx[5:0] 个（接在 ASCII 后面）")
[void]$sb.AppendLine("//   容量     : ($nAscii 实用 + $nCjk 实用) / ($nAsciiSlot + $nCjkSlot) 槽 x $Cell 行 = $(( $nAsciiSlot + $nCjkSlot ) * $Cell) x 32bit")
[void]$sb.AppendLine("//   ★ 该文件不参与算法链，只被 osd_overlay.v 读取；换字号只需重跑脚本")
[void]$sb.AppendLine("//   ★ v9：汉字槽 32 → 64；ASCII 槽与中文起始地址不变 ⇒ 老字模地址/内容完全不变 ✓")
[void]$sb.AppendLine("//=============================================================================")
[void]$sb.AppendLine("module osd_font_rom #(")
[void]$sb.AppendLine("    parameter integer CELL    = $Cell,")
[void]$sb.AppendLine("    parameter integer N_ASCII = $nAsciiSlot,")
[void]$sb.AppendLine("    parameter integer N_CJK   = $nCjkSlot")
[void]$sb.AppendLine(")(")
[void]$sb.AppendLine("    input  wire        clk,")
[void]$sb.AppendLine("    input  wire [6:0]  idx,      // {is_cjk, index[5:0]}")
[void]$sb.AppendLine("    input  wire [4:0]  row,      // 0 .. CELL-1")
[void]$sb.AppendLine("    output reg  [31:0] bits      // 该像素行的点阵（ASCII 在低 16 位）")
[void]$sb.AppendLine(");")
[void]$sb.AppendLine("    localparam integer TOTAL = (N_ASCII + N_CJK) * CELL;")
[void]$sb.AppendLine("    reg [31:0] ROM [0:TOTAL-1];")
[void]$sb.AppendLine("    initial begin")
$k = 0; $line = ""
foreach ($gl in $glyphs) {
    for ($y = 0; $y -lt $Cell; $y++) {
        $word = [uint32]$gl.Rows[$y]
        $line += ("        ROM[{0}] = 32'h{1};" -f $k, $word.ToString("X8"))
        $k++
        if (($k % 4) -eq 0) { [void]$sb.AppendLine($line); $line = "" }
    }
}
if ($line -ne "") { [void]$sb.AppendLine($line) }
[void]$sb.AppendLine("    end")
$cjkBase = $nAsciiSlot * $Cell
[void]$sb.AppendLine("    wire [11:0] addr = (idx[6] ? (12'd$cjkBase + ({6'd0, idx[5:0]} << $log2Cell)) : ({6'd0, idx[4:0]} << $log2Cell)) + {7'd0, row};")
[void]$sb.AppendLine("    always @(posedge clk) bits <= ROM[addr];")
[void]$sb.AppendLine("endmodule")

$dir = Split-Path -Parent $OutVerilog
if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
[System.IO.File]::WriteAllText($OutVerilog, $sb.ToString(), (New-Object System.Text.UTF8Encoding($false)))
Write-Host ("verilog -> {0}  ({1} rows)" -f $OutVerilog, $k)

# ------------------------------------------------------------------ contact sheet
$cols = 16
$nTotal = $glyphs.Count
$rowsN = [int][math]::Ceiling($nTotal / $cols)
$pd = 4
$W2 = $cols * ($Cell + $pd) + $pd
$H2 = $rowsN * ($Cell + $pd) + $pd
$img = New-Object System.Drawing.Bitmap($W2, $H2)
$gi  = [System.Drawing.Graphics]::FromImage($img)
$gi.Clear([System.Drawing.Color]::FromArgb(20, 20, 20))
$sbw = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
for ($i = 0; $i -lt $nTotal; $i++) {
    $gl = $glyphs[$i]
    $cx = $pd + ($i % $cols) * ($Cell + $pd)
    $cy = $pd + [int]($i / $cols) * ($Cell + $pd)
    if ($gl.Cjk) { $gi.DrawRectangle((New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(70,70,70))), $cx, $cy, $Cell - 1, $Cell - 1) }
    for ($y = 0; $y -lt $Cell; $y++) {
        $bits = $gl.Rows[$y]
        if ($bits -eq 0) { continue }
        for ($x = 0; $x -lt $Cell; $x++) {
            if ((($bits -shr $x) -band 1) -eq 1) { $gi.FillRectangle($sbw, $cx + $x, $cy + $y, 1, 1) }
        }
    }
}
$img.Save($OutPng, [System.Drawing.Imaging.ImageFormat]::Png)
$gi.Dispose(); $img.Dispose()
Write-Host ("preview -> {0}" -f $OutPng)
