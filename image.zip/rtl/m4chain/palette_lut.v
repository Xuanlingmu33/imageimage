module palette_lut
#(
  parameter DATA_WIDTH   = 16,     // RGB565
  parameter USE_VS_LATCH = 1'b1    // 1: 换色只在帧边界生效（推荐）
                                   // 0: 无 vs 可用时透传（立刻生效）
)
(
  input                       clk,          
  input                       sys_rst_n,
  input      [3:0]            color_sel,    
  input                       vs_in,        

  output     [DATA_WIDTH-1:0] edge_color
);

  reg        vs_dly;
  reg [3:0]  sel_latched;

  always @(posedge clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
      vs_dly      <= 1'b0;
      sel_latched <= 4'd0;          // 上电默认是红
    end
    else begin
      vs_dly <= vs_in;
      if(vs_in & ~vs_dly)         
        sel_latched <= color_sel;
    end
  end

  wire [3:0] pal_idx = USE_VS_LATCH ? sel_latched : color_sel;
  reg [DATA_WIDTH-1:0] pal_color;

  always @(*) begin
    case(pal_idx)
      4'd0: pal_color = 16'hF800;   // 红
      4'd1: pal_color = 16'hFC00;   // 橙
      4'd2: pal_color = 16'hFFE0;   // 黄
      4'd3: pal_color = 16'h07E0;   // 绿
      4'd4: pal_color = 16'h07FF;   // 青
      4'd5: pal_color = 16'h001F;   // 蓝
      4'd6: pal_color = 16'h8010;   // 紫
      4'd7: pal_color = 16'hFFFF;   // 白
      default: pal_color = 16'hF800;
    endcase
  end

  assign edge_color = pal_color;

endmodule
