module m4_pipeline (
    input  wire        clk,          // 74.25MHz（顶层 hdmi_tx_slow_clk）
    input  wire        rst_n,        // 顶层 vid_rst_n

    // ---- 来自顶层 vid_cnt 段：640 像素/行、1 像素/拍、RGB888 ----
    input  wire [7:0]  i_r,
    input  wire [7:0]  i_g,
    input  wire [7:0]  i_b,
    input  wire        i_de,
    input  wire        i_hs,
    input  wire        i_vs,

    // ★m6：传感器实时帧率（×10；在 i_mipi_rx_pclk 域测好后跨时钟域送来，只用于显示）
    input  wire [13:0] i_fps_sensor,

    // ---- 4 个按键（顶层已取反成"高 = 按下"）----
    input  wire        key0,         // 中值引入
    input  wire        key1,         // 阈值调节
    input  wire        key2,         // 显示档位（单击换档 / 长按进选色）
    input  wire        key3,         // 换源

    // ---- 给 dvi_encoder ----
    output wire [23:0] o_rgb,        // {B,G,R}
    output wire        o_de,
    output wire        o_hs,
    output wire        o_vs
);

//==============================================================================
// ★ 信号声明区（全部内部信号在此集中声明，之后才是逻辑 ⇒ 杜绝"先用后声明"✗）
//==============================================================================
    // --- 语义转换 / 输入基准 ---
    wire        c_hs, c_vs;
    wire [15:0] rgb565_in;
    wire        px_valid;

    // --- 按键 ---
    wire        kf0;                         // ★m6: kf1 已删除（key1 改由 m6_osd 的单键状态机处理）
                                             // ★v8: kf3 也删除（key3 改由 m6_osd 的第 2 个状态机处理）
                                             // ★v9: kf2 也删除（key2 改由 m6_osd 的 key2_fsm 处理，要分辨长按/单击）
    wire        ev_disp_from_osd;            // ★v9：key2 单击 ⇒ 档位 +1（单拍脉冲）
    wire [3:0]  color_sel_from_osd;          // ★v9：key2 选中的叠加颜色（0..6 = 红橙黄绿青蓝紫）
    wire [10:0] canny_thr_from_osd;          // ★v8：Canny 专用阈值（key3 状态机维护）
    reg  [10:0] canny_threshold_reg1, canny_threshold_reg2;
    wire [10:0] canny_threshold_use;
    wire        ev_src_from_osd;             // ★v8：换源脉冲（key3 单击一次 = 翻转一次）
    wire [10:0] thr_from_osd;                // ★m6: 由 m6_osd 里的状态机维护的阈值
    reg         key_median;
    reg  [3:0]  disp_mode_r;
    reg         split_mode;
    reg  [10:0] sobel_threshold_reg1, sobel_threshold_reg2;
    wire [10:0] sobel_threshold_use;
    wire        median_en_sync;          // key0 经 vs 锁存（↓在末尾例化）
    wire [3:0]  disp_mode_sync;          // key2 经 vs 锁存（↓在末尾例化）

    // --- 灰度 ---
    wire [7:0]  image_gray_data;
    wire        image_gray_valid, image_gray_hs, image_gray_vs;

    // --- [m8] min-max 拉伸的输出（灰度后、中值前）---
    wire [7:0]  gray_st_data;
    wire        gray_st_valid, gray_st_hs, gray_st_vs;

    // --- [m8] 算子开关：1 = Scharr(3,10,3,>>2)   0 = Sobel(1,2,1) ---
    //   本版相对 m7 只有这一处改动。Scharr 的横竖边幅值与 Sobel 相同(4Δ)
    //   ⇒ 阈值不用重标定（斜边会更强，所以斜线看起来会更连续）
    localparam GRAD_OP = 1;

    // --- Sobel 路 ---
    wire [7:0]  image_median_data;
    wire        image_median_valid, image_median_hs, image_median_vs;
    wire [7:0]  image_med2_data;
    wire        image_med2_valid, image_med2_hs, image_med2_vs;
    wire [7:0]  gray_row1, gray_row2;
    reg  [7:0]  gray_bf0, gray_bf1, gray_bf2, gray_bf3, gray_bf4;
    reg  [7:0]  gray_cf0, gray_cf1, gray_cf2, gray_cf3, gray_cf4;
    wire [7:0]  gray_dly_med;
    wire [7:0]  median_pix;
    wire        median_pix_vld;

    // --- Canny 路 ---
    wire [7:0]  image_canny_med_data;
    wire        image_canny_med_valid, image_canny_med_hs, image_canny_med_vs;
    wire [7:0]  image_gaussian_data;
    wire        image_gaussian_valid, image_gaussian_hs, image_gaussian_vs;
    wire [10:0] mag_o;
    wire [1:0]  dir_o;
    wire        image_grad_valid, image_grad_hs, image_grad_vs;
    wire [10:0] image_nms_data;
    wire        image_nms_valid, image_nms_hs, image_nms_vs;
    wire [7:0]  nms_gray;                // 5 1001 的中间量（不在显示路径）
    wire [15:0] nms_pix;                 // 同上
    wire [1:0]  image_thresh_state;
    wire        image_thresh_bin;
    wire        image_thresh_valid, image_thresh_hs, image_thresh_vs;
    wire [15:0] image_thresh_final_data; // 同上（不在显示路径）
    wire        image_hyst_data;
    wire        image_hyst_valid, image_hyst_hs, image_hyst_vs;
    wire [15:0] image_hyst_final_data;

    // --- Sobel ---
    wire        image_sobel_data;
    wire        image_sobel_vaild, image_sobel_hs, image_sobel_vs;
    wire [7:0]  image_edge_str;

    // --- [形态学前] 原始 sobel 输出 ---
    wire        raw_sobel_data, raw_sobel_valid, raw_sobel_hs, raw_sobel_vs;
    wire [7:0]  raw_sobel_str;

    // --- 软腐蚀门限 k：8 邻居里至少几个 1 才保留 ---
    //  ★ 仿真实测（tools/soft_k_test.py，同一张测试图只改 k）：
    //      k=1 → 1px 线 100% / 1px 斜线 30/30 / 孤立点 0/40 全灭
    //      k=2 → 1px 线  98% / 1px 斜线 28/30 / 孤立点 0/40 全灭   ← 当前
    //      k=3 → 1px 线   0% / 1px 斜线  0/30 / 孤立点 0/40       ← 细线全灭！
    //      k=5 → 同 k=3（1px 全灭），只保留 2px 以上的边
    //  ⇒ k>=3 是分水岭：会把所有 1px 的细边（含斜线）一起吃掉，线会变少。
    //  ⇒ 想"压噪点但保住细线"，只能用 k=1 或 k=2。
    //  ⇒ 想更狠地压噪（接受细线消失），改成 3~5。
    localparam integer SOFT_K = 5;      // k=5：比 4 略狠（再多删邻居数=4的边界像素）

    // --- 原图对齐 / 色板 / 叠加 ---
    wire [15:0] image_rgb_dly;
    wire [3:0]  color_sel;
    wire [15:0] image_edge_color;
    wire [15:0] image_overlay_data;
    wire        image_overlay_valid, image_overlay_hs, image_overlay_vs;

    // --- 灰度对齐 ---
    reg  [15:0] gray_565_r;
    wire [15:0] gray_aligned;
    wire        gray_aligned_vld;

    // --- 换源控制器 ---
    wire [15:0] src_gray, src_ovl, src_canny;
    wire        src_gray_vld, src_ovl_vld, src_canny_vld;
    wire        src_gray_vs,  src_ovl_vs,  src_canny_vs;
    wire [1:0]  split_left_sel, split_right_sel;
    wire [15:0] s_left, s_right;
    wire        s_lvld, s_rvld, s_lvs, s_rvs;

    // --- 显示时基 / 分屏 / 补黑 / 输出 ---
    wire        d_de, d_hs, d_vs, d_line_start, d_frame_start;
    wire [11:0] d_hcnt;
    wire [10:0] d_vcnt;
    reg         ivs_d;
    wire        frame_align;
    wire [15:0] t_pix;
    wire        t_vld;
    wire [15:0] b_data;
    wire        b_de, b_hs, b_vs_unused;
    wire [10:0] b_vcnt;
    reg         d_vs_r;

//==============================================================================
// 0) hs/vs 语义转换（★适配②）与输入基准
//==============================================================================
    assign c_hs = i_de;      // de 就是本行 640 拍有效窗，下降沿正好在行末 ✓
    assign c_vs = ~i_vs;     // i_vs 是消隐期脉冲 ⇒ 取反即"有效画面期"✓

    // 原图 RGB888 → RGB565：作为 delay_align 的"第 0 拍基准"
    //   （5 1001 这里接 ov7725 的 image_data；我方是 debayer 出的 RGB888 ✓）
    assign rgb565_in = {i_r[7:3], i_g[7:2], i_b[7:3]};

    // 通道有效标志（等价于 5 1001 的 image_data_en ✓）
    assign px_valid = i_de;

//==============================================================================
// 1) 按键：消抖 + 事件→电平（★适配③④：sys_clk 就是 clk）
//    key_filter 低电平有效 ⇒ 取反使用（顶层给的是"高 = 按下"）✓
//    ★m6：key1 不再用 key_filter —— 改由 m6_osd 里的 key_mode_fsm 处理
//          （需要区分短按/中按/长按，key_filter 只给"按下"脉冲，做不到 ✗）
//==============================================================================
    key_filter u_key_filter0 (.sys_clk(clk), .sys_rst_n(rst_n), .key_in(~key0), .key_flag(kf0));
    // ★v9：key2 不再用 key_filter —— 改由 m6_osd 的 key2_fsm 处理
    //       （要分辨"单击换档位"和"长按进选色"，key_filter 只给"按下"脉冲，做不到 ✗）

    // key0：中值开关（toggle，上电 0 = 无中值）
    always @(posedge clk or negedge rst_n)
        if (!rst_n)      key_median <= 1'b0;
        else if (kf0)    key_median <= ~key_median;      // ★m4-fix: 按用户规格 key0=中值 ✓

    // key2：显示模式循环（0 二值 → 1 反向 → 2 强度 → 3 热力 → 4 雷达 → 5 卡通 → 6 彩色 → 7 多色 → 8 彩虹 → 0）
    //   ★v9：动作由 OSD 的 key2_fsm 发脉冲 ⇒ 这里只做"加一"，长按选色/5 秒回落全在 OSD 里
    //   ★2026-10-28：九档已齐，不再跳档
    always @(posedge clk or negedge rst_n)
        if (!rst_n)                    disp_mode_r <= 4'd0;
        else if (ev_disp_from_osd)     disp_mode_r <= (disp_mode_r >= 4'd8) ? 4'd0 : disp_mode_r + 4'd1;

    // key3：换源（toggle，上电 0 = 左灰右 overlay）
    always @(posedge clk or negedge rst_n)
        if (!rst_n)      split_mode <= 1'b0;
        else if (ev_src_from_osd) split_mode <= ~split_mode;   // ★v8：key3 在换源模式下单击给脉冲

    // ★m6：key1 的阈值不再由本文件维护 —— 由 m6_osd 里的 key_mode_fsm 维护：
    //        短按 = 阈值 ± 步进（默认模式）；中按 = 换 ±；长按 = 换步进档；
    //        无操作 3 秒自动回默认模式；范围夹紧 [2, 2040]
    //      这里只保留【阈值跨到像素域的两级同步】（照 5 1001 原样 ✓）
    always @(posedge clk or negedge rst_n)
        if (!rst_n) begin
            sobel_threshold_reg1 <= 11'd8;     // ★m7：与 m5 一致
            sobel_threshold_reg2 <= 11'd8;     // ★m7：与 m5 一致
        end else begin
            sobel_threshold_reg1 <= thr_from_osd;
            sobel_threshold_reg2 <= sobel_threshold_reg1;
        end
    assign sobel_threshold_use = sobel_threshold_reg2;

    // ---- ★v8：Canny 专用阈值同样走两级同步（与 Sobel 完全平行、互不影响）----
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            canny_threshold_reg1 <= 11'd8;
            canny_threshold_reg2 <= 11'd8;
        end else begin
            canny_threshold_reg1 <= canny_thr_from_osd;
            canny_threshold_reg2 <= canny_threshold_reg1;
        end
    end
    assign canny_threshold_use = canny_threshold_reg2;

//==============================================================================
// 2) RGB888 → 8bit 灰度（★适配⑥：直接吃 8bit R/G/B）
//==============================================================================
    rgb2gray
    #(
        .PROC_METHOD ("FORMULA")
    ) rgb2gray_inst (
        .clk        (clk            ),
        .sys_rst_n  (rst_n          ),
        .rgb_valid  (px_valid       ),
        .rgb_hs     (c_hs           ),      // ★有效区电平
        .rgb_vs     (c_vs           ),      // ★有效区电平
        .red_8b_i   (i_r            ),      // ★ 直接 8bit
        .green_8b_i (i_g            ),
        .blue_8b_i  (i_b            ),
        .gray_8b_o  (image_gray_data),
        .gray_valid (image_gray_valid),
        .gray_hs    (image_gray_hs  ),
        .gray_vs    (image_gray_vs  )
    );

//==============================================================================
// 2.5) [m8] min-max 线性拉伸 —— 【温和版】
//
//   ★ 为什么叫温和版（原来是"用力过猛"）：
//       原参数 MIN_RANGE=4 / MAX_GAIN=2048（8x）⇒ 暗光下 range 只有 20~60 时
//       实际放大约 4~8 倍，噪声跟着放大 4~8 倍 ⇒ 满屏碎点、整幅边缘在抖
//       （那是"增益逐帧微变 + 幅度被放大到阈值附近"共同造成的）
//       现在：MIN_RANGE=24（range 太小就完全不放，那些 range 其实就是噪声）
//             MAX_GAIN =512（Q8：256=1x，512=2x ⇒ 最多放大 2 倍）
//       ⇒ 同一个 range=59 的输入：原来拉到 0..255，现在只到 0..118
//
//   ★ 如果还想更温和：MAX_GAIN 再降到 384(1.5x)；想再强一点：768(3x)
//   ★ 完全不想要拉伸：把那三路接回 image_gray_*、FINE_DLY_A 改回 15 即可
//
//   延迟 = 1 拍 ⇒ 下面 delay_align 的 FINE_DLY_A 必须 16（不是 15）
//   三条路（中值 / 中值旁路 / Canny）都吃 gray_st_*，否则按 key0 会跳亮度+相位
//   纯 Verilog-2001、无厂商原语；9bit x 12bit 乘法器由 Efinity 推断 DSP
//==============================================================================
    minmax_stretch
    #(
        .MIN_RANGE (24  ),      // [温和版] range<24 不放（原来是 4）
        .MAX_GAIN  (2048)       // Q8 上限 2048 = 最多 8 倍
                                //   ★ 统计已锁死（LOCK_STATS=1）⇒ gain 恒定 ⇒ 不闪
                                //   档位：256=1x 512=2x 768=3x 1024=4x 1280=5x 2048=8x
                                //   ★ 3x 的好处：削顶线在 range>85 ⇒ 室内场景(30~60)完全不削顶
                                //     对比 8x 时 range>32 就削顶 ⇒ 大面积纯白、边整段消失
                                //   ★ 噪声只放 3 倍（8x 是 8 倍）
                                //   ⚠️ 幅值比 8x 小 2.67 倍 ⇒ 阈值必须跟着降，否则边会更少！
    ) u_minmax_stretch (
        .clk       (clk             ),
        .sys_rst_n (rst_n           ),
        .din       (image_gray_data ),
        .valid     (image_gray_valid),
        .hs        (image_gray_hs   ),
        .vs        (image_gray_vs   ),
        .en        (1'b1            ),      // 常开
        .dout      (gray_st_data    ),
        .dout_valid(gray_st_valid   ),
        .dout_hs   (gray_st_hs      ),
        .dout_vs   (gray_st_vs      )
    );

//==============================================================================
// 3) 【Sobel 路】中值级联（2 级）+ 旁路对齐（同拍，1290）
//==============================================================================
    median_filter
    #(
        .DATA_WIDTH (8)
    ) median_filter_sobel1_inst (
        .clk            (clk               ),
        .sys_rst_n      (rst_n             ),
        .data_in        (gray_st_data      ),      // [m8] 吃拉伸后的灰度
        .data_in_valid  (gray_st_valid     ),
        .data_in_hs     (gray_st_hs        ),
        .data_in_vs     (gray_st_vs        ),
        .data_out       (image_median_data ),
        .data_out_valid (image_median_valid),
        .data_out_hs    (image_median_hs   ),
        .data_out_vs    (image_median_vs   )
    );

    median_filter
    #(
        .DATA_WIDTH (8)
    ) median_filter_sobel2_inst (
        .clk            (clk               ),
        .sys_rst_n      (rst_n             ),
        .data_in        (image_median_data ),
        .data_in_valid  (image_median_valid),
        .data_in_hs     (image_median_hs   ),
        .data_in_vs     (image_median_vs   ),
        .data_out       (image_med2_data   ),
        .data_out_valid (image_med2_valid  ),
        .data_out_hs    (image_med2_hs     ),
        .data_out_vs    (image_med2_vs     )
    );

    // ---- 旁路对齐：2 级 × (1 行 + 5 拍) = 1290 拍 ----
    shift_register_2taps
    #(
        .DATA_WIDTH (8)
    ) gray_bypass_align (
        .clk           (clk             ),
        .shiftin       (gray_st_data    ),      // [m8] 与中值路同源
        .shiftin_valid (gray_st_valid   ),
        .shiftout      (                ),
        .taps1x        (gray_row1       ),
        .taps0x        (                )
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            gray_bf0 <= 8'd0; gray_bf1 <= 8'd0; gray_bf2 <= 8'd0;
            gray_bf3 <= 8'd0; gray_bf4 <= 8'd0;
        end else if (gray_st_valid) begin
            gray_bf0 <= gray_row1;
            gray_bf1 <= gray_bf0;
            gray_bf2 <= gray_bf1;
            gray_bf3 <= gray_bf2;
            gray_bf4 <= gray_bf3;
        end
    end

    shift_register_2taps
    #(
        .DATA_WIDTH (8)
    ) gray_bypass_align2 (
        .clk           (clk             ),
        .shiftin       (gray_bf4        ),
        .shiftin_valid (gray_st_valid   ),      // [m8]
        .shiftout      (                ),
        .taps1x        (gray_row2       ),
        .taps0x        (                )
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            gray_cf0 <= 8'd0; gray_cf1 <= 8'd0; gray_cf2 <= 8'd0;
            gray_cf3 <= 8'd0; gray_cf4 <= 8'd0;
        end else if (gray_st_valid) begin
            gray_cf0 <= gray_row2;
            gray_cf1 <= gray_cf0;
            gray_cf2 <= gray_cf1;
            gray_cf3 <= gray_cf2;
            gray_cf4 <= gray_cf3;
        end
    end
    assign gray_dly_med = gray_cf4;      // 与中值级联同拍 ✓

    // ---- "选1"：旁路 / 中值级联 二选一（key0 控制，vs 边界锁存）----
    mux_sync #(.WIDTH(8)) median_mux_inst (
        .clk      (clk             ),
        .sys_rst_n(rst_n           ),
        .sel      (median_en_sync  ),
        .vs_in    (image_med2_vs   ),
        .d0       (gray_dly_med    ),     // 0 = 灰度直通（已补到 1290 同拍）
        .d1       (image_med2_data ),     // 1 = 中值级联
        .valid_in (image_med2_valid),
        .q        (median_pix      ),
        .q_valid  (median_pix_vld  )
    );

//==============================================================================
// 4) 【Canny 路】专用中值（常开）+ 高斯 + 四级 Canny
//==============================================================================
    median_filter
    #(
        .DATA_WIDTH (8)
    ) median_filter_canny_inst (
        .clk            (clk                  ),
        .sys_rst_n      (rst_n                ),
        .data_in        (gray_st_data         ),      // [m8] Canny 路也吃拉伸后的灰度
        .data_in_valid  (gray_st_valid        ),
        .data_in_hs     (gray_st_hs           ),
        .data_in_vs     (gray_st_vs           ),
        .data_out       (image_canny_med_data ),
        .data_out_valid (image_canny_med_valid),
        .data_out_hs    (image_canny_med_hs   ),
        .data_out_vs    (image_canny_med_vs   )
    );

    gaussian_filter
    #(
        .DATA_WIDTH (8)
    ) gaussian_filter_inst (
        .clk            (clk                  ),
        .sys_rst_n      (rst_n                ),
        .data_in        (image_canny_med_data ),
        .data_in_valid  (image_canny_med_valid),
        .data_in_hs     (image_canny_med_hs   ),
        .data_in_vs     (image_canny_med_vs   ),
        .data_out       (image_gaussian_data  ),
        .data_out_valid (image_gaussian_valid ),
        .data_out_hs    (image_gaussian_hs    ),
        .data_out_vs    (image_gaussian_vs    )
    );

    canny_grad
    #(
        .DATA_WIDTH (8)
    ) canny_grad_inst (
        .clk          (clk                 ),
        .sys_rst_n    (rst_n               ),
        .data_in      (image_gaussian_data ),
        .data_in_valid(image_gaussian_valid),
        .data_in_hs   (image_gaussian_hs   ),
        .data_in_vs   (image_gaussian_vs   ),
        .mag_o        (mag_o               ),
        .dir_o        (dir_o               ),
        .mag_valid_o  (image_grad_valid    ),
        .mag_hs_o     (image_grad_hs       ),
        .mag_vs_o     (image_grad_vs       )
    );

    canny_nms
    #(
        .MAG_WIDTH (11)
    ) canny_nms_inst (
        .clk          (clk             ),
        .sys_rst_n    (rst_n           ),
        .mag_in       (mag_o           ),
        .dir_in       (dir_o           ),
        .data_in_valid(image_grad_valid),
        .data_in_hs   (image_grad_hs   ),
        .data_in_vs   (image_grad_vs   ),
        .nms_o        (image_nms_data  ),
        .nms_valid_o  (image_nms_valid ),
        .nms_hs_o     (image_nms_hs    ),
        .nms_vs_o     (image_nms_vs    )
    );

    // 5 1001 的中间量（不在显示路径上，照搬保留以便对照）
    assign nms_gray = image_nms_data[10:2];
    assign nms_pix  = {nms_gray[7:3], nms_gray[7:2], nms_gray[7:3]};

    canny_thresh
    #(
        .MAG_WIDTH (11)
    ) canny_thresh_inst (
        .clk          (clk                 ),
        .sys_rst_n    (rst_n               ),
        .nms_in       (image_nms_data      ),
        .th_high      (canny_threshold_use ),   // ★v8：改接 Canny 专用阈值（key3 维护），不再与 Sobel 共用
        .data_in_valid(image_nms_valid     ),
        .data_in_hs   (image_nms_hs        ),
        .data_in_vs   (image_nms_vs        ),
        .edge_o       (image_thresh_state  ),
        .edge_bin_o   (image_thresh_bin    ),
        .edge_valid_o (image_thresh_valid  ),
        .edge_hs_o    (image_thresh_hs     ),
        .edge_vs_o    (image_thresh_vs     )
    );

    assign image_thresh_final_data = (image_thresh_state == 2'd2) ? 16'hFFFF :
                                     (image_thresh_state == 2'd1) ? 16'h8410 : 16'h0000;

    canny_hyst
    #(
        .LINE_WIDTH (640)
    ) canny_hyst_inst (
        .clk          (clk                ),
        .sys_rst_n    (rst_n              ),
        .edge_in      (image_thresh_state ),
        .data_in_valid(image_thresh_valid ),
        .data_in_hs   (image_thresh_hs    ),
        .data_in_vs   (image_thresh_vs    ),
        .edge_o       (image_hyst_data    ),
        .edge_valid_o (image_hyst_valid   ),
        .edge_hs_o    (image_hyst_hs      ),
        .edge_vs_o    (image_hyst_vs      )
    );

    // ★ Canny 最终输出：单色（1bit 边沿 → 白/黑），不上配色 ✓（用户要求）
    assign image_hyst_final_data = image_hyst_data ? 16'hFFFF : 16'h0000;

//==============================================================================
// 5) Sobel（吃"选1"的输出）+ 边缘强度
//==============================================================================
//==============================================================================
// [m8_duochidu] 5) 多尺度梯度（两套 Sobel 并联 + 组合 max）
//
//   细尺度：median_pix ──────────────────────────► sobel_fine   ──► mag_fine ─┐
//   粗尺度：median_pix ─► 1 行延迟 + 1 像素寄存 ─► 2×2 均值 ─► sobel_coarse ─► mag_coarse ─┴─► max ─► 阈值
//
//   ★ 延迟 = 0：2×2 均值的最"新"一项就是当前像素（纯组合），两路天然同拍
//     ⇒ 下面 delay_align 的 FINE_DLY_A 一个字都不用改（仍然是 16）
//   ★ MS_GAIN = 1：粗尺度幅值 ×2（弱边/模糊边响应翻倍，断线更少）
//     ⚠️ 这会让整体幅值抬高 ⇒【阈值要重新标定】，8 肯定不够了，往 32 左右试
//   ★ MS_EN = 0：粗尺度支路被 generate 掉 ⇒ 退化成单尺度 sobel（可回退对比）
//==============================================================================
    ms_grad
    #(
        .DATA_WIDTH     (8     ),
        .LINE_WIDTH     (640   ),
        .GRAD_OP        (GRAD_OP),     // 1 = Scharr（上方 localparam）
        .BORDER_MASK    (1'b0),        // ★m7：改回 m5 的值（黑边掩码交给 black_border）
        .STRENGTH_SHIFT (1     ),
        .MS_EN          (1     ),      // 1 = 多尺度开
        .MS_GAIN        (1     )       // 1 = 粗尺度 ×2（0 = 只取平均，效果很弱）
    ) ms_grad_inst (
        .clk           (clk               ),
        .sys_rst_n     (rst_n             ),
        .data_in       (median_pix        ),
        .data_in_valid (median_pix_vld    ),
        .data_in_hs    (image_med2_hs     ),
        .data_in_vs    (image_med2_vs     ),
        .threshold     (sobel_threshold_use),
        .data_out      (raw_sobel_data    ),      // [软腐蚀前]
        .data_out_valid(raw_sobel_valid   ),
        .data_out_hs   (raw_sobel_hs      ),
        .data_out_vs   (raw_sobel_vs      ),
        .strength_o    (raw_sobel_str     ),
        .mag_o         (                  )       // 合并后原始幅值：本工程不用
    );

//==============================================================================
// [实验] 5.5) 软腐蚀 k=SOFT_K（只上这一级，不做膨胀/硬腐蚀）
//
//   目的：x8 把弱边撑到 2~3px 粗，再用"8 邻居里 ≥k 个 1"把 1px 的噪点剃掉
//         ⇒ 阈值不用抬，线能留得多。
//   为什么只上这一级：软腐蚀【只减不加】⇒ 绝不可能让线变粗/连成块，
//         是最安全的第一步。先看它剃掉多少噪点、又剃掉多少真边。
//   k=5 相当于要求局部厚度 ≥2~3px：
//         1px 孤立噪点(0~1 邻居) → 灭 ✓
//         1px 线中段(2 邻居)     → 灭 ✗（细线会被吃掉！）
//         2px 宽(≈5 邻居)        → 勉强活
//         3px 以上(8 邻居)       → 稳活 ✓
//   ⚠️ 延迟 1286（两级 × (640+3)，实测）⇒ delay_align 已 +1286
//==============================================================================
    // ---- 形态学：只留一级【软腐蚀 k=SOFT_K】（不做膨胀、不做腐蚀）----
    //   作用：删掉邻居不够多的孤立噪点（k=2 只删"完全孤立"和"端点"），
    //        1px 的细线/斜线基本保留（实测 98%）。
    //   ⚠️ 只减不加 ⇒ 绝不会让线变粗/连成块。
    //   延迟：2 级(软腐蚀 + 直通) × 643 = 1286
    morph_close
    #(
        .LINE_WIDTH (640   ),
        .STRENGTH_W (8     ),
        .M1         (3     ),      // 软腐蚀（按邻居计数 k）
        .M2         (2     ),      // 直通（只为对齐延迟，不改数据）
        .KERNEL     (1     ),      // 方形核（数 8 个邻居）
        .NB_K       (SOFT_K)
    ) morph_soft_inst (
        .clk       (clk               ),
        .sys_rst_n (rst_n             ),
        .bin_in    (raw_sobel_data    ),
        .valid_in  (raw_sobel_valid   ),
        .hs_in     (raw_sobel_hs      ),
        .vs_in     (raw_sobel_vs      ),
        .str_in    (raw_sobel_str     ),
        .bin_out   (image_sobel_data  ),      // 软腐蚀后
        .valid_out (image_sobel_vaild ),
        .hs_out    (image_sobel_hs    ),
        .vs_out    (image_sobel_vs    ),
        .str_out   (image_edge_str    )
    );

//==============================================================================
// 6) 原图 RGB565 对齐延迟（1935 = 半行 640 + 2 行 1280 + FINE 15）
//    ⚠️ 上板若描边整体偏 N 像素：只调 FINE_DLY_A（15 → 14/16 试）
//==============================================================================
    delay_align
    #(
        .DATA_WIDTH (16 ),
        .HALF_ROW   (1'b1),
        // ★ 补两级形态学的 1286 拍：640×1 + 640×4 + 22 = 3222 = 1936(原) + 1286 ✓
        //   delay_align 内部 STAGES=ROW_DLY_B/2、SELA=ROW_DLY_A/2 ⇒ A/B 必须同时改
        .ROW_DLY_A  (4  ), .FINE_DLY_A (22),
        .ROW_DLY_B  (4  ), .FINE_DLY_B (22)
    ) delay_align_inst (
        .clk      (clk          ),
        .sys_rst_n(rst_n        ),
        .data_in  (rgb565_in    ),      // ★原图 RGB565（第 0 拍基准）
        .valid_in (px_valid     ),
        .sel      (1'b0         ),      // 固定抽头 A（照 5 1001）
        .data_out (image_rgb_dly),
        .valid_out(             )
    );

//==============================================================================
// 7) 色板 + 叠加器
//==============================================================================
    assign color_sel = color_sel_from_osd;   // ★v9：颜色由 key2 选色模式给定（0..6 = 红橙黄绿青蓝紫）

    palette_lut palette_lut_inst (
        .clk       (clk            ),
        .sys_rst_n (rst_n          ),
        .color_sel (color_sel      ),
        .vs_in     (image_sobel_vs ),      // 与边缘标志同拍的那个 vs
        .edge_color(image_edge_color)
    );

    edge_overlay
    #(
        .DATA_WIDTH (16       ),
        .BLEND_MODE ("REPLACE")
    ) edge_overlay_inst (
        .clk           (clk                ),
        .sys_rst_n     (rst_n              ),
        .edge_in       (image_sobel_data   ),
        .edge_in_valid (image_sobel_vaild  ),
        .edge_in_hs    (image_sobel_hs     ),
        .edge_in_vs    (image_sobel_vs     ),
        .img_in        (image_rgb_dly      ),
        .edge_color    (image_edge_color   ),
        .disp_mode     (disp_mode_sync     ),
        .edge_str      (image_edge_str     ),
        .data_out      (image_overlay_data ),
        .data_out_valid(image_overlay_valid),
        .data_out_hs   (image_overlay_hs   ),   // ★5 1001 里悬空；我方接出来给分屏用
        .data_out_vs   (image_overlay_vs   )    // ★同上（数据随行的帧边界）
    );

//==============================================================================
// 8) 灰度对齐延迟（旁路 1290 + 1 拍 + gray_align_dly 645 = 1936，与 overlay 同拍）
//==============================================================================
    always @(posedge clk or negedge rst_n)
        if (!rst_n)          gray_565_r <= 16'd0;
        else if (median_pix_vld) gray_565_r <= {median_pix[7:3], median_pix[7:2], median_pix[7:3]};   // ★m4-fix: 改用 mux 后的 median_pix（恒有效）+ 它的 valid（原来用 i_de ⇒ 门控错位 1290 拍 ⇒ 花屏 ✗）

    gray_align_dly #(
        .FINE (5)
    ) u_gray_align (
        .clk       (clk             ),
        .sys_rst_n (rst_n           ),
        .data_in   (gray_565_r      ),
        .valid_in  (median_pix_vld  ),   // ★m4-fix: 门控同步改成 median_pix_vld ✓
        .data_out  (gray_aligned    ),
        .valid_out (gray_aligned_vld)
    );

//==============================================================================
// 9) 换源控制器（key3；vs 边界锁存与左右互换由 split_src_mux 内部完成 ✓）
//      src0 = 灰度 gray_aligned        src1 = overlay image_overlay_data
//      src2 = Canny 单色               src3 = 预留（接 0，不悬空）
//    上电   ：左 = src0(灰)     右 = src1(overlay)
//    按 key3：左 = src1(overlay) 右 = src2(canny)
//    ★ 帧边界：gray 与 overlay 同拍 ⇒ 共用 overlay_vs；canny 那条链长得多
//      ⇒ 必须用它自己的 image_hyst_vs（否则写侧错行 ✗）
//==============================================================================
    assign src_gray     = gray_aligned;
    assign src_ovl      = image_overlay_data;
    assign src_canny    = image_thresh_final_data;   // ★改接 canny_thresh 输出（三值）对照

    assign src_gray_vld = src_ovl_vld;   // ★fix: gray_align_dly 的 valid_out 在 5 1001 里是悬空的(从未验证 ✗) => 改用 overlay 的 valid(灰度与 overlay 同拍 ✓)
    assign src_ovl_vld  = image_overlay_valid;
    assign src_canny_vld= image_thresh_valid;

    assign src_gray_vs  = image_overlay_vs;
    assign src_ovl_vs   = image_overlay_vs;
    assign src_canny_vs = image_thresh_vs;

    assign split_left_sel  = split_mode ? 2'd1 : 2'd0;   // 按 key3 → overlay
    assign split_right_sel = split_mode ? 2'd2 : 2'd1;   // 按 key3 → canny

    split_src_mux
    #(
        .DATA_WIDTH (16),
        .N_SRC      (4 ),
        .SEL_W      (2 )
    ) u_src_mux (
        .clk        (clk            ),
        .sys_rst_n  (rst_n          ),
        // 打包：{src3 | src2 | src1 | src0} ⇒ 低 16 位 = src0 ✓
        .src_data   ({16'd0, src_canny, src_ovl, src_gray}),
        .src_valid  ({1'b0,  src_canny_vld, src_ovl_vld, src_gray_vld}),
        .src_vs     ({1'b0,  src_canny_vs,  src_ovl_vs,  src_gray_vs }),
        .left_sel_r (split_left_sel ),
        .right_sel_r(split_right_sel),
        .swap_r     (1'b0           ),   // 左右互换已在选择位上做 ✓
        .vs_in      (src_ovl_vs     ),   // 帧边界基准：overlay 的 vs（任何状态下都在跑 ✓）
        .left_data  (s_left         ),
        .right_data (s_right        ),
        .left_valid (s_lvld         ),
        .right_valid(s_rvld         ),
        .left_vs    (s_lvs          ),
        .right_vs   (s_rvs          )
    );

//==============================================================================
// 10) 本地 720p60 显示时基（1650 x 750 @74.25MHz）
//     ★ 必须锁到内容帧边界（i_vs 上升沿）+ ALIGN_V=725
//==============================================================================
    always @(posedge clk or negedge rst_n)
        if (!rst_n) ivs_d <= 1'b0;
        else        ivs_d <= i_vs;

    assign frame_align = i_vs && !ivs_d;    // 内容 vs 上升沿（= 第 725 行的行首）

    disp_timing
    #(
        .H_ACTIVE (1280), .H_FP (110), .H_SYNC (40), .H_BP (220),
        .V_ACTIVE (720 ), .V_FP (5  ), .V_SYNC (5 ), .V_BP (20 ),
        .ALIGN_V  (725 )
    ) u_disp_timing (
        .clk        (clk          ),
        .rst_n      (rst_n        ),
        .align      (frame_align  ),
        .de         (d_de         ),
        .hs         (d_hs         ),
        .vs         (d_vs         ),
        .h_cnt      (d_hcnt       ),
        .v_cnt      (d_vcnt       ),
        .rd_en      (             ),
        .line_start (d_line_start ),
        .frame_start(d_frame_start)
    );

//==============================================================================
// 11) 分屏打包：两幅完整 640x480 → 1280x480（用 m2m3 已修好的版本 ✓）
//==============================================================================
    image_stitche_x
    #(
        .DATA_WIDTH       (16  ),
        .IMAGE1_WIDTH_IN  (640 ),
        .IMAGE1_HEIGHT_IN (480 ),
        .IMAGE2_WIDTH_IN  (640 ),
        .IMAGE2_HEIGHT_IN (480 ),
        .IMAGE_WIDTH_OUT  (1280),
        .IMAGE_HEIGHT_OUT (480 ),
        .LINE_WIDTH       (1280),
        .ALIGN_ROW_DLY    (0   ),
        .ALIGN_FINE_DLY   (1   ),
        .SEL_DIRECT       (1   )
    ) u_stitche (
        .clk_image1_in      (clk     ),
        .clk_image2_in      (clk     ),
        .clk_image_out      (clk     ),
        .sys_rst_n          (rst_n   ),
        .image1_data_pixel_i(s_left  ),
        .image1_data_valid_i(s_lvld  ),
        .image1_data_vs_i   (s_lvs   ),
        .image2_data_pixel_i(s_right ),
        .image2_data_valid_i(s_rvld  ),
        .image2_data_vs_i   (s_rvs   ),      // ★帧冲刷/换源锁存基准（右路自己的 vs ✓）
        .data_out_ready_i   (d_de    ),
        .sel_swap           (1'b0    ),
        .data_pixel_o       (t_pix   ),
        .data_valid_o       (t_vld   )
    );

//==============================================================================
// 12) 补黑边：1280x480 → 1280x720
//==============================================================================
    black_border
    #(
        .H_ACTIVE (1280     ),
        .V_IN     (480      ),
        .V_OUT    (720      ),
        .BLACK    (16'h0000 )
    ) u_black_border (
        .clk     (clk          ),
        .rst_n   (rst_n        ),
        .i_data  (t_pix        ),
        .i_valid (t_vld        ),
        .i_hs    (d_hs         ),
        .i_vs    (d_frame_start),
        .o_data  (b_data       ),
        .o_de    (b_de         ),
        .o_hs    (b_hs         ),
        .o_vs    (b_vs_unused  ),
        .o_v_cnt (b_vcnt       )
    );

//==============================================================================
// 13) ★m6【OSD 插入点】：black_border 之后、rgb565_to_888 之前
//
//   ① 坐标对齐：black_border 的输出比 d_hcnt/d_vcnt 晚 1 拍
//      ⇒ 这里把 d_hcnt/d_vcnt 也打一拍，喂给 OSD 才与 b_data 同拍 ✓
//      （v_cnt 与内容行号对齐：0~479 = 画面区、480~719 = 黑边区 ✓）
//   ② OSD 内部再打 2 拍流水（字模 ROM 1 拍 + 取位 1 拍），
//      data / de / hs / vs 四路在模块内【同步延迟】⇒ 输出仍严格对齐 ✓
//   ③ 帧率源：左半 ← 灰度/overlay 那条路的 vs（二者同拍，都是 image_overlay_vs）
//              右半 ← 按 key3 换源后的右区源（overlay 或 Canny）
//      ⇒ 屏幕上的两个 FPS 永远跟着"那一半当前显示的画面"走 ✓
//==============================================================================
    always @(posedge clk or negedge rst_n)
        if (!rst_n) d_vs_r <= 1'b0;
        else        d_vs_r <= d_vs;

    reg  [11:0] osd_h;
    reg  [10:0] osd_v;
    always @(posedge clk or negedge rst_n)
        if (!rst_n) begin osd_h <= 12'd0; osd_v <= 11'd0; end
        else        begin osd_h <= d_hcnt; osd_v <= d_vcnt; end

    wire [15:0] osd_data;
    wire        osd_de, osd_hs, osd_vs;

    m6_osd #(
        .CELL   (32         ),
        .CLK_HZ (74_250_000 ),
        .AVG_N  (4          )
    ) u_m6_osd (
        .clk        (clk          ),
        .rst_n      (rst_n        ),
        .i_data     (b_data       ),
        .i_de       (b_de         ),
        .i_hs       (b_hs         ),
        .i_vs       (d_vs_r       ),
        .h_cnt      (osd_h        ),
        .v_cnt      (osd_v        ),
        .key1       (key1         ),      // 高 = 按下 ✓
        .kf0        (kf0          ),
        .key2       (key2         ),      // ★v9：key2（单击换档位 / 长按进选色）
        .disp_mode  (disp_mode_r  ),      // 只用于写字 ★v9：key2_fsm 用它判断"能否进选色"
        .split_mode (split_mode   ),
        .key3       (key3         ),
        .o_canny_thr(canny_thr_from_osd),
        .o_ev_src   (ev_src_from_osd ),
        .o_disp_inc (ev_disp_from_osd),   // ★v9：档位 +1
        .o_color_sel(color_sel_from_osd), // ★v9：叠加颜色
        .median_en  (key_median   ),
        .fps_sensor (i_fps_sensor ),      // ★传感器实时帧率（跨域后）
        .o_data     (osd_data     ),
        .o_de       (osd_de       ),
        .o_hs       (osd_hs       ),
        .o_vs       (osd_vs       ),
        .o_threshold(thr_from_osd ),
        .o_sign     (             ),
        .o_step_idx (             )
    );

    rgb565_to_888 u_rgb565_to_888 (
        .clk    (clk     ),
        .rst_n  (rst_n   ),
        .i_data (osd_data),
        .i_valid(osd_de  ),
        .i_hs   (osd_hs  ),
        .i_vs   (osd_vs  ),
        .o_data (o_rgb   ),
        .o_valid(o_de    ),
        .o_hs   (o_hs    ),
        .o_vs   (o_vs    )
    );

//==============================================================================
// 14) 按键状态在像素域的锁存（照 5 1001 的 mux_sync 用法）
//     注：key3 的锁存由 split_src_mux 内部完成（vs 边界）⇒ 此处不再重复锁 ✗
//==============================================================================
    mux_sync #(.WIDTH(1)) median_en_latch (
        .clk      (clk             ),
        .sys_rst_n(rst_n           ),
        .sel      (key_median      ),
        .vs_in    (image_median_vs ),
        .d0       (1'b0            ),
        .d1       (1'b1            ),
        .valid_in (1'b1            ),
        .q        (median_en_sync  ),
        .q_valid  (                )
    );

    mux_sync #(.WIDTH(4)) disp_mode_latch (
        .clk      (clk             ),
        .sys_rst_n(rst_n           ),
        .sel      (1'b1            ),      // 恒选 d1 = disp_mode_r（= vs 边界打一拍）
        .vs_in    (image_sobel_vs  ),
        .d0       (disp_mode_r     ),
        .d1       (disp_mode_r     ),
        .valid_in (1'b1            ),
        .q        (disp_mode_sync  ),
        .q_valid  (                )
    );

endmodule
