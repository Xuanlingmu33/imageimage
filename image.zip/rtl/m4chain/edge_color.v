module edge_color
#(
  parameter DATA_WIDTH   = 16,     // RGB565
  parameter USE_VS_LATCH = 1'b1    // 1: 换色只在帧边界生效（推荐）
                                   // 0: 无 vs 可用时透传（立刻生效）
)
(
  input                       clk,    
  input                       sys_rst_n,

  input                       data_in,         
  input                       data_in_valid,
  input                       data_in_hs,
  input                       data_in_vs,

  input      [3:0]            color_sel,       
  input      [DATA_WIDTH-1:0] bg_color,        

  output reg [DATA_WIDTH-1:0] data_out,
  output reg                  data_out_valid,
  output reg                  data_out_hs,
  output reg                  data_out_vs
);

reg              vs_dly;
reg       [3:0]  sel_latched;

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    vs_dly      <= 1'b0;
    sel_latched <= 4'd0;          
  end
  else begin
    vs_dly <= data_in_vs;
    if(data_in_vs & ~vs_dly)     
      sel_latched <= color_sel;
  end
end

wire [3:0] pal_idx = USE_VS_LATCH ? sel_latched : color_sel;
reg [DATA_WIDTH-1:0] pal_color;

always @(*) begin
  case(pal_idx)
    4'd0: pal_color = 16'hFFFF;   //白 
    4'd1: pal_color = 16'hF800;   //红 
    4'd2: pal_color = 16'h07E0;   //绿
    4'd3: pal_color = 16'h001F;   //蓝
    4'd4: pal_color = 16'hFFE0;   //黄
    4'd5: pal_color = 16'h07FF;   //青
    4'd6: pal_color = 16'hF81F;   //品红
    4'd7: pal_color = 16'hFC00;   //橙
    default: pal_color = 16'hFFFF;
  endcase
end
always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    data_out      <= {DATA_WIDTH{1'b0}};
    data_out_valid<= 1'b0;
    data_out_hs   <= 1'b0;
    data_out_vs   <= 1'b0;
  end
  else begin
    data_out      <= data_in ? pal_color : bg_color;
    data_out_valid<= data_in_valid;
    data_out_hs   <= data_in_hs;
    data_out_vs   <= data_in_vs;
  end
end

endmodule
