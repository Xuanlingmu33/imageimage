module canny_nms
#(
  parameter MAG_WIDTH = 11          //幅值位宽（0~2040）
)
(
  input                       clk,          //pixel clk（与 canny_grad 同域）
  input                       sys_rst_n,

  input      [MAG_WIDTH-1:0]  mag_in,       //来自 canny_grad
  input      [1:0]            dir_in,       //来自 canny_grad
  input                       data_in_valid,
  input                       data_in_hs,
  input                       data_in_vs,

  output reg [MAG_WIDTH-1:0]  nms_o,
  output reg                  nms_valid_o,
  output reg                  nms_hs_o,
  output reg                  nms_vs_o
);
wire [7:0]  mag_lo_row0, mag_lo_row1;
wire [7:0]  mag_hi_row0, mag_hi_row1;

shift_register_2taps
#(
  .DATA_WIDTH ( 8 )
)u_mag_lo
(
  .clk           (clk              ),
  .shiftin       (mag_in[7:0]      ),
  .shiftin_valid (data_in_valid    ),
  .shiftout      (                 ),
  .taps0x        (mag_lo_row0      ),
  .taps1x        (mag_lo_row1      )
);

shift_register_2taps
#(
  .DATA_WIDTH ( 8 )
)u_mag_hi
(
  .clk           (clk                    ),
  .shiftin       ({5'b0, mag_in[10:8]}   ),
  .shiftin_valid (data_in_valid          ),
  .shiftout      (                       ),
  .taps0x        (mag_hi_row0            ),
  .taps1x        (mag_hi_row1            )
);

wire [MAG_WIDTH-1:0] line0_data = {mag_hi_row0[2:0], mag_lo_row0};  //2 行前
wire [MAG_WIDTH-1:0] line1_data = {mag_hi_row1[2:0], mag_lo_row1};  //1 行前
wire [MAG_WIDTH-1:0] line2_data = mag_in;                           //当前行
wire [7:0] dir_row1;

shift_register_2taps
#(
  .DATA_WIDTH ( 8 )
)u_dir
(
  .clk           (clk              ),
  .shiftin       ({6'b0, dir_in}   ),
  .shiftin_valid (data_in_valid    ),
  .shiftout      (                 ),
  .taps0x        (                 ),
  .taps1x        (dir_row1         )
);
reg  [MAG_WIDTH-1:0] a1,a2,a3;   //上行：左 中 右
reg  [MAG_WIDTH-1:0] b1,b2,b3;   //中行（b2 = 窗口中心）
reg  [MAG_WIDTH-1:0] c1,c2,c3;   //下行

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    a1<=0; a2<=0; a3<=0;
    b1<=0; b2<=0; b3<=0;
    c1<=0; c2<=0; c3<=0;
  end
  else if(data_in_hs && data_in_vs)
    if(data_in_valid) begin
      a3 <= line0_data;  a2 <= a3;  a1 <= a2;
      b3 <= line1_data;  b2 <= b3;  b1 <= b2;
      c3 <= line2_data;  c2 <= c3;  c1 <= c2;
    end
    else begin
      a1<=a1; a2<=a2; a3<=a3;
      b1<=b1; b2<=b2; b3<=b3;
      c1<=c1; c2<=c2; c3<=c3;
    end
  else begin
    a1<=0; a2<=0; a3<=0;
    b1<=0; b2<=0; b3<=0;
    c1<=0; c2<=0; c3<=0;
  end
end
reg [1:0] dir_c1;
reg [1:0] dir_c;

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    dir_c1 <= 2'd0;
    dir_c  <= 2'd0;
  end
  else if(data_in_hs && data_in_vs) begin
    if(data_in_valid) begin
      dir_c1 <= dir_row1[1:0];
      dir_c  <= dir_c1;
    end
  end
  else begin
    dir_c1 <= 2'd0;
    dir_c  <= 2'd0;
  end
end
reg vld1, vld2;
reg hs1,  hs2;
reg vs1,  vs2;

always @(posedge clk) begin
  vld1 <= data_in_valid;   vld2 <= vld1;
  hs1  <= data_in_hs;      hs2  <= hs1;
  vs1  <= data_in_vs;      vs2  <= vs1;
end
wire [MAG_WIDTH-1:0] n1 = (dir_c == 2'd0) ? b1 :
                          (dir_c == 2'd1) ? a2 :
                          (dir_c == 2'd2) ? a1 : a3;

wire [MAG_WIDTH-1:0] n2 = (dir_c == 2'd0) ? b3 :
                          (dir_c == 2'd1) ? c2 :
                          (dir_c == 2'd2) ? c3 : c1;

wire [MAG_WIDTH-1:0] nms_c = ((b2 > n1) && (b2 >= n2)) ? b2 : {MAG_WIDTH{1'b0}};
reg [MAG_WIDTH-1:0] nms_b;

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n)
    nms_b <= {MAG_WIDTH{1'b0}};
  else if(vld1)
    nms_b <= nms_c;
end
always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n)
    nms_o <= {MAG_WIDTH{1'b0}};
  else if(vld2)
    nms_o <= nms_b;
end

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    nms_valid_o <= 1'b0;
    nms_hs_o    <= 1'b0;
    nms_vs_o    <= 1'b0;
  end
  else begin
    nms_valid_o <= vld2;
    nms_hs_o    <= hs2;
    nms_vs_o    <= vs2;
  end
end

endmodule
