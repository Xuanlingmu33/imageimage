module align_row_delay
#(
  parameter DATA_WIDTH = 16,     // RGB565
  parameter ROW_DLY    = 4,      // 行延迟，必须是偶数（每级 2 行）
  parameter FINE_DLY   = 8       // 细调拍数（≥1）
)
(
  input                     clk,
  input                     sys_rst_n,

  input      [DATA_WIDTH-1:0] data_in,
  input                     valid_in,      // 与 data_in 同拍的有效标志

  output     [DATA_WIDTH-1:0] data_out,
  output                    valid_out
);

  localparam STAGES = ROW_DLY / 2;              // 每级 shift_register_2taps = 2 行

  genvar gi;
  integer ai;
  wire [7:0] a_hi [0:STAGES];
  wire [7:0] a_lo [0:STAGES];

  assign a_hi[0] = data_in[15:8];
  assign a_lo[0] = data_in[ 7:0];

  generate
    for (gi = 0; gi < STAGES; gi = gi + 1) begin : g_row
      shift_register_2taps
      #(
        .DATA_WIDTH (8)
      ) u_hi
      (
        .clk           (clk       ),
        .shiftin       (a_hi[gi]  ),
        .shiftin_valid (valid_in  ),
        .shiftout      (          ),
        .taps1x        (          ),
        .taps0x        (a_hi[gi+1])
      );

      shift_register_2taps
      #(
        .DATA_WIDTH (8)
      ) u_lo
      (
        .clk           (clk       ),
        .shiftin       (a_lo[gi]  ),
        .shiftin_valid (valid_in  ),
        .shiftout      (          ),
        .taps1x        (          ),
        .taps0x        (a_lo[gi+1])
      );
    end
  endgenerate

  wire [DATA_WIDTH-1:0] row_out = {a_hi[STAGES], a_lo[STAGES]};
  reg [DATA_WIDTH-1:0] fine_d [0:FINE_DLY-1];
  reg [FINE_DLY-1:0]   fine_v;

  always @(posedge clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
      fine_v <= {FINE_DLY{1'b0}};
      for(ai = 0; ai < FINE_DLY; ai = ai + 1)
        fine_d[ai] <= {DATA_WIDTH{1'b0}};
    end
    else begin
      if(valid_in)
        fine_d[0] <= row_out;
      fine_v[0] <= valid_in;

      for(ai = 1; ai < FINE_DLY; ai = ai + 1) begin
        if(fine_v[ai-1])
          fine_d[ai] <= fine_d[ai-1];
        fine_v[ai] <= fine_v[ai-1];
      end
    end
  end

  assign data_out  = fine_d[FINE_DLY-1];
  assign valid_out = fine_v[FINE_DLY-1];

endmodule
