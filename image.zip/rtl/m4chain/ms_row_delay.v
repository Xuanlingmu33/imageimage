module ms_row_delay
#(
  parameter DATA_WIDTH = 8,
  parameter LINE_WIDTH = 640
)
(
  input                       clk,
  input      [DATA_WIDTH-1:0] din,
  input                       din_valid,

  output reg [DATA_WIDTH-1:0] dout
);

  localparam AW = $clog2(LINE_WIDTH);

  reg [DATA_WIDTH-1:0] mem [0:LINE_WIDTH-1];
  reg [AW-1:0]         wptr;     
  wire [AW-1:0] rptr = (wptr == LINE_WIDTH[AW-1:0] - 1'b1) ? {AW{1'b0}}
                                                           : (wptr + 1'b1);

  integer mi;
  initial begin
    wptr = {AW{1'b0}};
    for(mi = 0; mi < LINE_WIDTH; mi = mi + 1)
      mem[mi] = {DATA_WIDTH{1'b0}};
    dout = {DATA_WIDTH{1'b0}};
  end

  always @(posedge clk) begin
    if(din_valid) begin
      mem[wptr] <= din;        
      dout      <= mem[rptr]; 
      wptr      <= rptr;
    end
  end

endmodule
module morph_cross_stage #(
    parameter integer DATA_WIDTH = 1,
    parameter integer MODE       = 3,    
    parameter integer KERNEL     = 1,    
    parameter integer NB_K       = 5     
)(
    input  wire                  clk,
    input  wire                  sys_rst_n,

    input  wire [DATA_WIDTH-1:0] data_in,
    input  wire                  valid_in,
    input  wire                  hs_in,
    input  wire                  vs_in,

    output reg  [DATA_WIDTH-1:0] data_out,
    output reg                   valid_out,
    output reg                   hs_out,
    output reg                   vs_out
);

    wire [DATA_WIDTH-1:0] l_up, l_mid;
    wire [DATA_WIDTH-1:0] l_dn;

    shift_register_2taps #(.DATA_WIDTH(DATA_WIDTH)) u_line_buf (
        .clk           (clk        ),
        .shiftin       (data_in    ),
        .shiftin_valid (valid_in   ),
        .shiftout      (           ),
        .taps1x        (l_mid      ),
        .taps0x        (l_up       )
    );
    assign l_dn = data_in;

    reg [DATA_WIDTH-1:0] r0c0, r0c1, r0c2;
    reg [DATA_WIDTH-1:0] r1c0, r1c1, r1c2;
    reg [DATA_WIDTH-1:0] r2c0, r2c1, r2c2;

    always @(posedge clk or negedge sys_rst_n) begin
        if(!sys_rst_n) begin
            r0c0 <= {DATA_WIDTH{1'b0}}; r0c1 <= {DATA_WIDTH{1'b0}}; r0c2 <= {DATA_WIDTH{1'b0}};
            r1c0 <= {DATA_WIDTH{1'b0}}; r1c1 <= {DATA_WIDTH{1'b0}}; r1c2 <= {DATA_WIDTH{1'b0}};
            r2c0 <= {DATA_WIDTH{1'b0}}; r2c1 <= {DATA_WIDTH{1'b0}}; r2c2 <= {DATA_WIDTH{1'b0}};
        end
        else if(valid_in) begin
            r0c2 <= l_up;  r0c1 <= r0c2;  r0c0 <= r0c1;
            r1c2 <= l_mid; r1c1 <= r1c2;  r1c0 <= r1c1;
            r2c2 <= l_dn;  r2c1 <= r2c2;  r2c0 <= r2c1;
        end
    end

    wire [DATA_WIDTH-1:0] diag_or  = (KERNEL != 0) ? (r0c0 | r0c2 | r2c0 | r2c2) : {DATA_WIDTH{1'b0}};
    wire [DATA_WIDTH-1:0] diag_and = (KERNEL != 0) ? (r0c0 & r0c2 & r2c0 & r2c2) : {DATA_WIDTH{1'b1}};

    wire [DATA_WIDTH-1:0] or_all  = r1c1 | r0c1 | r2c1 | r1c0 | r1c2 | diag_or;
    wire [DATA_WIDTH-1:0] and_all = r1c1 & r0c1 & r2c1 & r1c0 & r1c2 & diag_and;

    wire [3:0] nb_cnt4 = {3'd0, r0c1} + {3'd0, r2c1} + {3'd0, r1c0} + {3'd0, r1c2};
    wire [3:0] nb_cnt8 = nb_cnt4 + {3'd0, r0c0} + {3'd0, r0c2} + {3'd0, r2c0} + {3'd0, r2c2};

    wire soft_ok = (KERNEL != 0) ? (nb_cnt8 >= NB_K) : (nb_cnt4 >= NB_K);

    wire [DATA_WIDTH-1:0] res =
        (MODE == 0) ? or_all                    :            // 膨胀
        (MODE == 1) ? and_all                   :            // 硬腐蚀
        (MODE == 3) ? (r1c1 & {DATA_WIDTH{soft_ok}}) :       // 软腐蚀（中心是 1 且邻居够多）
                      r1c1;                                  // 直通（抽中心，延迟不变）

    reg v1, v2, h1, h2, s1, s2;

    always @(posedge clk or negedge sys_rst_n) begin
        if(!sys_rst_n) begin
            data_out  <= {DATA_WIDTH{1'b0}};
            valid_out <= 1'b0; hs_out <= 1'b0; vs_out <= 1'b0;
            v1 <= 1'b0; v2 <= 1'b0;
            h1 <= 1'b0; h2 <= 1'b0;
            s1 <= 1'b0; s2 <= 1'b0;
        end
        else begin
            v1 <= valid_in; v2 <= v1;
            h1 <= hs_in;    h2 <= h1;
            s1 <= vs_in;    s2 <= s1;

            data_out  <= res;
            valid_out <= v2;
            hs_out    <= h2;
            vs_out    <= s2;
        end
    end

endmodule

module morph_close #(
    parameter integer LINE_WIDTH = 640,
    parameter integer STRENGTH_W = 8,
    parameter integer M1         = 3,     // 第一级模式：0膨胀 1硬腐蚀 2直通 3软腐蚀
    parameter integer M2         = 2,     // 第二级模式
    parameter integer KERNEL     = 1,     // 0=十字 1=方形
    parameter integer NB_K       = 5      // 软腐蚀门限
)(
    input  wire                  clk,
    input  wire                  sys_rst_n,

    input  wire                  bin_in,
    input  wire                  valid_in,
    input  wire                  hs_in,
    input  wire                  vs_in,
    input  wire [STRENGTH_W-1:0] str_in,

    output wire                  bin_out,
    output wire                  valid_out,
    output wire                  hs_out,
    output wire                  vs_out,
    output wire [STRENGTH_W-1:0] str_out
);

    wire d1_bin;
    wire d1_v, d1_h, d1_s;
    wire [STRENGTH_W-1:0] d1_str;

    morph_cross_stage #(.DATA_WIDTH(1), .MODE(M1), .KERNEL(KERNEL), .NB_K(NB_K)) u_s1 (
        .clk(clk), .sys_rst_n(sys_rst_n),
        .data_in(bin_in), .valid_in(valid_in), .hs_in(hs_in), .vs_in(vs_in),
        .data_out(d1_bin), .valid_out(d1_v), .hs_out(d1_h), .vs_out(d1_s)
    );

    morph_cross_stage #(.DATA_WIDTH(STRENGTH_W), .MODE(2)) u_s1_str (
        .clk(clk), .sys_rst_n(sys_rst_n),
        .data_in(str_in), .valid_in(valid_in), .hs_in(hs_in), .vs_in(vs_in),
        .data_out(d1_str), .valid_out(), .hs_out(), .vs_out()
    );

    morph_cross_stage #(.DATA_WIDTH(1), .MODE(M2), .KERNEL(KERNEL), .NB_K(NB_K)) u_s2 (
        .clk(clk), .sys_rst_n(sys_rst_n),
        .data_in(d1_bin), .valid_in(d1_v), .hs_in(d1_h), .vs_in(d1_s),
        .data_out(bin_out), .valid_out(valid_out), .hs_out(hs_out), .vs_out(vs_out)
    );

    morph_cross_stage #(.DATA_WIDTH(STRENGTH_W), .MODE(2)) u_s2_str (
        .clk(clk), .sys_rst_n(sys_rst_n),
        .data_in(d1_str), .valid_in(d1_v), .hs_in(d1_h), .vs_in(d1_s),
        .data_out(str_out), .valid_out(), .hs_out(), .vs_out()
    );

endmodule

