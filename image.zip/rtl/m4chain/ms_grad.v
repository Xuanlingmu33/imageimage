module ms_grad
#(
  parameter DATA_WIDTH     = 8,
  parameter LINE_WIDTH     = 640,
  parameter integer GRAD_OP       = 0,  
  parameter BORDER_MASK    = 1'b1,      
  parameter STRENGTH_SHIFT = 1,         
  parameter integer MS_EN  = 1,         
  parameter integer MS_GAIN = 0         
)//多尺度对比
(
  input                       clk,
  input                       sys_rst_n,

  input      [DATA_WIDTH-1:0] data_in,
  input                       data_in_valid,
  input                       data_in_hs,
  input                       data_in_vs,
  input      [10:0]           threshold,

  output wire                 data_out,        
  output wire                 data_out_valid,
  output wire                 data_out_hs,
  output wire                 data_out_vs,
  output wire [7:0]           strength_o,     
  output wire [10:0]          mag_o           
);

wire [10:0]          mag_fine    ;     
wire                 fine_vld    ;     
wire                 fine_hs     ;
wire                 fine_vs     ;

wire [DATA_WIDTH-1:0] row1_y     ;     
wire [DATA_WIDTH-1:0] cur_x1     ;     
wire [DATA_WIDTH-1:0] row1_x1    ;     
reg  [DATA_WIDTH-1:0] cur_x1_r   ;     
reg  [DATA_WIDTH-1:0] row1_x1_r  ;     
wire [DATA_WIDTH+1:0] ms_sum     ;     
wire [DATA_WIDTH-1:0] ms_mean    ;     
wire [10:0]           mag_coarse ;     
wire                 coarse_vld  ;
wire                 coarse_hs   ;
wire                 coarse_vs   ;

wire [11:0]           mag_c_gain ;    
wire [11:0]           mag_merge  ;    
wire [11:0]           str_full   ;    
wire [10:0]           mag_sat    ;    

assign cur_x1  = cur_x1_r;
assign row1_x1 = row1_x1_r;

sobel
#(
  .DATA_WIDTH     (DATA_WIDTH    ),
  .LINE_WIDTH     (LINE_WIDTH    ),
  .GRAD_OP        (GRAD_OP       ),
  .BORDER_MASK    (BORDER_MASK   ),
  .STRENGTH_SHIFT (STRENGTH_SHIFT)
)
u_sobel_fine
(
  .clk           (clk           ),
  .sys_rst_n     (sys_rst_n     ),
  .data_in       (data_in       ),
  .data_in_valid (data_in_valid ),
  .data_in_hs    (data_in_hs    ),
  .data_in_vs    (data_in_vs    ),
  .threshold     (threshold     ),

  .data_out      (              ),  
  .data_out_valid(fine_vld      ),
  .data_out_hs   (fine_hs       ),
  .data_out_vs   (fine_vs       ),
  .strength_o    (              ),
  .mag_o         (mag_fine      )
);

generate
  if(MS_EN != 0) begin : g_ms
    ms_row_delay
    #(
      .DATA_WIDTH (DATA_WIDTH),
      .LINE_WIDTH (LINE_WIDTH)
    )
    u_row1
    (
      .clk       (clk        ),
      .din       (data_in    ),
      .din_valid (data_in_valid),
      .dout      (row1_y     )
    );

    always @(posedge clk or negedge sys_rst_n) begin
      if(!sys_rst_n) begin
        cur_x1_r  <= {DATA_WIDTH{1'b0}};
        row1_x1_r <= {DATA_WIDTH{1'b0}};
      end
      else if(data_in_valid) begin
        cur_x1_r  <= data_in;
        row1_x1_r <= row1_y;
      end
    end

    assign ms_sum  = {2'b00, data_in } + {2'b00, cur_x1  }
                   + {2'b00, row1_y  } + {2'b00, row1_x1 };
    assign ms_mean = ms_sum[DATA_WIDTH+1:2];

    sobel
    #(
      .DATA_WIDTH     (DATA_WIDTH    ),
      .LINE_WIDTH     (LINE_WIDTH    ),
      .GRAD_OP        (GRAD_OP       ),
      .BORDER_MASK    (BORDER_MASK   ),
      .STRENGTH_SHIFT (STRENGTH_SHIFT),
      .BORDER_ROWS    (3             ),
      .BORDER_COLS    (3             )
    )
    u_sobel_coarse
    (
      .clk           (clk           ),
      .sys_rst_n     (sys_rst_n     ),
      .data_in       (ms_mean       ),
      .data_in_valid (data_in_valid ),
      .data_in_hs    (data_in_hs    ),
      .data_in_vs    (data_in_vs    ),
      .threshold     (threshold     ),

      .data_out      (              ),
      .data_out_valid(coarse_vld    ),
      .data_out_hs   (coarse_hs     ),
      .data_out_vs   (coarse_vs     ),
      .strength_o    (              ),
      .mag_o         (mag_coarse    )
    );

    assign mag_c_gain = (MS_GAIN != 0) ? {mag_coarse, 1'b0} : {1'b0, mag_coarse};
    assign mag_merge  = (mag_c_gain > {1'b0, mag_fine}) ? mag_c_gain
                                                        : {1'b0, mag_fine};
  end
  else begin : g_no_ms
    assign mag_c_gain = 12'd0;
    assign mag_merge  = {1'b0, mag_fine};
    assign coarse_vld = fine_vld;
    assign coarse_hs  = fine_hs;
    assign coarse_vs  = fine_vs;
  end
endgenerate

assign data_out       = (mag_merge > {1'b0, threshold});

assign str_full       = mag_merge >> STRENGTH_SHIFT;
assign strength_o     = (str_full > 12'd255) ? 8'hFF : str_full[7:0];

assign mag_sat        = mag_merge[11] ? 11'h7FF : mag_merge[10:0];
assign mag_o          = mag_sat;

assign data_out_valid = coarse_vld;
assign data_out_hs    = coarse_hs;
assign data_out_vs    = coarse_vs;

endmodule
