module delay_align
#(
  parameter DATA_WIDTH = 16,     //RGB565
  parameter HALF_ROW   = 1'b0,  
                                 //用途：sobel 前面插入 gaussian 后，边缘链
                                 //多出 643 拍（高斯有效延迟 = 1 行 + 3 拍），
                                 //RGB 必须补上；ROW 的粒度是 2 行（1281 拍）
                                 //补不了，FINE 要 643 级又太贵 → 用这一级
  parameter ROW_DLY_A  = 2,      //A抽头（中值旁路用），必须是偶数
  parameter FINE_DLY_A = 5,      //A抽头细调拍数（≥1）
  parameter ROW_DLY_B  = 4,      //B抽头（中值生效用），必须是偶数
  parameter FINE_DLY_B = 8       //B抽头细调拍数（≥1）
)
(
  input                       clk,
  input                       sys_rst_n,

  input      [DATA_WIDTH-1:0] data_in,
  input                       valid_in,   

  input                       sel,        
                                          
                                          
                                          

  output     [DATA_WIDTH-1:0] data_out,
  output                      valid_out
);

  localparam STAGES = ROW_DLY_B / 2;             // 总级数
  localparam SELA   = ROW_DLY_A / 2;             // A 抽头
  localparam HAS_HI = (DATA_WIDTH > 8) ? 1 : 0;
  function [7:0] hi_byte;
    input [DATA_WIDTH-1:0] d;
    begin
      if(DATA_WIDTH > 8)
        hi_byte = d[DATA_WIDTH-1:8];
      else
        hi_byte = 8'h00;
    end
  endfunction

  genvar  gi;
  integer ai;
  wire [7:0] pre_hi;
  wire [7:0] pre_lo;

  generate
    if (HALF_ROW) begin : g_half_row
      shift_register_2taps
      #(
        .DATA_WIDTH (8)
      ) u_pre_hi
      (
        .clk           (clk             ),
        .shiftin       (hi_byte(data_in)),
        .shiftin_valid (valid_in        ),
        .shiftout      (                ),
        .taps1x        (pre_hi          ),
        .taps0x        (                )
      );

      shift_register_2taps
      #(
        .DATA_WIDTH (8)
      ) u_pre_lo
      (
        .clk           (clk             ),
        .shiftin       (data_in[7:0]    ),
        .shiftin_valid (valid_in        ),
        .shiftout      (                ),
        .taps1x        (pre_lo          ),
        .taps0x        (                )
      );
    end
    else begin : g_no_half_row
      assign pre_hi = hi_byte(data_in);
      assign pre_lo = data_in[7:0];
    end
  endgenerate
  wire [7:0] a_hi [0:STAGES];
  wire [7:0] a_lo [0:STAGES];

  assign a_hi[0] = pre_hi; 
  assign a_lo[0] = pre_lo;

  generate
    for (gi = 0; gi < STAGES; gi = gi + 1) begin : g_row
      shift_register_2taps
      #(
        .DATA_WIDTH (8)
      ) u_hi
      (
        .clk           (clk        ),
        .shiftin       (a_hi[gi]   ),
        .shiftin_valid (valid_in   ),
        .shiftout      (           ),
        .taps1x        (           ),
        .taps0x        (a_hi[gi+1] )
      );

      shift_register_2taps
      #(
        .DATA_WIDTH (8)
      ) u_lo
      (
        .clk           (clk        ),
        .shiftin       (a_lo[gi]   ),
        .shiftin_valid (valid_in   ),
        .shiftout      (           ),
        .taps1x        (           ),
        .taps0x        (a_lo[gi+1] )
      );
    end
  endgenerate
  wire [DATA_WIDTH-1:0] row_a = HAS_HI ? {a_hi[SELA],   a_lo[SELA]  } : a_lo[SELA];   // 短抽头
  wire [DATA_WIDTH-1:0] row_b = HAS_HI ? {a_hi[STAGES], a_lo[STAGES]} : a_lo[STAGES]; // 长抽头
  localparam AFD = (FINE_DLY_A < 1) ? 1 : FINE_DLY_A;
  localparam BFD = (FINE_DLY_B < 1) ? 1 : FINE_DLY_B;

  reg [DATA_WIDTH-1:0] fine_a [0:AFD-1];
  reg [AFD-1:0]        fine_a_v;
  reg [DATA_WIDTH-1:0] fine_b [0:BFD-1];
  reg [BFD-1:0]        fine_b_v;

  always @(posedge clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
      fine_a_v <= {AFD{1'b0}};
      fine_b_v <= {BFD{1'b0}};
      for(ai = 0; ai < AFD; ai = ai + 1)
        fine_a[ai] <= {DATA_WIDTH{1'b0}};
      for(ai = 0; ai < BFD; ai = ai + 1)
        fine_b[ai] <= {DATA_WIDTH{1'b0}};
    end
    else begin
      if(valid_in)
        fine_a[0] <= row_a;
      fine_a_v[0] <= valid_in;
      for(ai = 1; ai < AFD; ai = ai + 1) begin
        if(fine_a_v[ai-1])
          fine_a[ai] <= fine_a[ai-1];
        fine_a_v[ai] <= fine_a_v[ai-1];
      end

      if(valid_in)
        fine_b[0] <= row_a;  
      fine_b_v[0] <= valid_in;
      for(ai = 1; ai < BFD; ai = ai + 1) begin
        if(fine_b_v[ai-1])
          fine_b[ai] <= fine_b[ai-1];
        fine_b_v[ai] <= fine_b_v[ai-1];
      end
    end
  end
  assign data_out  = sel ? fine_b[BFD-1] : fine_a[AFD-1];
  assign valid_out = sel ? fine_b_v[BFD-1] : fine_a_v[AFD-1];

endmodule
