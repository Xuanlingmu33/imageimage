module edge_ctrl
#(
  parameter STATE_NUM = 9,        // 0=关, 1=白, 2..8=七种彩色
  parameter FORCE_ON    = 1'b0,
  parameter FORCE_COLOR = 4'd0    // 0=白 1=红 2=绿 3=蓝 4=黄 5=青 6=品红 7=橙
)
(
  input             clk,          // 按键域时钟（顶层 = sys_clk 50MHz）
  input             sys_rst_n,
  input             key_flag,     // 消抖后的单拍脉冲（来自 key_filter）

  output            ovl_en,       // 1 = 打开叠加
  output wire [3:0] color_sel     // 调色板索引，见 edge_palette.v
);

  reg [3:0] state;

  localparam [3:0] STATE_MAX = STATE_NUM - 1;

  always @(posedge clk or negedge sys_rst_n) begin
    if(!sys_rst_n)
      state <= 4'd0;                                  // 上电 = 纯原图
    else if(key_flag)
      state <= (state >= STATE_MAX) ? 4'd0 : state + 1'b1;
  end

  assign ovl_en    = FORCE_ON ? 1'b1 : (state != 4'd0);
  assign color_sel = FORCE_ON ? FORCE_COLOR : (state - 4'd1);   // state=1 → 0 → 白色

endmodule
