module canny_grad
#(
  parameter DATA_WIDTH = 8          //输入灰度位宽
)
(
  input                       clk,          //pixel clk（与上一级同域）
  input                       sys_rst_n,

  input      [DATA_WIDTH-1:0] data_in,      //高斯平滑后的灰度
  input                       data_in_valid,
  input                       data_in_hs,
  input                       data_in_vs,

  output reg [10:0]           mag_o,        //|gx|+|gy|，0~2040
  output reg [1:0]            dir_o,        //0/1/2/3，见文件头编码表
  output reg                  mag_valid_o,
  output reg                  mag_hs_o,
  output reg                  mag_vs_o
);
wire [DATA_WIDTH-1:0] line0_data;   //2 行前（窗口上行）
wire [DATA_WIDTH-1:0] line1_data;   //1 行前（窗口中行）
wire [DATA_WIDTH-1:0] line2_data;   //当前行（窗口下行）

shift_register_2taps
#(
  .DATA_WIDTH ( DATA_WIDTH )
)u_shift_2taps
(
  .clk           (clk           ),
  .shiftin       (data_in       ),
  .shiftin_valid (data_in_valid ),

  .shiftout      (              ),
  .taps0x        (line0_data    ),
  .taps1x        (line1_data    )
);

assign line2_data = data_in;
reg  [DATA_WIDTH-1:0] a1,a2,a3;   //上行
reg  [DATA_WIDTH-1:0] b1,b2,b3;   //中行
reg  [DATA_WIDTH-1:0] c1,c2,c3;   //下行

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    a1<=0; a2<=0; a3<=0;
    b1<=0; b2<=0; b3<=0;
    c1<=0; c2<=0; c3<=0;
  end
  else if(data_in_hs && data_in_vs)
    if(data_in_valid) begin
      a3 <= line0_data;  a2 <= a3;  a1 <= a2;
      b3 <= line1_data;  b2 <= b3;  b1 <= b2;
      c3 <= line2_data;  c2 <= c3;  c1 <= c2;
    end
    else begin
      a1<=a1; a2<=a2; a3<=a3;
      b1<=b1; b2<=b2; b3<=b3;
      c1<=c1; c2<=c2; c3<=c3;
    end
  else begin
    a1<=0; a2<=0; a3<=0;
    b1<=0; b2<=0; b3<=0;
    c1<=0; c2<=0; c3<=0;
  end
end

reg vld1, vld2;
reg hs1,  hs2;
reg vs1,  vs2;

always @(posedge clk) begin
  vld1 <= data_in_valid;   vld2 <= vld1;
  hs1  <= data_in_hs;      hs2  <= hs1;
  vs1  <= data_in_vs;      vs2  <= vs1;
end

wire [9:0] gx_right = a3 + {b3,1'b0} + c3;
wire [9:0] gx_left  = a1 + {b1,1'b0} + c1;
wire [9:0] gy_down  = c1 + {c2,1'b0} + c3;
wire [9:0] gy_up    = a1 + {a2,1'b0} + a3;

wire       gx_pos   = (gx_right >= gx_left);      //gx > 0
wire       gy_pos   = (gy_down  >= gy_up  );      //gy > 0

wire [9:0] gx_abs   = gx_pos ? (gx_right - gx_left) : (gx_left  - gx_right);
wire [9:0] gy_abs   = gy_pos ? (gy_down  - gy_up  ) : (gy_up    - gy_down );

wire [10:0] mag     = gx_abs + gy_abs;

wire        dir_h   = (gx_abs > {gy_abs,1'b0});   //|gx| > 2|gy|
wire        dir_v   = (gy_abs > {gx_abs,1'b0});   //|gy| > 2|gx|
wire        same_sg = (gx_pos == gy_pos);

wire [1:0]  dir     = dir_h    ? 2'd0 :
                      dir_v    ? 2'd1 :
                      same_sg  ? 2'd2 : 2'd3;

reg [10:0] mag_b;
reg [1:0]  dir_b;

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    mag_b <= 11'd0;
    dir_b <= 2'd0;
  end
  else if(vld1) begin
    mag_b <= mag;
    dir_b <= dir;
  end
end

reg [11:0] o_ccnt;      // 行内像素序号（输出域）
reg [11:0] o_vcnt;      // 自帧首以来的有效像素数（输出域）

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    o_ccnt <= 12'd0;
    o_vcnt <= 12'd0;
  end
  else begin
    if(hs2 == 1'b0)                       // 行末那拍 → 下一拍是新行第 0 列
      o_ccnt <= 12'd0;
    else if(vld2)
      o_ccnt <= (o_ccnt >= 12'd639) ? 12'd0 : o_ccnt + 1'b1;

    if(vs2 == 1'b0)                       // 帧末那拍 → 下一拍是新帧第 0 行
      o_vcnt <= 12'd0;
    else if(vld2 && (o_vcnt < 12'd1280))
      o_vcnt <= o_vcnt + 1'b1;
  end
end

wire border = (o_vcnt < 12'd1280) || (o_ccnt < 12'd2) || (o_ccnt >= 12'd638);

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    mag_o <= 11'd0;
    dir_o <= 2'd0;
  end
  else if(vld2) begin
    mag_o <= border ? 11'd0 : mag_b;      // [改] 边界区幅值置 0（不出假边）
    dir_o <= dir_b;
  end
end

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    mag_valid_o <= 1'b0;
    mag_hs_o    <= 1'b0;
    mag_vs_o    <= 1'b0;
  end
  else begin
    mag_valid_o <= vld2;
    mag_hs_o    <= hs2;
    mag_vs_o    <= vs2;
  end
end

endmodule
