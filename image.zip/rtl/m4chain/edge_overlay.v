module edge_overlay
#(
  parameter DATA_WIDTH   = 16,        // RGB565
  parameter BLEND_MODE   = "REPLACE", // REPLACE / ADD / MIX
  parameter USE_VS_LATCH = 1'b1       // 使能/换色只在帧边界生效（推荐）
)
(
  input                       clk,            // 必须与算法链同一个像素时钟
  input                       sys_rst_n,

  input                       edge_in,        // 1 = 边缘（sobel / Canny 的二值输出）
  input                       edge_in_valid,
  input                       edge_in_hs,
  input                       edge_in_vs,

  input      [DATA_WIDTH-1:0] img_in,         //已对齐到同拍的原始彩色像素
  input      [DATA_WIDTH-1:0] edge_color,     //来自 palette_lut.v
  input      [3:0]            disp_mode,      //显示模式（4bit，0~8）
                                              //0=二值 1=反向 2=强度灰度 3=热力图像
                                              //4=雷达模式 5=卡通滤镜
                                              //6=原图+彩色边 7=原图+多色边 8=原图+彩虹边
  input      [7:0]            edge_str,       //边缘强度 0~255（mode2 灰度 / mode3 热力用）

  output reg [DATA_WIDTH-1:0] data_out,
  output reg                  data_out_valid,
  output reg                  data_out_hs,
  output reg                  data_out_vs
);
  reg       vs_dly;
  reg [3:0] mode_latched;
  reg [DATA_WIDTH-1:0] col_latched;

  always @(posedge clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
      vs_dly       <= 1'b0;
      mode_latched <= 4'd0;                    // 上电默认：二值边缘图
      col_latched  <= 16'hFFFF;
    end
    else begin
      vs_dly <= edge_in_vs;
      if(edge_in_vs & ~vs_dly) begin           // vs 上升沿 = 一帧的开始
        mode_latched <= disp_mode;
        col_latched  <= edge_color;
      end
    end
  end

  wire [3:0]            mode_use = USE_VS_LATCH ? mode_latched : disp_mode;
  wire [DATA_WIDTH-1:0] col_use  = USE_VS_LATCH ? col_latched  : edge_color;
  localparam [DATA_WIDTH-1:0] C_Q_RED    = 16'hF800;   // RGB565 纯红
  localparam [DATA_WIDTH-1:0] C_Q_GREEN  = 16'h07E0;   // RGB565 纯绿
  localparam [DATA_WIDTH-1:0] C_Q_BLUE   = 16'h001F;   // RGB565 纯蓝
  localparam [DATA_WIDTH-1:0] C_Q_YELLOW = 16'hFFE0;   // RGB565 纯黄

  reg [9:0] qx, qy;
  reg       q_vs_d;
  reg [15:0] frame_cnt;              // 帧计数mode5 彩虹流动用

  always @(posedge clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
      qx        <= 10'd0;
      qy        <= 10'd0;
      q_vs_d    <= 1'b0;
      frame_cnt <= 16'd0;
    end
    else begin
      q_vs_d <= edge_in_vs;
      if(edge_in_vs & ~q_vs_d) begin
        qy        <= 10'd0;
        frame_cnt <= frame_cnt + 16'd1;
      end
      else if(edge_in_valid && (qx == 10'd639))
        qy <= qy + 10'd1;

      if(!edge_in_valid)
        qx <= 10'd0;
      else if(qx != 10'd639)
        qx <= qx + 10'd1;
    end
  end

  wire [DATA_WIDTH-1:0] quad_col =
      (qy < 10'd240) ? ((qx < 10'd320) ? C_Q_RED   : C_Q_GREEN) :
                       ((qx < 10'd320) ? C_Q_BLUE  : C_Q_YELLOW);
  wire [9:0] scan_y  = {1'b0, frame_cnt[5:0], 3'b000}; 
  wire       scan_ln = (qy >= scan_y) && (qy < scan_y + 10'd2);
  wire       in_band = (qy >= scan_y) && (qy < scan_y + 10'd32);

  function [DATA_WIDTH-1:0] rainbow_color;
    input [4:0] idx;
    begin
      case (idx)
        5'd 0: rainbow_color = 16'hF800;
        5'd 1: rainbow_color = 16'hF980;
        5'd 2: rainbow_color = 16'hFB00;
        5'd 3: rainbow_color = 16'hFC60;
        5'd 4: rainbow_color = 16'hFDE0;
        5'd 5: rainbow_color = 16'hFF60;
        5'd 6: rainbow_color = 16'hDFE0;
        5'd 7: rainbow_color = 16'hAFE0;
        5'd 8: rainbow_color = 16'h87E0;
        5'd 9: rainbow_color = 16'h57E0;
        5'd10: rainbow_color = 16'h27E0;
        5'd11: rainbow_color = 16'h07E2;
        5'd12: rainbow_color = 16'h07E8;
        5'd13: rainbow_color = 16'h07EE;
        5'd14: rainbow_color = 16'h07F3;
        5'd15: rainbow_color = 16'h07F9;
        5'd16: rainbow_color = 16'h07FF;
        5'd17: rainbow_color = 16'h067F;
        5'd18: rainbow_color = 16'h04FF;
        5'd19: rainbow_color = 16'h039F;
        5'd20: rainbow_color = 16'h021F;
        5'd21: rainbow_color = 16'h009F;
        5'd22: rainbow_color = 16'h201F;
        5'd23: rainbow_color = 16'h501F;
        5'd24: rainbow_color = 16'h801F;
        5'd25: rainbow_color = 16'hA81F;
        5'd26: rainbow_color = 16'hD81F;
        5'd27: rainbow_color = 16'hF81D;
        5'd28: rainbow_color = 16'hF817;
        5'd29: rainbow_color = 16'hF811;
        5'd30: rainbow_color = 16'hF80C;
        5'd31: rainbow_color = 16'hF806;
        default: rainbow_color = 16'hF800;
      endcase
    end
  endfunction

  wire [4:0]            rain_hue = frame_cnt[5:1] + qx[7:3] + qy[6:3];
  wire [DATA_WIDTH-1:0] rain_col = rainbow_color(rain_hue);
  function [DATA_WIDTH-1:0] heat_color;
    input [4:0] idx;
    begin
      case (idx)
        5'd 0: heat_color = 16'h001F;
        5'd 1: heat_color = 16'h011F;
        5'd 2: heat_color = 16'h021F;
        5'd 3: heat_color = 16'h031F;
        5'd 4: heat_color = 16'h043F;
        5'd 5: heat_color = 16'h053F;
        5'd 6: heat_color = 16'h063F;
        5'd 7: heat_color = 16'h073F;
        5'd 8: heat_color = 16'h07FE;
        5'd 9: heat_color = 16'h07FA;
        5'd10: heat_color = 16'h07F6;
        5'd11: heat_color = 16'h07F2;
        5'd12: heat_color = 16'h07EE;
        5'd13: heat_color = 16'h07EA;
        5'd14: heat_color = 16'h07E6;
        5'd15: heat_color = 16'h07E2;
        5'd16: heat_color = 16'h17E0;
        5'd17: heat_color = 16'h37E0;
        5'd18: heat_color = 16'h57E0;
        5'd19: heat_color = 16'h77E0;
        5'd20: heat_color = 16'h97E0;
        5'd21: heat_color = 16'hB7E0;
        5'd22: heat_color = 16'hD7E0;
        5'd23: heat_color = 16'hF7E0;
        5'd24: heat_color = 16'hFF20;
        5'd25: heat_color = 16'hFE20;
        5'd26: heat_color = 16'hFD20;
        5'd27: heat_color = 16'hFC20;
        5'd28: heat_color = 16'hFB00;
        5'd29: heat_color = 16'hFA00;
        5'd30: heat_color = 16'hF900;
        5'd31: heat_color = 16'hF800;
        default: heat_color = 16'h001F;
      endcase
    end
  endfunction

  wire [DATA_WIDTH-1:0] heat_col = heat_color(edge_str[7:3]);
  reg [DATA_WIDTH-1:0] blend;
  reg [DATA_WIDTH-1:0] edge_add;
  reg [DATA_WIDTH-1:0] edge_mix;

  always @(*) begin
    edge_add = img_in + col_use;              
    edge_mix = (img_in >> 1) + (col_use >> 1);

    case(BLEND_MODE)
      "ADD":     blend = edge_add;
      "MIX":     blend = edge_mix;
      default:   blend = col_use;          
    endcase
  end
  wire [4:0]  alpha5   = edge_str[7:3];                                          // 0~31
  wire [DATA_WIDTH-1:0] mix_25 = (img_in >> 2) + (img_in >> 1) + (col_use >> 2); // 25% 颜色
  wire [DATA_WIDTH-1:0] mix_50 = (img_in >> 1) + (col_use >> 1);                 // 50% 颜色
  wire [DATA_WIDTH-1:0] soft_col = (alpha5 >= 5'd20) ? col_use :                 // 强边：纯色
                                   (alpha5 >= 5'd8 ) ? mix_50  :                 // 中边：半透明
                                   (alpha5 >= 5'd2 ) ? mix_25  : img_in;         // 弱边：淡淡一层
  wire [DATA_WIDTH-1:0] str_gray = {edge_str[7:3], edge_str[7:2], edge_str[7:3]};
  wire [4:0]            post_r = {img_in[15:13], img_in[15:14]};
  wire [5:0]            post_g = {img_in[10:8],  img_in[10:8]};
  wire [4:0]            post_b = {img_in[4:2],   img_in[4:3]};
  wire [DATA_WIDTH-1:0] poster = {post_r, post_g, post_b};

  wire [DATA_WIDTH-1:0] body =
      (mode_use == 4'd0) ? (edge_in ? 16'hFFFF : 16'h0000) :                //黑底白边
      (mode_use == 4'd1) ? (edge_in ? 16'h0000 : 16'hFFFF) :                //白底黑边
      (mode_use == 4'd2) ? str_gray :                                       //强度灰度
      (mode_use == 4'd3) ? (edge_in ? heat_col : (img_in >> 1)) :           //热力图像（背景压暗）
      (mode_use == 4'd4) ? (edge_in ? (in_band ? 16'h07FF : 16'h0010) :     //雷达：带内青/带外暗蓝
                                    (scan_ln ? 16'h07E0 : (img_in >> 2))) : //扫描线绿/背景暗
      (mode_use == 4'd5) ? (edge_in ? 16'h0000 : poster) :                  //卡通滤镜
      (mode_use == 4'd7) ? (edge_in ? quad_col : img_in) :                  //多色叠加
      (mode_use == 4'd8) ? (edge_in ? rain_col : img_in) :                  //彩虹叠加
                           (edge_in ? blend : img_in);                      //原图 + 彩色边（mode6）

  always @(posedge clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
      data_out       <= {DATA_WIDTH{1'b0}};
      data_out_valid <= 1'b0;
      data_out_hs    <= 1'b0;
      data_out_vs    <= 1'b0;
    end
    else begin
      data_out       <= body;
      data_out_valid <= edge_in_valid;
      data_out_hs    <= edge_in_hs;
      data_out_vs    <= edge_in_vs;
    end
  end

endmodule
