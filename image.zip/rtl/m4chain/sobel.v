module sobel
#(
  parameter DATA_WIDTH  = 8,
  parameter LINE_WIDTH  = 640,    
  parameter BORDER_MASK = 1'b1,   
  parameter integer BORDER_ROWS = 2,
  parameter integer BORDER_COLS = 2,
  parameter integer GRAD_OP = 0, 
                                 
  parameter STRENGTH_SHIFT = 1   
                                 
                                 
)
(
  input                      clk,    //pixel clk
  input                      sys_rst_n,
  input     [DATA_WIDTH-1:0] data_in,
  input                      data_in_valid,
  input                      data_in_hs,
  input                      data_in_vs,
  input     [10:0]           threshold,

  output reg                 data_out,
  output reg                 data_out_valid,
  output reg                 data_out_hs,
  output reg                 data_out_vs,

  output reg [7:0]           strength_o,

  output reg [10:0]          mag_o
);
//line data
wire [DATA_WIDTH-1:0] line0_data;
wire [DATA_WIDTH-1:0] line1_data;
wire [DATA_WIDTH-1:0] line2_data;
//matrix 3x3 data
reg  [DATA_WIDTH-1:0] row0_col0;
reg  [DATA_WIDTH-1:0] row0_col1;
reg  [DATA_WIDTH-1:0] row0_col2;

reg  [DATA_WIDTH-1:0] row1_col0;
reg  [DATA_WIDTH-1:0] row1_col1;
reg  [DATA_WIDTH-1:0] row1_col2;

reg  [DATA_WIDTH-1:0] row2_col0;
reg  [DATA_WIDTH-1:0] row2_col1;
reg  [DATA_WIDTH-1:0] row2_col2;
//
reg                   data_in_valid_dly1;
reg                   data_in_valid_dly2;
reg                   data_in_hs_dly1;
reg                   data_in_hs_dly2;
reg                   data_in_vs_dly1;
reg                   data_in_vs_dly2;

wire                  Gx_is_positive;
wire                  Gy_is_positive;

reg  [DATA_WIDTH+1:0] Gx_absolute; //high bit expansion 2bit
reg  [DATA_WIDTH+1:0] Gy_absolute; //high bit expansion 2bit

//3xline data
shift_register_2taps
#(
  .DATA_WIDTH ( DATA_WIDTH )
)shift_register_2taps(
  .clk           (clk           ),
  .shiftin       (data_in       ),
  .shiftin_valid (data_in_valid ),

  .shiftout      (              ),
  .taps0x        (line0_data    ),
  .taps1x        (line1_data    )
);

assign line2_data = data_in;

// matrix 3x3 data
// row0_col0   row0_col1   row0_col2
// row1_col0   row1_col1   row1_col2
// row2_col0   row2_col1   row2_col2

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    row0_col0 <= 'd0;
    row0_col1 <= 'd0;
    row0_col2 <= 'd0;

    row1_col0 <= 'd0;
    row1_col1 <= 'd0;
    row1_col2 <= 'd0;

    row2_col0 <= 'd0;
    row2_col1 <= 'd0;
    row2_col2 <= 'd0;
  end
  else if(data_in_vs)                       
    if(data_in_valid) begin
      row0_col2 <= line0_data;
      row0_col1 <= row0_col2;
      row0_col0 <= row0_col1;

      row1_col2 <= line1_data;
      row1_col1 <= row1_col2;
      row1_col0 <= row1_col1;

      row2_col2 <= line2_data;
      row2_col1 <= row2_col2;
      row2_col0 <= row2_col1;
    end
    else begin
      row0_col2 <= row0_col2;
      row0_col1 <= row0_col1;
      row0_col0 <= row0_col0;

      row1_col2 <= row1_col2;
      row1_col1 <= row1_col1;
      row1_col0 <= row1_col0;

      row2_col2 <= row2_col2;
      row2_col1 <= row2_col1;
      row2_col0 <= row2_col0;
    end
  else begin                              
    row0_col0 <= 'd0;
    row0_col1 <= 'd0;
    row0_col2 <= 'd0;

    row1_col0 <= 'd0;
    row1_col1 <= 'd0;
    row1_col2 <= 'd0;

    row2_col0 <= 'd0;
    row2_col1 <= 'd0;
    row2_col2 <= 'd0;
  end
end

always @(posedge clk)
begin
  data_in_valid_dly1 <= data_in_valid;
  data_in_valid_dly2 <= data_in_valid_dly1;

  data_in_hs_dly1    <= data_in_hs;
  data_in_hs_dly2    <= data_in_hs_dly1;

  data_in_vs_dly1    <= data_in_vs;
  data_in_vs_dly2    <= data_in_vs_dly1;
end

localparam integer W_EDGE  = (GRAD_OP != 0) ? 3  : 1;
localparam integer W_MID   = (GRAD_OP != 0) ? 10 : 2;
localparam integer SH_POST = (GRAD_OP != 0) ? 2  : 0;

wire [DATA_WIDTH+3:0] gx_a = row0_col2*W_EDGE + row1_col2*W_MID + row2_col2*W_EDGE;
wire [DATA_WIDTH+3:0] gx_b = row0_col0*W_EDGE + row1_col0*W_MID + row2_col0*W_EDGE;
wire [DATA_WIDTH+3:0] gy_a = row0_col0*W_EDGE + row0_col1*W_MID + row0_col2*W_EDGE;
wire [DATA_WIDTH+3:0] gy_b = row2_col0*W_EDGE + row2_col1*W_MID + row2_col2*W_EDGE;

assign Gx_is_positive = (gx_a >= gx_b);
assign Gy_is_positive = (gy_a >= gy_b);

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n)
    Gx_absolute <= 'd0;
  else if(data_in_valid_dly1) begin
    if(Gx_is_positive)
      Gx_absolute <= (gx_a - gx_b) >> SH_POST;
    else
      Gx_absolute <= (gx_b - gx_a) >> SH_POST;
  end
end

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n)
    Gy_absolute <= 'd0;
  else if(data_in_valid_dly1) begin
    if(Gy_is_positive)
      Gy_absolute <= (gy_a - gy_b) >> SH_POST;
    else
      Gy_absolute <= (gy_b - gy_a) >> SH_POST;
  end
end

wire [DATA_WIDTH+1:0] mag_max = (Gx_absolute >= Gy_absolute) ? Gx_absolute : Gy_absolute;
wire [DATA_WIDTH+1:0] mag_min = (Gx_absolute >= Gy_absolute) ? Gy_absolute : Gx_absolute;
wire [DATA_WIDTH+2:0] mag_l2  = mag_max + (mag_min >> 1);

reg  [11:0] o_vcnt;     
reg  [11:0] o_ccnt;     

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    o_vcnt <= 12'd0;
    o_ccnt <= 12'd0;
  end
  else begin
    if(data_in_vs_dly2 == 1'b0)                 
      o_vcnt <= 12'd0;
    else if(data_in_valid_dly2 && (o_vcnt < BORDER_ROWS*LINE_WIDTH))
      o_vcnt <= o_vcnt + 1'b1;

    if(data_in_hs_dly2 == 1'b0)              
      o_ccnt <= 12'd0;
    else if(data_in_valid_dly2)
      o_ccnt <= (o_ccnt >= LINE_WIDTH-1) ? 12'd0 : o_ccnt + 1'b1;
  end
end

wire border = BORDER_MASK && ((o_vcnt < BORDER_ROWS*LINE_WIDTH) ||
                              (o_ccnt < BORDER_COLS));

wire [DATA_WIDTH+2:0] str_full = mag_l2 >> STRENGTH_SHIFT;
wire [7:0]            str_val  = (str_full > 11'd255) ? 8'hFF : str_full[7:0];

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    data_out   <= 1'b0;
    strength_o <= 8'd0;
    mag_o      <= 11'd0;
  end
  else if(data_in_valid_dly2) begin
    data_out   <= (mag_l2 > threshold) && ~border;   
    strength_o <= border ? 8'd0 : str_val;           
    mag_o      <= border ? 11'd0 : mag_l2[10:0];     
  end
end

always @(posedge clk)
begin
  data_out_valid <= data_in_valid_dly2;
  data_out_hs    <= data_in_hs_dly2;
  data_out_vs    <= data_in_vs_dly2;
end

endmodule 