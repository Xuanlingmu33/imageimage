`timescale 1ns/1ns
module minmax_stretch
#(
    parameter integer MIN_RANGE = 4,      // 小于它就不放大
    parameter integer MAX_GAIN  = 2048    // Q8 增益上限（2048/256 = 8×）
)//重要线性拉伸模块
(
    input  wire       clk,
    input  wire       sys_rst_n,

    input  wire [7:0] din,
    input  wire       valid,
    input  wire       hs,
    input  wire       vs,

    input  wire       en,                 // 1 = 开；0 = 旁路

    output wire [7:0] dout,
    output wire       dout_valid,
    output wire       dout_hs,
    output wire       dout_vs
);
    reg [7:0] f_min, f_max;       // 本帧统计
    reg [7:0] t_min, t_max;       // 上一帧锁存（本帧像素用它）

    reg en_p, en_p2, en_sync;
    reg vs_d;
    localparam integer LOCK_STATS = 1;
    localparam integer CAL_FRAMES = 16; 
    reg        cal_done;                
    reg  [4:0] cal_cnt;                 

    always @(posedge clk or negedge sys_rst_n) begin
        if(!sys_rst_n) begin
            en_p    <= 1'b0;
            en_p2   <= 1'b0;
            en_sync <= 1'b0;
            vs_d    <= 1'b0;
            t_min   <= 8'h00;
            t_max   <= 8'hFF;
            cal_done  <= 1'b0;
            cal_cnt   <= 5'd0;
        end
        else begin
            en_p  <= en;
            en_p2 <= en_p;
            vs_d  <= vs;
            if(vs & ~vs_d) begin
                en_sync <= en_p2;      // 帧起点生效
                if(LOCK_STATS == 0) begin
                    t_min <= f_min;           
                    t_max <= f_max;
                end
                else if(!cal_done) begin
                    if((f_min != 8'hFF) && (f_max > f_min) &&
                       ((f_max - f_min) >= 8'd16)) begin      
                        if(cal_cnt == 5'd0) begin
                            t_min <= f_min;                   
                            t_max <= f_max;
                        end
                        else begin                            
                            if(f_min < t_min) t_min <= f_min;
                            if(f_max > t_max) t_max <= f_max;
                        end
                        if(cal_cnt == (CAL_FRAMES-1)) cal_done <= 1'b1;
                        cal_cnt <= cal_cnt + 1'b1;
                    end
                end
            end
        end
    end

    always @(posedge clk or negedge sys_rst_n) begin
        if(!sys_rst_n) begin
            f_min <= 8'hFF;
            f_max <= 8'h00;
        end
        else if(vs & ~vs_d) begin
            f_min <= 8'hFF;
            f_max <= 8'h00;
        end
        else if(valid) begin
            if(din < f_min) f_min <= din;
            if(din > f_max) f_max <= din;
        end
    end
    wire [7:0] range = (t_max > t_min) ? (t_max - t_min) : 8'd0;

    reg [15:0] gain_case;
    always @(*) begin
        case(range[7:4])
            4'd0:  gain_case = 16'd2048;   // range  <=15  → 已由 MIN_RANGE 护栏处理
            4'd1:  gain_case = 16'd2048;   // ~24  → 2720，夹到上限
            4'd2:  gain_case = 16'd1632;   // ~40
            4'd3:  gain_case = 16'd1165;   // ~56
            4'd4:  gain_case = 16'd906;    // ~72
            4'd5:  gain_case = 16'd741;    // ~88
            4'd6:  gain_case = 16'd627;    // ~104
            4'd7:  gain_case = 16'd544;    // ~120
            4'd8:  gain_case = 16'd480;    // ~136
            4'd9:  gain_case = 16'd429;    // ~152
            4'd10: gain_case = 16'd388;    // ~168
            4'd11: gain_case = 16'd354;    // ~184
            4'd12: gain_case = 16'd326;    // ~200
            4'd13: gain_case = 16'd302;    // ~216
            4'd14: gain_case = 16'd281;    // ~232
            default: gain_case = 16'd263;  // ~248
        endcase
    end

    wire [15:0] gain_w = (range < MIN_RANGE) ? 16'd256 :
                         (gain_case > MAX_GAIN) ? MAX_GAIN : gain_case;
    reg  [7:0]  din_d, min_d;
    reg         valid_d, hs_d, vs_d2;
    reg  [15:0] gain_d;
    reg         en_d;

    always @(posedge clk or negedge sys_rst_n) begin
        if(!sys_rst_n) begin
            din_d <= 8'd0; min_d <= 8'd0;
            valid_d <= 1'b0; hs_d <= 1'b0; vs_d2 <= 1'b0;
            gain_d <= 16'd256; en_d <= 1'b0;
        end
        else begin
            din_d   <= din;
            min_d   <= t_min;
            gain_d  <= gain_w;
            valid_d <= valid;
            hs_d    <= hs;
            vs_d2   <= vs;
            en_d    <= en_sync;
        end
    end

    wire [8:0]  diff   = (din_d > min_d) ? ({1'b0, din_d} - {1'b0, min_d}) : 9'd0;
    wire [20:0] prod   = diff * gain_d;            // 9bit × 12bit ⇒ 21bit
    wire [12:0] scaled = prod >> 8;                // Q8 还原
    wire [7:0]  str    = (scaled > 13'd255) ? 8'd255 : scaled[7:0];

    assign dout       = en_d ? str : din_d;
    assign dout_valid = valid_d;
    assign dout_hs    = hs_d;
    assign dout_vs    = vs_d2;

endmodule