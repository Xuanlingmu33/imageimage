`timescale 1ns/1ps
module gray_align_dly #(
  parameter FINE = 5          //细调拍数
)(
  input  wire        clk,
  input  wire        sys_rst_n,
  input  wire [15:0] data_in,
  input  wire        valid_in,
  output wire [15:0] data_out,
  output wire        valid_out
);

  localparam F = (FINE < 1) ? 1 : FINE;
  wire [7:0] row_hi, row_lo;

  shift_register_2taps #(.DATA_WIDTH (8)) u_row_hi (
    .clk           (clk         ),
    .shiftin       (data_in[15:8]),
    .shiftin_valid (valid_in    ),
    .shiftout      (            ),
    .taps1x        (row_hi      ),
    .taps0x        (            )
  );

  shift_register_2taps #(.DATA_WIDTH (8)) u_row_lo (
    .clk           (clk         ),
    .shiftin       (data_in[7:0]),
    .shiftin_valid (valid_in    ),
    .shiftout      (            ),
    .taps1x        (row_lo      ),
    .taps0x        (            )
  );
  reg [7:0] d_hi [0:F-1];
  reg [7:0] d_lo [0:F-1];
  reg [F-1:0] v_dly;

  integer i;
  always @(posedge clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
      for(i = 0; i < F; i = i + 1) begin
        d_hi[i] <= 8'd0;
        d_lo[i] <= 8'd0;
      end
      v_dly <= {F{1'b0}};
    end
    else if(valid_in) begin
      d_hi[0] <= row_hi;
      d_lo[0] <= row_lo;
      for(i = 1; i < F; i = i + 1) begin
        d_hi[i] <= d_hi[i-1];
        d_lo[i] <= d_lo[i-1];
      end
      v_dly <= {v_dly[F-2:0], valid_in};
    end
  end

  assign data_out  = {d_hi[F-1], d_lo[F-1]};
  assign valid_out = v_dly[F-1];

endmodule
