module canny_hyst
#(
  parameter LINE_WIDTH = 640          //一行有效像素数
)
(
  input                       clk,
  input                       sys_rst_n,

  input      [1:0]            edge_in,        //来自 canny_thresh：0=丢弃 1=弱 2=强
  input                       data_in_valid,
  input                       data_in_hs,
  input                       data_in_vs,

  output reg                  edge_o,         //1 = 最终边缘
  output reg                  edge_valid_o,
  output reg                  edge_hs_o,
  output reg                  edge_vs_o
);

reg [LINE_WIDTH-1:0] buf_a;
reg [LINE_WIDTH-1:0] buf_b;
reg                  up_is_a;      
reg [15:0]           wcol;         
reg                  first_row;    
reg                  vs_d;

reg  [1:0] st_a, st_b;             
reg        v_d1, v_d2, v_d3;       
reg        up_m, up_l;             
reg        left_lab;               

reg hs1,hs2,hs3, vs1,vs2,vs3;

wire       vs_start = data_in_vs & (~vs_d);
wire [LINE_WIDTH-1:0] up_buf = up_is_a ? buf_a : buf_b;

wire up_r = first_row ? 1'b0 : up_buf[LINE_WIDTH-2];
wire up_c = first_row ? 1'b0 : up_m;
wire up_lf= first_row ? 1'b0 : up_l;

wire strong_e = (st_b == 2'd2);
wire weak_e   = (st_b == 2'd1);
wire lab    = strong_e | (weak_e & (up_lf | up_c | up_r | left_lab));

always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    buf_a <= {LINE_WIDTH{1'b0}};
    buf_b <= {LINE_WIDTH{1'b0}};
    up_is_a <= 1'b1;
    wcol <= 16'd0;
    first_row <= 1'b0;
    vs_d <= 1'b0;

    st_a <= 2'd0;  st_b <= 2'd0;
    v_d1 <= 1'b0;  v_d2 <= 1'b0;  v_d3 <= 1'b0;
    up_m <= 1'b0;  up_l <= 1'b0;  left_lab <= 1'b0;

    hs1<=1'b0; hs2<=1'b0; hs3<=1'b0;
    vs1<=1'b0; vs2<=1'b0; vs3<=1'b0;

    edge_o <= 1'b0;
    edge_valid_o <= 1'b0;
    edge_hs_o <= 1'b0;
    edge_vs_o <= 1'b0;
  end
  else begin
    vs_d <= data_in_vs;
    v_d1 <= data_in_valid;  v_d2 <= v_d1;  v_d3 <= v_d2;
    hs1  <= data_in_hs;     hs2  <= hs1;   hs3  <= hs2;
    vs1  <= data_in_vs;     vs2  <= vs1;   vs3  <= vs2;

    edge_valid_o <= v_d2;
    edge_hs_o    <= hs2;
    edge_vs_o    <= vs2;
    if(data_in_valid)
      st_a <= edge_in;
    if(v_d1) begin
      st_b <= st_a;
      up_l <= up_m;
      up_m <= up_r;
      if(up_is_a) buf_a <= {buf_a[LINE_WIDTH-2:0], 1'b0};
      else        buf_b <= {buf_b[LINE_WIDTH-2:0], 1'b0};
    end
    if(v_d2) begin
      if(up_is_a) buf_b <= {buf_b[LINE_WIDTH-2:0], lab};
      else        buf_a <= {buf_a[LINE_WIDTH-2:0], lab};

      left_lab <= lab;
      edge_o   <= lab;

      if(wcol == LINE_WIDTH-1) begin
        wcol      <= 16'd0;
        up_is_a   <= ~up_is_a;    
        first_row <= 1'b0;
      end
      else
        wcol <= wcol + 1'b1;
    end
    if(vs_start) begin
      first_row <= 1'b1;
    end
  end
end

endmodule
