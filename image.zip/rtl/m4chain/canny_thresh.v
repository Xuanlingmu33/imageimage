module canny_thresh
#(
  parameter MAG_WIDTH = 11          //幅值位宽（0~2040）
)
(
  input                       clk,          //pixel clk（与 canny_nms 同域）
  input                       sys_rst_n,

  input      [MAG_WIDTH-1:0]  nms_in,       //来自 canny_nms
  input      [MAG_WIDTH-1:0]  th_high,      //高阈值（基准，顶层按键给）

  input                       data_in_valid,
  input                       data_in_hs,
  input                       data_in_vs,

  output reg [1:0]            edge_o,       //0=丢弃 1=弱 2=强
  output reg                  edge_bin_o,   //1=强边（二值，给显示/对比用）
  output reg                  edge_valid_o,
  output reg                  edge_hs_o,
  output reg                  edge_vs_o
);
wire [MAG_WIDTH-1:0] th_low = {1'b0, th_high[MAG_WIDTH-1:1]};
wire        is_strong = (nms_in >= th_high);
wire        is_weak   = (nms_in >= th_low);

wire [1:0]  edge_c    = is_strong ? 2'd2 :
                        is_weak   ? 2'd1 : 2'd0;
always @(posedge clk or negedge sys_rst_n) begin
  if(!sys_rst_n) begin
    edge_o      <= 2'd0;
    edge_bin_o  <= 1'b0;
    edge_valid_o<= 1'b0;
    edge_hs_o   <= 1'b0;
    edge_vs_o   <= 1'b0;
  end
  else begin
    edge_o      <= edge_c;
    edge_bin_o  <= (edge_c == 2'd2);      //只有强边为 1
    edge_valid_o<= data_in_valid;
    edge_hs_o   <= data_in_hs;
    edge_vs_o   <= data_in_vs;
  end
end

endmodule
