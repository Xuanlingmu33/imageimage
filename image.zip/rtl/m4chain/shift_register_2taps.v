module shift_register_2taps
#(
  parameter DATA_WIDTH = 8
)
(
  input                      clk,
  input  [DATA_WIDTH-1:0]    shiftin,
  input                      shiftin_valid,

  output [DATA_WIDTH-1:0]    shiftout,
  output [DATA_WIDTH-1:0]    taps1x,
  output [DATA_WIDTH-1:0]    taps0x     //纯rtl逻辑替代ip核
);

  localparam DEPTH = 1280;    
  localparam TAP1  = 640;     
  localparam TAP0  = 1280;    
  localparam AW    = $clog2(DEPTH);

  reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];
  reg [AW-1:0]         wcnt;        

  wire signed [AW+1:0] pre0 = $signed({1'b0, wcnt}) + 1 - $signed({1'b0, TAP0[AW-1:0]});
  wire signed [AW+1:0] pre1 = $signed({1'b0, wcnt}) + 1 - $signed({1'b0, TAP1[AW-1:0]});
  wire [AW+1:0] raddr0 = pre0[AW+1] ? (pre0 + DEPTH) : pre0;
  wire [AW+1:0] raddr1 = pre1[AW+1] ? (pre1 + DEPTH) : pre1;

  reg [DATA_WIDTH-1:0] q1, q0;

  integer mi;
  initial begin
    wcnt = {AW{1'b0}};
    for(mi = 0; mi < DEPTH; mi = mi + 1) mem[mi] = {DATA_WIDTH{1'b0}};
    q1 = {DATA_WIDTH{1'b0}};
    q0 = {DATA_WIDTH{1'b0}};
  end

  always @(posedge clk) begin
    if(shiftin_valid) begin
      mem[wcnt] <= shiftin;
      wcnt      <= (wcnt == DEPTH[AW-1:0] - 1'b1) ? {AW{1'b0}} : (wcnt + 1'b1);
      q1        <= mem[raddr1[AW-1:0]];
      q0        <= mem[raddr0[AW-1:0]];
    end
  end

  assign taps1x   = q1;
  assign taps0x   = q0;
  assign shiftout = q0;    

endmodule
