module m6_osd #(
    parameter integer CELL     = 32,                // 字格边长
    parameter integer CLK_HZ   = 74_250_000,        // 像素时钟
    parameter integer AVG_N    = 4                  // 帧率平均帧数
)(
    input  wire         clk,
    input  wire         rst_n,

    input  wire [15:0]  i_data,
    input  wire         i_de,
    input  wire         i_hs,
    input  wire         i_vs,          

    input  wire [11:0]  h_cnt,
    input  wire [10:0]  v_cnt,

    input  wire         key1,           
    input  wire         key3,           
    input  wire         key2,           
    input  wire         kf0,            

    input  wire [3:0]   disp_mode,      
    input  wire         split_mode,     
    input  wire         median_en,      

    input  wire [13:0]  fps_sensor,

    output wire [15:0]  o_data,
    output wire         o_de,
    output wire         o_hs,
    output wire         o_vs,
    output wire [10:0]  o_threshold,    
    output wire [10:0]  o_canny_thr,    
    output wire         o_ev_src,       
    output wire         o_disp_inc,     
    output wire [3:0]   o_color_sel,    

    output wire         o_sign,
    output wire [2:0]   o_step_idx,
    output wire [13:0]  o_fps_disp,     
    output wire [13:0]  o_fps_sens      
);

    wire        ev_thr, ev_sign, ev_step, w_press, w_release;
    wire        ev_mode_sign, ev_mode_step, ev_mode_def;
    wire [1:0]  w_mode;
    wire        w_sign;
    wire [2:0]  w_step;
    wire [5:0]  w_step_val;

    key_mode_fsm u_key_fsm (
        .clk        (clk        ),
        .rst_n      (rst_n      ),
        .key        (key1       ),
        .ev_thr     (ev_thr     ),
        .ev_sign    (ev_sign    ),
        .ev_step    (ev_step    ),
        .ev_mode_sign(ev_mode_sign),
        .ev_mode_step(ev_mode_step),
        .ev_mode_def(ev_mode_def ),
        .key_press  (w_press    ),
        .key_release(w_release  ),
        .mode       (w_mode     ),
        .sign       (w_sign     ),
        .step_idx   (w_step     ),
        .step_val   (w_step_val ),
        .thr_cur    (o_threshold)
    );

    assign o_sign     = w_sign;
    assign o_step_idx = w_step;

    wire        ev_thr_c, ev_sign_c, ev_step_c, ev_src_c, w_press_c, w_release_c;
    wire        ev_msign_c, ev_mstep_c, ev_mdef_c, ev_msrc_c;
    wire [1:0]  w_mode_c;
    wire        w_sign_c;
    wire [2:0]  w_step_c;
    wire [5:0]  w_stepval_c;
    wire [10:0] w_canny_thr;

    key_mode_fsm #(
        .WITH_SRC   (1          ),
        .START_MODE (3          ),      //上电超时都回"换源"
        .THR_INIT   (8          ),
        .STEP_INIT  (0          )       //初始步进2
    ) u_key_fsm3 (
        .clk        (clk        ),
        .rst_n      (rst_n      ),
        .key        (key3       ),
        .ev_thr     (ev_thr_c   ),
        .ev_sign    (ev_sign_c  ),
        .ev_step    (ev_step_c  ),
        .ev_src     (ev_src_c   ),
        .ev_mode_def (ev_mdef_c ),
        .ev_mode_sign(ev_msign_c),
        .ev_mode_step(ev_mstep_c),
        .ev_mode_src (ev_msrc_c ),
        .key_press  (w_press_c  ),
        .key_release(w_release_c),
        .mode       (w_mode_c   ),
        .sign       (w_sign_c   ),
        .step_idx   (w_step_c   ),
        .step_val   (w_stepval_c),
        .thr_cur    (w_canny_thr)
    );

    assign o_canny_thr = w_canny_thr;
    assign o_ev_src    = ev_src_c;
    wire        ev_disp2, ev_color2, ev_cmode_on2, ev_cmode_off2;
    wire        w_color_mode;
    wire [2:0]  w_color_idx;

    key2_fsm u_key2_fsm (
        .clk        (clk        ),
        .rst_n      (rst_n      ),
        .key        (key2       ),
        .disp_mode  (disp_mode  ),
        .ev_disp    (ev_disp2   ),
        .ev_color   (ev_color2  ),
        .ev_cmode_on(ev_cmode_on2 ),
        .ev_cmode_off(ev_cmode_off2),
        .color_mode (w_color_mode),
        .color_idx  (w_color_idx)
    );

    assign o_disp_inc  = ev_disp2;
    assign o_color_sel = {1'b0, w_color_idx};

    reg ev_median_m, ev_thr_m, ev_sign_m, ev_step_m;
    reg ev_msign_m, ev_mstep_m, ev_mdef_m;
    reg ev_thr_c_m, ev_sign_c_m, ev_step_c_m, ev_msign_c_m, ev_mstep_c_m, ev_mdef_c_m;
    reg ev_color_m, ev_cmode_m;        

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ev_median_m <= 1'b0;
            ev_thr_m    <= 1'b0;
            ev_sign_m   <= 1'b0;
            ev_step_m   <= 1'b0;
            ev_msign_m  <= 1'b0;
            ev_mstep_m  <= 1'b0;
            ev_mdef_m   <= 1'b0;
            ev_thr_c_m  <= 1'b0; ev_sign_c_m <= 1'b0; ev_step_c_m <= 1'b0;
            ev_msign_c_m<= 1'b0; ev_mstep_c_m<= 1'b0; ev_mdef_c_m<= 1'b0;
            ev_color_m  <= 1'b0; ev_cmode_m  <= 1'b0;
        end else begin
            ev_median_m <= kf0;
            ev_thr_m    <= ev_thr;
            ev_sign_m   <= ev_sign;
            ev_step_m   <= ev_step;
            ev_msign_m  <= ev_mode_sign;
            ev_mstep_m  <= ev_mode_step;
            ev_mdef_m   <= ev_mode_def;
            ev_thr_c_m  <= ev_thr_c;   ev_sign_c_m <= ev_sign_c;   ev_step_c_m <= ev_step_c;
            ev_msign_c_m<= ev_msign_c; ev_mstep_c_m<= ev_mstep_c; ev_mdef_c_m <= ev_mdef_c;
            ev_color_m  <= ev_color2;
            ev_cmode_m  <= ev_cmode_on2;
        end
    end

    wire [13:0] fps_disp;

    fps_meter #(
        .CLK_HZ (CLK_HZ),
        .AVG_N  (AVG_N )
    ) u_fps_disp (
        .clk     (clk     ),
        .rst_n   (rst_n   ),
        .frame_vs(i_vs    ),
        .fps_x10 (fps_disp),
        .fps_vld (        ),
        .fps_upd (        )
    );

    assign o_fps_disp = fps_disp;
    assign o_fps_sens = fps_sensor;

    wire [223:0] line_fps_l, line_fps_r, line_msg, line_left, line_right, line_up;

    osd_text #(
        .MSG_CYCLES (222_750_000),
        .CLK_HZ     (CLK_HZ     )
    ) u_text (
        .clk        (clk        ),
        .rst_n      (rst_n      ),
        .disp_mode  (disp_mode  ),
        .split_mode (split_mode ),
        .median_en  (median_en  ),
        .threshold  (o_threshold),
        .sign       (w_sign     ),
        .step_idx   (w_step     ),
        .fps_l      (fps_sensor ),
        .fps_r      (fps_disp   ),
        .ev_median  (ev_median_m),
        .ev_thr     (ev_thr_m   ),
        .ev_sign    (ev_sign_m  ),
        .ev_step    (ev_step_m  ),
        .ev_mode_sign(ev_msign_m ),
        .ev_mode_step(ev_mstep_m ),
        .ev_mode_def(ev_mdef_m  ),
        .canny_thr  (w_canny_thr ),
        .sign_c     (w_sign_c    ),
        .step_c     (w_step_c    ),
        .ev_thr_c   (ev_thr_c_m  ),
        .ev_sign_c  (ev_sign_c_m ),
        .ev_step_c  (ev_step_c_m ),
        .ev_mode_sign_c(ev_msign_c_m),
        .ev_mode_step_c(ev_mstep_c_m),
        .ev_mode_def_c(ev_mdef_c_m),
        .color_idx  (w_color_idx),
        .ev_color   (ev_color_m),
        .ev_cmode_on(ev_cmode_m),
        .line_fps_l (line_fps_l ),
        .line_fps_r (line_fps_r ),
        .line_msg   (line_msg   ),
        .line_left  (line_left  ),
        .line_right (line_right ),
        .line_up   (line_up   )
    );

    osd_overlay #(
        .CELL (CELL)
    ) u_overlay (
        .clk        (clk        ),
        .rst_n      (rst_n      ),
        .i_data     (i_data     ),
        .i_de       (i_de       ),
        .i_hs       (i_hs       ),
        .i_vs       (i_vs       ),
        .h_cnt      (h_cnt      ),
        .v_cnt      (v_cnt      ),
        .line_fps_l (line_fps_l ),
        .line_fps_r (line_fps_r ),
        .line_msg   (line_msg   ),
        .line_left  (line_left  ),
        .line_right (line_right ),
        .line_up   (line_up   ),
        .o_data     (o_data     ),
        .o_de       (o_de       ),
        .o_hs       (o_hs       ),
        .o_vs       (o_vs       )
    );

endmodule
