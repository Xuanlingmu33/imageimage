module osd_overlay #(
    parameter integer CELL    = 32,
    parameter [15:0]  COL_FPS = 16'h07E0,      // 绿色（RGB565）
    parameter [15:0]  COL_TXT = 16'hFFFF       // 白色
)(
    input  wire         clk,
    input  wire         rst_n,

    input  wire [15:0]  i_data,
    input  wire         i_de,
    input  wire         i_hs,
    input  wire         i_vs,

    input  wire [11:0]  h_cnt,
    input  wire [10:0]  v_cnt,

    input  wire [223:0] line_fps_l,
    input  wire [223:0] line_fps_r,
    input  wire [223:0] line_msg,
    input  wire [223:0] line_left,
    input  wire [223:0] line_right,
    input  wire [223:0] line_up,       

    output reg  [15:0]  o_data,
    output reg          o_de,
    output reg          o_hs,
    output reg          o_vs
);

    localparam integer FPS_CELLS = 5;                       //FPS: 60.0
    localparam integer FPS_Y0    = 10;
    localparam integer FPS_X0L   = 636 - FPS_CELLS*CELL;    //左半右对齐
    localparam integer FPS_X0R   = 1272 - FPS_CELLS*CELL;   //右半右对齐
    localparam integer BOT_CELLS = 16;
    localparam integer BOT_X0    = 16;
    localparam integer PITCH     = CELL + 10;               //行距 42
    localparam integer MSG_Y0    = 720 - 14 - 3*PITCH;      //580
    localparam integer LFT_Y0    = MSG_Y0 + PITCH;          //622
    localparam integer RGT_Y0    = MSG_Y0 + 2*PITCH;        //664
    localparam integer CLK_CELLS = 8;
    localparam integer CLK_X0    = 1272 - CLK_CELLS*CELL;   //1016

//字块判定（band）0=无 1=FPS左 2=FPS右 3=消息 4=左区 5=右区

    reg  [2:0]  band;
    reg  [10:0] x0_sel;
    reg  [10:0] y0_sel;

    always @(*) begin
        band   = 3'd0;
        x0_sel = 11'd0;
        y0_sel = 11'd0;
        if ((v_cnt >= FPS_Y0) && (v_cnt < FPS_Y0 + CELL)) begin
            if ((h_cnt >= FPS_X0L) && (h_cnt < FPS_X0L + FPS_CELLS*CELL)) begin
                band = 3'd1; x0_sel = FPS_X0L; y0_sel = FPS_Y0;
            end else if ((h_cnt >= FPS_X0R) && (h_cnt < FPS_X0R + FPS_CELLS*CELL)) begin
                band = 3'd2; x0_sel = FPS_X0R; y0_sel = FPS_Y0;
            end
        end else if ((h_cnt >= CLK_X0) && (h_cnt < CLK_X0 + CLK_CELLS*CELL) &&
                     (v_cnt >= RGT_Y0) && (v_cnt < RGT_Y0 + CELL)) begin
            band = 3'd6; x0_sel = CLK_X0; y0_sel = RGT_Y0;
        end else if ((h_cnt >= BOT_X0) && (h_cnt < BOT_X0 + BOT_CELLS*CELL)) begin
            if ((v_cnt >= MSG_Y0) && (v_cnt < MSG_Y0 + CELL)) begin
                band = 3'd3; x0_sel = BOT_X0; y0_sel = MSG_Y0;
            end else if ((v_cnt >= LFT_Y0) && (v_cnt < LFT_Y0 + CELL)) begin
                band = 3'd4; x0_sel = BOT_X0; y0_sel = LFT_Y0;
            end else if ((v_cnt >= RGT_Y0) && (v_cnt < RGT_Y0 + CELL)) begin
                band = 3'd5; x0_sel = BOT_X0; y0_sel = RGT_Y0;
            end
        end
    end

    wire [10:0] x_off = h_cnt[10:0] - x0_sel;               //字块内横偏移
    wire [4:0]  sub   = x_off[4:0];                         //格内列
    wire [3:0]  cidx  = x_off[8:5];                         //格号
    wire [10:0] y_off = v_cnt - y0_sel;                     //字块内纵偏移,字模行号
    wire [4:0]  grow  = y_off[4:0];

    wire [223:0] line_sel = (band == 3'd1) ? line_fps_l :
                            (band == 3'd2) ? line_fps_r :
                            (band == 3'd3) ? line_msg   :
                            (band == 3'd4) ? line_left  :
                            (band == 3'd5) ? line_right : line_up;
    wire [13:0]  cell_w   = line_sel[cidx*14 +: 14];

    wire        is_cjk = cell_w[13];
    wire [6:0]  code_a = cell_w[13:7];
    wire [6:0]  code_b = cell_w[6:0];
    wire        half_r = sub[4];                          

    wire [6:0]  rom_idx = is_cjk ? {1'b1, code_a[5:0]}
                                 : {2'b00, (half_r ? code_b[4:0] : code_a[4:0])};
    wire [4:0]  sel_bit = is_cjk ? sub : {1'b0, sub[3:0]};
    wire [15:0] col_sel = ((band == 3'd1) || (band == 3'd2)) ? COL_FPS : COL_TXT;
    reg  [6:0]  rom_idx_r;
    reg  [4:0]  rom_row_r;
    reg  [4:0]  sel_bit_r;
    reg         in_band_r;
    reg  [15:0] col_r;
    reg  [15:0] d1_data;
    reg         d1_de, d1_hs, d1_vs;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rom_idx_r  <= 7'd0;
            rom_row_r  <= 5'd0;
            sel_bit_r  <= 5'd0;
            in_band_r  <= 1'b0;
            col_r      <= 16'd0;
            d1_data    <= 16'd0;
            d1_de      <= 1'b0;
            d1_hs      <= 1'b0;
            d1_vs      <= 1'b0;
        end else begin
            rom_idx_r  <= rom_idx;
            rom_row_r  <= grow;
            sel_bit_r  <= sel_bit;
            in_band_r  <= (band != 3'd0) & i_de;
            col_r      <= col_sel;
            d1_data    <= i_data;
            d1_de      <= i_de;
            d1_hs      <= i_hs;
            d1_vs      <= i_vs;
        end
    end

    wire [31:0] rom_bits;

    osd_font_rom #(
        .CELL    (CELL),
        .N_ASCII (32),
        .N_CJK   (64)
    ) u_font_rom (
        .clk  (clk       ),
        .idx  (rom_idx_r ),
        .row  (rom_row_r ),
        .bits (rom_bits  )
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            o_data <= 16'd0;
            o_de   <= 1'b0;
            o_hs   <= 1'b0;
            o_vs   <= 1'b0;
        end else begin
            o_data <= (in_band_r && rom_bits[sel_bit_r]) ? col_r : d1_data;
            o_de   <= d1_de;
            o_hs   <= d1_hs;
            o_vs   <= d1_vs;
        end
    end

endmodule
