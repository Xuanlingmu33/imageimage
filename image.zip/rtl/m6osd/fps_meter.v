module fps_meter #(
    parameter integer CLK_HZ = 74_250_000,      // 像素时钟频率
    parameter integer AVG_N  = 4                // 平均帧数
)(
    input  wire         clk,
    input  wire         rst_n,
    input  wire         frame_vs,               
    output reg  [13:0]  fps_x10,                
    output reg          fps_vld,                
    output reg          fps_upd                 //实时帧率测量模块
);

    localparam [63:0] NUM64  = CLK_HZ * AVG_N * 64'd10;
    localparam [31:0] NUM_32 = NUM64[31:0];

    localparam [1:0] S_IDLE = 2'd0, S_RUN = 2'd1, S_DONE = 2'd2;

    reg  [1:0]  div_st;
    reg  [31:0] div_d;             
    reg  [31:0] div_d_lat;         
    reg         div_req;           
    reg  [33:0] div_rem;
    reg  [31:0] div_quo;
    reg  [31:0] dvd_sh;            
    reg  [5:0]  div_i;

    wire        dvd_msb  = dvd_sh[31];
    wire [33:0] rem_next = {div_rem[32:0], dvd_msb};
    wire [33:0] rem_sub  = rem_next - {2'b0, div_d};

    reg         vs_d;
    wire        pos_vs = frame_vs & ~vs_d;
    reg  [31:0] per_cnt;            
    reg  [31:0] per_sum;            
    reg  [2:0]  frame_n;
    reg         first_done;         
    reg  [26:0] to_cnt;             
    wire        timeout = (to_cnt >= CLK_HZ);
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            vs_d       <= 1'b0;
            per_cnt    <= 32'd0;
            per_sum    <= 32'd0;
            frame_n    <= 3'd0;
            first_done <= 1'b0;
            to_cnt     <= 27'd0;
            div_st     <= S_IDLE;
            div_d      <= 32'd1;
            div_d_lat  <= 32'd1;
            div_req    <= 1'b0;
            div_rem    <= 34'd0;
            div_quo    <= 32'd0;
            dvd_sh     <= NUM_32;
            div_i      <= 6'd31;
            fps_x10    <= 14'd0;
            fps_vld    <= 1'b0;
            fps_upd    <= 1'b0;
        end else begin
            vs_d    <= frame_vs;
            fps_upd <= 1'b0;                    
            case (div_st)
                S_IDLE: begin
                    if (div_req) begin
                        div_d   <= (div_d_lat == 32'd0) ? 32'd1 : div_d_lat;
                        div_rem <= 34'd0;
                        div_quo <= 32'd0;
                        dvd_sh  <= NUM_32;
                        div_i   <= 6'd31;
                        div_req <= 1'b0;
                        div_st  <= S_RUN;
                    end
                end
                S_RUN: begin
                    dvd_sh <= {dvd_sh[30:0], 1'b0};
                    if (rem_next >= {2'b0, div_d}) begin
                        div_rem <= rem_sub;
                        div_quo <= {div_quo[30:0], 1'b1};
                    end else begin
                        div_rem <= rem_next;
                        div_quo <= {div_quo[30:0], 1'b0};
                    end
                    if (div_i == 6'd0) div_st <= S_DONE;
                    else               div_i <= div_i - 6'd1;
                end
                S_DONE: begin
                    if (div_rem >= {2'b0, (div_d >> 1)})
                        fps_x10 <= (div_quo >= 32'd9999) ? 14'd9999 : (div_quo[13:0] + 14'd1);
                    else
                        fps_x10 <= (div_quo > 32'd9999) ? 14'd9999 : div_quo[13:0];
                    fps_vld <= 1'b1;
                    fps_upd <= 1'b1;          
                    div_st  <= S_IDLE;
                end
                default: div_st <= S_IDLE;
            endcase

            if (pos_vs) begin
                if (!first_done) begin
                    first_done <= 1'b1;                    
                end else if ((div_st == S_IDLE) && !div_req) begin
                    if (frame_n == (AVG_N - 1)) begin
                        div_d_lat <= per_sum + per_cnt + 32'd1;  
                        div_req   <= 1'b1;
                        per_sum   <= 32'd0;
                        frame_n   <= 3'd0;
                    end else begin
                        per_sum <= per_sum + per_cnt + 32'd1;
                        frame_n <= frame_n + 3'd1;
                    end
                end
            end
            if (pos_vs)                          per_cnt <= 32'd0;
            else if (per_cnt < 32'hFFFF_0000)    per_cnt <= per_cnt + 32'd1;

            if (pos_vs)                          to_cnt <= 27'd0;
            else if (to_cnt < CLK_HZ)            to_cnt <= to_cnt + 27'd1;
            if (timeout && !pos_vs && (div_st != S_DONE)) begin
                fps_x10    <= 14'd0;
                fps_vld    <= 1'b0;
                per_sum    <= 32'd0;
                frame_n    <= 3'd0;
                first_done <= 1'b0;            
            end
        end
    end

endmodule

module fps_cdc #(
    parameter integer W = 14
)(
    input  wire         clk_a,      
    input  wire         rst_a_n,
    input  wire [W-1:0] din,        
    input  wire         upd_a,      

    input  wire         clk_b,      
    input  wire         rst_b_n,
    output reg  [W-1:0] dout        
);

    reg tog_a;
    always @(posedge clk_a or negedge rst_a_n) begin
        if (!rst_a_n) tog_a <= 1'b0;
        else if (upd_a) tog_a <= ~tog_a;
    end

    reg tog_s1, tog_s2, tog_s3;
    always @(posedge clk_b or negedge rst_b_n) begin
        if (!rst_b_n) begin
            tog_s1 <= 1'b0;
            tog_s2 <= 1'b0;
            tog_s3 <= 1'b0;
        end else begin
            tog_s1 <= tog_a;
            tog_s2 <= tog_s1;
            tog_s3 <= tog_s2;
        end
    end

    wire upd_b = tog_s2 ^ tog_s3;      

    always @(posedge clk_b or negedge rst_b_n) begin
        if (!rst_b_n) dout <= {W{1'b0}};
        else if (upd_b) dout <= din; 
    end

endmodule
