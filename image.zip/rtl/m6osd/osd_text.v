module osd_text #(
    parameter integer MSG_CYCLES = 222_750_000,      // 瞬时消息显示时长,3秒
    parameter integer CLK_HZ     = 74_250_000        // 运行时长计数用
)(
    input  wire         clk,
    input  wire         rst_n,

    input  wire [3:0]   disp_mode,      // key2 档位
    input  wire         split_mode,     // key3 换源
    input  wire         median_en,      // key0 中值开关
    input  wire [10:0]  threshold,      // 当前阈值
    input  wire         sign,           // 0是加 1是减
    input  wire [2:0]   step_idx,       // 步进档

    input  wire [13:0]  fps_l,          // 左半：实测传感器域
    input  wire [13:0]  fps_r,          // 右半：实测显示侧

    input  wire [10:0]  canny_thr,      // Canny的专用阈值
    input  wire         sign_c,         // Canny侧 0代表加 1代表减
    input  wire [2:0]   step_c,         // Canny侧步进档

    input  wire [2:0]   color_idx,      // 当前叠加颜色显示红橙黄绿青蓝紫
    input  wire         ev_color,      
    input  wire         ev_cmode_on,    // 进入选色模式,长按,单拍

    input  wire         ev_median,      // key0按下
    input  wire         ev_thr,         // key1单击
    input  wire         ev_sign,        // key1加减已互换
    input  wire         ev_step,        // key1步进档已循环
    input  wire         ev_mode_sign,   // key1进加减模式
    input  wire         ev_mode_step,   // key1进步进模式
    input  wire         ev_mode_def,    // key1回阈值模式

    input  wire         ev_thr_c,       // key3单击（Canny 阈值已变）
    input  wire         ev_sign_c,      // key3加减已互换
    input  wire         ev_step_c,      // key3步进档已循环
    input  wire         ev_mode_sign_c, // key3进加减模式
    input  wire         ev_mode_step_c, // key3进步进模式
    input  wire         ev_mode_def_c,  // key3进阈值模式

    output wire [223:0] line_fps_l,     //文字
    output wire [223:0] line_fps_r,
    output wire [223:0] line_msg,
    output wire [223:0] line_left,
    output wire [223:0] line_right,
    output wire [223:0] line_up
);
    //字模库
    localparam [6:0] A_SP  = 7'h00;
    localparam [6:0] A_COL = 7'h01;   // :
    localparam [6:0] A_DOT = 7'h02;   // .
    localparam [6:0] A_F   = 7'h0D;
    localparam [6:0] A_P   = 7'h0E;
    localparam [6:0] A_S   = 7'h0F;
    localparam [6:0] A_o   = 7'h10;
    localparam [6:0] A_b   = 7'h11;
    localparam [6:0] A_e   = 7'h12;
    localparam [6:0] A_l   = 7'h13;
    localparam [6:0] A_C   = 7'h14;
    localparam [6:0] A_a   = 7'h15;
    localparam [6:0] A_n   = 7'h16;
    localparam [6:0] A_y   = 7'h17;
    localparam [6:0] A_DSH = 7'h18;   // -
    localparam [6:0] A_SLH = 7'h19;   // /
    localparam [6:0] A_LP  = 7'h1A;   // (
    localparam [6:0] A_RP  = 7'h1B;   // )
    localparam [6:0] A_s   = 7'h1C;   //

    localparam [6:0] G_YOU    = 7'h40;   // 右
    localparam [6:0] G_QU     = 7'h41;   // 区
    localparam [6:0] G_HUA    = 7'h42;   // 画
    localparam [6:0] G_MIAN   = 7'h43;   // 面
    localparam [6:0] G_ZUO    = 7'h44;   // 左
    localparam [6:0] G_ZHONG  = 7'h45;   // 中
    localparam [6:0] G_ZHI    = 7'h46;   // 值
    localparam [6:0] G_LV     = 7'h47;   // 滤
    localparam [6:0] G_BO     = 7'h48;   // 波
    localparam [6:0] G_KAI    = 7'h49;   // 开
    localparam [6:0] G_GUAN   = 7'h4A;   // 关
    localparam [6:0] G_DANG   = 7'h4B;   // 当
    localparam [6:0] G_QIAN   = 7'h4C;   // 前
    localparam [6:0] G_YU     = 7'h4D;   // 阈
    localparam [6:0] G_MO     = 7'h4E;   // 模
    localparam [6:0] G_SHI    = 7'h4F;   // 式
    localparam [6:0] G_ZHUANG = 7'h50;   // 状
    localparam [6:0] G_TAI    = 7'h51;   // 态
    localparam [6:0] G_JIA    = 7'h52;   // 加
    localparam [6:0] G_JIAN   = 7'h53;   // 减
    localparam [6:0] G_BU     = 7'h54;   // 步
    localparam [6:0] G_JIN    = 7'h55;   // 进
    localparam [6:0] G_HUI    = 7'h56;   // 灰
    localparam [6:0] G_DU     = 7'h57;   // 度
    localparam [6:0] G_QIANG  = 7'h58;   // 强
    localparam [6:0] G_HONG   = 7'h59;   // 红
    localparam [6:0] G_SE     = 7'h5A;   // 色
    localparam [6:0] G_DIE    = 7'h5B;   // 叠
    localparam [6:0] G_YI     = 7'h5C;   // 已
    localparam [6:0] G_YUN    = 7'h5D;   // 运
    localparam [6:0] G_XING   = 7'h5E;   // 行
    localparam [6:0] G_CAI    = 7'h5F;   // 彩
    localparam [6:0] G_BIAN   = 7'h60;   // 边
    localparam [6:0] G_YUAN   = 7'h61;   // 缘
    localparam [6:0] G_YAN    = 7'h62;   // 颜
    localparam [6:0] G_CHENG  = 7'h63;   // 橙
    localparam [6:0] G_HUANG  = 7'h64;   // 黄
    localparam [6:0] G_LU     = 7'h65;   // 绿
    localparam [6:0] G_QING   = 7'h66;   // 青
    localparam [6:0] G_LAN    = 7'h67;   // 蓝
    localparam [6:0] G_ZI     = 7'h68;   // 紫
    localparam [6:0] G_FAN    = 7'h69;   // 反
    localparam [6:0] G_XIANG  = 7'h6A;   // 向
    localparam [6:0] G_DUO    = 7'h6B;   // 多
    localparam [6:0] G_HONG2  = 7'h6C;   // 虹
    localparam [6:0] G_RE     = 7'h6D;   // 热
    localparam [6:0] G_LI     = 7'h6E;   // 力
    localparam [6:0] G_TU     = 7'h6F;   // 图
    localparam [6:0] G_XIANG2 = 7'h70;   // 像
    localparam [6:0] G_KA     = 7'h71;   // 卡
    localparam [6:0] G_TONG   = 7'h72;   // 通
    localparam [6:0] G_JING   = 7'h73;   // 镜
    localparam [6:0] G_LEI    = 7'h74;   // 雷
    localparam [6:0] G_DA     = 7'h75;   // 达

    function [13:0] CC;                  // 中文全宽格
        input [6:0] c;
        begin CC = {c, 7'd0}; end
    endfunction
    function [13:0] CA;                  
        input [6:0] a;
        input [6:0] b;
        begin CA = {a, b}; end
    endfunction
    function [6:0] AD;                  
        input [3:0] d;
        begin AD = 7'h03 + {3'd0, d}; end
    endfunction
    function [15:0] BCD4;                
        input [10:0] v;
        integer i;
        reg [26:0] acc;
        begin
            acc = {16'd0, v};
            for (i = 0; i < 11; i = i + 1) begin
                if (acc[26:23] >= 4'd5) acc[26:23] = acc[26:23] + 4'd3;
                if (acc[22:19] >= 4'd5) acc[22:19] = acc[22:19] + 4'd3;
                if (acc[18:15] >= 4'd5) acc[18:15] = acc[18:15] + 4'd3;
                if (acc[14:11] >= 4'd5) acc[14:11] = acc[14:11] + 4'd3;
                acc = acc << 1;
            end
            BCD4 = acc[26:11];
        end
    endfunction
    function [15:0] BCD4_14;      
        input [13:0] v;
        integer i;
        reg [29:0] acc;
        begin
            acc = {16'd0, v};
            for (i = 0; i < 14; i = i + 1) begin
                if (acc[29:26] >= 4'd5) acc[29:26] = acc[29:26] + 4'd3;
                if (acc[25:22] >= 4'd5) acc[25:22] = acc[25:22] + 4'd3;
                if (acc[21:18] >= 4'd5) acc[21:18] = acc[21:18] + 4'd3;
                if (acc[17:14] >= 4'd5) acc[17:14] = acc[17:14] + 4'd3;
                acc = acc << 1;
            end
            BCD4_14 = acc[29:14];
        end
    endfunction

    localparam [13:0] BLK = 14'd0;

    //前缀
    localparam [223:0] PFX_ZUO   = {{11{BLK}}, CA(A_COL,A_SP), CC(G_MIAN), CC(G_HUA),   CC(G_QU),  CC(G_ZUO)  };
    localparam [223:0] PFX_YOU   = {{11{BLK}}, CA(A_COL,A_SP), CC(G_MIAN), CC(G_HUA),   CC(G_QU),  CC(G_YOU)  };
    localparam [223:0] PFX_ZHONG = {{11{BLK}}, CA(A_COL,A_SP), CC(G_BO),   CC(G_LV),    CC(G_ZHI), CC(G_ZHONG)};
    localparam [223:0] PFX_DANG  = {{11{BLK}}, CA(A_COL,A_SP), CC(G_ZHI),  CC(G_YU),    CC(G_QIAN),CC(G_DANG) };
    localparam [223:0] PFX_MO    = {{11{BLK}}, CA(A_COL,A_SP), CC(G_TAI),  CC(G_ZHUANG),CC(G_SHI), CC(G_MO)   };
    localparam [223:0] PFX_BU    = {{11{BLK}}, CA(A_COL,A_SP), CC(G_JIN),  CC(G_BU),    CC(G_ZHI), CC(G_YU)   };
    localparam [223:0] PFX_BIAN  = {{11{BLK}}, CA(A_COL,A_SP), CC(G_SE),   CC(G_YAN),   CC(G_YUAN),CC(G_BIAN) };  

    //内容名
    localparam [223:0] LBL_HUI   = {{9{BLK}}, CC(G_DU),  CC(G_HUI),  {5{BLK}}};
    localparam [223:0] LBL_INV   = {{6{BLK}}, CA(A_l,A_SP), CA(A_b,A_e), CA(A_s,A_o), CC(G_XIANG), CC(G_FAN), {5{BLK}}};
                                   //反向sobel
    localparam [223:0] LBL_QIANGDU = {{9{BLK}}, CC(G_DU), CC(G_QIANG), {5{BLK}}};
                                   //强度灰度
    localparam [223:0] LBL_COLOR = {{7{BLK}}, CC(G_JIA), CC(G_DIE),  CC(G_SE),   CC(G_CAI),{5{BLK}}};
                                   //彩色叠加
    localparam [223:0] LBL_DUOSE = {{7{BLK}}, CC(G_JIA), CC(G_DIE),  CC(G_SE),   CC(G_DUO),{5{BLK}}};
                                   //多色叠加
    localparam [223:0] LBL_RAINBOW = {{7{BLK}}, CC(G_JIA), CC(G_DIE), CC(G_HONG2), CC(G_CAI), {5{BLK}}};
                                   //彩虹叠加
    localparam [223:0] LBL_HEAT = {{7{BLK}}, CC(G_XIANG2), CC(G_TU), CC(G_LI), CC(G_RE), {5{BLK}}};
                                   //热力图像
    localparam [223:0] LBL_CARTOON = {{7{BLK}}, CC(G_JING), CC(G_LV), CC(G_TONG), CC(G_KA), {5{BLK}}};
                                   //卡通滤镜
    localparam [223:0] LBL_RADAR = {{7{BLK}}, CC(G_SHI), CC(G_MO), CC(G_DA), CC(G_LEI), {5{BLK}}};
                                   //雷达模式
    localparam [223:0] LBL_SOBEL = {{8{BLK}}, CA(A_l,A_SP), CA(A_b,A_e), CA(A_S,A_o), {5{BLK}}};
    localparam [223:0] LBL_CANNY = {{8{BLK}}, CA(A_y,A_SP), CA(A_n,A_n), CA(A_C,A_a), {5{BLK}}};


//瞬时消息,3秒后消失
    localparam [3:0] M_NONE = 4'd0, M_MEDIAN = 4'd1, M_THR = 4'd2, M_SIGN = 4'd3, M_STEP = 4'd4,
                     M_THR_C = 4'd5, M_SIGN_C = 4'd6, M_STEP_C = 4'd7, M_COLOR = 4'd8;   // ★v9 选色

    reg  [3:0]  msg_type;
    reg  [27:0] msg_cnt;
    wire        msg_on = (msg_type != M_NONE) && (msg_cnt != 28'd0);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            msg_type <= M_NONE;
            msg_cnt  <= 28'd0;
        end else if (ev_median) begin
            msg_type <= M_MEDIAN;  msg_cnt <= MSG_CYCLES;
        end else if (ev_thr || ev_mode_def) begin
            msg_type <= M_THR;     msg_cnt <= MSG_CYCLES;
        end else if (ev_sign || ev_mode_sign) begin
            msg_type <= M_SIGN;    msg_cnt <= MSG_CYCLES;
        end else if (ev_step || ev_mode_step) begin
            msg_type <= M_STEP;    msg_cnt <= MSG_CYCLES;
        end else if (ev_thr_c || ev_mode_def_c) begin
            msg_type <= M_THR_C;   msg_cnt <= MSG_CYCLES;      
        end else if (ev_sign_c || ev_mode_sign_c) begin
            msg_type <= M_SIGN_C;  msg_cnt <= MSG_CYCLES;      
        end else if (ev_step_c || ev_mode_step_c) begin
            msg_type <= M_STEP_C;  msg_cnt <= MSG_CYCLES;      
        end else if (ev_color || ev_cmode_on) begin
            msg_type <= M_COLOR;   msg_cnt <= MSG_CYCLES;      
        end else if (msg_cnt != 28'd0) begin
            msg_cnt  <= msg_cnt - 28'd1;
            if (msg_cnt == 28'd1) msg_type <= M_NONE;
        end else begin
            msg_type <= M_NONE;
        end
    end

    wire [223:0] msg_median = PFX_ZHONG | (median_en ? {{10{BLK}}, CC(G_KAI),  {5{BLK}}}
                                                      : {{10{BLK}}, CC(G_GUAN), {5{BLK}}});
    wire [223:0] msg_sign   = PFX_MO    | (sign      ? {{10{BLK}}, CC(G_JIAN), {5{BLK}}}
                                                      : {{10{BLK}}, CC(G_JIA),  {5{BLK}}});

    wire [15:0] thr_bcd = BCD4(threshold);
    wire [3:0]  thr_d3 = thr_bcd[15:12], thr_d2 = thr_bcd[11:8], thr_d1 = thr_bcd[7:4], thr_d0 = thr_bcd[3:0];
    wire [13:0] thr_c5 = (thr_d3 != 4'd0) ? CA(AD(thr_d3), AD(thr_d2)) :
                         (thr_d2 != 4'd0) ? CA(AD(thr_d2), AD(thr_d1)) :
                         (thr_d1 != 4'd0) ? CA(AD(thr_d1), AD(thr_d0)) :
                                            CA(AD(thr_d0), A_SP);
    wire [13:0] thr_c6 = (thr_d3 != 4'd0) ? CA(AD(thr_d1), AD(thr_d0)) :
                         (thr_d2 != 4'd0) ? CA(AD(thr_d0), A_SP)       : BLK;
    wire [223:0] msg_thr = PFX_DANG | {{9{BLK}}, thr_c6, thr_c5, {5{BLK}}};

    wire [13:0] stp_c5 = (step_idx == 3'd0) ? CA(AD(4'd2), A_SP) :
                         (step_idx == 3'd1) ? CA(AD(4'd4), A_SP) :
                         (step_idx == 3'd2) ? CA(AD(4'd8), A_SP) :
                         (step_idx == 3'd3) ? CA(AD(4'd1), AD(4'd6)) :
                                              CA(AD(4'd3), AD(4'd2));
    wire [223:0] msg_step = PFX_BU | {{10{BLK}}, stp_c5, {5{BLK}}};

    function [223:0] MK_PFX_C;
        input [6:0] c0, c1, c2, c3;      
        begin
            MK_PFX_C = {{8{BLK}},
                        CA(A_RP, A_COL),
                        CA(A_n,  A_y  ),
                        CA(A_a,  A_n  ),
                        CA(A_LP, A_C  ),
                        CC(c3), CC(c2), CC(c1), CC(c0)};
        end
    endfunction

    //当前阈值(Canny): N
    wire [15:0] cth_bcd = BCD4(canny_thr);
    wire [3:0]  cth_d3 = cth_bcd[15:12], cth_d2 = cth_bcd[11:8], cth_d1 = cth_bcd[7:4], cth_d0 = cth_bcd[3:0];
    wire [13:0] cth_c8 = (cth_d3 != 4'd0) ? CA(AD(cth_d3), AD(cth_d2)) :
                         (cth_d2 != 4'd0) ? CA(AD(cth_d2), AD(cth_d1)) :
                         (cth_d1 != 4'd0) ? CA(AD(cth_d1), AD(cth_d0)) :
                                            CA(AD(cth_d0), A_SP);
    wire [13:0] cth_c9 = (cth_d3 != 4'd0) ? CA(AD(cth_d1), AD(cth_d0)) :
                         (cth_d2 != 4'd0) ? CA(AD(cth_d0), A_SP)       : BLK;
    wire [223:0] msg_thr_c = MK_PFX_C(G_DANG, G_QIAN, G_YU, G_ZHI)
                           | {{6{BLK}}, cth_c9, cth_c8, {8{BLK}}};

    //模式状态(Canny): 加/减
    wire [223:0] msg_sign_c = MK_PFX_C(G_MO, G_SHI, G_ZHUANG, G_TAI)
                            | {{7{BLK}}, (sign_c ? CC(G_JIAN) : CC(G_JIA)), {8{BLK}}};

    //阈值步进(Canny): N
    wire [13:0] cstp_c8 = (step_c == 3'd0) ? CA(AD(4'd2), A_SP) :
                          (step_c == 3'd1) ? CA(AD(4'd4), A_SP) :
                          (step_c == 3'd2) ? CA(AD(4'd8), A_SP) :
                          (step_c == 3'd3) ? CA(AD(4'd1), AD(4'd6)) :
                                             CA(AD(4'd3), AD(4'd2));
    wire [223:0] msg_step_c = MK_PFX_C(G_YU, G_ZHI, G_BU, G_JIN)
                            | {{8{BLK}}, cstp_c8, {8{BLK}}};

    wire [13:0] col_cell = (color_idx == 3'd0) ? CC(G_HONG)  :   // 红
                           (color_idx == 3'd1) ? CC(G_CHENG) :   // 橙
                           (color_idx == 3'd2) ? CC(G_HUANG) :   // 黄
                           (color_idx == 3'd3) ? CC(G_LU)    :   // 绿
                           (color_idx == 3'd4) ? CC(G_QING)  :   // 青
                           (color_idx == 3'd5) ? CC(G_LAN)   :   // 蓝
                                                 CC(G_ZI);       // 紫
    wire [223:0] msg_color = PFX_BIAN | {{10{BLK}}, col_cell, {5{BLK}}};

    wire [223:0] msg_body = (msg_type == M_MEDIAN) ? msg_median :
                            (msg_type == M_THR_C)  ? msg_thr_c  :
                            (msg_type == M_SIGN_C) ? msg_sign_c :
                            (msg_type == M_STEP_C) ? msg_step_c :
                            (msg_type == M_COLOR)  ? msg_color  :
                            (msg_type == M_THR)    ? msg_thr    :
                            (msg_type == M_SIGN)   ? msg_sign   :
                            (msg_type == M_STEP)   ? msg_step   : 224'd0;

    assign line_msg = msg_on ? msg_body : 224'd0;     

    function [223:0] MK_FPS;
        input [15:0] bcd;      
        reg [3:0] h, t, u, x;
        begin
            h = bcd[15:12]; t = bcd[11:8]; u = bcd[7:4]; x = bcd[3:0];
            MK_FPS = {{11{BLK}},
                      CA(A_DOT, AD(x)),
                      CA(AD(t), AD(u)),
                      CA(A_SP, (h == 4'd0) ? A_SP : AD(h)),
                      CA(A_S, A_COL),
                      CA(A_F, A_P)};
        end
    endfunction

    assign line_fps_l = MK_FPS(BCD4_14(fps_l));        // 左半摄像头帧率
    assign line_fps_r = MK_FPS(BCD4_14(fps_r));        // 右半画面帧率

    wire [223:0] lbl_ovl = (disp_mode == 4'd0) ? LBL_SOBEL   :
                           (disp_mode == 4'd1) ? LBL_INV     :
                           (disp_mode == 4'd2) ? LBL_QIANGDU :
                           (disp_mode == 4'd3) ? LBL_HEAT    :
                           (disp_mode == 4'd4) ? LBL_RADAR   :
                           (disp_mode == 4'd5) ? LBL_CARTOON :
                           (disp_mode == 4'd6) ? LBL_COLOR   :
                           (disp_mode == 4'd7) ? LBL_DUOSE   :
                           (disp_mode == 4'd8) ? LBL_RAINBOW : LBL_HEAT;  
    wire [223:0] lbl_l   = split_mode ? lbl_ovl : LBL_HUI;
    wire [223:0] lbl_r   = split_mode ? LBL_CANNY : lbl_ovl;

    assign line_left  = PFX_ZUO | lbl_l;
    assign line_right = PFX_YOU | lbl_r;

    wire [3:0] uh1, uh0, un1, un0, us1, us0;

    osd_uptime #(
        .CLK_HZ (CLK_HZ)
    ) u_uptime (
        .clk(clk), .rst_n(rst_n),
        .h1(uh1), .h0(uh0), .n1(un1), .n0(un0), .s1(us1), .s0(us0)
    );

    assign line_up = {{8{BLK}},
                      CA(AD(us0), A_SP),        // 格7
                      CA(A_COL, AD(us1)),       // 格6
                      CA(AD(un1), AD(un0)),     // 格5
                      CA(AD(uh0), A_COL),       // 格4
                      CA(A_SP, AD(uh1)),        // 格3
                      CC(G_XING),               // 格2
                      CC(G_YUN),                // 格1
                      CC(G_YI)};                // 格0
endmodule

module osd_uptime #(
    parameter integer CLK_HZ = 74_250_000
)(
    input  wire        clk,
    input  wire        rst_n,
    output reg  [3:0]  h1, h0,      // 时
    output reg  [3:0]  n1, n0,      // 分
    output reg  [3:0]  s1, s0       // 秒
);

    reg  [26:0] div_cnt;
    wire        tick = (div_cnt >= (CLK_HZ - 1));
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)    div_cnt <= 27'd0;
        else if (tick) div_cnt <= 27'd0;
        else           div_cnt <= div_cnt + 27'd1;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin s1 <= 4'd0; s0 <= 4'd0; end
        else if (tick) begin
            if (s0 == 4'd9) begin
                s0 <= 4'd0;
                s1 <= (s1 == 4'd5) ? 4'd0 : (s1 + 4'd1);
            end else s0 <= s0 + 4'd1;
        end
    end
    wire sec_carry = tick & (s1 == 4'd5) & (s0 == 4'd9);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin n1 <= 4'd0; n0 <= 4'd0; end
        else if (sec_carry) begin
            if (n0 == 4'd9) begin
                n0 <= 4'd0;
                n1 <= (n1 == 4'd5) ? 4'd0 : (n1 + 4'd1);
            end else n0 <= n0 + 4'd1;
        end
    end
    wire min_carry = sec_carry & (n1 == 4'd5) & (n0 == 4'd9);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin h1 <= 4'd0; h0 <= 4'd0; end
        else if (min_carry) begin
            if ((h1 == 4'd9) && (h0 == 4'd9)) begin h1 <= 4'd0; h0 <= 4'd0; end
            else if (h0 == 4'd9)              begin h0 <= 4'd0; h1 <= h1 + 4'd1; end
            else                                   h0 <= h0 + 4'd1;
        end
    end

endmodule