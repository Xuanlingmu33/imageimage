module key_mode_fsm #(
    parameter integer DEBOUNCE  = 1_485_000,        
    parameter integer T_GAP     = 2_227_500,        
    parameter integer T_MINCLK  = 4_455_000,        
                                                    
    parameter integer T_LONG    = 59_400_000,       
    parameter integer T_IDLE    = 371_250_000,      
    parameter integer THR_INIT  = 8,                
    parameter integer THR_MIN   = 2,                
    parameter integer THR_MAX   = 2040,             
    parameter integer STEP_INIT = 0,                

    parameter integer WITH_SRC  = 0,                
                                                    
    parameter integer START_MODE= 0     //长按短按区分逻辑模块,加入消抖区间分辨0.8秒的长按逻辑和短按逻辑          
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        key,           

    output reg         ev_thr,          
    output reg         ev_sign,         
    output reg         ev_step,         
    output reg         ev_src,          
                                        
    output reg         ev_mode_def,     
    output reg         ev_mode_sign,    
    output reg         ev_mode_step,    
    output reg         ev_mode_src,     

    output reg         key_press,       
    output reg         key_release,     

    output reg  [1:0]  mode,            
    output reg         sign,            
    output reg  [2:0]  step_idx,        
    output wire [5:0]  step_val,        
    output reg  [10:0] thr_cur          
);

    localparam [10:0] THR_INIT_L  = THR_INIT;
    localparam [10:0] THR_MIN_L   = THR_MIN;
    localparam [10:0] THR_MAX_L   = THR_MAX;
    localparam [2:0]  STEP_INIT_L = STEP_INIT;
    localparam [1:0]  M_THR = 2'd0, M_SGN = 2'd1, M_STP = 2'd2, M_SRC = 2'd3;
    localparam [1:0]  START = START_MODE[1:0];
    localparam        HAS_SRC = (WITH_SRC != 0);

    //模式循环顺序:阈值→加减→步进→（换源）→阈值
    wire [1:0] mode_next = (mode == M_STP) ? (HAS_SRC ? M_SRC : M_THR) :
                           (mode == M_SRC) ? M_THR :
                           (mode == M_THR) ? M_SGN : M_STP;

    assign step_val = (step_idx == 3'd0) ? 6'd2  :
                      (step_idx == 3'd1) ? 6'd4  :
                      (step_idx == 3'd2) ? 6'd8  :
                      (step_idx == 3'd3) ? 6'd16 : 6'd32;

    wire [11:0] thr_up = {1'b0, thr_cur} + {6'd0, step_val};
//电平消抖
    reg  key_meta, key_sync, key_stable, key_stable_d;
    reg  [22:0] db_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            key_meta <= 1'b0; key_sync <= 1'b0;
            key_stable <= 1'b0; key_stable_d <= 1'b0; db_cnt <= 23'd0;
        end else begin
            key_meta     <= key;
            key_sync     <= key_meta;
            key_stable_d <= key_stable;
            if (key_sync == key_stable)      db_cnt <= 23'd0;
            else if (db_cnt >= (DEBOUNCE-1)) begin key_stable <= key_sync; db_cnt <= 23'd0; end
            else                             db_cnt <= db_cnt + 23'd1;
        end
    end
//抗抖动按压窗
    reg        pressed, pressed_d;
    reg [24:0] gap_cnt;
    wire       stb_fall = key_stable_d & ~key_stable;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pressed <= 1'b0; pressed_d <= 1'b0; gap_cnt <= 25'd0;
        end else begin
            pressed_d <= pressed;
            if (key_stable) begin
                pressed <= 1'b1; gap_cnt <= 25'd0;
            end else if (pressed) begin
                if (stb_fall)              gap_cnt <= 25'd0;
                else if (gap_cnt >= T_GAP) pressed <= 1'b0;
                else                       gap_cnt <= gap_cnt + 25'd1;
            end
        end
    end

    wire press_start = pressed & ~pressed_d;      // 按下那一刻
    wire release_ev  = ~pressed & pressed_d;      // 松手那一刻
    reg [27:0] dur;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)           dur <= 28'd0;
        else if (press_start) dur <= 28'd0;
        else if (pressed)     dur <= (dur == 28'hFFFFFFF) ? dur : (dur + 28'd1);
    end

// 4) 长按,单击判定

    reg  long_fired;                                                   
    wire hit_long  = pressed & (dur >= T_LONG) & ~long_fired;          
    wire is_noise  = release_ev & (dur <  T_MINCLK);                   
    wire is_click  = release_ev & ~long_fired & (dur >= T_MINCLK);     
    reg [28:0] idle_cnt;
    wire       idle_end = (idle_cnt >= T_IDLE);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mode <= START; sign <= 1'b0; step_idx <= STEP_INIT_L; thr_cur <= THR_INIT_L;
            ev_thr <= 1'b0; ev_sign <= 1'b0; ev_step <= 1'b0; ev_src <= 1'b0;
            ev_mode_def <= 1'b0; ev_mode_sign <= 1'b0; ev_mode_step <= 1'b0; ev_mode_src <= 1'b0;
            key_press <= 1'b0; key_release <= 1'b0;
            long_fired <= 1'b0; idle_cnt <= 29'd0;
        end else begin
            ev_thr <= 1'b0; ev_sign <= 1'b0; ev_step <= 1'b0; ev_src <= 1'b0;
            ev_mode_def <= 1'b0; ev_mode_sign <= 1'b0; ev_mode_step <= 1'b0; ev_mode_src <= 1'b0;
            key_press   <= press_start;
            key_release <= release_ev;

            if (press_start) long_fired <= 1'b0;

            if (hit_long) begin
                long_fired <= 1'b1;
                mode <= mode_next;
                case (mode_next)
                    M_THR:    ev_mode_def  <= 1'b1;
                    M_SGN:    ev_mode_sign <= 1'b1;
                    M_STP:    ev_mode_step <= 1'b1;
                    default:  ev_mode_src  <= 1'b1;   
                endcase
            end
            else if (is_click) begin
                case (mode)
                    M_THR: begin
                        ev_thr <= 1'b1;
                        if (!sign) thr_cur <= (thr_up > THR_MAX_L) ? THR_MAX_L : thr_up[10:0];
                        else       thr_cur <= (thr_cur < (THR_MIN_L + step_val[5:0]))
                                              ? THR_MIN_L : (thr_cur - step_val);
                    end
                    M_SGN: begin sign <= ~sign; ev_sign <= 1'b1; end
                    M_STP: begin
                        step_idx <= (step_idx >= 3'd4) ? 3'd0 : (step_idx + 3'd1);
                        ev_step  <= 1'b1;
                    end
                    default: begin ev_src <= 1'b1; end  
                endcase
            end
            if (pressed || press_start || release_ev) idle_cnt <= 29'd0;
            else if (idle_cnt < T_IDLE)               idle_cnt <= idle_cnt + 29'd1;

            if (idle_end && (mode != START) && !pressed) begin
                mode      <= START;
                idle_cnt  <= 29'd0;
                case (START)
                    M_THR:   ev_mode_def  <= 1'b1;
                    M_SGN:   ev_mode_sign <= 1'b1;
                    M_STP:   ev_mode_step <= 1'b1;
                    default: ev_mode_src  <= 1'b1;
                endcase
            end
        end
    end

endmodule
module key2_fsm #(
    parameter integer DEBOUNCE  = 1_485_000,        
    parameter integer T_GAP     = 2_227_500,        
    parameter integer T_MINCLK  = 4_455_000,        
    parameter integer T_LONG    = 59_400_000,       
    parameter integer T_IDLE    = 371_250_000,      
    parameter integer N_COLOR   = 7,                
    parameter integer M_OVERLAY = 6                 
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        key,             
    input  wire [3:0]  disp_mode,       // 当前档位（0 二值 / 1 反向 / 2 强度 / 3 热力图像 / 4 雷达 / 5 卡通 / 6 彩色叠加 / 7 多色叠加 / 8 彩虹叠加）


    output reg         ev_disp,        
    output reg         ev_color,       
    output reg         ev_cmode_on,    
    output reg         ev_cmode_off,   


    output reg         color_mode,     
    output reg  [2:0]  color_idx       
);

    localparam [2:0] N_COLOR_L = N_COLOR[2:0];
    reg  key_meta, key_sync, key_stable, key_stable_d;
    reg  [22:0] db_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            key_meta <= 1'b0; key_sync <= 1'b0;
            key_stable <= 1'b0; key_stable_d <= 1'b0; db_cnt <= 23'd0;
        end else begin
            key_meta     <= key;
            key_sync     <= key_meta;
            key_stable_d <= key_stable;
            if (key_sync == key_stable)      db_cnt <= 23'd0;
            else if (db_cnt >= (DEBOUNCE-1)) begin key_stable <= key_sync; db_cnt <= 23'd0; end
            else                             db_cnt <= db_cnt + 23'd1;
        end
    end
    reg        pressed, pressed_d;
    reg [24:0] gap_cnt;
    wire       stb_fall = key_stable_d & ~key_stable;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pressed <= 1'b0; pressed_d <= 1'b0; gap_cnt <= 25'd0;
        end else begin
            pressed_d <= pressed;
            if (key_stable) begin
                pressed <= 1'b1; gap_cnt <= 25'd0;
            end else if (pressed) begin
                if (stb_fall)              gap_cnt <= 25'd0;
                else if (gap_cnt >= T_GAP) pressed <= 1'b0;
                else                       gap_cnt <= gap_cnt + 25'd1;
            end
        end
    end

    wire press_start = pressed & ~pressed_d;      // 按下那一刻
    wire release_ev  = ~pressed & pressed_d;      // 松手那一刻
    reg [27:0] dur;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)           dur <= 28'd0;
        else if (press_start) dur <= 28'd0;
        else if (pressed)     dur <= (dur == 28'hFFFFFFF) ? dur : (dur + 28'd1);
    end
    reg  long_fired;
    wire hit_long  = pressed & (dur >= T_LONG) & ~long_fired;
    wire is_noise  = release_ev & (dur <  T_MINCLK);
    wire is_click  = release_ev & ~long_fired & (dur >= T_MINCLK);
    reg [28:0] idle_cnt;
    wire       idle_end = (idle_cnt >= T_IDLE);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            color_mode  <= 1'b0;                 
            color_idx   <= 3'd0;                
            ev_disp     <= 1'b0; ev_color <= 1'b0;
            ev_cmode_on <= 1'b0; ev_cmode_off <= 1'b0;
            long_fired  <= 1'b0; idle_cnt <= 29'd0;
        end else begin
            ev_disp <= 1'b0; ev_color <= 1'b0;
            ev_cmode_on <= 1'b0; ev_cmode_off <= 1'b0;

            if (press_start) long_fired <= 1'b0;
            if (hit_long) begin
                long_fired <= 1'b1;
                if (color_mode) begin                
                    color_mode  <= 1'b0;
                    ev_cmode_off <= 1'b1;
                end else if (disp_mode == M_OVERLAY[3:0]) begin
                    color_mode  <= 1'b1;            
                    ev_cmode_on <= 1'b1;
                end

            end
            else if (is_click) begin
                if (color_mode) begin
                    color_idx <= (color_idx >= (N_COLOR_L - 3'd1)) ? 3'd0 : (color_idx + 3'd1);
                    ev_color  <= 1'b1;
                end else begin
                    ev_disp <= 1'b1;
                end
            end
            if (!color_mode) begin
                idle_cnt <= 29'd0;
            end else if (pressed || press_start || release_ev) begin
                idle_cnt <= 29'd0;
            end else if (idle_cnt < T_IDLE) begin
                idle_cnt <= idle_cnt + 29'd1;
            end

            if (color_mode && idle_end && !pressed) begin
                color_mode   <= 1'b0;
                idle_cnt     <= 29'd0;
                ev_cmode_off <= 1'b1;
            end
        end
    end

endmodule
