module rgb565_to_888 (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [15:0] i_data,     
    input  wire        i_valid,
    input  wire        i_hs,
    input  wire        i_vs,
    output reg  [23:0] o_data,     
    output reg         o_valid,
    output reg         o_hs,
    output reg         o_vs
);
    wire [4:0] r5 = i_data[15:11];
    wire [5:0] g6 = i_data[10:5];
    wire [4:0] b5 = i_data[4:0];

    wire [7:0] r8 = {r5, r5[4:2]};
    wire [7:0] g8 = {g6, g6[5:4]};
    wire [7:0] b8 = {b5, b5[4:2]};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            o_data  <= 24'd0;
            o_valid <= 1'b0;
            o_hs    <= 1'b0;
            o_vs    <= 1'b0;
        end else begin
            o_data  <= {b8, g8, r8};
            o_valid <= i_valid;
            o_hs    <= i_hs;
            o_vs    <= i_vs;
        end
    end
endmodule
