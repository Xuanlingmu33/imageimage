module m2m3_pipeline (
    input  wire        clk,        
    input  wire        rst_n,
    input  wire [7:0]  i_r,
    input  wire [7:0]  i_g,
    input  wire [7:0]  i_b,
    input  wire        i_de,
    input  wire        i_hs,
    input  wire        i_vs,
    input  wire [1:0]  left_sel,
    input  wire [1:0]  right_sel,
    input  wire        key3,

    output wire [23:0] o_rgb,        // {B,G,R}
    output wire        o_de,
    output wire        o_hs,
    output wire        o_vs
);
    wire c_hs = i_de;   
    wire c_vs = ~i_vs;   
    wire [7:0] g_gray;
    wire       g_vld, g_hs, g_vs;

    rgb2gray
    #(
        .PROC_METHOD ("FORMULA")    
    ) u_rgb2gray (
        .clk       (clk    ),
        .sys_rst_n (rst_n  ),
        .rgb_valid (i_de   ),       
        .rgb_hs    (c_hs   ),       
        .rgb_vs    (c_vs   ),       
        .red_8b_i  (i_r    ),       
        .green_8b_i(i_g    ),
        .blue_8b_i (i_b    ),
        .gray_8b_o (g_gray ),
        .gray_valid(g_vld  ),
        .gray_hs   (g_hs   ),
        .gray_vs   (g_vs   )
    );

    wire [15:0] gray565 = {g_gray[7:3], g_gray[7:2], g_gray[7:3]};
    reg  [15:0] color565_r;
    reg         color_vld_r, color_vs_r;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            color565_r <= 16'd0;
            color_vld_r <= 1'b0;
            color_vs_r  <= 1'b0;
        end else begin
            color565_r <= {i_r[7:3], i_g[7:2], i_b[7:3]};   // RGB888 → RGB565
            color_vld_r <= i_de;
            color_vs_r  <= c_vs;
        end
    end
    wire key3_flag;                     // 消抖后的单拍脉冲
    key_filter u_key3_filter (
        .sys_clk  (clk        ),
        .sys_rst_n(rst_n      ),
        .key_in   (~key3      ),       
        .key_flag (key3_flag  )
    );

    reg key3_state;                   
    always @(posedge clk or negedge rst_n)
        if (!rst_n)            key3_state <= 1'b0;
        else if (key3_flag)    key3_state <= ~key3_state;   
    wire split_swap_sync;
    mux_sync #(.WIDTH(1)) u_latch_key3 (
        .clk      (clk            ),
        .sys_rst_n(rst_n          ),
        .sel      (key3_state     ),
        .vs_in    (g_vs           ),   
        .d0       (1'b0           ),
        .d1       (1'b1           ),
        .valid_in (1'b1           ),
        .q        (split_swap_sync),
        .q_valid  (               )
    );
    wire [15:0] s_left, s_right;
    wire        s_lvld, s_rvld, s_lvs, s_rvs;

    split_src_mux
    #(
        .DATA_WIDTH (16),
        .N_SRC      (4 ),
        .SEL_W      (2 )
    ) u_src_mux (
        .clk        (clk    ),
        .sys_rst_n  (rst_n  ),
        .src_data   ({32'd0, color565_r, gray565}),
        .src_valid  ({2'b00, color_vld_r, g_vld  }),
        .src_vs     ({2'b00, color_vs_r,  g_vs   }),
        .left_sel_r (left_sel  ),       
        .right_sel_r(right_sel ),       
        .swap_r     (split_swap_sync),  
        .vs_in      (g_vs      ),       
        .left_data  (s_left    ),
        .right_data (s_right   ),
        .left_valid (s_lvld    ),
        .right_valid(s_rvld    ),
        .left_vs    (s_lvs     ),
        .right_vs   (s_rvs     )
    );
    wire        d_de, d_hs, d_vs, d_line_start, d_frame_start;
    wire [11:0] d_hcnt;
    wire [10:0] d_vcnt;

    reg         ivs_d;
    always @(posedge clk or negedge rst_n)
        if (!rst_n) ivs_d <= 1'b0;
        else        ivs_d <= i_vs;

    wire frame_align = i_vs && !ivs_d;    

    disp_timing
    #(
        .H_ACTIVE (1280), .H_FP (110), .H_SYNC (40), .H_BP (220),
        .V_ACTIVE (720 ), .V_FP (5  ), .V_SYNC (5 ), .V_BP (20 ),
        .ALIGN_V  (725 )                   
    ) u_disp_timing (
        .clk        (clk          ),
        .rst_n      (rst_n        ),
        .align      (frame_align  ),        
        .de         (d_de         ),
        .hs         (d_hs         ),
        .vs         (d_vs         ),
        .h_cnt      (d_hcnt       ),
        .v_cnt      (d_vcnt       ),
        .rd_en      (             ),
        .line_start (d_line_start ),
        .frame_start(d_frame_start)
    );

    wire [15:0] t_pix;
    wire        t_vld;

    image_stitche_x
    #(
        .DATA_WIDTH       (16  ),
        .IMAGE1_WIDTH_IN  (640 ),
        .IMAGE1_HEIGHT_IN (480 ),
        .IMAGE2_WIDTH_IN  (640 ),
        .IMAGE2_HEIGHT_IN (480 ),
        .IMAGE_WIDTH_OUT  (1280),
        .IMAGE_HEIGHT_OUT (480 ),
        .LINE_WIDTH       (1280),
        .ALIGN_ROW_DLY    (0   ),
        .ALIGN_FINE_DLY   (1   ),
        .SEL_DIRECT       (1   )
    ) u_stitche (
        .clk_image1_in      (clk     ),
        .clk_image2_in      (clk     ),
        .clk_image_out      (clk     ),
        .sys_rst_n          (rst_n   ),
        .image1_data_pixel_i(s_left  ),
        .image1_data_valid_i(s_lvld  ),
        .image1_data_vs_i   (s_lvs   ),
        .image2_data_pixel_i(s_right ),
        .image2_data_valid_i(s_rvld  ),
        .image2_data_vs_i   (s_rvs   ),
        .data_out_ready_i   (d_de    ),      
        .sel_swap           (1'b0    ),      
        .data_pixel_o       (t_pix   ),
        .data_valid_o       (t_vld   )
    );
    wire [15:0] b_data;
    wire        b_de, b_hs, b_vs_unused;
    wire [10:0] b_vcnt;

    black_border
    #(
        .H_ACTIVE (1280     ),
        .V_IN     (480      ),
        .V_OUT    (720      ),
        .BLACK    (16'h0000 )
    ) u_black_border (
        .clk     (clk          ),
        .rst_n   (rst_n        ),
        .i_data  (t_pix        ),
        .i_valid (t_vld        ),
        .i_hs    (d_hs         ),
        .i_vs    (d_frame_start),
        .o_data  (b_data       ),
        .o_de    (b_de         ),
        .o_hs    (b_hs         ),
        .o_vs    (b_vs_unused  ),
        .o_v_cnt (b_vcnt       )
    );
    reg d_vs_r;
    always @(posedge clk or negedge rst_n)
        if (!rst_n) d_vs_r <= 1'b0;
        else        d_vs_r <= d_vs;

    rgb565_to_888 u_rgb565_to_888 (
        .clk    (clk    ),
        .rst_n  (rst_n  ),
        .i_data (b_data ),
        .i_valid(b_de   ),
        .i_hs   (b_hs   ),
        .i_vs   (d_vs_r ),
        .o_data (o_rgb  ),
        .o_valid(o_de   ),
        .o_hs   (o_hs   ),
        .o_vs   (o_vs   )
    );

endmodule
