module image_stitche_x
#(
  parameter DATA_WIDTH        = 16,   

  parameter IMAGE1_WIDTH_IN   = 320,
  parameter IMAGE1_HEIGHT_IN  = 480,

  parameter IMAGE2_WIDTH_IN   = 320,
  parameter IMAGE2_HEIGHT_IN  = 480,

  parameter IMAGE_WIDTH_OUT   = 640,
  parameter IMAGE_HEIGHT_OUT  = 480,

  parameter LINE_WIDTH        = 640,
  parameter ALIGN_ROW_DLY     = 4,
  parameter ALIGN_FINE_DLY    = 6,
  parameter SEL_DIRECT        = 1
)
(
  input                      clk_image1_in      ,
  input                      clk_image2_in      ,
  input                      clk_image_out      ,
  input                      sys_rst_n          ,

  input     [DATA_WIDTH-1:0] image1_data_pixel_i,
  input                      image1_data_valid_i,
  input                      image1_data_vs_i   ,

  input     [DATA_WIDTH-1:0] image2_data_pixel_i,
  input                      image2_data_valid_i,
  input                      image2_data_vs_i   ,

  input                      data_out_ready_i   ,
  input                      sel_swap           ,
  output reg[DATA_WIDTH-1:0] data_pixel_o       ,
  output reg                 data_valid_o
);

  localparam ALIGN_STAGES = ALIGN_ROW_DLY / 2;    
  localparam AFD          = (ALIGN_FINE_DLY < 1) ? 1 : ALIGN_FINE_DLY;

  localparam HALF1        = IMAGE1_WIDTH_IN;           
  localparam HALF2        = IMAGE2_WIDTH_IN;           
  localparam LINE_W       = LINE_WIDTH;                
  localparam FIFO_AW      = 12;
  localparam FIFO_DEPTH   = 4096;
  localparam PRIME        = 576;

  wire         rd_window;
  wire         rd_left;
  wire         rd_right;
  wire         rd_f1;
  wire         rd_f2;

  genvar  gi;
  integer ai;

generate
  if ((HALF1 + HALF2 != IMAGE_WIDTH_OUT) ||
      (IMAGE1_HEIGHT_IN != IMAGE_HEIGHT_OUT) ||
      (IMAGE2_HEIGHT_IN != IMAGE_HEIGHT_OUT))
  begin: error_set_pro
    always@(posedge clk_image_out or negedge sys_rst_n)
    begin
      if(!sys_rst_n) data_pixel_o <= 'd0;
      else           data_pixel_o <= {DATA_WIDTH{1'b1}};
    end

    always@(posedge clk_image_out or negedge sys_rst_n)
    begin
      if(!sys_rst_n) data_valid_o <= 'd0;
      else           data_valid_o <= 1'b1;
    end
  end
  else
  begin: correct_set_pro
    wire [7:0] a_row_hi [0:ALIGN_STAGES];
    wire [7:0] a_row_lo [0:ALIGN_STAGES];
    assign a_row_hi[0] = image1_data_pixel_i[15:8];
    assign a_row_lo[0] = image1_data_pixel_i[ 7:0];

    for (gi = 0; gi < ALIGN_STAGES; gi = gi + 1) begin : g_align_row
      shift_register_2taps
      #(
        .DATA_WIDTH (8)
      ) u_align_hi
      (
        .clk           (clk_image1_in       ),
        .shiftin       (a_row_hi[gi]        ),
        .shiftin_valid (image1_data_valid_i ),
        .shiftout      (                    ),
        .taps1x        (                    ),
        .taps0x        (a_row_hi[gi+1]      )
      );

      shift_register_2taps
      #(
        .DATA_WIDTH (8)
      ) u_align_lo
      (
        .clk           (clk_image1_in       ),
        .shiftin       (a_row_lo[gi]        ),
        .shiftin_valid (image1_data_valid_i ),
        .shiftout      (                    ),
        .taps1x        (                    ),
        .taps0x        (a_row_lo[gi+1]      )
      );
    end

    wire [DATA_WIDTH-1:0] a_row_out = {a_row_hi[ALIGN_STAGES], a_row_lo[ALIGN_STAGES]};
    reg [DATA_WIDTH-1:0] a_fine   [0:AFD-1];
    reg [DATA_WIDTH-1:0] b_fine   [0:AFD-1];
    reg [AFD-1:0]        a_fine_v;
    reg [AFD-1:0]        b_fine_v;

    always @(posedge clk_image1_in or negedge sys_rst_n) begin
      if(!sys_rst_n) begin
        a_fine_v <= {AFD{1'b0}};
        for (ai = 0; ai < AFD; ai = ai + 1)
          a_fine[ai] <= {DATA_WIDTH{1'b0}};
      end
      else begin
        if(image1_data_valid_i)
          a_fine[0] <= a_row_out;
        a_fine_v[0] <= image1_data_valid_i;

        for (ai = 1; ai < AFD; ai = ai + 1) begin
          if(a_fine_v[ai-1])
            a_fine[ai] <= a_fine[ai-1];
          a_fine_v[ai] <= a_fine_v[ai-1];
        end
      end
    end

    always @(posedge clk_image2_in or negedge sys_rst_n) begin
      if(!sys_rst_n) begin
        b_fine_v <= {AFD{1'b0}};
        for (ai = 0; ai < AFD; ai = ai + 1)
          b_fine[ai] <= {DATA_WIDTH{1'b0}};
      end
      else begin
        if(image2_data_valid_i)
          b_fine[0] <= image2_data_pixel_i;
        b_fine_v[0] <= image2_data_valid_i;

        for (ai = 1; ai < AFD; ai = ai + 1) begin
          if(b_fine_v[ai-1])
            b_fine[ai] <= b_fine[ai-1];
          b_fine_v[ai] <= b_fine_v[ai-1];
        end
      end
    end

    wire [DATA_WIDTH-1:0] img1_aligned   = a_fine[AFD-1];
    wire [DATA_WIDTH-1:0] img2_aligned   = b_fine[AFD-1];
    wire                  img1_aligned_v = a_fine_v[AFD-1];
    wire                  img2_aligned_v = b_fine_v[AFD-1];

    reg vs_dly_i;
    reg sel_swap_sync;
    always @(posedge clk_image_out or negedge sys_rst_n) begin
      if(!sys_rst_n) begin
        vs_dly_i      <= 1'b0;
        sel_swap_sync <= 1'b0;
      end
      else begin
        vs_dly_i <= image2_data_vs_i;
        if(image2_data_vs_i & ~vs_dly_i) sel_swap_sync <= sel_swap;
      end
    end

    wire sel_use = SEL_DIRECT ? sel_swap : sel_swap_sync;
    wire frame_edge = image2_data_vs_i & ~vs_dly_i;

    reg flush_r;
    always @(posedge clk_image_out or negedge sys_rst_n) begin
      if(!sys_rst_n) flush_r <= 1'b0;
      else           flush_r <= frame_edge;
    end
    wire fifo_rst_n = sys_rst_n & ~(frame_edge | flush_r);
    wire [DATA_WIDTH-1:0] f1_q, f2_q;
    wire                  f1_vld, f2_vld;
    wire [FIFO_AW:0]      f1_lvl, f2_lvl;

    m3_line_fifo #(
      .DATA_WIDTH (DATA_WIDTH),
      .AW         (FIFO_AW   ),
      .DEPTH      (FIFO_DEPTH)
    ) u_fifo_left (
      .clk      (clk_image1_in     ),
      .rst_n    (fifo_rst_n        ),   
      .wr_en    (img1_aligned_v    ),
      .wr_data  (img1_aligned      ),
      .rd_en    (rd_f1             ),
      .rd_data  (f1_q              ),
      .rd_valid (f1_vld            ),
      .level    (f1_lvl            ),
      .full     (                  ),
      .empty    (                  )
    );

    m3_line_fifo #(
      .DATA_WIDTH (DATA_WIDTH),
      .AW         (FIFO_AW   ),
      .DEPTH      (FIFO_DEPTH)
    ) u_fifo_right (
      .clk      (clk_image2_in     ),
      .rst_n    (fifo_rst_n        ),  
      .wr_en    (img2_aligned_v    ),
      .wr_data  (img2_aligned      ),
      .rd_en    (rd_f2             ),
      .rd_data  (f2_q              ),
      .rd_valid (f2_vld            ),
      .level    (f2_lvl            ),
      .full     (                  ),
      .empty    (                  )
    );
    wire primed_now = (f1_lvl >= PRIME[FIFO_AW:0]) &&
                      (f2_lvl >= PRIME[FIFO_AW:0]);

    reg primed;
    always @(posedge clk_image_out or negedge sys_rst_n) begin
      if(!sys_rst_n)                           primed <= 1'b0;
      else if(frame_edge)                      primed <= 1'b0;  
      else if(primed_now && !data_out_ready_i) primed <= 1'b1;   
    end

    reg [15:0] col_cnt;                    
    always @(posedge clk_image_out or negedge sys_rst_n) begin
      if(!sys_rst_n)                     col_cnt <= 16'd0;
      else if(!primed)                   col_cnt <= 16'd0;
      else if(data_out_ready_i)          col_cnt <= (col_cnt >= (LINE_W-1)) ? 16'd0
                                                                           : col_cnt + 1'b1;
    end

    assign rd_window = primed && data_out_ready_i;
    assign rd_left   = rd_window && (col_cnt <  HALF1[15:0]);   // 输出左半窗口
    assign rd_right  = rd_window && (col_cnt >= HALF1[15:0]);   // 输出右半窗口
    assign rd_f1 = sel_use ? rd_right : rd_left;   // FIFO1 服务于哪一半
    assign rd_f2 = sel_use ? rd_left  : rd_right;  // FIFO2 服务于哪一半
    reg rd_left_d1, rd_right_d1;
    always @(posedge clk_image_out or negedge sys_rst_n) begin
      if(!sys_rst_n) begin
        rd_left_d1  <= 1'b0;
        rd_right_d1 <= 1'b0;
      end
      else begin
        rd_left_d1  <= rd_left;
        rd_right_d1 <= rd_right;
      end
    end

    always@(posedge clk_image_out or negedge sys_rst_n)
    begin
      if(!sys_rst_n)
        data_pixel_o <= 'd0;
      else if(rd_left_d1)
        data_pixel_o <= sel_use ? f2_q : f1_q;  
      else if(rd_right_d1)
        data_pixel_o <= sel_use ? f1_q : f2_q;    
      else
        data_pixel_o <= 'd0;
    end

    always@(posedge clk_image_out or negedge sys_rst_n)
    begin
      if(!sys_rst_n) data_valid_o <= 1'b0;
      else           data_valid_o <= rd_left_d1 | rd_right_d1;
    end

  end
endgenerate

endmodule
