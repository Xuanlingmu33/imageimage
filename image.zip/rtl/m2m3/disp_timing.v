module disp_timing #(
    parameter integer H_ACTIVE = 1280,
    parameter integer H_FP     = 110,
    parameter integer H_SYNC   = 40,
    parameter integer H_BP     = 220,
    parameter integer V_ACTIVE = 720,
    parameter integer V_FP     = 5,
    parameter integer V_SYNC   = 5,
    parameter integer V_BP     = 20,
    parameter integer ALIGN_V  = 0
)(
    input  wire        clk,          
    input  wire        rst_n,
    input  wire        align,        
    output reg         de,           
    output reg         hs,           
    output reg         vs,           
    output reg  [11:0] h_cnt,        
    output reg  [10:0] v_cnt,        
    output wire        rd_en,        
    output wire        line_start,
    output wire        frame_start
);
    localparam integer H_TOTAL = H_ACTIVE + H_FP + H_SYNC + H_BP;   // 1650
    localparam integer V_TOTAL = V_ACTIVE + V_FP + V_SYNC + V_BP;   // 750

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            h_cnt <= 12'd0;
            v_cnt <= 11'd0;
        end else if (align) begin
            h_cnt <= 12'd0;
            v_cnt <= ALIGN_V[10:0];
        end else if (h_cnt == H_TOTAL[11:0] - 12'd1) begin
            h_cnt <= 12'd0;
            v_cnt <= (v_cnt == V_TOTAL[10:0] - 11'd1) ? 11'd0 : (v_cnt + 11'd1);
        end else begin
            h_cnt <= h_cnt + 12'd1;
        end
    end

    always @(*) begin
        de = (h_cnt < H_ACTIVE[11:0]);
        hs = (h_cnt >= (H_ACTIVE + H_FP)) && (h_cnt < (H_ACTIVE + H_FP + H_SYNC));
        vs = (v_cnt >= (V_ACTIVE + V_FP)) && (v_cnt < (V_ACTIVE + V_FP + V_SYNC));
    end

    assign rd_en       = de & ~h_cnt[0];
    assign line_start  = (h_cnt == 12'd0);
    assign frame_start = (h_cnt == 12'd0) && (v_cnt == 11'd0);
endmodule
