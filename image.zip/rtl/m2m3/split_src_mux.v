module split_src_mux #(
    parameter integer DATA_WIDTH = 16,   // RGB565
    parameter integer N_SRC      = 4,    
    parameter integer SEL_W      = 2     
)(
    input  wire                        clk,
    input  wire                        sys_rst_n,

    input  wire [N_SRC*DATA_WIDTH-1:0] src_data,
    input  wire [N_SRC-1:0]            src_valid,
    input  wire [N_SRC-1:0]            src_vs,

    input  wire [SEL_W-1:0]            left_sel_r,
    input  wire [SEL_W-1:0]            right_sel_r,
    input  wire                        swap_r,     
    input  wire                        vs_in,      

    output reg  [DATA_WIDTH-1:0]       left_data,
    output reg  [DATA_WIDTH-1:0]       right_data,
    output reg                         left_valid,
    output reg                         right_valid,
    output reg                         left_vs,
    output reg                         right_vs
);

    reg  vs_d;
    wire pos_vs = (vs_d == 1'b0) && (vs_in == 1'b1);

    reg [SEL_W-1:0] left_sel_s, right_sel_s;

    always @(posedge clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            vs_d        <= 1'b0;
            left_sel_s  <= {SEL_W{1'b0}};
            right_sel_s <= {SEL_W{1'b0}};
        end else begin
            vs_d <= vs_in;
            if (pos_vs) begin
                left_sel_s  <= swap_r ? right_sel_r : left_sel_r;
                right_sel_s <= swap_r ? left_sel_r  : right_sel_r;
            end
        end
    end

    reg [DATA_WIDTH-1:0] l_data_mux, r_data_mux;
    reg                  l_vld_mux,    r_vld_mux;
    reg                  l_vs_mux,     r_vs_mux;

    always @(*) begin
        l_data_mux = {DATA_WIDTH{1'b0}};
        l_vld_mux  = 1'b0;
        l_vs_mux   = 1'b0;
        case (left_sel_s)
            2'd0: begin l_data_mux = src_data[0*DATA_WIDTH +: DATA_WIDTH]; l_vld_mux = src_valid[0]; l_vs_mux = src_vs[0]; end
            2'd1: begin l_data_mux = src_data[1*DATA_WIDTH +: DATA_WIDTH]; l_vld_mux = src_valid[1]; l_vs_mux = src_vs[1]; end
            2'd2: begin l_data_mux = src_data[2*DATA_WIDTH +: DATA_WIDTH]; l_vld_mux = src_valid[2]; l_vs_mux = src_vs[2]; end
            default: begin l_data_mux = src_data[3*DATA_WIDTH +: DATA_WIDTH]; l_vld_mux = src_valid[3]; l_vs_mux = src_vs[3]; end
        endcase
    end

    always @(*) begin
        r_data_mux = {DATA_WIDTH{1'b0}};
        r_vld_mux  = 1'b0;
        r_vs_mux   = 1'b0;
        case (right_sel_s)
            2'd0: begin r_data_mux = src_data[0*DATA_WIDTH +: DATA_WIDTH]; r_vld_mux = src_valid[0]; r_vs_mux = src_vs[0]; end
            2'd1: begin r_data_mux = src_data[1*DATA_WIDTH +: DATA_WIDTH]; r_vld_mux = src_valid[1]; r_vs_mux = src_vs[1]; end
            2'd2: begin r_data_mux = src_data[2*DATA_WIDTH +: DATA_WIDTH]; r_vld_mux = src_valid[2]; r_vs_mux = src_vs[2]; end
            default: begin r_data_mux = src_data[3*DATA_WIDTH +: DATA_WIDTH]; r_vld_mux = src_valid[3]; r_vs_mux = src_vs[3]; end
        endcase
    end

    always @(posedge clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            left_data   <= {DATA_WIDTH{1'b0}};
            right_data  <= {DATA_WIDTH{1'b0}};
            left_valid  <= 1'b0;
            right_valid <= 1'b0;
            left_vs     <= 1'b0;
            right_vs    <= 1'b0;
        end else begin
            left_data   <= l_data_mux;
            right_data  <= r_data_mux;
            left_valid  <= l_vld_mux;
            right_valid <= r_vld_mux;
            left_vs     <= l_vs_mux;
            right_vs    <= r_vs_mux;
        end
    end

endmodule
