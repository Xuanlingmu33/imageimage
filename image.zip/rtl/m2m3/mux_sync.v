module mux_sync
#(
  parameter WIDTH        = 16,
  parameter USE_VS_LATCH = 1'b1    
)
(
  input                   clk,
  input                   sys_rst_n,

  input                   sel,       // 选择信号（来自按键域，任意时刻变都行）
  input                   vs_in,     // 帧边界参考（接算法链同拍的那路 vs）

  input      [WIDTH-1:0]  d0,        // sel = 0 时选它
  input      [WIDTH-1:0]  d1,        // sel = 1 时选它
  input                   valid_in,  // d0/d1 同拍的有效标志

  output reg [WIDTH-1:0]  q,
  output reg              q_valid
);

  reg vs_dly;
  reg sel_latched;

  always @(posedge clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
      vs_dly      <= 1'b0;
      sel_latched <= 1'b0;
    end
    else begin
      vs_dly <= vs_in;
      if(vs_in & ~vs_dly)         
        sel_latched <= sel;
    end
  end

  wire sel_use = USE_VS_LATCH ? sel_latched : sel;

  always @(posedge clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
      q       <= {WIDTH{1'b0}};
      q_valid <= 1'b0;
    end
    else begin
      q       <= sel_use ? d1 : d0;
      q_valid <= valid_in;
    end
  end

endmodule
