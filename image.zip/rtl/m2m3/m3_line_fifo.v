module m3_line_fifo #(
    parameter integer DATA_WIDTH = 16,
    parameter integer AW         = 11,              // 地址位宽 ⇒ 深度 = 2^AW = 2048
    parameter integer DEPTH      = 2048
)(
    input  wire                  clk,
    input  wire                  rst_n,

    input  wire                  wr_en,
    input  wire [DATA_WIDTH-1:0] wr_data,

    input  wire                  rd_en,
    output reg  [DATA_WIDTH-1:0] rd_data,
    output reg                   rd_valid,

    output reg  [AW:0]           level,         
    output wire                  full,
    output wire                  empty
);

    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];

    reg [AW:0] wptr;
    reg [AW:0] rptr;

    assign full  = (level >= DEPTH[AW:0]);
    assign empty = (level == {(AW+1){1'b0}});

    wire do_wr = wr_en && (!full);
    wire do_rd = rd_en && (!empty);

    always @(posedge clk) begin
        if (do_wr)
            mem[wptr[AW-1:0]] <= wr_data;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) wptr <= {(AW+1){1'b0}};
        else if (do_wr) wptr <= wptr + 1'b1;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rptr     <= {(AW+1){1'b0}};
            rd_data  <= {DATA_WIDTH{1'b0}};
            rd_valid <= 1'b0;
        end
        else begin
            rd_data  <= mem[rptr[AW-1:0]];
            rd_valid <= do_rd;
            if (do_rd) rptr <= rptr + 1'b1;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            level <= {(AW+1){1'b0}};
        else begin
            case ({do_wr, do_rd})
                2'b10:   level <= level + 1'b1;
                2'b01:   level <= level - 1'b1;
                default: level <= level;
            endcase
        end
    end

endmodule
