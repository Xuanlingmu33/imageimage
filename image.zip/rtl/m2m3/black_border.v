module black_border #(
    parameter integer H_ACTIVE = 1280,                // 一行像素数（信息用，本模块不数水平）
    parameter integer V_IN     = 480,                 // 输入有效行数（画面部分）
    parameter integer V_OUT    = 720,                 // 输出有效行数（720p60）
    parameter [15:0]  BLACK    = 16'h0000             // 黑（RGB565 = 0）
)(
    input  wire        clk,          
    input  wire        rst_n,

    input  wire [15:0] i_data,
    input  wire        i_valid,
    input  wire        i_hs,
    input  wire        i_vs,

    output reg  [15:0] o_data,
    output reg         o_de,
    output reg         o_hs,
    output reg         o_vs,
    output reg  [10:0] o_v_cnt      
);

    reg  hs_d, vs_d;
    wire pos_hs = ( hs_d == 1'b0 ) && ( i_hs == 1'b1 );
    wire pos_vs = ( vs_d == 1'b0 ) && ( i_vs == 1'b1 );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            hs_d <= 1'b0;
            vs_d <= 1'b0;
        end else begin
            hs_d <= i_hs;
            vs_d <= i_vs;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            o_v_cnt <= 11'd0;
        else if (pos_vs)
            o_v_cnt <= 11'd0;                
        else if (pos_hs && (o_v_cnt < 11'd749))
            o_v_cnt <= o_v_cnt + 11'd1;      
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            o_data <= BLACK;
            o_de   <= 1'b0;
            o_hs   <= 1'b0;
            o_vs   <= 1'b0;
        end else begin
            o_hs <= i_hs;
            o_vs <= i_vs;
            if (o_v_cnt < V_IN[10:0]) begin
                o_data <= i_data;             // 画面区：透传
                o_de   <= i_valid;
            end else if (o_v_cnt < V_OUT[10:0]) begin
                o_data <= BLACK;              // 黑边区：恒黑,但 de 要拉起来
                o_de   <= i_valid;
            end else begin
                o_data <= BLACK;              // 场消隐：de=0
                o_de   <= 1'b0;
            end
        end
    end
endmodule
