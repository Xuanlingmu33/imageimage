//=============================================================================
// tb_m6_pipeline.v —— m6 全链功能仿真 + 【真实帧导出】
//
//   与 tb_m4_pipeline 的关系：输入激励/时序判据完全沿用（同一套 1650x750 时基、
//   同样故意错开 137 行验证锁相），在它基础上加了 m6 的三样东西：
//     ① 右上角两半的实时帧率（绿色）
//     ② key1 单键状态机（短/中/长按 + 模式自动回落）
//     ③ 左下角三行白字（右区画面 / 左区画面 / 瞬时消息）
//
//   ★ 帧率数值怎么在仿真里对得上：
//     fps_meter 是"数 clk 拍"算帧率的 —— 本 TB 一帧正好 1650×750 = 1,237,500 拍，
//     CLK_HZ 用 74,250,000 ⇒ 74,250,000/1,237,500 = 60.0 ⇒ 屏幕上就该是 FPS: 60.0 ✓
//     （与 ModelSim 的 timescale 无关，只与拍数有关 ✓）
//
//   ★ 单键时长在仿真里改小（defparam）：
//       消抖 99 拍 / 中按 3000 拍 / 长按 9000 拍 / 模式回落 3,000,000 拍(≈2.4 帧)
//       瞬时消息 3,000,000 拍
//
//   ★ 每个状态的"真图"导到 sim\dump\*.hex（每像素 6 位十六进制 RGB888），
//     再由 tools\hex2png.ps1 转成 PNG 看效果（不是画示意图，是 RTL 实算的像素 ✓）
//=============================================================================
`timescale 1ns/1ps
module tb_m6_pipeline;

    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;                   // 10ns/拍（周期本身不影响 OSD 逻辑）

    // ---- 与 tb_m4_pipeline 相同的输入时基：一行 1650 拍，一帧 750 行 ----
    integer hc = 0, vc = 137;               // 行号故意错开 137，顺带验证显示锁相
    always @(posedge clk) begin
        if (hc == 1649) begin hc <= 0; vc <= (vc == 749) ? 0 : vc + 1; end
        else                  hc <= hc + 1;
    end

    wire in_de = rst_n && (hc >= 110) && (hc < 750);
    wire in_hs = rst_n && (hc >= 750) && (hc < 790);
    wire in_vs = rst_n && (vc >= 725) && (vc < 730);

    wire [9:0] col = (hc >= 110) ? (hc - 110) : 10'd1023;
    wire bar_v = in_de && (col >= 300) && (col < 308);
    wire bar_h = (vc >= 200) && (vc < 208);
    wire box   = in_de && (col >= 450) && (col < 520) && (vc >= 300) && (vc < 370);
    wire [7:0] i_r = (bar_v || bar_h) ? 8'd240 : box ? 8'd180 : 8'd80;
    wire [7:0] i_g = (bar_v || bar_h) ? 8'd240 : box ? 8'd120 : 8'd80;
    wire [7:0] i_b = (bar_v || bar_h) ? 8'd240 : box ? 8'd60  : 8'd80;

    reg k0 = 0, k1 = 0, k2 = 0, k3 = 0;

    wire [23:0] o_rgb;
    wire        o_de, o_hs, o_vs;

    m4_pipeline dut (
        .clk(clk), .rst_n(rst_n),
        .i_r(i_r), .i_g(i_g), .i_b(i_b),
        .i_de(in_de), .i_hs(in_hs), .i_vs(in_vs),
        .i_fps_sensor(14'd600),          // ★m6 传感器实时帧率（仿真里直接给 60.0）
        .key0(k0), .key1(k1), .key2(k2), .key3(k3),
        .o_rgb(o_rgb), .o_de(o_de), .o_hs(o_hs), .o_vs(o_vs)
    );

    // ---- 把 m6 的时长参数改小（只影响仿真）----
    defparam dut.u_m6_osd.u_key_fsm.DEBOUNCE = 99;         // v7 仿真缩放
    defparam dut.u_m6_osd.u_key_fsm.T_GAP    = 300;
    defparam dut.u_m6_osd.u_key_fsm.T_MINCLK = 500;        // 须 > DEBOUNCE+T_GAP=399
    defparam dut.u_m6_osd.u_key_fsm.T_LONG   = 3000;       // 长按界限（press_long=9500 拍 ⇒ dur≈9800 > 3000 ✓）
    defparam dut.u_m6_osd.u_key_fsm.T_IDLE   = 40_000_000; // 5 秒无操作（仿真缩短；★必须远大于各相位间的快照耗时，否则模式会在相位中途被超时回退）
    defparam dut.u_m6_osd.u_text.MSG_CYCLES  = 5_000_000;
    // ★v8：key3 实例的仿真参数（否则用真实 0.8s 门限，仿真里按不动）
    defparam dut.u_m6_osd.u_key_fsm3.DEBOUNCE = 99;
    defparam dut.u_m6_osd.u_key_fsm3.T_GAP    = 300;
    defparam dut.u_m6_osd.u_key_fsm3.T_MINCLK = 500;
    defparam dut.u_m6_osd.u_key_fsm3.T_LONG   = 3000;
    defparam dut.u_m6_osd.u_key_fsm3.T_IDLE   = 40_000_000;

    // ---- 其它三键的消抖也改小（与 m4 TB 一致）----
    defparam dut.u_key_filter0.CNT_MAX = 99;
    // ★v9：key2 状态机（单击换档 / 长按进选色）也要缩小参数
    defparam dut.u_m6_osd.u_key2_fsm.DEBOUNCE = 99;
    defparam dut.u_m6_osd.u_key2_fsm.T_GAP    = 300;
    defparam dut.u_m6_osd.u_key2_fsm.T_MINCLK = 500;       // 须 > DEBOUNCE+T_GAP=399
    defparam dut.u_m6_osd.u_key2_fsm.T_LONG   = 3000;      // 短按 400 拍≈800 < 3000；长按 9500 拍≈9800 > 3000 ✓
    defparam dut.u_m6_osd.u_key2_fsm.T_IDLE   = 40_000_000; // 选色 5 秒回落（仿真放大，避免相位中途退出）

    //==========================================================================
    // 观测：OSD 像素统计（每帧清零）
    //==========================================================================
    wire [7:0] oR = o_rgb[7:0], oG = o_rgb[15:8], oB = o_rgb[23:16];
    wire is_green = (oR == 8'h00) && (oG == 8'hFF) && (oB == 8'h00);   // FPS 绿
    wire is_white = (oR == 8'hFF) && (oG == 8'hFF) && (oB == 8'hFF);   // 文字白

    integer dcol = 0, drow = 0;
    reg     o_de_d, o_vs_d;
    always @(posedge clk) begin
        o_de_d <= o_de;
        o_vs_d <= o_vs;
        if (o_vs && !o_vs_d)                     drow <= 0;
        else if (o_de && !o_de_d)                drow <= drow + 1;
        if (o_de && !o_de_d)                     dcol <= 0;
        else if (o_de)                           dcol <= dcol + 1;
    end

    integer g_l = 0, g_r = 0, w_msg = 0, w_lft = 0, w_rgt = 0;
    integer g_l_t = 0, g_r_t = 0, w_msg_t = 0, w_lft_t = 0, w_rgt_t = 0;
    integer frm = 0;

    always @(posedge clk) begin
        if (o_de) begin
            // 左半 FPS 带：行 10~41、列 476~635
            if ((drow >= 10) && (drow < 42) && (dcol >= 476) && (dcol < 636) && is_green) g_l <= g_l + 1;
            // 右半 FPS 带：行 10~41、列 1112~1271
            if ((drow >= 10) && (drow < 42) && (dcol >= 1112) && (dcol < 1272) && is_green) g_r <= g_r + 1;
            // 左下三行（白）：行 580~611 / 622~653 / 664~695，列 16~527
            if ((drow >= 580) && (drow < 612) && (dcol >= 16) && (dcol < 528) && is_white) w_msg <= w_msg + 1;
            if ((drow >= 622) && (drow < 654) && (dcol >= 16) && (dcol < 528) && is_white) w_lft <= w_lft + 1;
            if ((drow >= 664) && (drow < 696) && (dcol >= 16) && (dcol < 528) && is_white) w_rgt <= w_rgt + 1;
        end
        if (o_vs && !o_vs_d) begin
            g_l_t <= g_l; g_r_t <= g_r; w_msg_t <= w_msg; w_lft_t <= w_lft; w_rgt_t <= w_rgt;
            g_l <= 0; g_r <= 0; w_msg <= 0; w_lft <= 0; w_rgt <= 0;
            frm <= frm + 1;
        end
    end

    //==========================================================================
    // 真帧导出（只导含文字的行：0~47 与 576~719，其余行转换时补灰）
    //==========================================================================
    integer thr_before = 0;
    integer fails = 0;                      // ★v9：CHECK 计数
    integer fd;
    reg     dump_en = 0;

    always @(posedge clk) begin
        if (dump_en && o_de) begin
            // ★v9-fix：o_rgb 是 {B,G,R}（见 rgb565_to_888），直接写会把红蓝写反 ⇒ 按 R,G,B 写
            if ((drow < 48) || (drow >= 576)) $fwrite(fd, "%06x", {oR, oG, oB});
            if (dcol == 1279) $fwrite(fd, "\n");
        end
    end

    task automatic snap;
        input [8*40-1:0] fname;
        begin
            // ★ 必须从【帧首第一个有效像素】开始导：否则文件第一行是上一帧的半行，
            //   转换时行号会整体错位（图上会出现首尾两条"半行"重影 ✗ 已踩过）
            wait (o_vs == 1'b1);
            wait (o_de == 1'b1);
            @(posedge clk);
            fd = $fopen(fname, "w");
            if (fd == 0) begin $display("!! 打不开 %0s", fname); end
            dump_en = 1;
            repeat (1650 * 750) @(posedge clk);      // 整整一帧
            dump_en = 0;
            $fclose(fd);
            $display("   [snap] %0s  (frame %0d)", fname, frm);
        end
    endtask

    task automatic show_state;
        input [8*28-1:0] tag;
        begin
            $display("  [%0s] thr=%0d sign=%0d step=%0d mode=%0d | dm=%0d split=%0d med=%0b",
                     tag,
                     dut.u_m6_osd.o_threshold, dut.u_m6_osd.o_sign,
                     dut.u_m6_osd.o_step_idx, dut.u_m6_osd.o_threshold,
                     dut.disp_mode_r, dut.split_mode, dut.key_median);
            $display("        OSD绿像素 左=%0d 右=%0d | 白字 消息行=%0d 左区行=%0d 右区行=%0d",
                     g_l_t, g_r_t, w_msg_t, w_lft_t, w_rgt_t);
        end
    endtask

    task automatic wait_frames;
        input integer n;
        begin repeat (n * 750 * 1650) @(posedge clk); end
    endtask

    // 短按（400 拍高）/ 中按（3500）/ 长按（9500）；消抖 99 拍 ⇒ 按下沿后 ~100 拍生效
    task automatic press_short; begin k1 = 1'b1; repeat (400)  @(posedge clk); k1 = 1'b0; repeat (1500) @(posedge clk); end endtask
    task automatic press_med;   begin k1 = 1'b1; repeat (3500) @(posedge clk); k1 = 1'b0; repeat (1500) @(posedge clk); end endtask
    task automatic press_long;  begin k1 = 1'b1; repeat (9500) @(posedge clk); k1 = 1'b0; repeat (1500) @(posedge clk); end endtask
    task automatic press_key0;  begin k0 = 1'b1; repeat (400)  @(posedge clk); k0 = 1'b0; repeat (1500) @(posedge clk); end endtask
    task automatic press_key2;  begin k2 = 1'b1; repeat (400)  @(posedge clk); k2 = 1'b0; repeat (1500) @(posedge clk); end endtask
    task automatic press_key2_long; begin k2 = 1'b1; repeat (9500) @(posedge clk); k2 = 1'b0; repeat (1500) @(posedge clk); end endtask
    task automatic press_key3;  begin k3 = 1'b1; repeat (400)  @(posedge clk); k3 = 1'b0; repeat (1500) @(posedge clk); end endtask

    //==========================================================================
    initial begin
        $display("==== tb_m6_pipeline : m6 三步显示功能 ====");
        $display("（一帧 1650x750 = 1,237,500 拍；CLK_HZ=74,250,000 ⇒ 应显示 60.0fps）");
        rst_n = 0;
        repeat (20) @(posedge clk);
        rst_n = 1;

        //---------------------------------------------------------------- A 上电
        wait_frames(4);
        $display("");
        $display("---- A 上电态：左=灰度 / 右=Sobel(二值) / 两半 FPS ----");
        snap("sim/dump/A_poweron.hex");
        show_state("A");

        //---------------------------------------------------------------- B key2
        $display("");
        $display("---- B 按 key2 一次：右区画面 -> 反向sobel（白底黑边）----");
        press_key2; wait_frames(2);
        $display("   disp_mode=%0d（期望 1=反向sobel）", dut.disp_mode_r);
        if (dut.disp_mode_r === 2'd1) $display("   CHECK-B OK : 档位 0 -> 1（反向sobel）");
        else begin $display("   CHECK-B NG"); fails = fails + 1; end
        snap("sim/dump/B_dm1.hex");
        show_state("B");

        //---------------------------------------------------------------- C key2
        $display("");
        $display("---- C 再按 key2：右区画面 -> 彩色叠加（默认红）----");
        press_key2; wait_frames(2);
        $display("   disp_mode=%0d（期望 2）  color=%0d（期望 0=红）", dut.disp_mode_r, dut.u_m6_osd.o_color_sel);
        if ((dut.disp_mode_r === 2'd2) && (dut.u_m6_osd.o_color_sel === 4'd0))
             $display("   CHECK-C OK : 档位 1 -> 2（彩色叠加，红）");
        else begin $display("   CHECK-C NG"); fails = fails + 1; end
        snap("sim/dump/C_dm2.hex");
        show_state("C");

        //---------------------------------------------------------------- C2 长按进选色
        $display("");
        $display("---- C2 长按 key2（彩色叠加档）：进【选色模式】----");
        press_key2_long; wait_frames(2);
        $display("   color_mode=%0d（期望 1）  color=%0d（期望仍 0=红）  disp_mode=%0d（期望 2）",
                 dut.u_m6_osd.u_key2_fsm.color_mode, dut.u_m6_osd.o_color_sel, dut.disp_mode_r);
        if ((dut.u_m6_osd.u_key2_fsm.color_mode === 1'b1) && (dut.u_m6_osd.o_color_sel === 4'd0))
             $display("   CHECK-C2 OK : 进选色，颜色不变");
        else begin $display("   CHECK-C2 NG"); fails = fails + 1; end
        snap("sim/dump/C2_color_red.hex");

        //---------------------------------------------------------------- C3 选色模式单击换色
        $display("");
        $display("---- C3 选色模式单击：红 -> 橙 ----");
        press_key2; wait_frames(2);
        $display("   color=%0d（期望 1=橙）  disp_mode=%0d（期望仍 2，选色里短按不再换档）",
                 dut.u_m6_osd.o_color_sel, dut.disp_mode_r);
        if ((dut.u_m6_osd.o_color_sel === 4'd1) && (dut.disp_mode_r === 2'd2))
             $display("   CHECK-C3 OK");
        else begin $display("   CHECK-C3 NG"); fails = fails + 1; end
        snap("sim/dump/C3_color_orange.hex");

        //---------------------------------------------------------------- C4 连按到紫，再按回红
        $display("");
        $display("---- C4 继续单击：橙 -> 黄 -> 绿 -> 青 -> 蓝 -> 紫；紫再按一下回红 ----");
        press_key2; press_key2; press_key2; press_key2; press_key2;
        wait_frames(2);
        $display("   color=%0d（期望 6=紫）", dut.u_m6_osd.o_color_sel);
        if (dut.u_m6_osd.o_color_sel === 4'd6) $display("   CHECK-C4 OK : 循环到紫");
        else begin $display("   CHECK-C4 NG"); fails = fails + 1; end
        snap("sim/dump/C4_color_purple.hex");

        press_key2; wait_frames(2);
        $display("   color=%0d（期望 0=红，紫色之后再按回红）", dut.u_m6_osd.o_color_sel);
        if (dut.u_m6_osd.o_color_sel === 4'd0) $display("   CHECK-C5 OK : 紫 -> 红 回绕");
        else begin $display("   CHECK-C5 NG"); fails = fails + 1; end

        //---------------------------------------------------------------- C6 长按退出选色
        $display("");
        $display("---- C6 选色模式里再长按：退回档位循环 ----");
        press_key2_long; wait_frames(1);
        $display("   color_mode=%0d（期望 0）", dut.u_m6_osd.u_key2_fsm.color_mode);
        if (dut.u_m6_osd.u_key2_fsm.color_mode === 1'b0) $display("   CHECK-C6 OK : 长按退出选色");
        else begin $display("   CHECK-C6 NG"); fails = fails + 1; end

        //---------------------------------------------------------------- D key3
        $display("");
        $display("---- D 按 key3：左=overlay / 右=Canny ----");
        press_key3; wait_frames(2);
        snap("sim/dump/D_canny.hex");
        show_state("D");
        press_key3; wait_frames(2);              // 换回来

        //---------------------------------------------------------------- E 单击
        $display("");
        $display("---- E key1 单击：阈值 8 -> 10 ----");
        press_short; wait_frames(1);
        $display("   thr=%0d（期望 10）  mode=%0d（期望 0）", dut.u_m6_osd.o_threshold, dut.u_m6_osd.u_key_fsm.mode);
        snap("sim/dump/E_thr.hex");

        //---------------------------------------------------------------- F 长按→加减模式
        $display("");
        $display("---- F 长按 ⇒ 进【加减】模式，阈值不动 ----");
        thr_before = dut.u_m6_osd.o_threshold;
        press_long; wait_frames(1);
        $display("   mode=%0d（期望 1）  thr=%0d（应仍为 %0d）",
                 dut.u_m6_osd.u_key_fsm.mode, dut.u_m6_osd.o_threshold, thr_before);
        if ((dut.u_m6_osd.u_key_fsm.mode === 2'd1) && (dut.u_m6_osd.o_threshold === thr_before))
             $display("   CHECK-F OK");
        else $display("   CHECK-F NG");
        snap("sim/dump/F_sign.hex");

        //---------------------------------------------------------------- G 加减模式下单击
        $display("");
        $display("---- G 加减模式下单击：换符号（阈值仍不变）----");
        press_short; wait_frames(1);
        $display("   sign=%0d（期望 1=减）  thr=%0d（应仍为 %0d）",
                 dut.u_m6_osd.o_sign, dut.u_m6_osd.o_threshold, thr_before);
        if ((dut.u_m6_osd.o_sign === 1'b1) && (dut.u_m6_osd.o_threshold === thr_before))
             $display("   CHECK-G OK");
        else $display("   CHECK-G NG");
        snap("sim/dump/G_sign2.hex");

        //---------------------------------------------------------------- H 长按→步进模式
        $display("");
        $display("---- H 长按 ⇒ 进【步进】模式 ----");
        press_long; wait_frames(1);
        $display("   mode=%0d（期望 2）  step=%0d  thr=%0d", dut.u_m6_osd.u_key_fsm.mode, dut.u_m6_osd.o_step_idx, dut.u_m6_osd.o_threshold);
        if (dut.u_m6_osd.u_key_fsm.mode === 2'd2) $display("   CHECK-H OK"); else $display("   CHECK-H NG");
        snap("sim/dump/H_step.hex");

        //---------------------------------------------------------------- I 步进模式下单击
        $display("");
        $display("---- I 步进模式下单击：步进档 2->4（阈值不变）----");
        press_short; wait_frames(1);
        $display("   step=%0d（期望 1=4）  thr=%0d", dut.u_m6_osd.o_step_idx, dut.u_m6_osd.o_threshold);
        if (dut.u_m6_osd.o_step_idx === 3'd1) $display("   CHECK-I OK"); else $display("   CHECK-I NG");
        snap("sim/dump/I_step2.hex");

        //---------------------------------------------------------------- J key0
        $display("");
        $display("---- J 按 key0：中值开启，屏幕出【中值滤波: 开】 ----");
        press_key0; wait_frames(1);
        snap("sim/dump/J_median.hex");

        //---------------------------------------------------------------- K 长按回阈值 + 单击生效
        $display("");
        $display("---- K 长按 ⇒ 回【阈值】模式；再单击 ⇒ 阈值生效 ----");
        press_long; wait_frames(1);
        $display("   mode=%0d（期望 0）", dut.u_m6_osd.u_key_fsm.mode);
        if (dut.u_m6_osd.u_key_fsm.mode === 2'd0) $display("   CHECK-K OK : back to threshold mode");
        else                                      $display("   CHECK-K NG : mode=%0d", dut.u_m6_osd.u_key_fsm.mode);
        thr_before = dut.u_m6_osd.o_threshold;
        press_short; wait_frames(1);
        $display("   单击后：thr %0d -> %0d", thr_before, dut.u_m6_osd.o_threshold);
        if (dut.u_m6_osd.o_threshold !== thr_before) $display("   CHECK-K2 OK : threshold changed");
        else                                         $display("   CHECK-K2 NG");
        snap("sim/dump/K_revert.hex");
$display("");
        $display("==================================================");
        $display("  判据：A~K 每帧 左/右 FPS 绿像素 > 0、左区/右区行白像素 > 0；");
        $display("        K 的消息行白像素 = 0");
        if (fails == 0) $display("==== tb_m6_pipeline : ALL CHECKS PASSED ====");
        else            $display("==== tb_m6_pipeline : %0d CHECK(S) FAILED ====", fails);
        $display("==================================================");
        $finish;
    end

    initial begin
        repeat (750 * 1650 * 70) @(posedge clk);
        $display("  TIMEOUT");
        $finish;
    end

endmodule
