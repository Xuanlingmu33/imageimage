//=============================================================================
// tb_m4_pipeline.v —— m4_pipeline 功能仿真（v2：修正黑边判据 + 加按键/对齐诊断）
//
//   输入：640x480 / 一行 1650 拍（de=640 拍：第 110~749 拍；hs=40 拍：第 750~789 拍）
//         一帧 750 行，vs = 第 725~729 行
//         输入行号初值【故意错开 137 行】⇒ 顺带验证显示时基锁相 ✓
//   图形：背景(80,80,80) + 竖条(列300~307 白) + 横条(行200~207 白) + 方块(列450~520/行300~370)
//
//   v1 的两个问题：
//     · blackErr 每帧 +240 ⇒ 其实是【判据写反了】：480~719 行本来就该是全黑 ✓
//       本版改为：480~719 行出现非零才算错 ✓；同时统计 0~479 行的内容范围 ✓
//     · median_en_sync 没变成 1 ⇒ 本版加按键链路诊断（kf0 脉冲数 / key_median / vs 跳变数）✓
//=============================================================================
`timescale 1ns/1ps
module tb_m4_pipeline;

    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;

    integer hc = 0, vc = 137;

    always @(posedge clk) begin
        if (hc == 1649) begin hc <= 0; vc <= (vc == 749) ? 0 : vc + 1; end
        else                  hc <= hc + 1;
    end

    wire in_de = rst_n && (hc >= 110) && (hc < 750);
    wire in_hs = rst_n && (hc >= 750) && (hc < 790);
    wire in_vs = rst_n && (vc >= 725) && (vc < 730);

    wire [9:0] col = (hc >= 110) ? (hc - 110) : 10'd1023;
    wire bar_v = in_de && (col >= 300) && (col < 308);
    wire bar_h = (vc >= 200) && (vc < 208);
    wire box   = in_de && (col >= 450) && (col < 520) && (vc >= 300) && (vc < 370);
    wire [7:0] i_r = (bar_v || bar_h) ? 8'd240 : box ? 8'd180 : 8'd80;
    wire [7:0] i_g = (bar_v || bar_h) ? 8'd240 : box ? 8'd120 : 8'd80;
    wire [7:0] i_b = (bar_v || bar_h) ? 8'd240 : box ? 8'd60  : 8'd80;

    reg k0 = 0, k1 = 0, k2 = 0, k3 = 0;

    wire [23:0] o_rgb;
    wire        o_de, o_hs, o_vs;

    m4_pipeline dut (
        .clk(clk), .rst_n(rst_n),
        .i_r(i_r), .i_g(i_g), .i_b(i_b),
        .i_de(in_de), .i_hs(in_hs), .i_vs(in_vs),
        .key0(k0), .key1(k1), .key2(k2), .key3(k3),
        .o_rgb(o_rgb), .o_de(o_de), .o_hs(o_hs), .o_vs(o_vs)
    );

    defparam dut.u_key_filter0.CNT_MAX = 99;
    defparam dut.u_key_filter1.CNT_MAX = 99;
    defparam dut.u_key_filter2.CNT_MAX = 99;
    defparam dut.u_key_filter3.CNT_MAX = 99;

    wire [7:0] oR = o_rgb[7:0], oG = o_rgb[15:8], oB = o_rgb[23:16];
    wire dRG = (oR > oG) ? (oR - oG) : (oG - oR);
    wire dGB = (oG > oB) ? (oG - oB) : (oB - oG);
    wire is_gray565 = (dRG <= 8'd8) && (dGB <= 8'd8);
    wire is_mono    = (oR==8'h00 && oG==8'h00 && oB==8'h00) ||
                      (oR==8'hFF && oG==8'hFF && oB==8'hFF);
    wire is_color   = (dRG > 8'd40) || (dGB > 8'd40);

    // ---- 诊断计数 ----
    integer kf0_cnt = 0, kf1_cnt = 0, kf2_cnt = 0, kf3_cnt = 0;
    integer medvs_rise = 0;           // image_median_vs 上升沿数
    reg     medvs_d = 0;
    always @(posedge clk) begin
        if (dut.kf0) kf0_cnt <= kf0_cnt + 1;
        if (dut.kf1) kf1_cnt <= kf1_cnt + 1;
        if (dut.kf2) kf2_cnt <= kf2_cnt + 1;
        if (dut.kf3) kf3_cnt <= kf3_cnt + 1;
        medvs_d <= dut.image_median_vs;
        if (dut.image_median_vs && !medvs_d) medvs_rise <= medvs_rise + 1;
    end

    // ---- 行/帧统计 ----
    integer line_de = 0, xpos = 0, frm = 0;
    integer l_de = 0, l_vs = 0, l_tot = 0;
    integer bad_width = 0, bad_black = 0;      // bad_black = 480~719 行出现非零
    integer empty_pic_lines = 0;               // 0~479 行里全黑的行数（观测用）
    integer nzLline = 0, nzRline = 0;
    integer lfL = -1, llL = -1, lfR = -1, llR = -1;   // 左/右半内容的首/末行
    integer cLg = 0, cLm = 0, cLc = 0, cLn = 0;
    integer cRg = 0, cRm = 0, cRc = 0, cRn = 0;
    reg ohs_d = 0, ovs_d = 0;
    wire pos_hs = o_hs && !ohs_d;
    wire pos_vs = o_vs && !ovs_d;

    always @(posedge clk) begin
        ohs_d <= o_hs; ovs_d <= o_vs;
        if (!rst_n) begin
            line_de <= 0; xpos <= 0; frm <= 0;
            l_de <= 0; l_vs <= 0; l_tot <= 0;
            bad_width <= 0; bad_black <= 0; empty_pic_lines <= 0;
            nzLline <= 0; nzRline <= 0;
            lfL <= -1; llL <= -1; lfR <= -1; llR <= -1;
            cLg <= 0; cLm <= 0; cLc <= 0; cLn <= 0;
            cRg <= 0; cRm <= 0; cRc <= 0; cRn <= 0;
        end else begin
            if (pos_hs) begin
                if (line_de != 0 && line_de != 1280) bad_width <= bad_width + 1;
                if (line_de != 0) begin
                    l_de <= l_de + 1;
                    // ★黑边判据（v2 修正）：480~719 行应当全黑 ⇒ 出现非零才是错
                    if (dut.d_vcnt >= 480) begin
                        if ((nzLline + nzRline) != 0) bad_black <= bad_black + 1;
                    end else begin
                        if ((nzLline + nzRline) == 0) empty_pic_lines <= empty_pic_lines + 1;
                        else begin
                            if (nzLline != 0) begin
                                if (lfL < 0) lfL <= dut.d_vcnt;
                                llL <= dut.d_vcnt;
                            end
                            if (nzRline != 0) begin
                                if (lfR < 0) lfR <= dut.d_vcnt;
                                llR <= dut.d_vcnt;
                            end
                        end
                    end
                end
                line_de <= 0; xpos <= 0; l_tot <= l_tot + 1;
                nzLline <= 0; nzRline <= 0;
            end

            if (ovs_d && !o_vs) begin
                $display("[FRAME %0d] total=%0d de_lines=%0d vs_lines=%0d | widthErr=%0d blackErr=%0d emptyPic=%0d | Lrows=%0d..%0d Rrows=%0d..%0d",
                         frm, l_tot, l_de, l_vs, bad_width, bad_black, empty_pic_lines,
                         lfL, llL, lfR, llR);
                $display("   KEYS: k0=%b kf0=%0d key_median=%b median_en=%b | kf1=%0d thr=%0d | kf2=%0d dm=%0d | kf3=%0d split=%b(%0d/%0d) | medvs_rise=%0d",
                         k0, kf0_cnt, dut.key_median, dut.median_en_sync,
                         kf1_cnt, dut.sobel_threshold_use,
                         kf2_cnt, dut.disp_mode_sync,
                         kf3_cnt, dut.split_mode, dut.split_left_sel, dut.split_right_sel,
                         medvs_rise);
                frm <= frm + 1;
                l_de <= 0; l_vs <= 0; l_tot <= 0;
                empty_pic_lines <= 0;
                lfL <= -1; llL <= -1; lfR <= -1; llR <= -1;
            end

            if (pos_hs && o_vs) l_vs <= l_vs + 1;

            if (o_de) begin
                line_de <= line_de + 1;
                if (dut.d_vcnt >= 300 && dut.d_vcnt < 380) begin
                    if (xpos < 640) begin
                        if (is_gray565) cLg <= cLg + 1;
                        if (is_mono)    cLm <= cLm + 1;
                        if (is_color)   cLc <= cLc + 1;
                        if (oR!=0||oG!=0||oB!=0) cLn <= cLn + 1;
                    end else begin
                        if (is_gray565) cRg <= cRg + 1;
                        if (is_mono)    cRm <= cRm + 1;
                        if (is_color)   cRc <= cRc + 1;
                        if (oR!=0||oG!=0||oB!=0) cRn <= cRn + 1;
                    end
                end
                if (xpos < 640) begin if (oR!=0||oG!=0||oB!=0) nzLline <= nzLline + 1; end
                else            begin if (oR!=0||oG!=0||oB!=0) nzRline <= nzRline + 1; end
                xpos <= xpos + 1;
            end
        end
    end

    task automatic press_key;
        input integer which;
        begin
            case (which)
                0: k0 = 1'b1; 1: k1 = 1'b1; 2: k2 = 1'b1; default: k3 = 1'b1;
            endcase
            repeat (400) @(posedge clk);
            case (which)
                0: k0 = 1'b0; 1: k1 = 1'b0; 2: k2 = 1'b0; default: k3 = 1'b0;
            endcase
            repeat (200) @(posedge clk);
        end
    endtask

    task automatic wait_frames;
        input integer n;
        begin
            repeat (n * 750 * 1650) @(posedge clk);
        end
    endtask

    task automatic show;
        input [8*20-1:0] tag;
        begin
            $display("  [%0s] LEFT  gray=%0d mono=%0d col=%0d nz=%0d | RIGHT gray=%0d mono=%0d col=%0d nz=%0d",
                     tag, cLg, cLm, cLc, cLn, cRg, cRm, cRc, cRn);
            cLg=0; cLm=0; cLc=0; cLn=0; cRg=0; cRm=0; cRc=0; cRn=0;
        end
    endtask

    initial begin
        $display("==== tb_m4_pipeline v2 ====");
        rst_n = 0;
        repeat (20) @(posedge clk);
        rst_n = 1;

        wait_frames(6);
        $display("");
        $display("---- A: 上电态（左=灰度 / 右=edge_overlay(mode0=二值)）----");
        $display("   sel=%0d/%0d median_en=%0b dm=%0d thr=%0d split=%b",
                 dut.split_left_sel, dut.split_right_sel, dut.median_en_sync,
                 dut.disp_mode_sync, dut.sobel_threshold_use, dut.split_mode);
        show("A");

        $display("");
        $display("---- B: 按 key2 两次（dm 0->1->2 硬彩边）----");
        press_key(2); press_key(2);
        wait_frames(4);
        $display("   dm=%0d（期望 2）", dut.disp_mode_sync);
        show("B");

        $display("");
        $display("---- C: 按 key0（中值引入）----");
        $display("   按之前 key_median=%b median_en=%b kf0=%0d", dut.key_median, dut.median_en_sync, kf0_cnt);
        press_key(0);
        wait_frames(4);
        $display("   按之后 key_median=%b median_en=%b kf0=%0d（期望 1 / 1 / >=1）",
                 dut.key_median, dut.median_en_sync, kf0_cnt);
        show("C");

        $display("");
        $display("---- D: 按 key1（阈值 +32）----");
        $display("   按之前 thr=%0d", dut.sobel_threshold_use);
        press_key(1);
        wait_frames(3);
        $display("   按之后 thr=%0d（期望 48）", dut.sobel_threshold_use);

        $display("");
        $display("---- E: 按 key3（换源：左=overlay 右=Canny 单色）----");
        press_key(3);
        wait_frames(5);
        $display("   sel=%0d/%0d（期望 1 / 2） split=%b", dut.split_left_sel, dut.split_right_sel, dut.split_mode);
        show("E");

        $display("");
        $display("==================================================");
        $display("  时序: widthErr=%0d（每帧 1 行是帧首过渡，正常）", bad_width);
        $display("  黑边: blackErr=%0d（480~719 行出现非零的次数，应为 0）", bad_black);
        $display("==================================================");
        $finish;
    end

    initial begin
        repeat (750 * 1650 * 60) @(posedge clk);
        $display("  TIMEOUT widthErr=%0d blackErr=%0d", bad_width, bad_black);
        $finish;
    end

endmodule
