//==============================================================================
// tb_minmax_smooth.v —— 量化 gain 平滑到底压掉多少抖
//
// 关键：直接读模块内部信号
//     f_min / f_max : 本帧统计（未平滑）  → "如果直接跟随"会用的 range
//     t_min / t_max : 平滑后（实际使用）  → 真正的 range
// 输入：每帧的低/高灰度都在抖（模拟"极值由噪声决定，每帧不一样"）
//      min 在 90..110 之间跳、max 在 230..250 之间跳
//      ⇒ 未平滑的 range 在 120..160 之间跳 ⇒ gain 在 388..544 之间跳（±21%）
// 期望：平滑后 range 只在很小范围内缓慢变化 ⇒ gain 基本稳定
//==============================================================================
`timescale 1ns/1ns
module tb_minmax_smooth;

  reg clk, rst_n, vld, vs, hs;
  reg [7:0] din;

  initial clk = 1'b0;
  always #20 clk = ~clk;

  wire [7:0] dout;
  wire dvalid, dhs, dvs;

  minmax_stretch #(.MIN_RANGE(24), .MAX_GAIN(768)) u_dut (
    .clk(clk), .sys_rst_n(rst_n), .din(din), .valid(vld), .hs(hs), .vs(vs),
    .en(1'b1),
    .dout(dout), .dout_valid(dvalid), .dout_hs(dhs), .dout_vs(dvs)
  );

  // 内部信号（ModelSim 层级引用）
  wire [7:0] f_min_i = u_dut.f_min;
  wire [7:0] f_max_i = u_dut.f_max;
  wire [7:0] t_min_i = u_dut.t_min;
  wire [7:0] t_max_i = u_dut.t_max;

  integer fr, k, y, x;
  integer lo, hi;
  integer range_f, range_t;
  integer gmin_t, gmax_t, gmin_f, gmax_f;   // 平滑/未平滑 的 range 极值

  // Q8 增益表（和模块里一致，用于估算 gain 抖多少）
  function integer gain_of;
    input integer r;
    integer cls;
    begin
      cls = (r > 255) ? 15 : (r / 16);
      case(cls)
        0: gain_of = 2048;  1: gain_of = 2048;  2: gain_of = 1632;
        3: gain_of = 1165;  4: gain_of = 906;   5: gain_of = 741;
        6: gain_of = 627;   7: gain_of = 544;   8: gain_of = 480;
        9: gain_of = 429;  10: gain_of = 388;  11: gain_of = 354;
       12: gain_of = 326;  13: gain_of = 302;  14: gain_of = 281;
        default: gain_of = 263;
      endcase
      if(gain_of > 768) gain_of = 768;     // MAX_GAIN
    end
  endfunction

  task do_frame;
    input integer f;
    integer yy, xx;
    begin
      // 每帧的 min/max 都在抖（模拟噪声极值）
      lo = 90 + ((f * 7) % 21);      // 90..110
      hi = 230 + ((f * 11) % 21);    // 230..250
      for (yy = 0; yy < 3; yy = yy + 1) begin
        for (xx = 0; xx < 640; xx = xx + 1) begin
          @(negedge clk);
          vld = 1'b1; hs = 1'b1; vs = 1'b1;
          din = lo + ((xx * (hi - lo)) / 640);
        end
        for (k = 0; k < 6; k = k + 1) begin
          @(negedge clk);
          vld = 1'b0; hs = 1'b0; vs = 1'b1;
        end
      end
      // 帧末 vs 拉低：这里统计值会锁进 t_min/t_max
      for (k = 0; k < 12; k = k + 1) begin
        @(negedge clk);
        vld = 1'b0; hs = 1'b1; vs = 1'b0;
      end
      @(negedge clk); @(negedge clk);   // 等锁存结果
      range_f = f_max_i - f_min_i;
      range_t = t_max_i - t_min_i;
      if(f > 1) begin          // 前两帧跳过（统计还没建立）
        if(range_f < gmin_f) gmin_f = range_f;
        if(range_f > gmax_f) gmax_f = range_f;
        if(range_t < gmin_t) gmin_t = range_t;
        if(range_t > gmax_t) gmax_t = range_t;
        $display("  帧%0d:  f_min/f_max=%0d/%0d → range_f=%0d (gain=%0d)   |   t_min/t_max=%0d/%0d → range_t=%0d (gain=%0d)",
                 f, f_min_i, f_max_i, range_f, gain_of(range_f),
                 t_min_i, t_max_i, range_t, gain_of(range_t));
      end
    end
  endtask

  initial begin
    rst_n = 1'b0; vld = 1'b0; din = 8'd0; vs = 1'b0; hs = 1'b1;
    gmin_f = 999; gmax_f = 0; gmin_t = 999; gmax_t = 0;
    repeat(5) @(negedge clk);
    rst_n = 1'b1;
    repeat(6) @(negedge clk);

    $display("============================================================");
    $display(" 输入：每帧 min 在 90..110、max 在 230..250 之间抖（模拟噪声极值）");
    $display("------------------------------------------------------------");
    for (fr = 0; fr < 10; fr = fr + 1) do_frame(fr);
    $display("------------------------------------------------------------");
    $display(" 【未平滑 f】range 范围 %0d..%0d  ⇒ gain %0d..%0d  （抖动 %0d%%）",
             gmin_f, gmax_f, gain_of(gmax_f), gain_of(gmin_f),
             (gmax_f > 0) ? ((gmax_f - gmin_f) * 100 / gmax_f) : 0);
    $display(" 【平滑后 t】range 范围 %0d..%0d  ⇒ gain %0d..%0d  （抖动 %0d%%）",
             gmin_t, gmax_t, gain_of(gmax_t), gain_of(gmin_t),
             (gmax_t > 0) ? ((gmax_t - gmin_t) * 100 / gmax_t) : 0);
    $display("============================================================");
    $finish;
  end

endmodule
