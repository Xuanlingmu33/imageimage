//==============================================================================
// tb_m8_minmax.v —— 证明 m8 里的 min-max 拉伸真的在起作用（不只是接线）
//
// 做法：喂 3 帧【低对比度】灰度（线性 40..99，range=59）
//   第 1 帧：t_min/t_max 还是复位值(0/255) ⇒ 基本原样输出（增益≈1.03x）
//   第 2 帧起：用第 1 帧统计出的 min=40 / max=99 ⇒ 增益查表
//             range=59 → range[7:4]=3 → gain_case=1165 → out=(in-40)*1165>>8 ≈ 4.55x
//             ⇒ 40..99 被拉到 0..268，饱和到 255（= 拉满量程）
//
// 判据：第 3 帧的输出最大值必须【明显大于】输入最大值，且接近 255
//       —— 这就证明"拉伸生效"，不是"接了个摆设"。
//==============================================================================
`timescale 1ns/1ns
module tb_m8_minmax;

  reg clk, rst_n, vld, vs, hs;
  reg [7:0] din;
  wire [7:0] dout;
  wire dvalid, dhs, dvs;

  initial clk = 1'b0;
  always #20 clk = ~clk;

  minmax_stretch #(.MIN_RANGE(4), .MAX_GAIN(2048)) u_dut (
    .clk(clk), .sys_rst_n(rst_n),
    .din(din), .valid(vld), .hs(hs), .vs(vs),
    .en(1'b1),
    .dout(dout), .dout_valid(dvalid), .dout_hs(dhs), .dout_vs(dvs)
  );

  integer fr, y, x, k;
  integer in_max, out_max_f1, out_max_f3;

  task do_frame;
    input integer f;
    integer yy, xx;
    begin
      for (yy = 0; yy < 4; yy = yy + 1) begin
        for (xx = 0; xx < 640; xx = xx + 1) begin
          @(negedge clk);
          vld = 1'b1; hs = 1'b1; vs = 1'b1;
          din = 8'd40 + ((xx * 60) / 640);     // 40..99，range = 59
          // 采集输出（第 1 帧 / 第 3 帧）
          if (f == 0 && dout > out_max_f1) out_max_f1 = dout;
          if (f == 2 && dout > out_max_f3) out_max_f3 = dout;
        end
        // 行间 8 拍空档
        for (k = 0; k < 8; k = k + 1) begin
          @(negedge clk);
          vld = 1'b0; hs = 1'b0; vs = 1'b1;
        end
      end
      // 帧末：vs 拉低 20 拍（= 消隐期；min-max 就在 vs 上升沿锁存统计）
      for (k = 0; k < 20; k = k + 1) begin
        @(negedge clk);
        vld = 1'b0; hs = 1'b1; vs = 1'b0;
      end
    end
  endtask

  initial begin
    rst_n = 1'b0; vld = 1'b0; din = 8'd0; vs = 1'b0; hs = 1'b1;
    in_max = 0; out_max_f1 = 0; out_max_f3 = 0;
    repeat(5) @(negedge clk);
    rst_n = 1'b1;
    repeat(6) @(negedge clk);      // 让 en 生效

    for (fr = 0; fr < 3; fr = fr + 1) do_frame(fr);
    // 排空
    repeat(30) @(negedge clk);

    $display("------------------------------------------------------------");
    $display(" 输入灰度范围       : 40 .. 99   (range=59)");
    $display(" 第 1 帧输出最大值  : %0d   (统计还没建立，增益≈1.03x)", out_max_f1);
    $display(" 第 3 帧输出最大值  : %0d   (已按 40/99 拉伸，理论≈255 饱和)", out_max_f3);
    $display("------------------------------------------------------------");
    if (out_max_f1 < 110 && out_max_f3 > 200)
      $display(" [OK] 第1帧≈原样(%0d)，第3帧被拉满(%0d)  ⇒ min-max 拉伸确实在工作", out_max_f1, out_max_f3);
    else if (out_max_f3 <= 110)
      $display(" [FAIL] 第3帧没被拉伸(%0d)，说明 min-max 没起作用", out_max_f3);
    else
      $display(" [CHECK] f1=%0d f3=%0d（数值不典型，人工看一下）", out_max_f1, out_max_f3);
    $display("------------------------------------------------------------");
    $finish;
  end

endmodule
