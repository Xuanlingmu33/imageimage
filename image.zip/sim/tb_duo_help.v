//==============================================================================
// tb_duo_help.v —— 量化"多尺度 ×2"对断线/弱边到底有多大帮助（干净版）
//
// 三个 DUT 吃同一路像素：
//   u_ref : 单尺度 sobel（Scharr）
//   u_m0  : ms_grad  MS_EN=0           → 应与 u_ref 的 mag 逐位相同
//   u_m1  : ms_grad  MS_EN=1 GAIN=1    → 多尺度 ×2（m8_duochidu）
//
// 图像：640 宽；软竖边在 x≈320（5px 斜坡）；
//       边的【幅度沿 y 平滑变化】200→135→200（周期 12 行，每行只变 13）
//       ⇒ 行与行之间没有突变 ⇒ 竖直方向几乎不产生梯度 ⇒ 测到的就是横边本身
//       ⇒ 幅度小的那几行就代表"弱边/临界断线"
//
// 统计（按输出行，x∈[316,324] 内的最大幅值）：
//   · 单尺度/多尺度的 最小、平均、最大
//   · 不同阈值下"该行能检出"的行占比（覆盖率）
//==============================================================================
`timescale 1ns/1ns
module tb_duo_help;

  localparam W  = 640;
  localparam NR = 120;
  localparam NTH = 7;

  reg clk, rst_n, vld, hs, vs;
  reg [7:0] din;

  initial clk = 1'b0;
  always #20 clk = ~clk;

  wire d_ref, v_ref, h_ref, s_ref;
  wire [7:0]  st_ref;
  wire [10:0] mg_ref;
  wire d_m0, v_m0, h_m0, s_m0;
  wire [7:0]  st_m0;
  wire [10:0] mg_m0;
  wire d_m1, v_m1, h_m1, s_m1;
  wire [7:0]  st_m1;
  wire [10:0] mg_m1;

  sobel #(.DATA_WIDTH(8), .LINE_WIDTH(W), .GRAD_OP(1), .BORDER_MASK(1'b0), .STRENGTH_SHIFT(1))
  u_ref (.clk(clk), .sys_rst_n(rst_n), .data_in(din), .data_in_valid(vld),
         .data_in_hs(hs), .data_in_vs(vs), .threshold(11'd256),
         .data_out(d_ref), .data_out_valid(v_ref), .data_out_hs(h_ref), .data_out_vs(s_ref),
         .strength_o(st_ref), .mag_o(mg_ref));

  ms_grad #(.DATA_WIDTH(8), .LINE_WIDTH(W), .GRAD_OP(1), .BORDER_MASK(1'b0),
            .STRENGTH_SHIFT(1), .MS_EN(0), .MS_GAIN(0))
  u_m0 (.clk(clk), .sys_rst_n(rst_n), .data_in(din), .data_in_valid(vld),
        .data_in_hs(hs), .data_in_vs(vs), .threshold(11'd256),
        .data_out(d_m0), .data_out_valid(v_m0), .data_out_hs(h_m0), .data_out_vs(s_m0),
        .strength_o(st_m0), .mag_o(mg_m0));

  ms_grad #(.DATA_WIDTH(8), .LINE_WIDTH(W), .GRAD_OP(1), .BORDER_MASK(1'b0),
            .STRENGTH_SHIFT(1), .MS_EN(1), .MS_GAIN(1))
  u_m1 (.clk(clk), .sys_rst_n(rst_n), .data_in(din), .data_in_valid(vld),
        .data_in_hs(hs), .data_in_vs(vs), .threshold(11'd256),
        .data_out(d_m1), .data_out_valid(v_m1), .data_out_hs(h_m1), .data_out_vs(s_m1),
        .strength_o(st_m1), .mag_o(mg_m1));

  //--------------------------------------------------------------------------
  function [7:0] pix;
    input integer y, x;
    integer amp, v, cyc;
    begin
      cyc = y % 12;
      amp = (cyc < 6) ? (200 - cyc*13) : (135 + (cyc-6)*13);   // 200→135→200 平滑
      if      (x <= 318) v = 0;
      else if (x >= 323) v = amp;
      else               v = amp * (x - 318) / 5;
      pix = v;
    end
  endfunction

  //--------------------------------------------------------------------------
  integer x, y, k, i;
  integer th_list[0:NTH-1];
  integer cmax_ref, cmax_m1;
  integer ok_ref[0:NTH-1], ok_m1[0:NTH-1];
  integer sum_ref, sum_m1, mn_ref, mn_m1, mx_ref, mx_m1;
  integer err_eq, rows_done;
  integer ocol, orow;

  initial begin
    th_list[0]=80; th_list[1]=120; th_list[2]=160; th_list[3]=200;
    th_list[4]=240; th_list[5]=320; th_list[6]=400;
    for (k = 0; k < NTH; k = k + 1) begin ok_ref[k]=0; ok_m1[k]=0; end
    cmax_ref=0; cmax_m1=0; err_eq=0; rows_done=0;
    sum_ref=0; sum_m1=0; mn_ref=9999; mn_m1=9999; mx_ref=0; mx_m1=0;
    ocol=0; orow=0;

    rst_n = 1'b0; vld = 1'b0; hs = 1'b1; vs = 1'b1; din = 8'd0;
    repeat(5) @(negedge clk);
    rst_n = 1'b1;
    repeat(3) @(negedge clk);

    for (y = 0; y < NR; y = y + 1) begin
      for (x = 0; x < W; x = x + 1) begin
        @(negedge clk);
        vld = 1'b1; hs = 1'b1; vs = 1'b1;
        din = pix(y, x);
      end
      @(negedge clk); vld = 1'b0; hs = 1'b0; vs = 1'b1;
      for (k = 0; k < 6; k = k + 1) begin
        @(negedge clk); vld = 1'b0; hs = 1'b1; vs = 1'b1;
      end
    end
    repeat(200) @(negedge clk);

    $display("");
    $display("================================================================");
    $display(" 图像 %0d 行，软竖边(x=320)，幅度沿 y 平滑变化 200->135->200", NR);
    $display("----------------------------------------------------------------");
    $display(" 【包装层无损】 u_m0(MS_EN=0) 与 u_ref 的 mag 不等次数 = %0d", err_eq);
    $display("----------------------------------------------------------------");
    $display(" 每行(x附近)最大幅值：  最小   平均   最大");
    $display("   单尺度 sobel      : %5d  %5d  %5d", mn_ref, (rows_done>0)?(sum_ref/rows_done):0, mx_ref);
    $display("   多尺度 x2         : %5d  %5d  %5d", mn_m1,  (rows_done>0)?(sum_m1/rows_done):0,  mx_m1);
    $display("----------------------------------------------------------------");
    $display(" 覆盖率（该行在边附近有像素超过阈值，就算检出；共 %0d 行）", rows_done);
    $display("   阈值 |  单尺度  |  多尺度x2 | 提升");
    for (k = 0; k < NTH; k = k + 1)
      $display("  %5d |  %3d%%    |  %3d%%     | %4d%%", th_list[k],
               (rows_done>0)?(ok_ref[k]*100/rows_done):0,
               (rows_done>0)?(ok_m1[k]*100/rows_done):0,
               (rows_done>0)?((ok_m1[k]-ok_ref[k])*100/rows_done):0);
    $display("================================================================");
    $finish;
  end

  //--------------------------------------------------------------------------
  always @(posedge clk) begin
    if (rst_n && v_ref) begin
      if (mg_m0 !== mg_ref) err_eq = err_eq + 1;

      if (ocol >= 316 && ocol <= 324) begin
        if (mg_ref > cmax_ref) cmax_ref = mg_ref;
        if (mg_m1  > cmax_m1 ) cmax_m1  = mg_m1;
      end

      if (ocol == W-1) begin
        ocol <= 0;
        orow <= orow + 1;
        if (orow >= 4) begin
          rows_done = rows_done + 1;
          sum_ref = sum_ref + cmax_ref;   if (cmax_ref < mn_ref) mn_ref = cmax_ref;  if (cmax_ref > mx_ref) mx_ref = cmax_ref;
          sum_m1  = sum_m1  + cmax_m1;    if (cmax_m1  < mn_m1 ) mn_m1  = cmax_m1;   if (cmax_m1  > mx_m1 ) mx_m1  = cmax_m1;
          for (i = 0; i < NTH; i = i + 1) begin
            if (cmax_ref > th_list[i]) ok_ref[i] = ok_ref[i] + 1;
            if (cmax_m1  > th_list[i]) ok_m1[i]  = ok_m1[i]  + 1;
          end
        end
        cmax_ref = 0; cmax_m1 = 0;
      end
      else ocol <= ocol + 1;
    end
  end

endmodule
