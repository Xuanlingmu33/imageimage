//==============================================================================
// tb_minmax_gentle.v —— 量化"温和版"到底温和了多少
//
// 两个 DUT 吃同一路灰度，只是参数不同：
//   u_orig  : MIN_RANGE=4    MAX_GAIN=2048   （原来那版"用力过猛"）
//   u_gentle: MIN_RANGE=24   MAX_GAIN=512    （现在 m8 里的温和版）
//
// 两组测试：
//   case 1  range=59（40..99）  正常低对比
//   case 2  range=10（40..49）  极低对比 —— 这种 range 其实就是噪声
//
// 期望：
//   case 1: 原版拉到 ~255，温和版只到 ~118（放大 2 倍封顶）
//   case 2: 原版仍然放大 ~8 倍（噪声爆炸），温和版 range<24 ⇒ 完全不放大 ⇒ 输出只有 ~10
//==============================================================================
`timescale 1ns/1ns
module tb_minmax_gentle;

  reg clk, rst_n, vld, vs, hs;
  reg [7:0] din;

  initial clk = 1'b0;
  always #20 clk = ~clk;

  wire [7:0] d_orig, d_gentle;
  wire v_o, v_g, h_o, h_g, s_o, s_g;

  minmax_stretch #(.MIN_RANGE(4),  .MAX_GAIN(2048)) u_orig (
    .clk(clk), .sys_rst_n(rst_n), .din(din), .valid(vld), .hs(hs), .vs(vs), .en(1'b1),
    .dout(d_orig), .dout_valid(v_o), .dout_hs(h_o), .dout_vs(s_o));

  minmax_stretch #(.MIN_RANGE(24), .MAX_GAIN(512)) u_gentle (
    .clk(clk), .sys_rst_n(rst_n), .din(din), .valid(vld), .hs(hs), .vs(vs), .en(1'b1),
    .dout(d_gentle), .dout_valid(v_g), .dout_hs(h_g), .dout_vs(s_g));

  integer lo, hi;
  integer mx_orig, mx_gentle;
  integer fr, k, y, x;

  task do_frame;
    input integer f;
    integer yy, xx;
    begin
      for (yy = 0; yy < 4; yy = yy + 1) begin
        for (xx = 0; xx < 640; xx = xx + 1) begin
          @(negedge clk);
          vld = 1'b1; hs = 1'b1; vs = 1'b1;
          din = lo + ((xx * (hi - lo + 1)) / 640);
          if (f == 2) begin
            if (d_orig   > mx_orig)   mx_orig   = d_orig;
            if (d_gentle > mx_gentle) mx_gentle = d_gentle;
          end
        end
        for (k = 0; k < 8; k = k + 1) begin
          @(negedge clk);
          vld = 1'b0; hs = 1'b0; vs = 1'b1;
        end
      end
      for (k = 0; k < 20; k = k + 1) begin
        @(negedge clk);
        vld = 1'b0; hs = 1'b1; vs = 1'b0;
      end
    end
  endtask

  task run_case;
    input integer l;
    input integer h;
    input [255:0] name;
    begin
      lo = l; hi = h;
      mx_orig = 0; mx_gentle = 0;
      for (fr = 0; fr < 3; fr = fr + 1) do_frame(fr);
      $display("  %0s  (灰度 %0d..%0d, range=%0d):  原版最大输出=%0d   温和版最大输出=%0d",
               name, l, h, h - l, mx_orig, mx_gentle);
    end
  endtask

  initial begin
    rst_n = 1'b0; vld = 1'b0; din = 8'd0; vs = 1'b0; hs = 1'b1;
    repeat(5) @(negedge clk);
    rst_n = 1'b1;
    repeat(6) @(negedge clk);

    $display("------------------------------------------------------------");
    run_case(40, 99, "case1 正常低对比");
    run_case(40, 49, "case2 极低对比(实为噪声)");
    $display("------------------------------------------------------------");
    $finish;
  end

endmodule
