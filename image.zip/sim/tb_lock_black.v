//==============================================================================
// tb_lock_black.v —— 复现"上电无效帧把画面锁成全黑"的 bug，并验证已修好
//
// 激励：
//   阶段1：3 帧【全 255】（模拟上电后 DDR3/传感器还没稳定时的无效画面）
//   阶段2：20 帧正常画面（灰度斜坡 40..160，range=120）
//
// 判据：
//   · 阶段1 结束时 t_min 必须【还是 0】（不能变成 255）
//   · 阶段2 里 dout 的最大值必须 > 0（不能全黑）
//   · 阶段2 标定完成后 t_min≈40、t_max≈160
//==============================================================================
`timescale 1ns/1ns
module tb_lock_black;

  reg clk, rst_n, vld, hs, vs;
  reg [7:0] din;
  wire [7:0] dout;
  wire dvalid, dhs, dvs;

  initial clk = 1'b0;
  always #20 clk = ~clk;

  minmax_stretch #(.MIN_RANGE(24), .MAX_GAIN(768)) u_dut (
    .clk(clk), .sys_rst_n(rst_n), .din(din), .valid(vld), .hs(hs), .vs(vs),
    .en(1'b1),
    .dout(dout), .dout_valid(dvalid), .dout_hs(dhs), .dout_vs(dvs)
  );

  wire [7:0] t_min_i = u_dut.t_min;
  wire [7:0] t_max_i = u_dut.t_max;

  integer fr, k, x, y;
  integer all255;        // 1 = 送全 255
  integer dmax, tmin_after_bad;

  task do_frame;
    input integer f;
    integer yy, xx;
    begin
      for (yy = 0; yy < 8; yy = yy + 1) begin
        for (xx = 0; xx < 640; xx = xx + 1) begin
          @(negedge clk);
          vld = 1'b1; hs = 1'b1; vs = 1'b1;
          if (all255) din = 8'hFF;
          else        din = 8'd40 + ((xx * 121) / 640);   // 40..160
          if (dout > dmax) dmax = dout;
        end
        for (k = 0; k < 6; k = k + 1) begin
          @(negedge clk); vld = 1'b0; hs = 1'b0; vs = 1'b1;
        end
      end
      for (k = 0; k < 12; k = k + 1) begin
        @(negedge clk); vld = 1'b0; hs = 1'b1; vs = 1'b0;
      end
      @(negedge clk); @(negedge clk);
    end
  endtask

  initial begin
    rst_n = 1'b0; vld = 1'b0; hs = 1'b1; vs = 1'b1; din = 8'd0;
    dmax = 0; tmin_after_bad = 0;
    repeat(5) @(negedge clk);
    rst_n = 1'b1;
    repeat(4) @(negedge clk);

    // ---- 阶段1：3 帧全 255（无效画面）----
    all255 = 1;
    for (fr = 0; fr < 3; fr = fr + 1) do_frame(fr);
    tmin_after_bad = t_min_i;
    $display("");
    $display("------------------------------------------------------------");
    $display(" 阶段1（3 帧全 255 的无效画面）结束后：");
    $display("   t_min = %0d   t_max = %0d   （t_min 必须还是 0）", t_min_i, t_max_i);

    // ---- 阶段2：20 帧正常画面 ----
    all255 = 0;
    dmax = 0;
    for (fr = 0; fr < 20; fr = fr + 1) do_frame(fr);
    $display("------------------------------------------------------------");
    $display(" 阶段2（20 帧正常画面，灰度 40..160）结束后：");
    $display("   t_min = %0d   t_max = %0d   （应≈40/160）", t_min_i, t_max_i);
    $display("   输出最大值 = %0d   （必须 > 0，不能全黑）", dmax);
    $display("------------------------------------------------------------");
    if (tmin_after_bad == 0)
      $display(" [OK]   无效帧没有把 t_min 锁成 255  → 不会再全黑");
    else
      $display(" [FAIL] t_min 被锁成 %0d → 会全黑！", tmin_after_bad);
    if (dmax > 0)
      $display(" [OK]   正常画面有输出（max=%0d）", dmax);
    else
      $display(" [FAIL] 正常画面输出全 0（黑屏）");
    $display("------------------------------------------------------------");
    $finish;
  end

endmodule
