//=============================================================================
// tb_dbg_long.v —— 长按调试探针：按住不放，每 100ms 打印一次内部计时器
//=============================================================================
`timescale 1ns/1ps
module tb_dbg_long;
    reg clk = 0;
    always #6.734 clk = ~clk;
    reg rst_n = 0, key = 0;

    wire ev_thr, ev_sign, ev_step, ev_msign, ev_mstep, ev_mdef;
    wire kp, kr;
    wire [1:0] mode; wire sign; wire [2:0] step_idx; wire [5:0] step_val; wire [10:0] thr;

    key_mode_fsm u (
        .clk(clk), .rst_n(rst_n), .key(key),
        .ev_thr(ev_thr), .ev_sign(ev_sign), .ev_step(ev_step),
        .ev_mode_def(ev_mdef), .ev_mode_sign(ev_msign), .ev_mode_step(ev_mstep),
        .key_press(kp), .key_release(kr),
        .mode(mode), .sign(sign), .step_idx(step_idx), .step_val(step_val), .thr_cur(thr)
    );

    integer i;
    initial begin
        $display("T_LONG(参数)=%0d  T_MINCLK=%0d  DEBOUNCE=%0d  T_GAP=%0d",
                 u.T_LONG, u.T_MINCLK, u.DEBOUNCE, u.T_GAP);
        rst_n = 0; repeat (200) @(posedge clk); rst_n = 1;
        repeat (74250) @(posedge clk);                 // 1ms
        key = 1'b1;
        $display("按下开始");
        for (i = 0; i < 15; i = i + 1) begin
            repeat (74250 * 100) @(posedge clk);       // 每 100ms
            $display("  t=%0dms  pressed=%b key_stable=%b dur=%0d long_fired=%b hit_long=%b mode=%0d",
                     (i+1)*100, u.pressed, u.key_stable, u.dur, u.long_fired,
                     u.pressed & (u.dur >= u.T_LONG) & ~u.long_fired, mode);
        end
        key = 1'b0;
        repeat (74250 * 100) @(posedge clk);
        $display("松开后: mode=%0d thr=%0d", mode, thr);
        $finish;
    end
endmodule
