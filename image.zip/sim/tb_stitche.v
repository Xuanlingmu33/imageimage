//=============================================================================
// tb_stitche.v —— image_stitche_x 单元测试（两路【不同图案】）
//
// 为什么需要它：
//   整体 TB 两半接同一个灰度源 ⇒ 只能证明"两半一致"，对"左右搞混 / 读窗偏移 /
//   某半被抽空"这类错误完全盲 ✗ ⇒ 必须两路不同图案，且要测【列位置】✓
//
// 【上层真实条件（照抄，否则复现不出 bug）】
//   · 输入：一行 1650 拍；两路 valid 在行内第 110~749 拍（640 拍，1 像素/拍）
//           ★ 而且 valid 只在【第 0~479 行】有（cvo_axi 的 o_de 受 v_state 门控）★
//           ⇒ 每帧每路只写 480x640 = 307200 拍
//   · 一帧 750 行；vs（有效区电平 = ~i_vs）在第 725~729 行为低，其余为高
//   · 读窗 data_out_ready_i = disp_timing 的 de = (h_cnt < 1280)
//           ★ de 只跟水平有关 ⇒ 750 行里【每一行】都拉高 1280 拍 ★
//           ⇒ 每帧每路被读 750x640 = 480000 拍  ←—— 读 480000 / 写 307200 ✗
//
// 【图案】
//   image1: 背景 0x1001；第 10  列竖条 0x1002；第 100 行横条 0x1003
//   image2: 背景 0x2001；第 600 列竖条 0x2002；第 300 行横条 0x2003
//
// 【期望】
//   左半：每行恰好 1 个 0x1002，且它出现在【输出列 10】；右半不得出现 0x1002
//   右半：每行恰好 1 个 0x2002，且它出现在【输出列 1240】；左半不得出现 0x2002
//   0x1003 只在左半、只出现在 1 行；0x2003 只在右半、只出现在 1 行
//=============================================================================
`timescale 1ns/1ps
module tb_stitche;

    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;

    // ---------------- 输入时序（照抄上层）----------------
    integer hc = 0;          // 0..1649
    integer vc = 0;          // 0..749
    always @(posedge clk) begin
        if (hc == 1649) begin hc <= 0; vc <= (vc == 749) ? 0 : vc + 1; end
        else                  hc <= hc + 1;
    end

    wire row_vis  = (vc < 480);                                   // ★ 只有 480 个有效行
    wire in_valid = rst_n && (hc >= 110) && (hc < 750) && row_vis;
    wire in_vs    = rst_n && !((vc >= 725) && (vc < 730));        // 有效区电平
    wire [15:0] icol = hc[15:0] - 16'd110;

    wire [15:0] p1 = (vc == 100) ? 16'h1003 : ((icol == 16'd10 ) ? 16'h1002 : 16'h1001);
    wire [15:0] p2 = (vc == 300) ? 16'h2003 : ((icol == 16'd600) ? 16'h2002 : 16'h2001);

    // ---------------- 读窗（照抄 disp_timing 的 de：每一行都 1280 拍）----------------
    wire rd_ready = rst_n && (hc < 1280);

    // ---------------- DUT ----------------
    wire [15:0] o_pix;
    wire        o_vld;
    image_stitche_x #(
        .DATA_WIDTH       (16  ),
        .IMAGE1_WIDTH_IN  (640 ),
        .IMAGE1_HEIGHT_IN (480 ),
        .IMAGE2_WIDTH_IN  (640 ),
        .IMAGE2_HEIGHT_IN (480 ),
        .IMAGE_WIDTH_OUT  (1280),
        .IMAGE_HEIGHT_OUT (480 ),
        .LINE_WIDTH       (1280),
        .ALIGN_ROW_DLY    (0   ),
        .ALIGN_FINE_DLY   (1   ),
        .SEL_DIRECT       (1   )
    ) dut (
        .clk_image1_in      (clk      ),
        .clk_image2_in      (clk      ),
        .clk_image_out      (clk      ),
        .sys_rst_n          (rst_n    ),
        .image1_data_pixel_i(p1       ),
        .image1_data_valid_i(in_valid ),
        .image1_data_vs_i   (in_vs    ),
        .image2_data_pixel_i(p2       ),
        .image2_data_valid_i(in_valid ),
        .image2_data_vs_i   (in_vs    ),
        .data_out_ready_i   (rd_ready ),
        .sel_swap           (1'b0     ),
        .data_pixel_o       (o_pix    ),
        .data_valid_o       (o_vld    )
    );

    // ---------------- 统计 ----------------
    // 每行：左半 1002 出现的输出列、右半 2002 出现的输出列（-1 = 没出现）
    integer cL = -1, cR = -1;
    integer nL_row = 0, nR_row = 0, nH_L_row = 0, nH_R_row = 0;
    // 整帧累计
    integer rows_L_bar = 0, rows_R_bar = 0;
    integer colL_min = 99999, colL_max = -1, colL_sum = 0;
    integer colR_min = 99999, colR_max = -1, colR_sum = 0;
    integer xL_in_R = 0, xR_in_L = 0;          // 交叉污染：右半出现 1002 / 左半出现 2002
    integer hL_rows = 0, hR_rows = 0, hL_first = -1, hR_first = -1;
    integer other_L = 0, other_R = 0, bg_L = 0, bg_R = 0, vld_cnt = 0;
    integer minL_row = -1, maxL_row = -1, minR_row = -1, maxR_row = -1;
    integer v_extraL = 0, v_extraR = 0;        // 一行里竖条多于 1 个的次数
    // 水位
    integer l1_min = 99999, l1_max = 0, l2_min = 99999, l2_max = 0;
    integer l1_at_row0 = -1;
    integer frames = 0, prev_vc = 0;

    wire [12:0] lv1 = dut.correct_set_pro.u_fifo_left.level;
    wire [12:0] lv2 = dut.correct_set_pro.u_fifo_right.level;

    // 输出列号标定：
    //   DUT 内 rd(T) → FIFO 寄存输出(T+1) → data_pixel_o 在(T+1)边沿更新 ⇒ 从 T+2 起可见
    //   TB 又把 o_pix 打一拍(o_pix_d) ⇒ 在 hc 采样到的是 T+2 的值
    //   ⇒ 该拍对应的输出列 = (该读的 col_cnt) = T = hc-3 ✓
    reg [15:0] o_pix_d;
    reg        o_vld_d;
    always @(posedge clk) begin
        o_pix_d <= o_pix;
        o_vld_d <= o_vld;
    end
    integer ocol;
    always @(*) ocol = hc - 3;

    task reset_stats;
        begin
            rows_L_bar=0; rows_R_bar=0; v_extraL=0; v_extraR=0;
            colL_min=99999; colL_max=-1; colL_sum=0;
            colR_min=99999; colR_max=-1; colR_sum=0;
            xL_in_R=0; xR_in_L=0;
            hL_rows=0; hR_rows=0; hL_first=-1; hR_first=-1;
            other_L=0; other_R=0; bg_L=0; bg_R=0; vld_cnt=0;
            minL_row=-1; maxL_row=-1; minR_row=-1; maxR_row=-1;
        end
    endtask

    always @(posedge clk) begin
        if (rst_n) begin
            if (lv1 < l1_min) l1_min = lv1;
            if (lv1 > l1_max) l1_max = lv1;
            if (lv2 < l2_min) l2_min = lv2;
            if (lv2 > l2_max) l2_max = lv2;
            if (vc == 1 && hc == 0) l1_at_row0 = lv1;

            if (o_vld_d) begin
                vld_cnt = vld_cnt + 1;
                if (ocol >= 0 && ocol <= 639) begin          // 左半
                    case (o_pix_d)
                        16'h1001: bg_L = bg_L + 1;
                        16'h1002: begin
                            nL_row = nL_row + 1;
                            if (cL < 0) cL = ocol;
                        end
                        16'h1003: nH_L_row = nH_L_row + 1;
                        16'h2002: xR_in_L = xR_in_L + 1;     // 污染
                        default : other_L = other_L + 1;
                    endcase
                end else if (ocol >= 640 && ocol <= 1279) begin   // 右半
                    case (o_pix_d)
                        16'h2001: bg_R = bg_R + 1;
                        16'h2002: begin
                            nR_row = nR_row + 1;
                            if (cR < 0) cR = ocol;
                        end
                        16'h2003: nH_R_row = nH_R_row + 1;
                        16'h1002: xL_in_R = xL_in_R + 1;     // 污染
                        default : other_R = other_R + 1;
                    endcase
                end
            end

            // 行末结算
            if (hc == 1649) begin
                if (nL_row > 0) begin
                    rows_L_bar = rows_L_bar + 1;
                    colL_sum = colL_sum + cL;
                    if (cL < colL_min) colL_min = cL;
                    if (cL > colL_max) colL_max = cL;
                    if (minL_row < 0) minL_row = vc;
                    maxL_row = vc;
                end
                if (nR_row > 0) begin
                    rows_R_bar = rows_R_bar + 1;
                    colR_sum = colR_sum + cR;
                    if (cR < colR_min) colR_min = cR;
                    if (cR > colR_max) colR_max = cR;
                    if (minR_row < 0) minR_row = vc;
                    maxR_row = vc;
                end
                if (nL_row > 1) v_extraL = v_extraL + 1;
                if (nR_row > 1) v_extraR = v_extraR + 1;
                if (nH_L_row > 0) begin hL_rows = hL_rows + 1; if (hL_first < 0) hL_first = vc; end
                if (nH_R_row > 0) begin hR_rows = hR_rows + 1; if (hR_first < 0) hR_first = vc; end
                cL = -1; cR = -1; nL_row = 0; nR_row = 0; nH_L_row = 0; nH_R_row = 0;
            end

            // 帧界报告
            if (vc == 0 && prev_vc == 749) begin
                frames = frames + 1;
                if (frames >= 3) begin
                    $display("==== [FRAME %0d] ====", frames);
                    $display("  valid=%0d  bgL=%0d bgR=%0d otherL=%0d otherR=%0d  xL_in_R=%0d xR_in_L=%0d",
                             vld_cnt, bg_L, bg_R, other_L, other_R, xL_in_R, xR_in_L);
                    $display("  LEFT  bar(1002): rows=%0d  rows[%0d..%0d]  col(min/avg/max)=%0d/%0d/%0d  multi=%0d",
                             rows_L_bar, minL_row, maxL_row,
                             (rows_L_bar>0)?colL_min:-1, (rows_L_bar>0)?(colL_sum/rows_L_bar):-1,
                             colL_max, v_extraL);
                    $display("  RIGHT bar(2002): rows=%0d  rows[%0d..%0d]  col(min/avg/max)=%0d/%0d/%0d  multi=%0d",
                             rows_R_bar, minR_row, maxR_row,
                             (rows_R_bar>0)?colR_min:-1, (rows_R_bar>0)?(colR_sum/rows_R_bar):-1,
                             colR_max, v_extraR);
                    $display("  H bar left(1003): rows=%0d first=%0d ; H bar right(2003): rows=%0d first=%0d",
                             hL_rows, hL_first, hR_rows, hR_first);
                    $display("  FIFO1 lvl min/max=%0d/%0d  FIFO2 lvl min/max=%0d/%0d", l1_min, l1_max, l2_min, l2_max);
                    $display("  ------------------------------------------------------------");
                    // 判定
                    if (rows_L_bar < 400 || rows_R_bar < 400)
                        $display("  >>> FAIL: 竖条出现的行数太少（左%0d 右%0d，期望约480）✗", rows_L_bar, rows_R_bar);
                    if (xL_in_R != 0 || xR_in_L != 0)
                        $display("  >>> FAIL: 左右串了（右半出现1002 %0d 次、左半出现2002 %0d 次）✗", xL_in_R, xR_in_L);
                    if (colL_max != colL_min || colR_max != colR_min)
                        $display("  >>> FAIL: 竖条列位置在漂（左 %0d~%0d，右 %0d~%0d）⇒ 读指针错位 ✗",
                                 colL_min, colL_max, colR_min, colR_max);
                    if (colL_min != 10)
                        $display("  >>> FAIL: 左半竖条应落在输出列 10，实际 %0d ✗", colL_min);
                    if (colR_min != 1240)
                        $display("  >>> FAIL: 右半竖条应落在输出列 1240，实际 %0d ✗", colR_min);
                    if (v_extraL != 0 || v_extraR != 0)
                        $display("  >>> FAIL: 有行出现多个竖条（左%0d 右%0d 行）⇒ 行边界错位 ✗", v_extraL, v_extraR);
                    if (hL_rows != 1 || hR_rows != 1)
                        $display("  >>> FAIL: 横条跨行（左%0d 右%0d，期望各 1）✗", hL_rows, hR_rows);
                    if (rows_L_bar>=400 && rows_R_bar>=400 && xL_in_R==0 && xR_in_L==0 &&
                        colL_max==colL_min && colR_max==colR_min && colL_min==10 && colR_min==1240 &&
                        v_extraL==0 && v_extraR==0 && hL_rows==1 && hR_rows==1)
                        $display("  >>> PASS: 左右、列位置、行边界全部正确 ✓");
                    $finish;
                end
                reset_stats;
            end
            prev_vc <= vc;
        end
    end

    initial begin
        $display("==== image_stitche_x 单元测试（两路不同图案）====");
        $display("  输入: 行1650拍, valid=行内110~749 且只在 0~479 行（照抄 cvo_axi 的 o_de）");
        $display("  读窗: data_out_ready_i 每行都 1280 拍（照抄 disp_timing 的 de）");
        $display("  图案: img1 列10=1002 行100=1003 ; img2 列600=2002 行300=2003");
        rst_n = 0;
        repeat (20) @(posedge clk);
        rst_n = 1;
        repeat (750*1650*6) @(posedge clk);
        $display("  (超时) rows_L=%0d rows_R=%0d colL=%0d~%0d colR=%0d~%0d FIFO1min=%0d",
                 rows_L_bar, rows_R_bar, colL_min, colL_max, colR_min, colR_max, l1_min);
        $finish;
    end

endmodule
