//=============================================================================
// tb_m2m3_pipeline.v —— m2_to_m3 主封装仿真（v3：换源测试版）
//
//   本版两半接【不同源】：
//       左半 = src0 = 灰度           右半 = src1 = 原图（彩色）
//       按 key3 ⇒ 左右互换（split_src_mux 的 sel_swap，帧边界锁存 ✓）
//   ⇒ 这次能真正验证「左右没搞混 / 接缝正确 / 换源生效」✓✓
//
//   判定依据（输入背景 R=200 G=100 B=50）：
//       灰度 ⇒ R≈G≈B（|R-G|<=8）   打包再经 565→888 ⇒ 约 (123,123,123)
//       原图 ⇒ |R-G| 很大（>50）     ⇒ 约 (201,101,54)
//   ⇒ 用 |R-G| 就能区分两半是不是接对了源 ✓
//
//   【输入时序】一行 1650 拍：de=640 拍(110~749)、hs=40 拍(750~789)；一帧 750 行，vs=725~729
//   消抖：用 defparam 把 CNT_MAX 缩到 99（否则仿真要等 ~13.5ms ✗）
//=============================================================================
`timescale 1ns/1ps
module tb_m2m3_pipeline;

    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;

    integer hc = 0, vc = 137;          // ★初值错开 137 行，顺带验证显示锁相 ✓

    always @(posedge clk) begin
        if (hc == 1649) begin hc <= 0; vc <= (vc == 749) ? 0 : vc + 1; end
        else                  hc <= hc + 1;
    end

    wire in_de = rst_n && (hc >= 110) && (hc < 750);
    wire in_hs = rst_n && (hc >= 750) && (hc < 790);
    wire in_vs = rst_n && (vc >= 725) && (vc < 730);

    wire bar_v = in_de && (((hc - 110) >= 300) && ((hc - 110) < 304));
    wire bar_h = (vc >= 200) && (vc < 204);
    wire [7:0] i_r = (bar_v || bar_h) ? 8'd250 : 8'd200;
    wire [7:0] i_g = (bar_v || bar_h) ? 8'd250 : 8'd100;
    wire [7:0] i_b = (bar_v || bar_h) ? 8'd250 : 8'd50;

    reg  key3 = 1'b0;                  // ★换源按键（对应顶层 VIO 的 gamma_sel 位）

    wire [23:0] o_rgb;
    wire        o_de, o_hs, o_vs;
    m2m3_pipeline dut (
        .clk(clk), .rst_n(rst_n),
        .i_r(i_r), .i_g(i_g), .i_b(i_b),
        .i_de(in_de), .i_hs(in_hs), .i_vs(in_vs),
        .left_sel (2'd0),              // 左 = 灰度
        .right_sel(2'd1),              // 右 = 原图彩色
        .key3     (key3  ),
        .o_rgb(o_rgb), .o_de(o_de), .o_hs(o_hs), .o_vs(o_vs)
    );
    defparam dut.u_key3_filter.CNT_MAX = 99;    // ★缩短消抖，仿真才跑得动 ✓

    wire [7:0] oR = o_rgb[7:0], oG = o_rgb[15:8], oB = o_rgb[23:16];

    // ---- 每像素：区分"灰"还是"彩" ----
    wire dRG = (oR > oG) ? (oR - oG) : (oG - oR);
    wire is_gray  = (dRG <= 8'd8);
    wire is_color = (dRG >  8'd50);

    integer line_de = 0;
    integer frm = 0;
    integer l_de = 0, l_vs = 0, l_tot = 0;
    integer bad_width = 0, bad_black = 0;
    integer bad_left = 0, bad_right = 0;      // 左右两半"源不对"的像素数
    integer xpos = 0;
    reg [7:0] smpL, smpR;                     // 行300 左/右半采样
    reg ohs_d = 0, ovs_d = 0;
    wire pos_hs = o_hs && !ohs_d;
    wire pos_vs = o_vs && !ovs_d;

    always @(posedge clk) begin
        ohs_d <= o_hs; ovs_d <= o_vs;
        if (!rst_n) begin
            line_de <= 0; xpos <= 0; frm <= 0;
            l_de <= 0; l_vs <= 0; l_tot <= 0;
            bad_width <= 0; bad_black <= 0; bad_left <= 0; bad_right <= 0;
        end else begin
            if (pos_hs) begin
                if (line_de != 0 && line_de != 1280) bad_width <= bad_width + 1;
                if (line_de != 0) l_de <= l_de + 1;
                line_de <= 0; xpos <= 0; l_tot <= l_tot + 1;
            end

            if (ovs_d && !o_vs) begin
                $display("[FRAME %0d] total=%0d de_lines=%0d vs_lines=%0d | widthErr=%0d blackErr=%0d leftWrong=%0d rightWrong=%0d",
                         frm, l_tot, l_de, l_vs, bad_width, bad_black, bad_left, bad_right);
                frm <= frm + 1;
                l_de <= 0; l_vs <= 0; l_tot <= 0;
                bad_left <= 0; bad_right <= 0;      // 每帧清零，判据干净 ✓
                if (frm >= 5) begin
                    $display("==================================================");
                    $display("  VERDICT timing=%s black=%s",
                             (bad_width==0 && l_de==720) ? "PASS" : "FAIL",
                             (bad_black==0) ? "PASS" : "FAIL");
                    $display("  （左右源是否正确请看每帧 leftWrong/rightWrong：全 0 为 PASS）");
                    $display("==================================================");
                    $finish;
                end
            end

            if (pos_hs && o_vs) l_vs <= l_vs + 1;

            if (o_de) begin
                line_de <= line_de + 1;
                if (dut.d_vcnt >= 480 && !(oR==0 && oG==0 && oB==0)) bad_black <= bad_black + 1;
                if (dut.d_vcnt == 300) begin
                    if (xpos == 100) smpL <= oR;                  // 左半采样
                    if (xpos == 740) begin
                        smpR <= oR;                              // 右半采样
                        // ★调试：把换源链路中间信号一次打全 ✓
                        $display("DBG x740: i_r=%0d color565=%h gray565=%h | sL=%h sR=%h | t_pix=%h out=(R%0d G%0d B%0d) | swap=%b k3st=%b lsel=%0d rsel=%0d",
                                 dut.i_r, dut.color565_r, dut.gray565,
                                 dut.s_left, dut.s_right, dut.t_pix,
                                 oR, oG, oB,
                                 dut.split_swap_sync, dut.key3_state, dut.left_sel, dut.right_sel);
                    end
                    // ★左右源检查：key3_state=0 ⇒ 左灰右彩；=1 ⇒ 左彩右灰
                    if (xpos < 640) begin
                        if (dut.key3_state == 1'b0) begin if (!is_gray ) bad_left  <= bad_left  + 1; end
                        else                        begin if (!is_color) bad_left  <= bad_left  + 1; end
                    end else begin
                        if (dut.key3_state == 1'b0) begin if (!is_color) bad_right <= bad_right + 1; end
                        else                        begin if (!is_gray ) bad_right <= bad_right + 1; end
                    end
                end
                xpos <= xpos + 1;
            end
        end
    end

    initial begin
        $display("==== m2_to_m3 pipeline sim v3 (source-switch test) ====");
        $display("  上电：左=灰度(src0) / 右=原图彩色(src1)；按 key3 后互换");
        rst_n = 0;
        repeat (20) @(posedge clk);
        rst_n = 1;
        repeat (750 * 1650 * 3) @(posedge clk);      // 约第 3 帧末
        $display("  >>> 按下 key3 <<<");
        key3 = 1'b1;
        repeat (400) @(posedge clk);                 // CNT_MAX=99 ⇒ 足够触发 ✓
        key3 = 1'b0;
        repeat (750 * 1650 * 4) @(posedge clk);
        $display("  TIMEOUT: widthErr=%0d blackErr=%0d leftWrong=%0d rightWrong=%0d",
                 bad_width, bad_black, bad_left, bad_right);
        $finish;
    end
endmodule
