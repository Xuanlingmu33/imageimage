//=============================================================================
// tb_key_real.v —— 【真实参数·冒烟测试】单键状态机（★m8）
//
//   为什么要有它：其它测试台为了跑得快，把 DEBOUNCE/T_GAP/T_MINCLK/T_LONG 全用
//   defparam 缩小了 ⇒ **恰好掩盖"计数器位宽不够 / 十六进制常数位数写错"这类 bug**
//   （历史上栽过两次：v6 计数器溢出导致 key1 全死、v7 常数少写 4 位导致长按失效，
//     两次都是缩放版仿真全过、真实参数下才暴露 ✗）
//
//   ★ 设计原则：**只保留最便宜的冒烟用例**（总仿真时间约 8 秒），
//     完整覆盖交给缩放版 tb_m6_osd（跑得快、用例全）。
//     真实参数下只验证"能不能数到门限"：
//       · 单击一次 100ms  → 该动参数
//       · 长按一次 900ms  → 该切模式
//     这两条能过，就说明消抖 / 抗抖窗 / 时长计数 / 长按门限的**位宽和常数都是对的** ✓
//   （不加任何 defparam ⇒ 用真实参数）
//=============================================================================
`timescale 1ns/1ps
module tb_key_real;

    reg clk = 0;
    always #6.734 clk = ~clk;               // ≈74.25MHz（与像素时钟一致）

    reg rst_n = 0, key = 0, key3 = 0, key2 = 0;

    // ---- key1 实例（默认参数：WITH_SRC=0, START_MODE=0）----
    wire        ev_thr, ev_sign, ev_step, ev_src, ev_mode_def, ev_mode_sign, ev_mode_step, ev_mode_src;
    wire        key_press, key_release;
    wire [1:0]  mode;
    wire        sign;
    wire [2:0]  step_idx;
    wire [5:0]  step_val;
    wire [10:0] thr_cur;

    key_mode_fsm u_fsm (
        .clk(clk), .rst_n(rst_n), .key(key),
        .ev_thr(ev_thr), .ev_sign(ev_sign), .ev_step(ev_step), .ev_src(ev_src),
        .ev_mode_def(ev_mode_def), .ev_mode_sign(ev_mode_sign),
        .ev_mode_step(ev_mode_step), .ev_mode_src(ev_mode_src),
        .key_press(key_press), .key_release(key_release),
        .mode(mode), .sign(sign), .step_idx(step_idx), .step_val(step_val), .thr_cur(thr_cur)
    );

    // ---- key3 实例（WITH_SRC=1, START_MODE=3：上电=换源）----
    wire        ev_thr_c, ev_sign_c, ev_step_c, ev_src_c;
    wire        ev_mdef_c, ev_msign_c, ev_mstep_c, ev_msrc_c;
    wire        kp_c, kr_c, sign_c;
    wire [1:0]  mode_c;
    wire [2:0]  step_c;
    wire [5:0]  stepval_c;
    wire [10:0] thr_c;

    key_mode_fsm #(
        .WITH_SRC (1), .START_MODE (3), .THR_INIT (8), .STEP_INIT (0)
    ) u_fsm3 (
        .clk(clk), .rst_n(rst_n), .key(key3),
        .ev_thr(ev_thr_c), .ev_sign(ev_sign_c), .ev_step(ev_step_c), .ev_src(ev_src_c),
        .ev_mode_def(ev_mdef_c), .ev_mode_sign(ev_msign_c),
        .ev_mode_step(ev_mstep_c), .ev_mode_src(ev_msrc_c),
        .key_press(kp_c), .key_release(kr_c),
        .mode(mode_c), .sign(sign_c), .step_idx(step_c), .step_val(stepval_c), .thr_cur(thr_c)
    );

    integer fails = 0;
    integer n_src = 0, n_thr = 0, n_thr_c = 0;

    // ---- ★v9：key2 实例（同样零 defparam ⇒ 真实参数）----
    //   只在"彩色叠加"档才允许长按进选色 ⇒ 这里把 disp_mode 固定给 2
    reg  [1:0] k2_dm = 2'd2;
    wire       ev_disp2, ev_color2, ev_cmode_on2, ev_cmode_off2, color_mode2;
    wire [2:0] color_idx2;
    integer    n_disp2 = 0, n_color2 = 0, n_on2 = 0, n_off2 = 0;

    key2_fsm u_fsm2 (
        .clk(clk), .rst_n(rst_n), .key(key2), .disp_mode(k2_dm),
        .ev_disp(ev_disp2), .ev_color(ev_color2),
        .ev_cmode_on(ev_cmode_on2), .ev_cmode_off(ev_cmode_off2),
        .color_mode(color_mode2), .color_idx(color_idx2)
    );

    always @(posedge clk) begin
        if (ev_disp2)     n_disp2  = n_disp2  + 1;
        if (ev_color2)    n_color2 = n_color2 + 1;
        if (ev_cmode_on2) n_on2    = n_on2    + 1;
        if (ev_cmode_off2)n_off2   = n_off2   + 1;
    end

    always @(posedge clk) begin
        if (ev_src_c) n_src   = n_src   + 1;
        if (ev_thr)   n_thr   = n_thr   + 1;
        if (ev_thr_c) n_thr_c = n_thr_c + 1;
    end

    task automatic wait_ms; input integer ms; begin repeat (ms * 74_250) @(posedge clk); end endtask

    initial begin
        $display("==== tb_key_real（真实参数冒烟：专抓位宽/常数错）====");
        $display("     DEBOUNCE=20ms  T_GAP=30ms  T_MINCLK=60ms  T_LONG=0.8s");
        rst_n = 0; repeat (200) @(posedge clk); rst_n = 1; wait_ms(2);

        // ================= key1 =================
        $display("");
        $display("---- K1-a 上电：thr=8 step=2 mode=0 ----");
        if ((thr_cur === 11'd8) && (step_idx === 3'd0) && (mode === 2'd0)) $display("   CHECK-A OK");
        else begin $display("   CHECK-A NG (thr=%0d step=%0d mode=%0d)", thr_cur, step_idx, mode); fails=fails+1; end

        $display("---- K1-b 单击 100ms ⇒ 必须 +2（挂 = 消抖/抗抖窗数不到门限）----");
        key = 1'b1; wait_ms(100); key = 1'b0; wait_ms(300);
        $display("   ev_thr=%0d（应 1）  thr=%0d（应 10）", n_thr, thr_cur);
        if ((n_thr === 1) && (thr_cur === 11'd10)) $display("   CHECK-B OK");
        else begin $display("   CHECK-B NG"); fails=fails+1; end

        $display("---- K1-c 长按 900ms ⇒ 必须切模式（挂 = 长按计数/常数写错）----");
        key = 1'b1; wait_ms(900); key = 1'b0; wait_ms(300);
        $display("   mode=%0d（应 1=加减）  thr=%0d（应仍 10）", mode, thr_cur);
        if ((mode === 2'd1) && (thr_cur === 11'd10)) $display("   CHECK-C OK");
        else begin $display("   CHECK-C NG"); fails=fails+1; end

        // ================= key3 =================
        $display("");
        $display("---- K3-a 上电：mode_c=3（换源） thr_c=8 step_c=0 ----");
        if ((mode_c === 2'd3) && (thr_c === 11'd8) && (step_c === 3'd0)) $display("   CHECK-D OK");
        else begin $display("   CHECK-D NG (mode_c=%0d thr_c=%0d step_c=%0d)", mode_c, thr_c, step_c); fails=fails+1; end

        $display("---- K3-b 换源模式单击 ⇒ 发换源脉冲，不动任何阈值 ----");
        n_src = 0; n_thr = 0; n_thr_c = 0;
        key3 = 1'b1; wait_ms(100); key3 = 1'b0; wait_ms(300);
        $display("   ev_src=%0d（应 1）  Sobel ev=%0d（应 0）  Canny ev=%0d（应 0）", n_src, n_thr, n_thr_c);
        if ((n_src === 1) && (n_thr === 0) && (n_thr_c === 0)) $display("   CHECK-E OK");
        else begin $display("   CHECK-E NG"); fails=fails+1; end

        $display("---- K3-c 长按 900ms ⇒ 进 Canny 阈值模式 mode_c=0 ----");
        key3 = 1'b1; wait_ms(900); key3 = 1'b0; wait_ms(300);
        if (mode_c === 2'd0) $display("   CHECK-F OK"); else begin $display("   CHECK-F NG (mode_c=%0d)", mode_c); fails=fails+1; end

        $display("---- K3-d ★单击 ⇒ 只改 Canny 阈值 8→10，Sobel 阈值不动 ----");
        n_thr = 0; n_thr_c = 0;
        key3 = 1'b1; wait_ms(100); key3 = 1'b0; wait_ms(300);
        $display("   Sobel ev=%0d（应 0） thr=%0d（应仍 10）  Canny ev=%0d（应 1） thr_c=%0d（应 10）",
                 n_thr, thr_cur, n_thr_c, thr_c);
        if ((n_thr === 0) && (thr_cur === 11'd10) && (n_thr_c === 1) && (thr_c === 11'd10))
             $display("   CHECK-G OK：两条阈值通道互相独立");
        else begin $display("   CHECK-G NG"); fails=fails+1; end

        $display("---- K3-e 长按 ⇒ 加减模式 mode_c=1；单击 ⇒ 换 Canny 符号 ----");
        key3 = 1'b1; wait_ms(900); key3 = 1'b0; wait_ms(300);
        key3 = 1'b1; wait_ms(100); key3 = 1'b0; wait_ms(300);
        $display("   mode_c=%0d（应 1）  sign_c=%0d（应 1）", mode_c, sign_c);
        if ((mode_c === 2'd1) && (sign_c === 1'b1)) $display("   CHECK-H OK");
        else begin $display("   CHECK-H NG"); fails=fails+1; end

        $display("---- K3-f 长按 ⇒ 步进模式 mode_c=2；单击 ⇒ 步进 0→1(=4) ----");
        key3 = 1'b1; wait_ms(900); key3 = 1'b0; wait_ms(300);
        key3 = 1'b1; wait_ms(100); key3 = 1'b0; wait_ms(300);
        $display("   mode_c=%0d（应 2）  step_c=%0d（应 1）", mode_c, step_c);
        if ((mode_c === 2'd2) && (step_c === 3'd1)) $display("   CHECK-I OK");
        else begin $display("   CHECK-I NG"); fails=fails+1; end

        $display("---- K3-g 长按 ⇒ 回换源模式 mode_c=3 ----");
        key3 = 1'b1; wait_ms(900); key3 = 1'b0; wait_ms(300);
        if (mode_c === 2'd3) $display("   CHECK-J OK"); else begin $display("   CHECK-J NG (mode_c=%0d)", mode_c); fails=fails+1; end

        // ================= ★v9 key2 =================
        $display("");
        $display("---- K2-a 上电：选色关、颜色=红 ----");
        if ((color_mode2 === 1'b0) && (color_idx2 === 3'd0)) $display("   CHECK-K2-A OK");
        else begin $display("   CHECK-K2-A NG (cmode=%0b color=%0d)", color_mode2, color_idx2); fails=fails+1; end

        $display("---- K2-b 单击 100ms ⇒ 档位 +1 脉冲（挂 = 消抖/时长计数数不到门限）----");
        n_disp2 = 0;
        key2 = 1'b1; wait_ms(100); key2 = 1'b0; wait_ms(300);
        $display("   ev_disp=%0d（应 1）  color_mode=%0b（应 0）", n_disp2, color_mode2);
        if ((n_disp2 === 1) && (color_mode2 === 1'b0)) $display("   CHECK-K2-B OK");
        else begin $display("   CHECK-K2-B NG"); fails=fails+1; end

        $display("---- K2-c 长按 900ms ⇒ 进选色（挂 = 长按计数/常数写错）----");
        n_on2 = 0;
        key2 = 1'b1; wait_ms(900); key2 = 1'b0; wait_ms(300);
        $display("   ev_cmode_on=%0d（应 1）  color_mode=%0b（应 1）", n_on2, color_mode2);
        if ((n_on2 === 1) && (color_mode2 === 1'b1)) $display("   CHECK-K2-C OK");
        else begin $display("   CHECK-K2-C NG"); fails=fails+1; end

        $display("---- K2-d 选色里单击 ⇒ 颜色 红->橙，档位脉冲必须为 0 ----");
        n_color2 = 0; n_disp2 = 0;
        key2 = 1'b1; wait_ms(100); key2 = 1'b0; wait_ms(300);
        $display("   ev_color=%0d（应 1）  color=%0d（应 1=橙）  ev_disp=%0d（应 0）",
                 n_color2, color_idx2, n_disp2);
        if ((n_color2 === 1) && (color_idx2 === 3'd1) && (n_disp2 === 0)) $display("   CHECK-K2-D OK");
        else begin $display("   CHECK-K2-D NG"); fails=fails+1; end

        $display("---- K2-e 选色里长按 900ms ⇒ 退出选色 ----");
        n_off2 = 0;
        key2 = 1'b1; wait_ms(900); key2 = 1'b0; wait_ms(300);
        $display("   ev_cmode_off=%0d（应 1）  color_mode=%0b（应 0）", n_off2, color_mode2);
        if ((n_off2 === 1) && (color_mode2 === 1'b0)) $display("   CHECK-K2-E OK");
        else begin $display("   CHECK-K2-E NG"); fails=fails+1; end

        $display("");
        if (fails == 0) $display("==== tb_key_real : ALL CHECKS PASSED（真实参数下计时链路正常）====");
        else            $display("==== tb_key_real : %0d CHECK(S) FAILED ====", fails);
        $finish;
    end

    initial begin
        repeat (1_000_000_000) @(posedge clk);    // 约 13.5 秒仿真时间上限（★不能超 2^31-1）
        $display("  TIMEOUT");
        $finish;
    end

endmodule
