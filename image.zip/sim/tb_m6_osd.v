//=============================================================================
// tb_m6_osd.v —— 快速 OSD + 单键连击仿真（★m6 · v4）
//
//   验证 v4 的四件事：
//     ① 帧率左右对调：左 = 摄像头（fps_sensor），右 = 画面（显示侧）
//     ② 右下角日期时钟在走（仿真里把 osd_clock 的 CLK_HZ 改小 ⇒ 秒飞快地跳）
//     ③ key1 连击：单击=阈值 / 双击=加减模式 / 三击=步进模式 / 5 秒回阈值
//        并且"双击/三击要把第一击的动作撤销掉"（不能白改阈值）
//     ④ 消息是纯瞬时（3 秒消失），不再常显
//=============================================================================
`timescale 1ns/1ps
module tb_m6_osd;

    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;

    integer hc = 0, vc = 0;
    always @(posedge clk) begin
        if (hc == 1649) begin hc <= 0; vc <= (vc == 749) ? 0 : vc + 1; end
        else                  hc <= hc + 1;
    end

    wire [11:0] h_cnt = hc[11:0];
    wire [10:0] v_cnt = vc[10:0];
    wire        de    = rst_n && (hc < 1280) && (vc < 720);
    wire        hs    = rst_n && (hc >= 1390) && (hc < 1430);
    wire        vs    = rst_n && (vc >= 725) && (vc < 730);

    wire [15:0] bg = (hc < 640) ? 16'h8410 :
                     ((hc[7:4] == 4'd0) ? 16'hF800 :
                      (hc[7:4] == 4'd1) ? 16'h07E0 :
                      (hc[7:4] == 4'd2) ? 16'h001F :
                      (hc[7:4] == 4'd3) ? 16'hFFE0 :
                      (hc[7:4] == 4'd4) ? 16'hF81F : 16'h07FF);

    reg [1:0]  disp_mode  = 2'd0;
    reg        split_mode = 1'b0;
    reg        median_en  = 1'b0;
    reg [13:0] fps_sensor = 14'd300;      // 左半：摄像头（故意给 30.0）
    reg        k1 = 0, k0 = 0, k3 = 0, k2 = 0;

    wire [15:0] o_data;
    wire        o_de, o_hs, o_vs;
    wire [10:0] o_thr;
    wire        o_sign;
    wire [2:0]  o_step;
    wire [13:0] o_fps_disp, o_fps_sens;
    wire [10:0] o_canny_thr;
    wire        o_ev_src;
    wire        o_disp_inc;               // ★v9：key2 单击 ⇒ 档位 +1
    wire [3:0]  o_color_sel;              // ★v9：选色

    m6_osd #(.CELL(32), .CLK_HZ(74_250_000), .AVG_N(4)) dut (
        .clk(clk), .rst_n(rst_n),
        .i_data(de ? bg : 16'h0000), .i_de(de), .i_hs(hs), .i_vs(vs),
        .h_cnt(h_cnt), .v_cnt(v_cnt),
        .key1(k1), .key3(k3), .key2(k2), .kf0(k0),
        .disp_mode(disp_mode), .split_mode(split_mode), .median_en(median_en),
        .fps_sensor(fps_sensor),
        .o_data(o_data), .o_de(o_de), .o_hs(o_hs), .o_vs(o_vs),
        .o_threshold(o_thr), .o_sign(o_sign), .o_step_idx(o_step),
        .o_fps_disp(o_fps_disp), .o_fps_sens(o_fps_sens),
        .o_canny_thr(o_canny_thr), .o_ev_src(o_ev_src),
        .o_disp_inc(o_disp_inc), .o_color_sel(o_color_sel)
    );

    // ★v9：本 TB 扮演 m4_pipeline 的角色 —— 收到 o_disp_inc 就把档位 +1
    always @(posedge clk or negedge rst_n)
        if (!rst_n)               disp_mode <= 2'd0;
        else if (o_disp_inc)      disp_mode <= (disp_mode >= 2'd2) ? 2'd0 : disp_mode + 2'd1;

    defparam dut.u_key_fsm.DEBOUNCE = 99;        // v7 仿真缩放
    defparam dut.u_key_fsm.T_GAP    = 300;
    defparam dut.u_key_fsm.T_MINCLK = 500;       // 须 > DEBOUNCE+T_GAP = 399
    defparam dut.u_key_fsm.T_LONG   = 3000;      // 长按界限（仿真缩短）
    defparam dut.u_key_fsm.T_IDLE   = 3_000_000; // 5 秒无操作（仿真缩短，须 > 一次快照 1.24M 拍）
    defparam dut.u_text.MSG_CYCLES  = 8_000_000; // 瞬时消息（★须 >> 一帧 1.24M，否则拍到第 580 行时已过期）
    // ★v8：key3 那个实例同样要缩小参数，否则用的是真实 0.8s 门限，仿真里按不动
    defparam dut.u_key_fsm3.DEBOUNCE = 99;
    defparam dut.u_key_fsm3.T_GAP    = 300;
    defparam dut.u_key_fsm3.T_MINCLK = 500;
    defparam dut.u_key_fsm3.T_LONG   = 3000;
    defparam dut.u_key_fsm3.T_IDLE   = 3_000_000;
    // ★v9：key2 实例（单击换档 / 长按进选色 / 5 秒回落）
    defparam dut.u_key2_fsm.DEBOUNCE = 99;
    defparam dut.u_key2_fsm.T_GAP    = 300;
    defparam dut.u_key2_fsm.T_MINCLK = 500;
    defparam dut.u_key2_fsm.T_LONG   = 3000;      // 长按界限（仿真缩短）
    defparam dut.u_key2_fsm.T_IDLE   = 3_000_000; // 选色 5 秒回落（仿真缩短）
    defparam dut.u_text.u_uptime.CLK_HZ = 200_000; // 计时 1 秒 = 200k 拍（一帧≈8 秒，看得见在走）

    // ---- 真帧导出 ----
    wire [4:0]  oR5 = o_data[15:11];
    wire [5:0]  oG6 = o_data[10:5];
    wire [4:0]  oB5 = o_data[4:0];
    wire [23:0] o888 = {oR5, oR5[4:2], oG6, oG6[5:4], oB5, oB5[4:2]};

    integer dcol = 0, drow = 0;
    reg     o_de_d, o_vs_d;
    always @(posedge clk) begin
        o_de_d <= o_de; o_vs_d <= o_vs;
        if (o_vs && !o_vs_d)      drow <= 0;
        else if (o_de && !o_de_d) drow <= drow + 1;
        if (o_de && !o_de_d)      dcol <= 0;
        else if (o_de)            dcol <= dcol + 1;
    end

    integer fd;
    reg     dump_en = 0;
    always @(posedge clk) begin
        if (dump_en && o_de) begin
            if ((drow < 48) || (drow >= 576)) $fwrite(fd, "%06x", o888);
            if (dcol == 1279) $fwrite(fd, "\n");
        end
    end

    task automatic snap;
        input [8*44-1:0] fname;
        begin
            wait (o_vs == 1'b1);
            wait (o_de == 1'b1);
            @(posedge clk);
            fd = $fopen(fname, "w");
            if (fd == 0) $display("!! cannot open %0s", fname);
            dump_en = 1;
            repeat (1650 * 750 + 2000) @(posedge clk);
            dump_en = 0;
            $fclose(fd);
            $display("   [snap] %0s | thr=%0d sign=%0d step=%0d mode=%0d", fname, o_thr, o_sign, o_step, dut.u_key_fsm.mode);
            $display("          MSG: type=%0d on=%0d line_msg_zero=%0d canny_thr=%0d",
                     dut.u_text.msg_type, dut.u_text.msg_on, (dut.u_text.line_msg === 224'd0), o_canny_thr);
            $display("          UPTIME = %0d%0d:%0d%0d:%0d%0d",
                     dut.u_text.u_uptime.h1, dut.u_text.u_uptime.h0,
                     dut.u_text.u_uptime.n1, dut.u_text.u_uptime.n0,
                     dut.u_text.u_uptime.s1, dut.u_text.u_uptime.s0);
        end
    endtask

    // v7 手势：单击 = 按 400 拍（实测 dur≈800 < T_LONG=3000）
    task automatic click_once;  begin k1 = 1'b1; repeat (400)  @(posedge clk); k1 = 1'b0; repeat (1200) @(posedge clk); end endtask
    // 长按 = 按 4000 拍（实测 dur≈4400 > T_LONG=3000）⇒ 切模式
    task automatic press_long;  begin k1 = 1'b1; repeat (4000) @(posedge clk); k1 = 1'b0; repeat (1200) @(posedge clk); end endtask
    // 电噪声 = 按 80 拍（实测 dur≈480 < T_MINCLK=500）⇒ 忽略
    task automatic click_noise; begin k1 = 1'b1; repeat (80)   @(posedge clk); k1 = 1'b0; repeat (1200) @(posedge clk); end endtask
    // ★v8 key3 手势
    task automatic click3;      begin k3 = 1'b1; repeat (400)  @(posedge clk); k3 = 1'b0; repeat (1200) @(posedge clk); end endtask
    task automatic long3;       begin k3 = 1'b1; repeat (4000) @(posedge clk); k3 = 1'b0; repeat (1200) @(posedge clk); end endtask
    // ★v9 key2 手势
    task automatic click2;      begin k2 = 1'b1; repeat (400)  @(posedge clk); k2 = 1'b0; repeat (1200) @(posedge clk); end endtask
    task automatic long2;       begin k2 = 1'b1; repeat (4000) @(posedge clk); k2 = 1'b0; repeat (1200) @(posedge clk); end endtask
    integer fails = 0;
    reg [10:0] thr_b;
    reg        sg_b;
    reg [2:0]  st_b;
    reg [1:0]  md_b;
    integer    n_ev;
    integer    n_src = 0;
    integer    n_src_old = 0;
    always @(posedge clk) if (o_ev_src) n_src = n_src + 1;
    task automatic chk;
        input [8*20-1:0] tag;
        input [10:0] e_thr; input e_sign; input [2:0] e_step; input [1:0] e_mode;
        begin
            if ((o_thr === e_thr) && (o_sign === e_sign) && (o_step === e_step) && (dut.u_key_fsm.mode === e_mode))
                $display("   CHECK-%0s OK  (thr=%0d sign=%0d step=%0d mode=%0d)", tag, o_thr, o_sign, o_step, dut.u_key_fsm.mode);
            else begin
                $display("   CHECK-%0s NG  got thr=%0d sign=%0d step=%0d mode=%0d | want thr=%0d sign=%0d step=%0d mode=%0d",
                         tag, o_thr, o_sign, o_step, dut.u_key_fsm.mode, e_thr, e_sign, e_step, e_mode);
                fails = fails + 1;
            end
        end
    endtask

    initial begin
        $display("==== tb_m6_osd v4（连击 / 时钟 / 帧率对调）====");
        rst_n = 0; repeat (20) @(posedge clk); rst_n = 1;
        repeat (6 * 1650 * 750) @(posedge clk);

        $display("");
        $display("---- (1) 上电：thr=8 sign=加 step=2 mode=阈值 ----");
        chk("POWERON", 11'd8, 1'b0, 3'd0, 2'd0);
        snap("sim/dump/osd_0_poweron.hex");

        $display("");
        $display("---- (2) 单击 ×2 ⇒ 阈值 10 / 12（单击永远只管参数）----");
        click_once; chk("CLICK1", 11'd10, 1'b0, 3'd0, 2'd0);
        click_once; chk("CLICK2", 11'd12, 1'b0, 3'd0, 2'd0);
        snap("sim/dump/osd_1_thr12.hex");

        $display("");
        $display("---- (3) 长按 4000 拍 ⇒ 进【加减】模式，且不改阈值 ----");
        thr_b = o_thr; n_ev = 0;
        press_long;
        $display("   长按后 mode=%0d（应 1）  thr=%0d（应 %0d，没动）", dut.u_key_fsm.mode, o_thr, thr_b);
        if ((dut.u_key_fsm.mode === 2'd1) && (o_thr === thr_b)) $display("   CHECK-LONG-SIGN OK");
        else begin $display("   CHECK-LONG-SIGN NG"); fails = fails + 1; end
        snap("sim/dump/osd_2_mode_sign.hex");

        $display("");
        $display("---- (4) 加减模式下单击 ⇒ 换符号（阈值不变）----");
        thr_b = o_thr;
        click_once;
        $display("   sign=%0d（应 1）  thr=%0d（应 %0d）", o_sign, o_thr, thr_b);
        if ((o_sign === 1'b1) && (o_thr === thr_b)) $display("   CHECK-SIGN OK");
        else begin $display("   CHECK-SIGN NG"); fails = fails + 1; end
        snap("sim/dump/osd_3_sign_jian.hex");

        $display("");
        $display("---- (5) 长按 ⇒ 进【步进】模式；单击 ⇒ 步进档 8→16 ----");
        press_long;
        if (dut.u_key_fsm.mode === 2'd2) $display("   CHECK-LONG-STEP OK（mode=2）");
        else begin $display("   CHECK-LONG-STEP NG（mode=%0d）", dut.u_key_fsm.mode); fails = fails + 1; end
        click_once;
        $display("   step=%0d（应 1=4）  thr=%0d", o_step, o_thr);
        if (o_step === 3'd1) $display("   CHECK-STEP OK"); else begin $display("   CHECK-STEP NG"); fails = fails + 1; end
        snap("sim/dump/osd_4_step16.hex");

        $display("");
        $display("---- (6) 长按 ⇒ 回【阈值】模式；单击 ⇒ 按当前 减/步进16 生效 ----");
        press_long;
        if (dut.u_key_fsm.mode === 2'd0) $display("   CHECK-LONG-THR OK（回阈值模式）");
        else begin $display("   CHECK-LONG-THR NG"); fails = fails + 1; end
        thr_b = o_thr;
        click_once;
        $display("   单击后 thr %0d -> %0d", thr_b, o_thr);
        if (o_thr !== thr_b) $display("   CHECK-BACK-CLICK OK");
        else begin $display("   CHECK-BACK-CLICK NG"); fails = fails + 1; end

        $display("");
        $display("---- (7) 电噪声（80 拍 < T_MINCLK）⇒ 完全无动作 ----");
        thr_b = o_thr; sg_b = o_sign; st_b = o_step; md_b = dut.u_key_fsm.mode;
        click_noise;
        if ((o_thr===thr_b)&&(o_sign===sg_b)&&(o_step===st_b)&&(dut.u_key_fsm.mode===md_b))
             $display("   CHECK-NOISE OK");
        else begin $display("   CHECK-NOISE NG"); fails = fails + 1; end

        $display("");
        $display("---- (8) 5 秒无操作（仿真 T_IDLE=3M 拍）⇒ 自动回阈值模式 ----");
        press_long;
        $display("   长按后 mode=%0d（应 1）", dut.u_key_fsm.mode);
        repeat (3_300_000) @(posedge clk);
        $display("   等待后 mode=%0d（应 0）", dut.u_key_fsm.mode);
        if (dut.u_key_fsm.mode === 2'd0) $display("   CHECK-IDLE-BACK OK");
        else begin $display("   CHECK-IDLE-BACK NG"); fails = fails + 1; end
        $display("");
        $display("==== ★v8 key3（Canny）专项 ====");
        $display("---- (C1) 上电：key3 在【换源】模式 mode_c=3 ----");
        if (dut.u_key_fsm3.mode === 2'd3) $display("   CHECK-K3-POWERON OK（mode_c=3 换源）");
        else begin $display("   CHECK-K3-POWERON NG（mode_c=%0d）", dut.u_key_fsm3.mode); fails = fails + 1; end
        $display("---- (C2) 换源模式单击 ⇒ 发一次换源脉冲（m4_pipeline 据此翻转 split_mode）----");
        n_src_old = n_src; click3;
        $display("   换源脉冲 %0d -> %0d（应 +1）  Canny 阈值=%0d（应仍 8）", n_src_old, n_src, o_canny_thr);
        if ((n_src === n_src_old + 1) && (o_canny_thr === 11'd8) && (o_thr === 11'd8)) $display("   CHECK-K3-SRC OK：只换源，没动任何阈值");
        else begin $display("   CHECK-K3-SRC NG"); fails = fails + 1; end
        repeat (4000) @(posedge clk);

        $display("---- (C3) 长按 ⇒ 进【Canny 阈值】模式（mode_c=0）----");
        long3;
        if (dut.u_key_fsm3.mode === 2'd0) $display("   CHECK-K3-THRMODE OK");
        else begin $display("   CHECK-K3-THRMODE NG（mode_c=%0d）", dut.u_key_fsm3.mode); fails = fails + 1; end
        snap("sim/dump/k3_0_thrmode.hex");

        $display("---- (C4) ★单击 ⇒ 只改 Canny 阈值，Sobel 阈值必须不变 ----");
        thr_b = o_thr; n_ev = o_canny_thr; click3;
        $display("   Sobel 阈值 %0d -> %0d（应不变）   Canny 阈值 %0d -> %0d（应 +2 = 10）", thr_b, o_thr, n_ev, o_canny_thr);
        if ((o_thr === thr_b) && (o_canny_thr === n_ev + 11'd2)) $display("   CHECK-K3-INDEPENDENT OK：两条阈值通道互相独立");
        else begin $display("   CHECK-K3-INDEPENDENT NG"); fails = fails + 1; end
        snap("sim/dump/k3_1_canny10.hex");
        repeat (4000) @(posedge clk);

        $display("---- (C5) 长按 ⇒ 加减模式(mode_c=1)；单击 ⇒ 换 Canny 符号 ----");
        long3;
        if (dut.u_key_fsm3.mode === 2'd1) $display("   CHECK-K3-SIGNMODE OK"); else begin $display("   CHECK-K3-SIGNMODE NG"); fails=fails+1; end
        click3;
        $display("   sign_c=%0d（应 1）  Canny 阈值=%0d（应仍 10）", dut.u_key_fsm3.sign, o_canny_thr);
        if ((dut.u_key_fsm3.sign === 1'b1) && (o_canny_thr === 11'd10)) $display("   CHECK-K3-SIGN OK");
        else begin $display("   CHECK-K3-SIGN NG"); fails = fails + 1; end
        repeat (4000) @(posedge clk);

        $display("---- (C6) 长按 ⇒ 步进模式(mode_c=2)；单击 ⇒ 步进档 0->1(=4) ----");
        long3;
        click3;
        $display("   step_c=%0d（应 1=4）", dut.u_key_fsm3.step_idx);
        if (dut.u_key_fsm3.step_idx === 3'd1) $display("   CHECK-K3-STEP OK"); else begin $display("   CHECK-K3-STEP NG"); fails=fails+1; end
        repeat (4000) @(posedge clk);

        $display("---- (C7) 长按 ⇒ 回【换源】模式(mode_c=3) ----");
        long3;
        if (dut.u_key_fsm3.mode === 2'd3) $display("   CHECK-K3-BACKSRC OK"); else begin $display("   CHECK-K3-BACKSRC NG（mode_c=%0d）", dut.u_key_fsm3.mode); fails=fails+1; end
        repeat (4000) @(posedge clk);

        $display("---- (C8) 5 秒超时 ⇒ 回换源（仿真 T_IDLE=3M 拍）----");
        long3;                                  // 先进 Canny 阈值模式
        $display("   长按后 mode_c=%0d（应 0）", dut.u_key_fsm3.mode);
        repeat (3_300_000) @(posedge clk);
        $display("   等待后 mode_c=%0d（应 3=换源）", dut.u_key_fsm3.mode);
        if (dut.u_key_fsm3.mode === 2'd3) $display("   CHECK-K3-IDLE OK"); else begin $display("   CHECK-K3-IDLE NG"); fails=fails+1; end
        $display("");
        $display("==== ★v9 key2（换档 / 长按选色 / 5 秒回落）====");
        $display("---- (K2-1) 上电：档位=0 二值、颜色=红、选色=关 ----");
        if ((disp_mode === 2'd0) && (o_color_sel === 4'd0) && (dut.u_key2_fsm.color_mode === 1'b0))
             $display("   CHECK-K2-POWERON OK");
        else begin $display("   CHECK-K2-POWERON NG (dm=%0d color=%0d cmode=%0d)", disp_mode, o_color_sel, dut.u_key2_fsm.color_mode); fails = fails + 1; end

        $display("---- (K2-2) 二值档长按 ⇒ 必须被忽略（只有彩色叠加档才进选色）----");
        long2;
        $display("   长按后：dm=%0d（期望仍 0）  color_mode=%0d（期望 0）", disp_mode, dut.u_key2_fsm.color_mode);
        if ((disp_mode === 2'd0) && (dut.u_key2_fsm.color_mode === 1'b0))
             $display("   CHECK-K2-IGNORE OK");
        else begin $display("   CHECK-K2-IGNORE NG"); fails = fails + 1; end

        $display("---- (K2-3) 单击两次：档位 0 -> 1(反向sobel) -> 2(彩色叠加) ----");
        click2;
        $display("   第一次单击后 dm=%0d（期望 1）", disp_mode);
        if (disp_mode !== 2'd1) begin $display("   CHECK-K2-DM1 NG"); fails = fails + 1; end
        click2;
        $display("   第二次单击后 dm=%0d（期望 2）", disp_mode);
        if (disp_mode === 2'd2) $display("   CHECK-K2-DM2 OK");
        else begin $display("   CHECK-K2-DM2 NG"); fails = fails + 1; end

        $display("---- (K2-4) 彩色叠加档长按 ⇒ 进选色，弹【边缘颜色:红】----");
        long2;
        $display("   color_mode=%0d（期望 1）  color=%0d（期望 0=红）  msg_type=%0d（期望 8=M_COLOR）",
                 dut.u_key2_fsm.color_mode, o_color_sel, dut.u_text.msg_type);
        if ((dut.u_key2_fsm.color_mode === 1'b1) && (o_color_sel === 4'd0) && (dut.u_text.msg_type === 4'd8))
             $display("   CHECK-K2-ENTER OK");
        else begin $display("   CHECK-K2-ENTER NG"); fails = fails + 1; end
        snap("sim/dump/osd_8_color_red.hex");

        $display("---- (K2-5) 选色里单击：红 -> 橙（档位不再变）----");
        click2;
        $display("   color=%0d（期望 1=橙）  dm=%0d（期望仍 2）", o_color_sel, disp_mode);
        if ((o_color_sel === 4'd1) && (disp_mode === 2'd2)) $display("   CHECK-K2-ORANGE OK");
        else begin $display("   CHECK-K2-ORANGE NG"); fails = fails + 1; end
        snap("sim/dump/osd_9_color_orange.hex");

        $display("---- (K2-6) 连按到紫（6），再按一下回红（0）----");
        click2; click2; click2; click2; click2;
        $display("   color=%0d（期望 6=紫）", o_color_sel);
        if (o_color_sel === 4'd6) $display("   CHECK-K2-PURPLE OK");
        else begin $display("   CHECK-K2-PURPLE NG"); fails = fails + 1; end
        click2;
        $display("   color=%0d（期望 0=红）", o_color_sel);
        if (o_color_sel === 4'd0) $display("   CHECK-K2-WRAP OK");
        else begin $display("   CHECK-K2-WRAP NG"); fails = fails + 1; end

        $display("---- (K2-7) 选色模式 5 秒无操作（仿真 T_IDLE=3M）⇒ 自动退回档位 ----");
        repeat (3_300_000) @(posedge clk);
        $display("   等待后 color_mode=%0d（期望 0）  dm=%0d（期望仍 2）", dut.u_key2_fsm.color_mode, disp_mode);
        if ((dut.u_key2_fsm.color_mode === 1'b0) && (disp_mode === 2'd2)) $display("   CHECK-K2-IDLE OK");
        else begin $display("   CHECK-K2-IDLE NG"); fails = fails + 1; end

        $display("---- (K2-8) 再长按进选色、再长按退出 ----");
        long2;
        if (dut.u_key2_fsm.color_mode === 1'b1) $display("   CHECK-K2-REENTER OK");
        else begin $display("   CHECK-K2-REENTER NG"); fails = fails + 1; end
        long2;
        if (dut.u_key2_fsm.color_mode === 1'b0) $display("   CHECK-K2-EXIT OK");
        else begin $display("   CHECK-K2-EXIT NG"); fails = fails + 1; end

        $display("");
        $display("---- (9) 运行时长在走：连拍两帧看秒有没有变 ----");
        snap("sim/dump/osd_6_uptime_a.hex");
        repeat (3 * 1650 * 750) @(posedge clk);
        snap("sim/dump/osd_7_uptime_b.hex");

        $display("");
        if (fails == 0) $display("==== tb_m6_osd v4 : ALL CHECKS PASSED ====");
        else            $display("==== tb_m6_osd v4 : %0d CHECK(S) FAILED ====", fails);
        $finish;
    end

    initial begin
        repeat (1650 * 750 * 60) @(posedge clk);
        $display("  TIMEOUT");
        $finish;
    end

endmodule
