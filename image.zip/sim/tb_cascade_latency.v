//==============================================================================
// tb_cascade_latency.v —— 实测"软腐蚀+膨胀 → 腐蚀"四级级联的总延迟
//   用 5x5 白块当探针（软腐蚀 k=2 会吃掉单个点，5x5 能穿过去）
//   全 0 背景，块放在 (row=5, col=100)，看输出块出现在哪 ⇒ 反推延迟
//   期望 2572（= 4 × 643）
//==============================================================================
`timescale 1ns/1ns
module tb_cascade_latency;

  localparam W = 640;
  reg clk, rst_n, vld, hs, vs, bin_in;
  reg [7:0] str_in;
  wire b1, v1, h1, s1, bin_out, v_out, h_out, s_out;
  wire [7:0] st1, st_out;

  initial clk = 1'b0;
  always #20 clk = ~clk;

  // 第 1 级：软腐蚀(k=2) + 膨胀
  morph_close #(.LINE_WIDTH(W), .STRENGTH_W(8), .M1(3), .M2(0), .KERNEL(1), .NB_K(2))
  u_s1 (.clk(clk), .sys_rst_n(rst_n),
        .bin_in(bin_in), .valid_in(vld), .hs_in(hs), .vs_in(vs), .str_in(str_in),
        .bin_out(b1), .valid_out(v1), .hs_out(h1), .vs_out(s1), .str_out(st1));

  // 第 2 级：腐蚀 + 直通
  morph_close #(.LINE_WIDTH(W), .STRENGTH_W(8), .M1(1), .M2(2), .KERNEL(1), .NB_K(2))
  u_s2 (.clk(clk), .sys_rst_n(rst_n),
        .bin_in(b1), .valid_in(v1), .hs_in(h1), .vs_in(s1), .str_in(st1),
        .bin_out(bin_out), .valid_out(v_out), .hs_out(h_out), .vs_out(s_out), .str_out(st_out));

  integer in_cnt, row, col, k;
  integer first_r, first_c, ocol, orow;
  reg     got;

  initial begin in_cnt = 0; got = 0; first_r = -1; first_c = -1; ocol = 0; orow = 0; end

  always @(posedge clk) begin
    if (rst_n && vld) in_cnt <= in_cnt + 1;
    // 记录输出块第一次出现的位置（按输出列/行计数）
    if (rst_n && v_out) begin
      if (bin_out && !got) begin
        got <= 1'b1;
        first_r = orow;
        first_c = ocol;
      end
      if (ocol == W-1) begin
        ocol <= 0;
        orow <= orow + 1;
      end
      else ocol <= ocol + 1;
    end
  end

  initial begin
    rst_n = 1'b0; vld = 1'b0; hs = 1'b1; vs = 1'b1; bin_in = 1'b0; str_in = 8'd0;
    repeat(5) @(negedge clk);
    rst_n = 1'b1;
    repeat(3) @(negedge clk);

    // 送 20 行 x 640，只在 row=5, col=100..104 放一个 5x5 白块
    for (row = 0; row < 30; row = row + 1) begin
      for (col = 0; col < W; col = col + 1) begin
        @(negedge clk);
        vld = 1'b1; hs = 1'b1; vs = 1'b1;
        bin_in = (row >= 5 && row <= 9 && col >= 100 && col <= 104) ? 1'b1 : 1'b0;
        str_in = 8'd0;
      end
      @(negedge clk); vld = 1'b0; hs = 1'b0;
    end
    for (k = 0; k < 3500; k = k + 1) begin @(negedge clk); vld = 1'b0; hs = 1'b1; end

    $display("");
    $display("------------------------------------------------------------");
    $display(" 输入块位置 : row=5   col=100");
    $display(" 输出块位置 : row=%0d  col=%0d", first_r, first_c);
    $display(" 行偏移 = %0d   列偏移 = %0d", first_r - 5, first_c - 100);
    $display(" 实测总延迟 = %0d 拍  (= 行偏移×640 + 列偏移)", (first_r-5)*W + (first_c-100));
    $display(" 理论延迟   = 2572 拍  (4 级 x 643)");
    $display("------------------------------------------------------------");
    if ((first_r-5)*W + (first_c-100) == 2572)
      $display(" [OK] 与理论一致，delay_align 的 4508 是对的");
    else
      $display(" [!!] 差 %0d 拍 ⇒ delay_align 的 FINE 要改成 %0d",
               2572 - ((first_r-5)*W + (first_c-100)),
               28 + (2572 - ((first_r-5)*W + (first_c-100))));
    $display("------------------------------------------------------------");
    $finish;
  end

endmodule
