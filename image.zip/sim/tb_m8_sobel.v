//==============================================================================
// tb_m8_sobel.v —— 验证 m8 的 sobel.v 里 GRAD_OP 参数真的切了算子
//
// 判据（纯数学，不靠猜）：
//   1) 竖直台阶边：Sobel 与 Scharr 幅值【必须完全相同】
//      （Sobel=4Δ，Scharr=16Δ>>2=4Δ ⇒ 阈值语义不变）
//   2) 45° 斜边：两者【必须不同】，且 Scharr 更大
//      （Scharr 方向响应更平 ⇒ 斜边不被吃掉）
//   只要 1) 相等、2) Scharr 更大，就证明参数确实生效且只改算子。
//
// 注意：本模块只有 strength_o（8bit，mag>>1 且饱和到 255），没有 mag_o，
//       所以对比用【小对比度】(Δ=32)，让它别饱和：
//       竖直边 Sobel=Scharr=4*32=128 → strength=64（都不饱和）
//==============================================================================
`timescale 1ns/1ns
module tb_m8_sobel;

  localparam W = 640;

  reg clk, rst_n, vld;
  reg [7:0] din;

  initial clk = 1'b0;
  always #20 clk = ~clk;

  // 两个 DUT：GRAD_OP=0（Sobel）和 GRAD_OP=1（Scharr）
  wire d0, d1, v0, v1, h0, h1, s0, s1;
  wire [7:0] st0, st1;

  sobel #(.DATA_WIDTH(8), .LINE_WIDTH(W), .GRAD_OP(0), .BORDER_MASK(1'b0), .STRENGTH_SHIFT(1))
  u_sobel (.clk(clk), .sys_rst_n(rst_n), .data_in(din), .data_in_valid(vld),
           .data_in_hs(1'b1), .data_in_vs(1'b1), .threshold(11'd32),
           .data_out(d0), .data_out_valid(v0), .data_out_hs(h0), .data_out_vs(s0),
           .strength_o(st0));

  sobel #(.DATA_WIDTH(8), .LINE_WIDTH(W), .GRAD_OP(1), .BORDER_MASK(1'b0), .STRENGTH_SHIFT(1))
  u_scharr (.clk(clk), .sys_rst_n(rst_n), .data_in(din), .data_in_valid(vld),
            .data_in_hs(1'b1), .data_in_vs(1'b1), .threshold(11'd32),
            .data_out(d1), .data_out_valid(v1), .data_out_hs(h1), .data_out_vs(s1),
            .strength_o(st1));

  //----------------------------------------------------------------------------
  // 两次激励：竖直边 / 45°斜边；每次统计最大 strength（跳过前 2 行窗口填充期）
  //----------------------------------------------------------------------------
  integer y, x, k;
  integer st0_v, st1_v;      // 竖直边：两者最大值
  integer st0_d, st1_d;      // 斜边：两者最大值

  task run_img;
    input integer mode;      // 0 = 竖直边   1 = 45° 斜边
    output integer m0;
    output integer m1;
    integer yy, xx;
    begin
      m0 = 0; m1 = 0;
      // 先给 2 行"预热"，让行缓存填满同一图案（避免帧首垃圾）
      for (yy = 0; yy < 6; yy = yy + 1) begin
        for (xx = 0; xx < W; xx = xx + 1) begin
          @(negedge clk);
          vld = 1'b1;
          if (mode == 0) din = (xx >= 320) ? 8'd32 : 8'd0;
          else           din = ((xx + yy) >= 320) ? 8'd32 : 8'd0;
          // 读上一拍的输出
          if (yy >= 3) begin
            if (st0 > m0) m0 = st0;
            if (st1 > m1) m1 = st1;
          end
        end
      end
      // 排空
      for (yy = 0; yy < W+40; yy = yy + 1) begin
        @(negedge clk);
        vld = 1'b1; din = 8'd0;
      end
    end
  endtask

  initial begin
    rst_n = 1'b0; vld = 1'b0; din = 8'd0;
    repeat(5) @(negedge clk);
    rst_n = 1'b1;
    repeat(3) @(negedge clk);

    run_img(0, st0_v, st1_v);
    run_img(1, st0_d, st1_d);

    $display("------------------------------------------------------------");
    $display(" 竖直台阶边最大 strength : Sobel=%0d   Scharr=%0d", st0_v, st1_v);
    $display(" 45 度斜边最大 strength : Sobel=%0d   Scharr=%0d", st0_d, st1_d);
    $display("------------------------------------------------------------");
    if (st0_v == st1_v) $display(" [OK]   竖直边 Sobel == Scharr  → 幅值尺度相同，阈值不用改");
    else                $display(" [FAIL] 竖直边不相等！Sobel=%0d Scharr=%0d", st0_v, st1_v);
    if (st1_d > st0_d)  $display(" [OK]   斜边 Scharr > Sobel    → GRAD_OP=1 确实生效（斜边更强）");
    else                $display(" [FAIL] 斜边 Scharr(%0d) 不大于 Sobel(%0d) → 参数没生效或权重错", st1_d, st0_d);
    $display("------------------------------------------------------------");
    $finish;
  end

endmodule
