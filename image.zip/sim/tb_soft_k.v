//==============================================================================
// tb_morph_vis.v —— 把闭运算的效果"画"出来
//
// 做法：从文件读一幅二值边缘图（每行 640 个 0/1 字符），连续送进 morph_close，
//       把输出按 valid 序号对齐（延迟 1286）写回文件。
//       之后用 Python 转成 PNG 对比图。
//
// 为什么 valid 一直给 1 而不模拟行间消隐：
//   shift_register 只在 valid 时移位 ⇒ 连续 valid 等价于"压缩掉消隐的像素流"，
//   行边界由列号隐式决定，结果完全一致，且仿真更快。
//==============================================================================
`timescale 1ns/1ns
module tb_soft_k;

  parameter integer NBK = 5;

  localparam W    = 640;
  localparam H    = 160;
  localparam NPIX = W * H;
  localparam PAD  = 1286;      // 闭运算数据延迟（实测）

  reg clk, rst_n, vld, hs, vs, bin_in;
  reg [7:0] str_in;
  wire bin_out, vld_out, hs_out, vs_out;
  wire [7:0] str_out;

  initial clk = 1'b0;
  always #20 clk = ~clk;

  morph_close #(.LINE_WIDTH(W), .STRENGTH_W(8), .M1(3), .M2(2), .KERNEL(1), .NB_K(NBK)) u_dut (
    .clk(clk), .sys_rst_n(rst_n),
    .bin_in(bin_in), .valid_in(vld), .hs_in(hs), .vs_in(vs), .str_in(str_in),
    .bin_out(bin_out), .valid_out(vld_out), .hs_out(hs_out), .vs_out(vs_out), .str_out(str_out)
  );

  // ---- 输入图（每行 640 字符）----
  reg [7:0] in_img [0:W-1];          // 一行缓存
  reg [7:0] src_mem [0:NPIX-1];      // 全图（1 字节/像素：'0' 或 '1'）

  integer fi, fo, r, c, k, n;
  integer ocnt;                       // 输出有效像素序号
  integer wcnt;                       // 已写出的像素数
  reg [7:0] ch;

  task write_px;
    input integer idx;
    input b;
    begin
      src_mem[idx] = b ? 8'h31 : 8'h30;   // '1' / '0'
    end
  endtask

  initial begin
    // ---- 读输入图 ----
    fi = $fopen("D:/dsh/m8_duochidu/sim/soft_in.txt", "r");
    if (fi == 0) begin
      $display("!! 打不开输入图");
      $finish;
    end
    for (r = 0; r < H; r = r + 1) begin
      for (c = 0; c < W; c = c + 1) begin
        ch = 8'h30;
        n = $fgetc(fi);
        if (n == 10 || n == 13 || n == -1) begin
          // 行尾/EOF：补 0
          src_mem[r*W + c] = 8'h30;
        end
        else begin
          src_mem[r*W + c] = n[7:0];
        end
      end
      // 吃掉该行剩余字符（换行）
      n = $fgetc(fi);
      while (n != 10 && n != -1) n = $fgetc(fi);
    end
    $fclose(fi);

    fo = $fopen("D:/dsh/m8_duochidu/sim/soft_out.txt", "w");

    rst_n = 1'b0; vld = 1'b0; hs = 1'b1; vs = 1'b1; bin_in = 1'b0; str_in = 8'd0;
    ocnt = 0; wcnt = 0;
    repeat(5) @(negedge clk);
    rst_n = 1'b1;
    repeat(3) @(negedge clk);

    // ---- 先灌 PAD 个 0（让延迟对齐）----
    for (k = 0; k < PAD; k = k + 1) begin
      @(negedge clk);
      vld = 1'b1; hs = 1'b1; vs = 1'b1;
      bin_in = 1'b0; str_in = 8'd0;
    end
    // ---- 送整幅图 ----
    for (k = 0; k < NPIX; k = k + 1) begin
      @(negedge clk);
      vld = 1'b1; hs = 1'b1; vs = 1'b1;
      bin_in = (src_mem[k] == 8'h31);
      str_in = 8'd0;
    end
    // ---- 排空 ----
    for (k = 0; k < PAD + 200; k = k + 1) begin
      @(negedge clk);
      vld = 1'b1; hs = 1'b1; vs = 1'b1;
      bin_in = 1'b0;
    end
    @(negedge clk); vld = 1'b0;

    $fclose(fo);
    $display("");
    $display("--------------------------------------------------------");
    $display(" 输入 %0d 像素，延迟 PAD = %0d", NPIX, PAD);
    $display(" 输出已写 %0d 像素", wcnt);
    $display(" 结果: D:/dsh/m8_duochidu/sim/soft_out.txt");
    $display("--------------------------------------------------------");
    $finish;
  end

  // ---- 收集输出：第 ocnt 个有效像素 → 第 (ocnt - PAD) 个结果 ----
  //   每行 640 个字符，行末换行
  always @(posedge clk) begin
    if (rst_n && vld_out) begin
      if (ocnt >= PAD) begin
        ch = bin_out ? 8'h31 : 8'h30;
        $fwrite(fo, "%c", ch);
        wcnt = wcnt + 1;
        if ((wcnt % W) == 0) $fwrite(fo, "\n");
      end
      ocnt = ocnt + 1;
    end
  end

endmodule
