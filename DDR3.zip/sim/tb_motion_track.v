`timescale 1ns/1ps
////////////////////////////////////////////////////////////////////////
// tb_motion_track : motion_track 自检测试台(小分辨率回归用例)
//
//   画面 64x48(8x8 块 => 8x6 = 48 个块)：
//     背景灰度 100，一个 24x24 的亮块(灰度 200，正好 3x3 个块)在动。
//
//   帧序列：
//     F0 bg                  (warm-up)
//     F1 bg                  (无运动)
//     F2 bg + 方块@(8,8)     <- 相对 F1 出现 => 有运动
//     F3 bg + 方块@(8,8)     <- 应画出 F2 的框；本帧与 F2 相同 => 无新运动
//     F4 bg + 方块@(8,8)     <- 重复帧：HOLD=0 应无框，HOLD=4 应仍有框
//     F5 bg + 方块@(24,16)   <- 移动 => 有新运动
//     F6 bg + 方块@(24,16)   <- 应画出新位置的框
//     F7 bg + 方块@(24,16)   <- 重复帧
//     F8 bg                  <- 目标消失
//
//   断言：
//     1) F0~F2 无红框
//     2) F3 红点数 = 320，矩形 x=8..31 / y=8..31，线宽 4
//     3) F4(DUT_A, HOLD=0) 无框；F4(DUT_B, HOLD=4) 仍有框(= 320)
//     4) F6 有框(F6 的框来自 F5 的移动)
//     5) DUT_C(en=0) 输出 = 输入延迟 4 拍，逐像素一致
////////////////////////////////////////////////////////////////////////

module tb_motion_track;

localparam integer HACT = 64;
localparam integer VACT = 48;
localparam integer HFP  = 8;
localparam integer HSP  = 4;
localparam integer HBP  = 8;
localparam integer VFP  = 2;
localparam integer VSP  = 2;
localparam integer VBP  = 2;
localparam integer SQ   = 24;      // 方块边长(正好 3x3 个块)
localparam integer BARW = 4;       // 薄竖条宽度(像素)：只覆盖块内 4/8 = 50%
localparam        BARV = 8'd140;   // 薄竖条亮度：与背景 100 的对比度只有 40

//! bar_x < 0 时不画竖条；>=0 时在该列画一条贯穿全高的 BARW 像素亮条
integer bar_x = -1;

//--------------------------------------------------------------------------
// 时钟 / 复位
//--------------------------------------------------------------------------
reg clk = 1'b0;
always #5 clk = ~clk;

reg rst_n = 1'b0;

//--------------------------------------------------------------------------
// 视频激励
//--------------------------------------------------------------------------
reg [7:0] din_r, din_g, din_b;
reg       din_de, din_hs, din_vs;

task gen_line(input integer y, input integer sqx, input integer sqy,
              input integer son, input integer vsel, input integer act);
    integer c;
    reg [7:0] px;
    begin
        // ---- 行前肩 ----
        for(c=0; c<HFP; c=c+1) begin
            @(negedge clk);
            din_de <= 1'b0; din_hs <= 1'b0; din_vs <= vsel;
            din_r <= 8'd0;  din_g <= 8'd0;  din_b <= 8'd0;
        end
        // ---- 行同步 ----
        for(c=0; c<HSP; c=c+1) begin
            @(negedge clk);
            din_de <= 1'b0; din_hs <= 1'b1; din_vs <= vsel;
            din_r <= 8'd0;  din_g <= 8'd0;  din_b <= 8'd0;
        end
        // ---- 行后肩 ----
        for(c=0; c<HBP; c=c+1) begin
            @(negedge clk);
            din_de <= 1'b0; din_hs <= 1'b0; din_vs <= vsel;
            din_r <= 8'd0;  din_g <= 8'd0;  din_b <= 8'd0;
        end
        // ---- 有效像素区 ----
        for(c=0; c<HACT; c=c+1) begin
            if(son && (c >= sqx) && (c < sqx+SQ) && (y >= sqy) && (y < sqy+SQ))
                px = 8'd200;
            else if((bar_x >= 0) && (c >= bar_x) && (c < bar_x+BARW))
                px = BARV;                  //! 薄竖条：模拟慢速目标形成的"运动月牙"
            else
                px = 8'd100;
            @(negedge clk);
            din_de <= (act != 0);
            din_hs <= 1'b0;
            din_vs <= vsel;
            din_r <= px;    din_g <= px;    din_b <= px;
        end
    end
endtask

task gen_frame(input integer sqx, input integer sqy, input integer son);
    integer y;
    begin
        // 场同步(2 行)
        for(y=0; y<VSP; y=y+1) gen_line(0, sqx, sqy, 0, 1'b1, 0);
        // 场后肩
        for(y=0; y<VBP; y=y+1) gen_line(0, sqx, sqy, 0, 1'b0, 0);
        // 有效行
        for(y=0; y<VACT; y=y+1) gen_line(y, sqx, sqy, son, 1'b0, 1);
        // 场前肩
        for(y=0; y<VFP; y=y+1) gen_line(0, sqx, sqy, 0, 1'b0, 0);
    end
endtask

//--------------------------------------------------------------------------
// DUT_A : HOLD=0（每帧严格按上一帧运动出框）
// DUT_B : HOLD=4（重复帧保持框）
// DUT_C : en=0   （直通校验）
//--------------------------------------------------------------------------
wire [7:0] a_r, a_g, a_b;
wire       a_de, a_hs, a_vs, a_mv;

wire [7:0] b_r, b_g, b_b;
wire       b_de, b_hs, b_vs, b_mv;

wire [7:0] c_r, c_g, c_b;
wire       c_de, c_hs, c_vs, c_mv;

motion_track #(
    .HACT(64), .VACT(48), .ADDR_W(15), .THRESH(24), .BW(4),
    .HOLD_FRAMES(0), .GATE_PLAY(0), .REJECT_BIG(1), .MIN_BOX_W(0), .MIN_BOX_H(0)
) dut_a (
    .clk(clk), .rst_n(rst_n),
    .i_r(din_r), .i_g(din_g), .i_b(din_b),
    .i_de(din_de), .i_hs(din_hs), .i_vs(din_vs),
    .en(1'b1), .play_state(4'd3), .play_tog(1'b0),
    .o_r(a_r), .o_g(a_g), .o_b(a_b),
    .o_de(a_de), .o_hs(a_hs), .o_vs(a_vs), .o_motion(a_mv)
);

motion_track #(
    .HACT(64), .VACT(48), .ADDR_W(15), .THRESH(24), .BW(4),
    .HOLD_FRAMES(4), .GATE_PLAY(0), .REJECT_BIG(1), .MIN_BOX_W(0), .MIN_BOX_H(0)
) dut_b (
    .clk(clk), .rst_n(rst_n),
    .i_r(din_r), .i_g(din_g), .i_b(din_b),
    .i_de(din_de), .i_hs(din_hs), .i_vs(din_vs),
    .en(1'b1), .play_state(4'd3), .play_tog(1'b0),
    .o_r(b_r), .o_g(b_g), .o_b(b_b),
    .o_de(b_de), .o_hs(b_hs), .o_vs(b_vs), .o_motion(b_mv)
);

motion_track #(
    .HACT(64), .VACT(48), .ADDR_W(15), .THRESH(24), .BW(4),
    .HOLD_FRAMES(0), .GATE_PLAY(0), .REJECT_BIG(1), .MIN_BOX_W(0), .MIN_BOX_H(0)
) dut_c (
    .clk(clk), .rst_n(rst_n),
    .i_r(din_r), .i_g(din_g), .i_b(din_b),
    .i_de(din_de), .i_hs(din_hs), .i_vs(din_vs),
    .en(1'b0), .play_state(4'd3), .play_tog(1'b0),
    .o_r(c_r), .o_g(c_g), .o_b(c_b),
    .o_de(c_de), .o_hs(c_hs), .o_vs(c_vs), .o_motion(c_mv)
);

//--------------------------------------------------------------------------
// DUT_D : GATE_PLAY=1（默认配置），验证"非回放状态不出框"
//--------------------------------------------------------------------------
wire [7:0] d_r, d_g, d_b;
wire       d_de, d_hs, d_vs, d_mv;

reg  [3:0] play_state_tb = 4'd0;    // 0=实时
reg        play_tog_tb   = 1'b0;

motion_track #(
    .HACT(64), .VACT(48), .ADDR_W(15), .THRESH(24), .BW(4),
    .HOLD_FRAMES(0), .GATE_PLAY(1), .REJECT_BIG(1), .MIN_BOX_W(32), .MIN_BOX_H(32)
) dut_d (
    .clk(clk), .rst_n(rst_n),
    .i_r(din_r), .i_g(din_g), .i_b(din_b),
    .i_de(din_de), .i_hs(din_hs), .i_vs(din_vs),
    .en(1'b1), .play_state(play_state_tb), .play_tog(play_tog_tb),
    .o_r(d_r), .o_g(d_g), .o_b(d_b),
    .o_de(d_de), .o_hs(d_hs), .o_vs(d_vs), .o_motion(d_mv)
);

//--------------------------------------------------------------------------
// DUT_E / DUT_F : 灵敏度对比（本次修复的核心回归）
//   同一路画面：只有一条 4 像素宽、对比度 40 的"运动月牙"（竖条从 x=16 挪到 x=40）。
//   块内变化 = 4/8 * 40 = 20
//     DUT_F(THRESH=24, 旧值) ⇒ 20 < 24，应该完全不出框
//     DUT_E(THRESH=8,  新值) ⇒ 20 > 8 ，应该正常出框
//--------------------------------------------------------------------------
wire [7:0] e_r, e_g, e_b;
wire       e_de, e_hs, e_vs, e_mv;
wire [9:0] e_cnt;

wire [7:0] f_r, f_g, f_b;
wire       f_de, f_hs, f_vs, f_mv;
wire [9:0] f_cnt;

motion_track #(
    .HACT(64), .VACT(48), .ADDR_W(15), .THRESH(8), .BW(4),
    .HOLD_FRAMES(0), .GATE_PLAY(0), .REJECT_BIG(1),
    .MIN_BOX_W(0), .MIN_BOX_H(0), .MIN_BLOCKS(4)
) dut_e (
    .clk(clk), .rst_n(rst_n),
    .i_r(din_r), .i_g(din_g), .i_b(din_b),
    .i_de(din_de), .i_hs(din_hs), .i_vs(din_vs),
    .en(1'b1), .play_state(4'd3), .play_tog(1'b0),
    .o_r(e_r), .o_g(e_g), .o_b(e_b),
    .o_de(e_de), .o_hs(e_hs), .o_vs(e_vs), .o_motion(e_mv), .o_blkcnt(e_cnt)
);

motion_track #(
    .HACT(64), .VACT(48), .ADDR_W(15), .THRESH(24), .BW(4),
    .HOLD_FRAMES(0), .GATE_PLAY(0), .REJECT_BIG(1),
    .MIN_BOX_W(0), .MIN_BOX_H(0), .MIN_BLOCKS(4)
) dut_f (
    .clk(clk), .rst_n(rst_n),
    .i_r(din_r), .i_g(din_g), .i_b(din_b),
    .i_de(din_de), .i_hs(din_hs), .i_vs(din_vs),
    .en(1'b1), .play_state(4'd3), .play_tog(1'b0),
    .o_r(f_r), .o_g(f_g), .o_b(f_b),
    .o_de(f_de), .o_hs(f_hs), .o_vs(f_vs), .o_motion(f_mv), .o_blkcnt(f_cnt)
);

//--------------------------------------------------------------------------
// DUT_G : 运行中途打开开关（en 由 TB 翻转），验证"无需预热、下一帧立刻出框"
//--------------------------------------------------------------------------
wire [7:0] g_r, g_g, g_b;
wire       g_de, g_hs, g_vs, g_mv;

reg        en_g = 1'b0;

motion_track #(
    .HACT(64), .VACT(48), .ADDR_W(15), .THRESH(24), .BW(4),
    .HOLD_FRAMES(0), .GATE_PLAY(0), .REJECT_BIG(1),
    .MIN_BOX_W(0), .MIN_BOX_H(0), .MIN_BLOCKS(4)
) dut_g (
    .clk(clk), .rst_n(rst_n),
    .i_r(din_r), .i_g(din_g), .i_b(din_b),
    .i_de(din_de), .i_hs(din_hs), .i_vs(din_vs),
    .en(en_g), .play_state(4'd3), .play_tog(1'b0),
    .o_r(g_r), .o_g(g_g), .o_b(g_b),
    .o_de(g_de), .o_hs(g_hs), .o_vs(g_vs), .o_motion(g_mv)
);

//--------------------------------------------------------------------------
// 帧统计监视器
//--------------------------------------------------------------------------
integer a_red  [0:15];
integer a_redx0[0:15];
integer a_redx1[0:15];
integer a_redy0[0:15];
integer a_redy1[0:15];
integer b_red  [0:15];
integer d_red  [0:15];
integer d_x0   [0:15];
integer d_x1   [0:15];
integer e_red  [0:15];
integer g_red  [0:15];
integer f_red  [0:15];
integer e_maxblk, f_maxblk;

integer fa, fb, fd, fe, ff, fg;
integer ax, ay;
integer a_rc, a_x0, a_x1, a_y0, a_y1;
integer b_rc, d_rc, dx, d_xa, d_xb;
integer e_rc, f_rc, g_rc;
reg     a_vsd, b_vsd, d_vsd, e_vsd, f_vsd, g_vsd;

integer i;
initial begin
    for(i=0; i<16; i=i+1) begin
        a_red[i]=0; a_redx0[i]=0; a_redx1[i]=0; a_redy0[i]=0; a_redy1[i]=0;
        b_red[i]=0; d_red[i]=0; d_x0[i]=0; d_x1[i]=0;
        e_red[i]=0; f_red[i]=0; g_red[i]=0;
    end
    e_maxblk=0; f_maxblk=0;
    fa=0; fb=0; fd=0; fe=0; ff=0; fg=0; ax=0; ay=0;
    a_rc=0; a_x0=9999; a_x1=-1; a_y0=9999; a_y1=-1;
    b_rc=0; d_rc=0; dx=0; d_xa=9999; d_xb=-1;
    e_rc=0; f_rc=0; g_rc=0;
    a_vsd=1'b0; b_vsd=1'b0; d_vsd=1'b0; e_vsd=1'b0; f_vsd=1'b0; g_vsd=1'b0;
end

// E / F：只看红点数和运动块数
always @(posedge clk) begin
    e_vsd <= e_vs;  f_vsd <= f_vs;
    if(e_vs & ~e_vsd) begin

        if(fe > 0) begin
            e_red[fe-1] = e_rc;
            $display("[E] frame %0d : red=%0d  (THRESH=8 新值)", fe-1, e_rc);
        end
        fe   <= fe + 1;
        e_rc <= 0;
    end else if(e_de) begin
        if((e_r == 8'hFF) && (e_g == 8'h00) && (e_b == 8'h00))
            e_rc <= e_rc + 1;
    end

    if(f_vs & ~f_vsd) begin

        if(ff > 0) begin
            f_red[ff-1] = f_rc;
            $display("[F] frame %0d : red=%0d  (THRESH=24 旧值)", ff-1, f_rc);
        end
        ff   <= ff + 1;
        f_rc <= 0;
    end else if(f_de) begin
        if((f_r == 8'hFF) && (f_g == 8'h00) && (f_b == 8'h00))
            f_rc <= f_rc + 1;
    end

    g_vsd <= g_vs;
    if(g_vs & ~g_vsd) begin
        if(fg > 0) begin
            g_red[fg-1] = g_rc;
            $display("[G] frame %0d : red=%0d  (en 中途打开)", fg-1, g_rc);
        end
        fg   <= fg + 1;
        g_rc <= 0;
    end else if(g_de) begin
        if((g_r == 8'hFF) && (g_g == 8'h00) && (g_b == 8'h00))
            g_rc <= g_rc + 1;
    end
end

always @(posedge clk) begin
    d_vsd <= d_vs;
    if(d_vs & ~d_vsd) begin
        if(fd > 0) begin
            d_red[fd-1] = d_rc;
            d_x0[fd-1]  = d_xa;
            d_x1[fd-1]  = d_xb;
            $display("[D] frame %0d : red=%0d  x=%0d..%0d (GATE_PLAY=1, state=%0d)",
                     fd-1, d_rc, d_xa, d_xb, play_state_tb);
        end
        fd   <= fd + 1;
        d_rc <= 0;
        d_xa <= 9999;
        d_xb <= -1;
    end else if(d_de) begin
        if((d_r == 8'hFF) && (d_g == 8'h00) && (d_b == 8'h00)) begin
            d_rc <= d_rc + 1;
            if(dx < d_xa) d_xa <= dx;
            if(dx > d_xb) d_xb <= dx;
        end
        if(dx == HACT-1) begin
            dx <= 0;
        end else
            dx <= dx + 1;
    end else begin
        dx <= 0;
    end
end

always @(posedge clk) begin
    a_vsd <= a_vs;
    if(a_vs & ~a_vsd) begin
        if(fa > 0) begin
            a_red[fa-1]   = a_rc;
            a_redx0[fa-1] = a_x0;
            a_redx1[fa-1] = a_x1;
            a_redy0[fa-1] = a_y0;
            a_redy1[fa-1] = a_y1;
            $display("[A] frame %0d : red=%0d  bbox x=%0d..%0d  y=%0d..%0d",
                     fa-1, a_rc, a_x0, a_x1, a_y0, a_y1);
        end
        fa    <= fa + 1;
        a_rc  <= 0;
        a_x0  <= 9999; a_x1 <= -1; a_y0 <= 9999; a_y1 <= -1;
        ax    <= 0;
        ay    <= 0;
    end else if(a_de) begin
        if((a_r == 8'hFF) && (a_g == 8'h00) && (a_b == 8'h00)) begin
            a_rc <= a_rc + 1;
            if(ax < a_x0) a_x0 <= ax;
            if(ax > a_x1) a_x1 <= ax;
            if(ay < a_y0) a_y0 <= ay;
            if(ay > a_y1) a_y1 <= ay;
        end
        if(ax == HACT-1) begin
            ax <= 0;
            ay <= ay + 1;
        end else
            ax <= ax + 1;
    end else begin
        ax <= 0;
    end
end

always @(posedge clk) begin
    b_vsd <= b_vs;
    if(b_vs & ~b_vsd) begin
        if(fb > 0) begin
            b_red[fb-1] = b_rc;
            $display("[B] frame %0d : red=%0d  (HOLD=4)", fb-1, b_rc);
        end
        fb   <= fb + 1;
        b_rc <= 0;
    end else if(b_de) begin
        if((b_r == 8'hFF) && (b_g == 8'h00) && (b_b == 8'h00))
            b_rc <= b_rc + 1;
    end
end

//--------------------------------------------------------------------------
// 直通校验：en=0 时输出应等于输入延迟 4 拍
//--------------------------------------------------------------------------
reg [7:0] d1r,d2r,d3r,d4r,d5r;
reg       d1e,d2e,d3e,d4e,d5e;
integer   err4, err3, err5;

initial begin
    d1r=0; d2r=0; d3r=0; d4r=0; d5r=0;
    d1e=0; d2e=0; d3e=0; d4e=0; d5e=0;
    err4=0; err3=0; err5=0;
end

always @(posedge clk) begin
    d1r <= din_r; d2r <= d1r; d3r <= d2r; d4r <= d3r; d5r <= d4r;
    d1e <= din_de; d2e <= d1e; d3e <= d2e; d4e <= d3e; d5e <= d4e;

    if(d4e) begin
        if(c_r !== d4r) err4 = err4 + 1;
        if(c_de !== d4e) err4 = err4 + 1;
    end
    if(d3e) begin
        if(c_r !== d3r) err3 = err3 + 1;
    end
    if(d5e) begin
        if(c_r !== d5r) err5 = err5 + 1;
    end
end

//--------------------------------------------------------------------------
// 判定
//--------------------------------------------------------------------------
integer fail;
`define CHK(cond, msg) \
    if(!(cond)) begin $display("  FAIL : %0s", msg); fail = fail + 1; end \
    else         begin $display("  pass : %0s", msg); end


//--------------------------------------------------------------------------
// 主流程
//--------------------------------------------------------------------------
initial begin
    fail = 0;
    $dumpfile("tb_motion_track.vcd");
    $dumpvars(0, tb_motion_track);

    din_r = 0; din_g = 0; din_b = 0;
    din_de = 0; din_hs = 0; din_vs = 0;

    rst_n = 1'b0;
    repeat(8) @(negedge clk);
    rst_n = 1'b1;

    gen_frame(0,  0,  0);        // F0
    gen_frame(0,  0,  0);        // F1
    gen_frame(8,  8,  1);        // F2 出现
    en_g = 1'b1;                 // ★DUT_G：在 F3 的场同步之前把开关打开
    repeat(20) @(negedge clk);   // 等两拍同步(模拟按键随机落点)
    gen_frame(8,  8,  1);        // F3 出框
    gen_frame(8,  8,  1);        // F4 重复帧
    gen_frame(24, 16, 1);        // F5 移动
    gen_frame(24, 16, 1);        // F6 出框
    gen_frame(24, 16, 1);        // F7 重复帧
    gen_frame(0,  0,  0);        // F8 消失

    //---- DUT_D：切到"回放"状态(state=3)后应恢复出框 ----
    play_state_tb <= 4'd3;
    repeat(20) @(negedge clk);
    play_tog_tb   <= ~play_tog_tb;      // 翻转握手提交新状态
    repeat(20) @(negedge clk);

    gen_frame(40, 8, 1);         // F9  移动（state=3，有运动）
    gen_frame(40, 8, 1);         // F10 应出框

    //---- E / F：薄月牙灵敏度对比（4px 宽、对比度 40 的竖条从 x=16 挪到 x=40）----
    bar_x = 16;  gen_frame(0, 0, 0);   // F11 竖条在 x=16
    bar_x = 16;  gen_frame(0, 0, 0);   // F12 重复（无运动）
    bar_x = 40;  gen_frame(0, 0, 0);   // F13 竖条移动 -> 块内只变 20
    bar_x = 40;  gen_frame(0, 0, 0);   // F14 应出框（F14 的统计在 F15 的场同步处落盘）
    bar_x = 40;  gen_frame(0, 0, 0);   // F15 收尾帧

    repeat(6000) @(negedge clk);

    $display("==================================================");
    $display(" 1) 静止/warm-up 帧不应出框");
    `CHK(a_red[0] == 0, "F0 无框");
    `CHK(a_red[1] == 0, "F1 无框");
    `CHK(a_red[2] == 0, "F2 无框(运动本帧不出框)");

    $display(" 2) 目标出现后下一帧出框，几何正确");
    `CHK(a_red[3] == 320,   "F3 红点数 = 320 (24x24 框线宽4)");
    `CHK(a_redx0[3] == 8,   "F3 框左沿 x = 8");
    `CHK(a_redx1[3] == 31,  "F3 框右沿 x = 31");
    `CHK(a_redy0[3] == 8,   "F3 框上沿 y = 8");
    `CHK(a_redy1[3] == 31,  "F3 框下沿 y = 31");

    $display(" 3) 重复帧：HOLD=0 清框 / HOLD=4 保持");
    `CHK(a_red[4] == 0,     "F4 (HOLD=0) 无框");
    `CHK(b_red[4] == 320,   "F4 (HOLD=4) 仍保持 320 点");

    $display(" 4) 目标移动后重新出框");
    `CHK(a_red[6] > 0,      "F6 有框");
    `CHK(a_redx0[6] >= 8,   "F6 框左沿 >= 8");
    `CHK(a_redx1[6] <= 63,  "F6 框右沿 <= 63");
    `CHK((a_redx1[6] - a_redx0[6]) >= 23, "F6 框宽 >= 24");

    $display(" 5) en=0 直通");
    `CHK(err4 == 0,         "en=0 输出与输入逐像素一致(延迟 4 拍)");
    `CHK(err3 != 0,         "延迟不是 3 拍");
    `CHK(err5 != 0,         "延迟不是 5 拍");

    $display(" 6) GATE_PLAY=1：非回放状态不出框，回放状态恢复");
    `CHK(d_red[3] == 0,     "F3 实时画面(state=0) 无框");
    `CHK(d_red[6] == 0,     "F6 实时画面(state=0) 无框");
    `CHK(d_red[9] > 0,      "F9 回放画面(state=3) 出框");
    `CHK((d_x1[9] - d_x0[9] + 1) >= 32, "F9 最小框宽 >= 32 像素(MIN_BOX_W 生效)");

    $display(" 7) 灵敏度：4px 宽 / 对比度 40 的薄月牙（块内只变 20/255）");
    `CHK(e_red[14] > 0,     "THRESH=8  能检出（新值）");
    `CHK(f_red[14] == 0,    "THRESH=24 检不出（旧值，复现上板现象）");

    $display(" 8) 运行中途打开开关（不预热）");
    `CHK(g_red[2] == 0,     "en=0 期间不出框");
    `CHK(g_red[3] == 320,   "F3 之前打开 ⇒ F3 立刻出框 320 点，无需预热");

    $display("==================================================");
    if(fail == 0)
        $display("RESULT : ALL PASS");
    else
        $display("RESULT : %0d FAILED", fail);
    $display("==================================================");
    $finish;
end

endmodule
