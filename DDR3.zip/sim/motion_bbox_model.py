"""Sweep bbox-algorithm parameters (ASCII output)."""
import numpy as np

BW, BH = 240, 135
THRESH = 8
NFRAME = 60
TRUTH_A = 25 * 50          # target blocks

def make_seq(n_false, sigma=2.0, dx=2, dy=1, seed=7):
    rng = np.random.default_rng(seed)
    bw, bh = 25, 50
    x, y = 40.0, 30.0
    prev = np.full((BH, BW), 100.0)
    seq = []
    for t in range(NFRAME):
        cur = np.full((BH, BW), 100.0)
        xi, yi = int(round(x)), int(round(y))
        cur[yi:yi+bh, xi:xi+bw] = 200.0
        cur = cur + rng.normal(0, sigma, cur.shape)
        m = np.abs(cur - prev) > THRESH
        if n_false > 0:
            m[rng.integers(0, BH, n_false), rng.integers(0, BW, n_false)] = True
        seq.append((m, (xi, yi, xi+bw-1, yi+bh-1)))
        prev = cur
        x += dx + rng.normal(0, .6); y += dy + rng.normal(0, .4)
        if x < 5 or x > BW-bw-5: dx = -dx
        if y < 5 or y > BH-bh-5: dy = -dy
    return seq

def denoise(m, thr):
    if thr <= 1: return m
    p = np.pad(m.astype(np.int16), 1)
    cnt = np.zeros_like(m, dtype=np.int16)
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            cnt += p[1+dy:1+dy+BH, 1+dx:1+dx+BW]
    return cnt >= thr

def bbox_old(m):
    ys, xs = np.nonzero(m)
    return None if len(xs) == 0 else (xs.min(), ys.min(), xs.max(), ys.max())

def bbox_proj(m, th):
    cs = np.nonzero(m.sum(0) >= th)[0]
    rs = np.nonzero(m.sum(1) >= th)[0]
    if len(cs) == 0 or len(rs) == 0: return None
    return cs[0], rs[0], cs[-1], rs[-1]

def minbox(b, w=4):
    if b is None: return None
    l, t, r, bb = b
    while (r-l+1) < w: l -= 1; r += 1
    while (bb-t+1) < w: t -= 1; bb += 1
    return (max(l, 0), max(t, 0), min(r, BW-1), min(bb, BH-1))

def slew(c, n, s):
    return c + s if n > c+s else (c - s if n < c-s else n)

def run(seq, new=True, dn=2, th=2, slew_s=3):
    out, prev = [], None
    for m, tr in seq:
        b = bbox_proj(denoise(m, dn), th) if new else bbox_old(m)
        b = minbox(b)
        if b is None:
            out.append(out[-1] if out else None); continue
        if new and prev is not None:
            b = tuple(slew(prev[i], b[i], slew_s) for i in range(4))
        out.append(b); prev = b
    return out

def stats(seq, boxes):
    areas, ious, blow = [], [], 0
    for b, (m, tr) in zip(boxes, seq):
        if b is None: areas.append(0); ious.append(0); blow += 1; continue
        a = (b[2]-b[0]+1)*(b[3]-b[1]+1); areas.append(a)
        ix = max(0, min(b[2], tr[2])-max(b[0], tr[0])+1)
        iy = max(0, min(b[3], tr[3])-max(b[1], tr[1])+1)
        u = a + (tr[2]-tr[0]+1)*(tr[3]-tr[1]+1) - ix*iy
        ious.append(ix*iy/u if u else 0)
        if a > 4*TRUTH_A: blow += 1
    a = np.array(areas, float)
    return a.mean(), a.std(), a.max(), a.std()/max(a.mean(), 1), np.mean(ious), blow/NFRAME

for nf in (2, 5, 15):
    seq = make_seq(nf)
    print(f"\n=== extra false blocks/frame = {nf} ===")
    m, s, mx, cv, iou, bl = stats(seq, run(seq, False))
    print(f"  A old min/max          area={m:7.0f} sd={s:6.0f} max={mx:6.0f} CV={cv:.2f} IoU={iou:.2f} blow={bl:.2f}")
    for dn in (2, 3):
        for th in (2, 3, 4, 6, 8):
            m, s, mx, cv, iou, bl = stats(seq, run(seq, True, dn, th))
            print(f"  B dn>={dn} proj_th={th}   area={m:7.0f} sd={s:6.0f} max={mx:6.0f} "
                  f"CV={cv:.2f} IoU={iou:.2f} blow={bl:.2f}")
