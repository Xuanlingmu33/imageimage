`timescale 1ns/1ns
////////////////////////////////////////////////////////////////////////
// Module Name   : osd_mgr
// Project       : ti60f225 1920x1080 DDR3 录像/回放 OSD 工程
// Description   : OSD 状态字符叠加(像素时钟域)
//
//   功能：
//     1. 把 rec_play_ctrl(core 时钟域) 送来的 OSD 数据经"翻转标志"握手
//        同步到像素时钟域，并在每帧边界更新；
//     2. 用 DE 计数生成 1920x1080 显示坐标，叠加两行文字：
//          主行  : 状态名(4 字汉字) + [帧号 或 倍速] + 余xs
//          提示行: 「帧冻结n」(KEY3 短按后显示 0.15s)
//     3. 字模 32x32 中文 / 16x32 ASCII，纯组合取字 + ROM 同步读出；
//        视频四路(data/de/hs/vs)同步延迟 3 拍，与文字严格对齐。
//
//   显示规则：
//     帧号  : 仅"帧冻结 / 多帧对比"状态显示
//     倍速  : 仅"录像区回放 / 倒放"状态显示
//     OSD 位置: 左上角，X0/Y0 可参数化
//
//   注意：本模块不产生 hs/vs/de，只做延迟对齐，不改动任何显示时序参数。
//   1080p：行/场计数 10 -> 12bit，字格列计数 5 -> 6bit。
////////////////////////////////////////////////////////////////////////

module osd_mgr #(
    parameter integer HACT       = 1920,       //! 行有效像素
    parameter integer VACT       = 1080,       //! 场有效行数
    parameter integer CS         = 32,         //! 字格边长(px)，须为 2 的幂
    parameter integer X0         = 32,         //! OSD 左起点(须为 CS 整数倍)
    parameter integer Y0         = 48,         //! 主行上起点(下移，避开监视器上边沿)
    parameter integer Y1         = 96,         //! 保留(提示行已移除)
    parameter integer LINE_CELLS = 14,         //! 主行字数
    parameter integer N_ASCII    = 14,         //! 字库 ASCII 字数
    parameter integer CLK_FREQ   = 148500000   //! 像素时钟频率
)(
    input  wire            clk      ,   //! 像素时钟(hdmi_tx_slow_clk)
    input  wire            rst_n    ,   //! 复位，低电平有效

    //---- 视频流(正极性，来自 debayer)----
    input  wire    [7:0]   i_r      ,
    input  wire    [7:0]   i_g      ,
    input  wire    [7:0]   i_b      ,
    input  wire            i_de     ,
    input  wire            i_hs     ,
    input  wire            i_vs     ,

    //---- OSD 数据(core 时钟域)----
    input  wire    [3:0]   osd_state,
    input  wire    [15:0]  osd_num  ,
    input  wire    [2:0]   osd_speed,
    input  wire    [7:0]   osd_rem  ,
    input  wire            osd_tog  ,

    //---- 视频输出(延迟对齐)----
    output reg     [7:0]   o_r      ,
    output reg     [7:0]   o_g      ,
    output reg     [7:0]   o_b      ,
    output reg             o_de     ,
    output reg             o_hs     ,
    output reg             o_vs
);

//********************************************************************//
//******************* 字库/字格 编码函数 *****************************//
//********************************************************************//
//ASCII 索引: 0=空格, 1~10='0'~'9', 11='.', 12='X', 13='s'
localparam [4:0] A_SP = 5'd0;
localparam [4:0] A_D0 = 5'd1;      //! '0'
localparam [4:0] A_DOT= 5'd11;     //! '.'
localparam [4:0] A_X  = 5'd12;     //! 'X'
localparam [4:0] A_S  = 5'd13;     //! 's'

//汉字索引
localparam [4:0] H_SHI=5'd0 , H_SH2=5'd1 , H_HUA=5'd2 , H_MIAN=5'd3;   // 实 时 画 面
localparam [4:0] H_LU =5'd4 , H_XIANG=5'd5, H_JIN=5'd6 , H_XING=5'd7;  // 录 像 进 行
localparam [4:0] H_ZAN=5'd8 , H_TING=5'd9 ;                            // 暂 停
localparam [4:0] H_HUI=5'd10, H_FANG=5'd11;                            // 回 放
localparam [4:0] H_DAO=5'd12, H_XU  =5'd13;                            // 倒 序
localparam [4:0] H_DUO=5'd14, H_ZHEN=5'd15,H_DUI=5'd16, H_BI  =5'd17;  // 多 帧 对 比
localparam [4:0] H_DONG=5'd18,H_JIE=5'd19;                             // 冻 结
localparam [4:0] H_YU =5'd20;                                          // 余
localparam [4:0] H_BEI=5'd23,H_SU  =5'd24;                             // 倍 速
localparam [4:0] H_HAO=5'd25;                                          // 号

//字格编码: {is_cjk, code_a[4:0], 3'b0, code_b[4:0]} = 14bit
function [13:0] CJKC;
    input [4:0] i;
    begin CJKC = {1'b1, i, 3'b0, 5'b0}; end
endfunction
function [13:0] ASC;
    input [4:0] a;
    input [4:0] b;
    begin ASC = {1'b0, a, 3'b0, b}; end
endfunction
localparam [13:0] BLK = {1'b0, A_SP, 3'b0, 5'b0};   //! 空格

//字库索引: 0..N_ASCII-1 = ASCII, N_ASCII..N_ASCII+N_CJK-1 = 中文
localparam [5:0]  NA    = N_ASCII;
localparam [11:0] Y0V   = Y0;
localparam [11:0] Y1V   = Y1;

//********************************************************************//
//******************* 1) OSD 数据跨时钟域握手 ************************//
//********************************************************************//
reg  [2:0]  tog_s;
reg  [3:0]  st_r;
reg  [15:0] num_r;
reg  [2:0]  spd_r;
reg  [7:0]  rem_r;

wire tog_ev = tog_s[2] ^ tog_s[1];

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        tog_s    <= 3'd0;
        st_r     <= 4'd0;
        num_r    <= 16'd0;
        spd_r    <= 3'd0;
        rem_r    <= 8'h67;
    end else begin
        tog_s <= {tog_s[1:0], osd_tog};
        //数据翻转 == 帧边界更新，此时数据已稳定
        if(tog_ev == 1'b1) begin
            st_r   <= osd_state;
            num_r  <= osd_num;
            spd_r  <= osd_speed;
            rem_r  <= osd_rem;
        end
    end

//********************************************************************//
//******************* 2) 显示坐标(仅统计 DE 像素) ********************//
//********************************************************************//
reg  [11:0] h_cnt;      //! 0..1919
reg  [11:0] v_cnt;      //! 0..1079
reg  [4:0]  sub_x;      //! 格内列
reg  [5:0]  cel_x;      //! 第几格(从 x=0 起算，1920/32=60 格)
reg         vs_d;

wire vs_rise = i_vs & ~vs_d;

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        h_cnt <= 12'd0;
        v_cnt <= 12'd0;
        sub_x <= 5'd0;
        cel_x <= 6'd0;
        vs_d  <= 1'b0;
    end else begin
        vs_d <= i_vs;
        if(vs_rise == 1'b1) begin
            h_cnt <= 12'd0;
            v_cnt <= 12'd0;
            sub_x <= 5'd0;
            cel_x <= 6'd0;
        end else if(i_de == 1'b1) begin
            if(h_cnt >= HACT-1) begin
                h_cnt <= 12'd0;
                v_cnt <= (v_cnt >= VACT-1) ? 12'd0 : (v_cnt + 1'b1);
                sub_x <= 5'd0;
                cel_x <= 6'd0;
            end else begin
                h_cnt <= h_cnt + 1'b1;
                if(sub_x >= CS-1) begin
                    sub_x <= 5'd0;
                    cel_x <= cel_x + 1'b1;
                end else
                    sub_x <= sub_x + 1'b1;
            end
        end
    end

//********************************************************************//
//******************* 3) 文字内容(组合) ******************************//
//********************************************************************//
wire [13:0] c_t1 , c_t2 , c_t3;
reg  [13:0] c_s0 , c_s1 , c_s2 , c_s3;
reg  [13:0] c_a0 , c_a1 , c_a2 , c_a3 , c_a4;

//BCD 帧号 -> ASCII 索引
wire [4:0] na3 = {1'b0,num_r[15:12]} + 1'b1;
wire [4:0] na2 = {1'b0,num_r[11:8]}  + 1'b1;
wire [4:0] na1 = {1'b0,num_r[7:4]}   + 1'b1;
wire [4:0] na0 = {1'b0,num_r[3:0]}   + 1'b1;

//状态名(4 格)
always @(*) begin
    case(st_r)
    4'd0: begin c_s0=CJKC(H_SHI); c_s1=CJKC(H_SH2); c_s2=CJKC(H_HUA); c_s3=CJKC(H_MIAN); end // 实时画面
    4'd1: begin c_s0=CJKC(H_LU ); c_s1=CJKC(H_XIANG); c_s2=CJKC(H_JIN); c_s3=CJKC(H_XING); end // 录像进行
    4'd2: begin c_s0=CJKC(H_LU ); c_s1=CJKC(H_XIANG); c_s2=CJKC(H_ZAN); c_s3=CJKC(H_TING); end // 录像暂停
    4'd3: begin c_s0=CJKC(H_HUI); c_s1=CJKC(H_FANG); c_s2=BLK; c_s3=BLK; end // 回放
    4'd4: begin c_s0=CJKC(H_DAO); c_s1=CJKC(H_FANG); c_s2=BLK; c_s3=BLK; end // 倒放
    4'd5: begin c_s0=CJKC(H_DUO); c_s1=CJKC(H_ZHEN); c_s2=CJKC(H_DUI); c_s3=CJKC(H_BI  ); end // 多帧对比
    default: begin                                                                                // 帧冻结n
           c_s0 = CJKC(H_ZHEN); c_s1 = CJKC(H_DONG); c_s2 = CJKC(H_JIE);
           c_s3 = {1'b0, {1'b0,(st_r - 4'd4)}, 3'b0, 5'b0};    //! '1'~'4' 的 ASCII 索引 = 2~5
           end
    endcase
end

//附加字段(5 格)：多帧对比显示“帧号1..4”；回放/倒放显示倍速；其余留空
always @(*) begin
    c_a0 = BLK; c_a1 = BLK; c_a2 = BLK; c_a3 = BLK; c_a4 = BLK;
    if(st_r == 4'd5) begin                       //多帧对比 -> 帧号 1..4
        c_a0 = CJKC(H_ZHEN);                     //帧
        c_a1 = CJKC(H_HAO );                     //号
        c_a2 = ASC({1'b0,num_r[3:0]} + 1'b1, A_SP);
    end else if((st_r == 4'd3) || (st_r == 4'd4)) begin   //回放/倒放 -> 倍速
        c_a0 = CJKC(H_BEI);                      //倍
        c_a1 = CJKC(H_SU );                      //速
        case(spd_r)
        3'd0: begin c_a2=ASC(A_D0,A_DOT); c_a3=ASC(5'd3,5'd6); c_a4=ASC(A_X,A_SP); end // 0.25X
        3'd1: begin c_a2=ASC(A_D0,A_DOT); c_a3=ASC(5'd6,A_X ); end   // 0.5X
        3'd2: begin c_a2=ASC(5'd2,A_DOT); c_a3=ASC(A_D0,A_X ); end   // 1.0X
        3'd3: begin c_a2=ASC(5'd3,A_DOT); c_a3=ASC(A_D0,A_X ); end   // 2.0X
        3'd4: begin c_a2=ASC(5'd5,A_DOT); c_a3=ASC(A_D0,A_X ); end   // 4.0X
        default: begin c_a2=ASC(5'd2,A_DOT); c_a3=ASC(A_D0,A_X ); end // 1.0X
        endcase
    end
end

//剩余时间 「余xx s」：只在 KEY1 录像进行状态(st_r==1)显示
wire show_rem = (st_r == 4'd1) || (st_r == 4'd2);   // 录像进行/暂停都显示余秒
wire [4:0] rem_t = {1'b0, rem_r[7:4]} + 1'b1;
wire [4:0] rem_o = {1'b0, rem_r[3:0]} + 1'b1;
assign c_t1 = show_rem ? CJKC(H_YU) : BLK;
assign c_t2 = show_rem ? ASC((rem_r[7:4] == 4'd0) ? A_SP : rem_t, rem_o) : BLK;
assign c_t3 = show_rem ? ASC(A_S, A_SP) : BLK;

//主行(14 格)
wire [195:0] line_main = { c_t3, c_t2, c_t1, BLK,
                           c_a4, c_a3, c_a2, c_a1, c_a0,
                           BLK,
                           c_s3, c_s2, c_s1, c_s0 };

//********************************************************************//
//******************* 4) 字块判定与取字 ******************************//
//********************************************************************//
wire in_a = (v_cnt >= Y0) && (v_cnt < Y0+CS) && (h_cnt >= X0) && (h_cnt < X0+CS*LINE_CELLS);
wire in_band = in_a;

wire [5:0] cidx = cel_x - 6'd1;                     //! X0 为 CS 整数倍，第 0 格对应 cel_x=1
wire       cidx_ok = (cidx < LINE_CELLS);           //! 1920/32=60 格；只取主行 14 格，防越界

wire [13:0] cell_sel = cidx_ok ? line_main[cidx*14 +: 14] : BLK;

wire        is_cjk  = cell_sel[13];
wire [4:0]  cw_a    = cell_sel[12:8];
wire [4:0]  cw_b    = cell_sel[4:0];
wire [4:0]  acode   = sub_x[4] ? cw_b : cw_a;       //! 每格放 2 个半宽 ASCII
wire [5:0]  rom_idx = is_cjk ? (NA + {1'b0,cw_a}) : {1'b0,acode};
wire [4:0]  sel_bit = is_cjk ? sub_x : {1'b0, sub_x[3:0]};
wire [11:0] voff    = v_cnt - Y0V;
wire [4:0]  rom_row = voff[4:0];

//********************************************************************//
//******************* 5) 流水线(3 拍)与字模读出 **********************//
//********************************************************************//
reg  [5:0]  idx_r;
reg  [4:0]  row_r;
reg  [4:0]  bit_r;
reg         inb_r;
reg  [4:0]  bit_r2;
reg         inb_r2;
reg  [7:0]  d1_r, d1_g, d1_b, d2_r, d2_g, d2_b;
reg         d1_de, d1_hs, d1_vs, d2_de, d2_hs, d2_vs;

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        idx_r <= 6'd0;
        row_r <= 5'd0;
        bit_r <= 5'd0;
        inb_r <= 1'b0;
        d1_r  <= 8'd0;  d1_g <= 8'd0;  d1_b <= 8'd0;
        d1_de <= 1'b0;  d1_hs<= 1'b0;  d1_vs<= 1'b0;
    end else begin
        idx_r <= rom_idx;
        row_r <= rom_row;
        bit_r <= sel_bit;
        inb_r <= in_band & i_de;
        d1_r  <= i_r;   d1_g <= i_g;   d1_b <= i_b;
        d1_de <= i_de;  d1_hs<= i_hs;  d1_vs<= i_vs;
    end

wire [31:0] rom_bits;

osd_font_rom u_font_rom (
    .clk  (clk      ),
    .idx  (idx_r    ),
    .row  (row_r    ),
    .bits (rom_bits )
);

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        bit_r2 <= 5'd0;
        inb_r2 <= 1'b0;
        d2_r   <= 8'd0;  d2_g <= 8'd0;  d2_b <= 8'd0;
        d2_de  <= 1'b0;  d2_hs<= 1'b0;  d2_vs<= 1'b0;
    end else begin
        bit_r2 <= bit_r;
        inb_r2 <= inb_r;
        d2_r   <= d1_r;  d2_g <= d1_g;  d2_b <= d1_b;
        d2_de  <= d1_de; d2_hs<= d1_hs; d2_vs<= d1_vs;
    end

//********************************************************************//
//******************* 6) 像素插入(白字，无底色) **********************//
//********************************************************************//
wire hit = inb_r2 & rom_bits[bit_r2];

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        o_r  <= 8'd0;  o_g  <= 8'd0;  o_b  <= 8'd0;
        o_de <= 1'b0;  o_hs <= 1'b0;  o_vs <= 1'b0;
    end else begin
        o_r  <= hit ? 8'hFF : d2_r;
        o_g  <= hit ? 8'hFF : d2_g;
        o_b  <= hit ? 8'hFF : d2_b;
        o_de <= d2_de;
        o_hs <= d2_hs;
        o_vs <= d2_vs;
    end

endmodule
