`timescale 1ns/1ns
////////////////////////////////////////////////////////////////////////
// Module Name   : rec_play_ctrl
// Project       : ti60f225 1920x1080 DDR3 录像/回放 OSD 工程
// Description   : 录像/回放/帧冻结/多帧对比/倍速 控制 + OSD 数据产生
//
//   ★ 本版为 1080p 改造：摄像头 1920x1080@30fps，HDMI 1920x1080@60Hz。
//     倍速/剩余时间一律以【物理时间 1 秒】为基准：
//       60 个显示帧 = 1s，30 个摄像头录像帧 = 1s
//       1.0X：每 2 个显示帧推进 1 个录像帧（30 帧/s）
//       0.5X：每 4 个显示帧 1 帧；0.25X：每 8 个显示帧 1 帧
//       2.0X：每个显示帧推进 1 帧（60 帧/s）
//       4.0X：每个显示帧推进 2 帧（120 帧/s）
//     剩余秒数 = RING_SLOTS / 摄像头实测 fps（120 帧 @30fps = 4s）。
//
//   显示状态 : LIVE(实时) / REC(录像中) / REC_PAUSE(录像暂停) / PLAY(回放,含倒放)
//   叠加模式 : 帧冻结(下一帧写入快照槽并冻结显示, 1->2->3->4 循环覆盖)
//              多帧对比(顺序轮播已抓拍快照, 1 秒/张, 播完自动退出)
//
//   按键(20ms 消抖；短按=释放且未触发长按；长按=按住 1s 触发一次)：
//     KEY1短: 实时/回放 -> 开始或继续录像；录像中 -> 暂停；暂停中 -> 继续
//     KEY1长: 回到实时(保留已录片段，随后 KEY1 短可继续录)
//     KEY2短: 实时/录像/暂停 <-> 录像区回放 (两态切换)
//     KEY2长: 动态目标追踪(帧差法红框) 开/关切换 —— 见输出 track_on
//             (长按 1s 触发，且不再产生短按动作，不影响上面的显示源切换)
//     KEY3短: 帧冻结(下一帧写入快照槽，1->2->3->4 循环覆盖，并冻结显示)
//     KEY3长: 多帧对比(1 秒/张顺序轮播，播完自动退出)
//     KEY4短: 倍速循环 0.25X/0.5X/1.0X/2.0X/4.0X (仅回放态有效)
//     KEY4长: 回放/倒放切换 (仅回放态有效)
//   除 KEY3 外，任意按键都会退出帧冻结/多帧对比
////////////////////////////////////////////////////////////////////////

module rec_play_ctrl #(
    parameter FRAME_BYTES    = 2073600,      //! 一帧字节数 (1920*1080*1B = 0x1FA400)
    parameter RING_SLOTS     = 120,          //! 录像区帧数（256MiB DDR3 安全上限 122）
    parameter CLK_FREQ       = 100000000,    //! sys_clk 频率(Hz)
    parameter KEY_ACTIVE_LOW = 1'b1,         //! 按键低电平有效(按下=0)
    parameter integer FRZ_HOLD_MS = 150,     //! 帧冻结画面保持时间(ms)，之后自动回原状态
    parameter TRACK_DEFAULT  = 1'b1          //! 上电时动态目标追踪默认开(1)/关(0)
)(
    input  wire            sys_clk         ,  //! 系统时钟(core_clk 100MHz)
    input  wire            sys_rst_n       ,  //! 复位，低电平有效
    input  wire            init_end        ,  //! 系统初始化完成(DDR 校准+摄像头)

    input  wire    [3:0]   key_in          ,  //! 按键 {KEY4,KEY3,KEY2,KEY1}
    input  wire            wr_frame_done   ,  //! 一帧写完(单周期脉冲)
    input  wire            rd_frame_done   ,  //! 一帧读完(单周期脉冲)

    output reg     [31:0]  wr_base         ,  //! 下一写帧基址(字节, 供 bank_switch)
    output reg     [31:0]  rd_base         ,  //! 下一显示帧基址(字节, 供 bank_switch)

    output reg     [3:0]   osd_state       ,  //! 状态编码 0~5
    output reg     [15:0]  osd_num         ,  //! BCD 帧号
    output reg     [2:0]   osd_speed       ,  //! 倍速档
    output reg     [7:0]   osd_rem         ,  //! 剩余整秒 BCD：{十秒, 秒}
    output reg             osd_tog         ,  //! OSD 数据更新标志(翻转)

    output reg             track_on        ,  //! ★动态目标追踪开关(KEY2 长按切换，高=开)

    output wire    [3:0]   led                //! {LED4,LED3,LED2,LED1}
);

//********************************************************************//
//****************** Parameter and Internal Signal *******************//
//********************************************************************//

//DDR 布局(字节地址)
//  ★ 实时通路必须用 3 个乒乓槽轮转：读端整帧读某槽、写端 3 帧后才回到同槽，
//    否则"读正在写的槽"会让 AXI 读写抢同一片地址、读引擎收不满 burst，
//    rd_frame_done 就会停跳 → 读基址不再更新 → 花屏且 OSD 不刷新。
localparam [31:0] PING0     = 32'h00000000;
localparam [31:0] PING1     = PING0 + FRAME_BYTES;
localparam [31:0] PING2     = PING1 + FRAME_BYTES;
localparam [31:0] SNAP0     = PING2 + FRAME_BYTES;
localparam [31:0] SNAP1     = SNAP0 + FRAME_BYTES;
localparam [31:0] SNAP2     = SNAP1 + FRAME_BYTES;
localparam [31:0] SNAP3     = SNAP2 + FRAME_BYTES;
localparam [31:0] RING_BASE = SNAP3 + FRAME_BYTES;
localparam [31:0] RING_END  = RING_BASE + RING_SLOTS*FRAME_BYTES;

//状态编码
localparam        S_LIVE    = 2'd0,
                  S_REC     = 2'd1,
                  S_REC_P   = 2'd2,
                  S_PLAY    = 2'd3;

//按键时间参数
localparam        DEB_CNT   = CLK_FREQ/50;      // 20ms 消抖
localparam        LONG_CNT  = CLK_FREQ;         // 1s 长按
localparam        CMP_PERIOD= 6'd59;            // 多帧对比单张显示 60 显示帧 ≈ 1s

//剩余时间：按实测 fps 折算整秒(120 帧 @15fps≈8s / @30fps≈4s / @60fps≈2s)
localparam [7:0] REM15 = (((RING_SLOTS/15)/10) << 4) | ((RING_SLOTS/15) % 10);
localparam [7:0] REM30 = (((RING_SLOTS/30)/10) << 4) | ((RING_SLOTS/30) % 10);
localparam [7:0] REM60 = (((RING_SLOTS/60)/10) << 4) | ((RING_SLOTS/60) % 10);
localparam integer FRZ_HOLD_CNT = (CLK_FREQ/1000) * FRZ_HOLD_MS;

//reg define
reg     [1:0]   state       ;
reg     [1:0]   state_nxt   ;
reg             rec_open    ;
reg     [9:0]   rec_cnt     ;   //! 已录帧数 0..RING_SLOTS
reg     [15:0]  rec_cnt_bcd ;
reg     [31:0]  rec_end_base;   //! 录像区已录结束基址
reg     [15:0]  cam_frm_bcd ;   //! 摄像头帧计数(BCD)
reg     [31:0]  lat_ping_base;  //! 最新写完的乒乓帧基址
reg     [31:0]  lat_ring_base;  //! 最新录完的录像帧基址
reg             lat_ring_v  ;
reg     [7:0]   rem_bcd     ;   //! 剩余整秒 BCD
reg     [5:0]   rem_div     ;   //! 每秒 fps 帧
reg     [7:0]   fps_cnt     ;   //! 1s 窗口内写帧数
reg     [7:0]   fps_meas    ;   //! 实测 fps
reg     [1:0]   fps_sel     ;   //! 0:<=20fps 1:<=40fps 2:>40fps
reg     [26:0]  sec_cnt     ;   //! 1s 计时
reg     [26:0]  frz_hold_cnt;   //! 帧冻结保持计时
reg     [2:0]   snap_cnt    ;   //! 已抓拍数量 0..4
reg             snap_req    ;
reg     [1:0]   frz_idx     ;   //! 下一次快照槽 0..3
reg             frz_act     ;   //! 帧冻结进行中(显示快照)
reg             frz_disp    ;   //! 快照已写完，可以切显示
reg     [1:0]   frz_disp_idx;   //! 正在冻结显示的槽 0..3
reg     [31:0]  frz_base0, frz_base1, frz_base2, frz_base3;  //! 各冻结帧基址(实时=SNAP, 回放=录像帧)
reg             frz_play_req;   //! 回放/倒放冻结：等下一个显示帧边界锁存 rd_base
reg     [15:0]  sfr0,sfr1,sfr2,sfr3;  //! 各快照帧号(BCD)
reg     [3:0]   svld        ;
reg             cmp_act     ;
reg     [1:0]   cmp_idx     ;
reg     [2:0]   cmp_num     ;
reg     [5:0]   cmp_cnt     ;
reg             dir         ;   //! 0=正放 1=倒放
reg     [2:0]   speed       ;   //! 0:0.25X 1:0.5X 2:1.0X 3:2.0X 4:4.0X
reg     [3:0]   div_cnt     ;
reg     [31:0]  play_base   ;
reg     [31:0]  play_end    ;
reg     [1:0]   ping_idx    ;   //! 实时乒乓写槽 0/1/2 轮转(3 槽防读写撞车)
reg     [27:0]  blink_cnt   ;
reg     [31:0]  next_wr_base;

//wire define
wire    [3:0]   k_short     ;
wire    [3:0]   k_long      ;
wire            key1_short  ;
wire            key1_long   ;
wire            key2_short  ;
wire            key2_long   ;
wire            key3_short  ;
wire            key3_long   ;
wire            key4_short  ;
wire            key4_long   ;
wire            rec_resume  ;
wire            key1_new    ;
wire            is_ring_cur ;
wire            is_ping_cur ;
wire            ring_frame_done;
wire            ping_frame_done;
wire            snap_done   ;
wire            snap_pending;
wire            ring_full   ;
wire            exit_overlay;
wire    [15:0]  cam_frm_nxt ;
wire    [15:0]  rec_bcd_nxt ;
wire            cmp_start   ;
wire            cmp_step_end;
wire            cmp_finish  ;
wire            tick_en     ;
wire            enter_play  ;
reg             step_now    ;
reg     [3:0]   step_sz     ;
wire    [31:0]  step_off    ;
wire    [31:0]  play_fwd    ;
wire    [31:0]  play_bwd    ;
wire    [31:0]  play_nxt    ;
wire    [31:0]  snap_cur_base;
wire    [31:0]  cmp_base    ;
wire    [31:0]  frz_base_disp;
wire            ping_sel_nxt;
wire    [1:0]   ping_idx_nxt;
wire    [31:0]  ping_base_nxt;
wire    [31:0]  ring_ptr_nxt;
wire            osd_upd     ;
wire    [7:0]   fps_thr     ;
wire    [7:0]   rem_init_bcd;
wire            frz_hold_done;

//********************************************************************//
//***************************** Main Code ****************************//
//********************************************************************//

//bcd_inc：4 位 BCD 加 1 (0000~9999 回绕)
function [15:0] bcd_inc;
    input   [15:0]  x;
    begin
        bcd_inc[3:0]   = (x[3:0]   == 4'd9)   ? 4'd0 : (x[3:0]   + 1'b1);
        bcd_inc[7:4]   = (x[3:0]   == 4'd9)   ? ((x[7:4]   == 4'd9) ? 4'd0 : (x[7:4]   + 1'b1)) : x[7:4];
        bcd_inc[11:8]  = (x[7:0]   == 8'h99)  ? ((x[11:8]  == 4'd9) ? 4'd0 : (x[11:8]  + 1'b1)) : x[11:8];
        bcd_inc[15:12] = (x[11:0]  == 12'h999) ? ((x[15:12] == 4'd9) ? 4'd0 : (x[15:12] + 1'b1)) : x[15:12];
    end
endfunction

//bcd_dec：8 位 BCD(两位) 减 1，下限 0
function [7:0] bcd_dec;
    input   [7:0]   x;
    begin
        bcd_dec[3:0] = (x[3:0] == 4'd0) ? 4'd9 : (x[3:0] - 1'b1);
        bcd_dec[7:4] = (x[3:0] == 4'd0) ? ((x[7:4] == 4'd0) ? 4'd0 : (x[7:4] - 1'b1)) : x[7:4];
    end
endfunction

//--------------------------- 按键消抖与解码 ---------------------------
//短按=释放时且未触发长按，输出单周期脉冲；长按=按住达到 LONG_CNT 输出单周期脉冲
genvar  gi;
generate
for(gi=0; gi<4; gi=gi+1) begin : gen_key
    wire        k_raw    = KEY_ACTIVE_LOW ? ~key_in[gi] : key_in[gi];   //! 按下=1
    reg  [1:0]  k_sync;
    reg         k_stable;
    reg         k_stable_d;
    reg  [20:0] deb_cnt;
    reg  [26:0] long_cnt;
    reg         long_fired;

    always@(posedge sys_clk or negedge sys_rst_n)
        if(sys_rst_n == 1'b0) begin
            k_sync   <= 2'b00;
            k_stable <= 1'b0;
            deb_cnt  <= 21'd0;
        end else begin
            k_sync <= {k_sync[0], k_raw};
            if(k_sync[1] == k_stable)
                deb_cnt <= 21'd0;
            else if(deb_cnt == DEB_CNT-1) begin
                k_stable <= k_sync[1];
                deb_cnt  <= 21'd0;
            end else
                deb_cnt <= deb_cnt + 1'b1;
        end

    always@(posedge sys_clk or negedge sys_rst_n)
        if(sys_rst_n == 1'b0)   k_stable_d <= 1'b0;
        else                    k_stable_d <= k_stable;

    always@(posedge sys_clk or negedge sys_rst_n)
        if(sys_rst_n == 1'b0) begin
            long_cnt   <= 27'd0;
            long_fired <= 1'b0;
        end else if(k_stable == 1'b1) begin
            if(long_cnt >= LONG_CNT-1) begin
                long_cnt   <= long_cnt;
                long_fired <= 1'b1;
            end else
                long_cnt <= long_cnt + 1'b1;
        end else begin
            long_cnt   <= 27'd0;
            long_fired <= 1'b0;
        end

    assign  k_long [gi] = k_stable & (long_cnt >= LONG_CNT-1) & ~long_fired;
    assign  k_short[gi] = k_stable_d & ~k_stable & ~long_fired;
end
endgenerate

//--------------------------- 按键动作(组合) ---------------------------
assign  key1_short = k_short[0] & init_end;         //! 录像控制(初始化完成后有效)
assign  key1_long  = k_long [0] & init_end;         //! 回实时(保留片段)
assign  key2_short = k_short[1];                    //! 显示源切换
assign  key2_long  = k_long [1];                    //! 动态目标追踪 开/关
assign  key3_short = k_short[2] & ~snap_req & ~cmp_act & ~frz_disp & ~frz_play_req;  //! 抓拍(冻结保持期间不重复触发)
assign  key3_long  = k_long [2];                    //! 多帧对比
assign  key4_short = k_short[3];                    //! 倍速
assign  key4_long  = k_long [3];                    //! 正/倒放

//任意按键(除 KEY3 自身)退出多帧对比
assign  exit_overlay = (key1_short | key1_long | key2_short | key4_short | key4_long) & (frz_act | cmp_act);

//--------------------------- 动态目标追踪开关(KEY2 长按) ---------------------------
//   长按 KEY2 一次翻转一次；上电默认 TRACK_DEFAULT(默认开，方便演示)。
//   ★ 长按不会产生 key2_short —— 消抖单元里 k_short 已经用 long_fired 屏蔽了，
//     所以"KEY2 短按=实时/录像区切换"和"KEY2 长按=追踪开关"互不干扰。
//   track_on 是慢变电平，进像素域前在 motion_track 内部再打两拍同步。
always@(posedge sys_clk or negedge sys_rst_n)
    if(sys_rst_n == 1'b0)        track_on <= TRACK_DEFAULT;
    else if(key2_long == 1'b1)   track_on <= ~track_on;

//--------------------------- 帧识别与计数 ---------------------------
assign  is_ring_cur      = (wr_base >= RING_BASE) && (wr_base < RING_END);
assign  is_ping_cur      = (wr_base == PING0) || (wr_base == PING1) || (wr_base == PING2);
assign  ring_frame_done  = wr_frame_done & is_ring_cur;     //! 录像帧完成
assign  ping_frame_done  = wr_frame_done & is_ping_cur;     //! 乒乓帧完成
assign  snap_done        = wr_frame_done & snap_req & (wr_base == snap_cur_base);
assign  snap_pending     = snap_req & ~snap_done;      //! 本次抓拍帧是否尚未写完
assign  ring_full        = ring_frame_done & (rec_cnt == RING_SLOTS-1);  //! 本帧写完后录像区满
assign  cam_frm_nxt      = bcd_inc(cam_frm_bcd);
assign  rec_bcd_nxt      = bcd_inc(rec_cnt_bcd);

assign  rec_resume = 1'b0;      //! 旧语义取消：KEY1 从实时按下永远是“新建片段”
assign  key1_new   = key1_short & (state == S_LIVE) & ~cmp_act & ~frz_act;   //! 实时且无叠加时 KEY1 = 新录像

//--------------------------- 实测摄像头帧率(1s 窗口) ---------------------------
// ★ 摄像头目标是 1920x1080@30fps；显示固定 1920x1080@60Hz。
//   每 1s 统计 wr_frame_done 个数，得到实际 15/30/60fps，余秒/倍速都按实测值算。
//   正常上板 fps_cnt≈30 ⇒ fps_sel=1，1.0X 正好是物理时间 1 秒 = 30 录像帧。
//   若 sensor VTS 没生效退化成 15fps，也能自动切到 15fps 表，1.0X 仍是物理实时。
always@(posedge sys_clk or negedge sys_rst_n)
    if(sys_rst_n == 1'b0)
        begin
            sec_cnt  <= 27'd0;
            fps_cnt  <= 8'd0;
            fps_meas <= 8'd30;
            fps_sel  <= 2'd1;
        end
    else if(sec_cnt >= CLK_FREQ-1) begin
        sec_cnt  <= 27'd0;
        fps_meas <= fps_cnt;
        // 首秒摄像头还没出帧时 fps_cnt=0：保持默认 30fps 表，避免误切 15fps 表
        if(fps_cnt != 8'd0)
            fps_sel <= (fps_cnt <= 8'd20) ? 2'd0 :
                       (fps_cnt <= 8'd40) ? 2'd1 : 2'd2;
        fps_cnt  <= 8'd0;
    end else begin
        sec_cnt <= sec_cnt + 1'b1;
        if(wr_frame_done == 1'b1)
            fps_cnt <= fps_cnt + 1'b1;
    end

assign  fps_thr     = (fps_sel == 2'd0) ? 8'd15 :
                      (fps_sel == 2'd1) ? 8'd30 : 8'd60;
assign  rem_init_bcd = (fps_sel == 2'd0) ? REM15 :
                       (fps_sel == 2'd1) ? REM30 : REM60;

//--------------------------- 状态机 ---------------------------
always@(*)
    begin
        state_nxt = state;
        case(state)
        S_LIVE:
            begin
                if(key1_short == 1'b1)
                    state_nxt = S_REC;                      //! 从实时进入录像(新建片段)
                else if((key2_short == 1'b1) && (rec_cnt != 10'd0))
                    state_nxt = S_PLAY;                     //! 进入录像区回放
            end
        S_REC:
            begin
                if(key1_short == 1'b1)
                    state_nxt = S_REC_P;                    //! 录像暂停(保留本段)
                else if((key2_short == 1'b1) && (rec_cnt != 10'd0))
                    state_nxt = S_PLAY;                     //! 进入回放(自动停止写录像区)
                else if(ring_full == 1'b1)
                    state_nxt = S_LIVE;                     //! 录满自动回实时
            end
        S_REC_P:
            begin
                if(key1_short == 1'b1)
                    state_nxt = S_REC;                      //! 继续暂停前那一小段
                else if((key2_short == 1'b1) && (rec_cnt != 10'd0))
                    state_nxt = S_PLAY;
            end
        S_PLAY:
            begin
                if(key2_short == 1'b1)
                    state_nxt = S_LIVE;                     //! 回实时
                else if(key1_short == 1'b1)
                    state_nxt = S_LIVE;                     //! 先回实时；再按一次才开新录像
            end
        default: state_nxt = S_LIVE;
        endcase
    end

always@(posedge sys_clk or negedge sys_rst_n)
    if(sys_rst_n == 1'b0)
        state <= S_LIVE;
    else if(cmp_start == 1'b1)
        state <= (state == S_REC) ? S_REC_P : S_LIVE;   //! 对比期间暂停录像
    else if(cmp_finish == 1'b1)
        state <= S_LIVE;                                //! 多帧对比播完自动回实时
    else if(key1_long == 1'b1)
        state <= S_LIVE;                                //! 长按回实时(本段算完整录像)
    else
        state <= state_nxt;

//--------------------------- 录像片段管理 ---------------------------
always@(posedge sys_clk or negedge sys_rst_n)
    if(sys_rst_n == 1'b0)
        begin
            rec_open     <= 1'b0;
            rec_cnt      <= 10'd0;
            rec_cnt_bcd  <= 16'd0;
            rec_end_base <= RING_BASE;
            cam_frm_bcd  <= 16'd0;
            rem_bcd      <= REM30;
            rem_div      <= 6'd0;
        end
    else
        begin
            //摄像头帧计数(每个写完的帧 +1)
            if(wr_frame_done == 1'b1)
                cam_frm_bcd <= cam_frm_nxt;

            if(key1_new == 1'b1)                //开始新片段(旧录像删除)
                begin
                    rec_cnt      <= 10'd0;
                    rec_cnt_bcd  <= 16'd0;
                    rec_end_base <= RING_BASE;
                    rem_bcd      <= rem_init_bcd;   //! 按实测 fps 给初值(15/30/60)
                    rem_div      <= 6'd0;
                end
            else if(key1_long == 1'b1)          //回实时并保留片段；下次 KEY1 重新覆盖录
                begin
                    rec_open     <= 1'b0;       //! 只关闭片段，不清 rec_cnt/rec_end_base
                end                                //! ⇒ KEY2 仍可回放这段；KEY1 则从 RING_BASE 重录
            else if(ring_full == 1'b1)          //录满：片段结束(仍可回放)，下次 KEY1 重录
                rec_open <= 1'b0;
            else if(ring_frame_done == 1'b1)
                begin                           //录像帧完成
                    if(rec_cnt < RING_SLOTS) begin
                        rec_cnt      <= rec_cnt + 1'b1;
                        rec_cnt_bcd  <= rec_bcd_nxt;
                        rec_end_base <= rec_end_base + FRAME_BYTES;
                    end
                    //剩余时间：每 fps_thr 帧减 1 秒(实测 15/30/60fps)
                    if(rem_div >= fps_thr-1) begin
                        rem_div <= 6'd0;
                        rem_bcd <= (rem_bcd == 8'd0) ? 8'd0 : bcd_dec(rem_bcd);
                    end else
                        rem_div <= rem_div + 1'b1;
                end

            //KEY1 短按：实时态开新录像；录像/暂停态暂停/继续；回放态先回实时
            if(key1_new == 1'b1)
                rec_open <= 1'b1;
            else if(key1_short == 1'b1 && ((state == S_REC) || (state == S_REC_P)))
                rec_open <= 1'b1;                   //! 暂停/继续都保留同一段
            else if(key1_short == 1'b1)
                rec_open <= 1'b0;                   //! 从回放回实时：本段结束
            else if(key1_long == 1'b1)
                rec_open <= 1'b0;                   //! 长按回实时：本段算完整录像
            else if(cmp_finish == 1'b1)
                rec_open <= 1'b0;                   //! 对比播完回实时：本段结束
            else if((key2_short == 1'b1) && ((state == S_REC) || (state == S_REC_P)))
                rec_open <= 1'b0;                   //! 切到录像区：本段结束
        end

//--------------------------- 帧冻结 / 快照管理 ---------------------------
//  KEY3 短按：抓拍下一帧到 SNAP 槽，抓完后显示该快照并冻结，OSD 只显示一处
//  “帧冻结n”(n=1..4)。写侧/录像/回放位置继续保留，退出冻结后从原状态继续。
always@(posedge sys_clk or negedge sys_rst_n)
    if(sys_rst_n == 1'b0)
        begin
            frz_idx  <= 2'd0;
            frz_act  <= 1'b0;
            frz_disp <= 1'b0;
            frz_disp_idx <= 2'd0;
            frz_base0 <= 32'd0; frz_base1 <= 32'd0;
            frz_base2 <= 32'd0; frz_base3 <= 32'd0;
            frz_play_req <= 1'b0;
            frz_hold_cnt <= 27'd0;
            snap_req <= 1'b0;
            snap_cnt <= 3'd0;
            svld     <= 4'd0;
            sfr0 <= 16'd0; sfr1 <= 16'd0; sfr2 <= 16'd0; sfr3 <= 16'd0;
        end
    else
        begin
            if(key3_short == 1'b1)
                begin
                    frz_act <= 1'b1;
                    if(state == S_PLAY)
                        frz_play_req <= 1'b1;   //! 回放/倒放：锁存当前显示帧，不写实时帧
                    else
                        snap_req <= 1'b1;       //! 实时/录像：抓下一帧到 SNAP 槽
                end
            else if(cmp_start == 1'b1)          //进入多帧对比：退出帧冻结
                begin
                    frz_act  <= 1'b0;
                    frz_disp <= 1'b0;
                    frz_hold_cnt <= 27'd0;
                    snap_req <= 1'b0;
                    frz_play_req <= 1'b0;
                end
            else if(exit_overlay == 1'b1)       //KEY1/2/4 退出帧冻结
                begin
                    frz_act  <= 1'b0;
                    frz_disp <= 1'b0;
                    frz_hold_cnt <= 27'd0;
                    snap_req <= 1'b0;
                    frz_play_req <= 1'b0;
                end

            if(snap_done == 1'b1)               //实时/录像抓拍帧写完
                begin
                    snap_req <= 1'b0;
                    frz_disp <= 1'b1;
                    frz_disp_idx <= frz_idx;
                    frz_hold_cnt <= FRZ_HOLD_CNT;   //! 保持 0.15s 后自动回原状态
                    case(frz_idx)
                    2'd0: frz_base0 <= snap_cur_base;
                    2'd1: frz_base1 <= snap_cur_base;
                    2'd2: frz_base2 <= snap_cur_base;
                    default: frz_base3 <= snap_cur_base;
                    endcase
                    if(snap_cnt != 3'd4)
                        snap_cnt <= snap_cnt + 1'b1;
                    case(frz_idx)
                    2'd0: begin sfr0 <= cam_frm_nxt; svld[0] <= 1'b1; end
                    2'd1: begin sfr1 <= cam_frm_nxt; svld[1] <= 1'b1; end
                    2'd2: begin sfr2 <= cam_frm_nxt; svld[2] <= 1'b1; end
                    default: begin sfr3 <= cam_frm_nxt; svld[3] <= 1'b1; end
                    endcase
                    frz_idx <= (frz_idx == 2'd3) ? 2'd0 : (frz_idx + 1'b1);
                end
            else if(frz_play_req == 1'b1 && rd_frame_done == 1'b1)
                begin                           //回放/倒放抓拍：锁存当前显示帧基址
                    frz_play_req <= 1'b0;
                    frz_disp <= 1'b1;
                    frz_disp_idx <= frz_idx;
                    frz_hold_cnt <= FRZ_HOLD_CNT;
                    case(frz_idx)
                    2'd0: frz_base0 <= rd_base;
                    2'd1: frz_base1 <= rd_base;
                    2'd2: frz_base2 <= rd_base;
                    default: frz_base3 <= rd_base;
                    endcase
                    if(snap_cnt != 3'd4)
                        snap_cnt <= snap_cnt + 1'b1;
                    frz_idx <= (frz_idx == 2'd3) ? 2'd0 : (frz_idx + 1'b1);
                end
            else if(frz_hold_cnt != 27'd0)
                frz_hold_cnt <= frz_hold_cnt - 1'b1;

            //! 保持时间到：自动退出冻结，回到冻结前的实时/录像/回放状态
            if(frz_hold_cnt == 27'd1) begin
                frz_act  <= 1'b0;
                frz_disp <= 1'b0;
            end

            if(cmp_finish == 1'b1)              //本轮对比结束：快照清零
                begin
                    snap_cnt <= 3'd0;
                    svld     <= 4'd0;
                    frz_idx  <= 2'd0;           //! 下一次抓拍重新从 1 号槽开始
                    snap_req <= 1'b0;
                    frz_act  <= 1'b0;
                    frz_disp <= 1'b0;
                    frz_play_req <= 1'b0;
                    frz_hold_cnt <= 27'd0;
                end
        end

//snap_cur_base：当前抓拍写入基址
assign  snap_cur_base = (frz_idx == 2'd0) ? SNAP0 :
                        (frz_idx == 2'd1) ? SNAP1 :
                        (frz_idx == 2'd2) ? SNAP2 : SNAP3;

//--------------------------- 多帧对比 ---------------------------
assign  cmp_start    = key3_long & (snap_cnt != 3'd0) & ~snap_req & ~frz_play_req;
assign  cmp_step_end = cmp_act & rd_frame_done & (cmp_cnt == CMP_PERIOD);
assign  cmp_finish   = cmp_step_end & (cmp_idx == (cmp_num - 1'b1));

always@(posedge sys_clk or negedge sys_rst_n)
    if(sys_rst_n == 1'b0)
        begin
            cmp_act <= 1'b0;
            cmp_idx <= 2'd0;
            cmp_num <= 3'd0;
            cmp_cnt <= 6'd0;
        end
    else if(cmp_start == 1'b1)
        begin
            cmp_act <= 1'b1;
            cmp_idx <= 2'd0;
            cmp_cnt <= 6'd0;
            cmp_num <= snap_cnt;
        end
    else if(exit_overlay == 1'b1)
        cmp_act <= 1'b0;                    //! 其它按键退出多帧对比
    else if(cmp_act == 1'b1)
        begin
            if(cmp_step_end == 1'b1)
                begin
                    if(cmp_idx == (cmp_num - 1'b1))
                        cmp_act <= 1'b0;            //! 播完最后一张，退出
                    else
                        begin
                            cmp_idx <= cmp_idx + 1'b1;
                            cmp_cnt <= 6'd0;
                        end
                end
            else if(rd_frame_done == 1'b1)
                cmp_cnt <= cmp_cnt + 1'b1;
        end

//多帧对比/冻结显示都用抓拍时记下的基址：
//  实时/录像抓拍 -> SNAP 槽；回放/倒放抓拍 -> 当时显示的那一帧(录像区地址)
assign  cmp_base = (cmp_idx == 2'd0) ? frz_base0 :
                   (cmp_idx == 2'd1) ? frz_base1 :
                   (cmp_idx == 2'd2) ? frz_base2 : frz_base3;

assign  frz_base_disp = (frz_disp_idx == 2'd0) ? frz_base0 :
                        (frz_disp_idx == 2'd1) ? frz_base1 :
                        (frz_disp_idx == 2'd2) ? frz_base2 : frz_base3;

//--------------------------- 回放控制 ---------------------------
assign  enter_play = (state_nxt == S_PLAY) && (state != S_PLAY);
assign  tick_en    = (state == S_PLAY) && (cmp_act == 1'b0) && (frz_disp == 1'b0) && (rd_frame_done == 1'b1);

//倍速换算：显示固定 60Hz，按实测摄像头 fps 选表；只保留 0.25/0.5/1/2/4 五档
//  speed: 0=0.25X 1=0.5X 2=1.0X 3=2.0X 4=4.0X
//  物理时间基准：60 显示帧 = 1s，fps 个录像帧 = 1s
//    nX 档 = 每秒推进 n*fps 个录像帧；30fps 时：
//      1.0X 每 2 显示帧 1 帧、2.0X 每显示帧 1 帧、4.0X 每显示帧 2 帧
//      0.5X 每 4 显示帧 1 帧、0.25X 每 8 显示帧 1 帧
always@(*)
begin
    step_now = 1'b1;
    step_sz  = 4'd1;
    case(fps_sel)
    2'd0: begin // 15fps 素材
        case(speed)
        3'd0: begin step_now = (div_cnt[3:0] == 4'd15);  step_sz = 4'd1; end // 0.25X：每16帧1帧
        3'd1: begin step_now = (div_cnt[2:0] == 3'd7);   step_sz = 4'd1; end // 0.5X ：每8帧1帧
        3'd2: begin step_now = (div_cnt[1:0] == 2'd3);   step_sz = 4'd1; end // 1.0X ：每4帧1帧
        3'd3: begin step_now = (div_cnt[0] == 1'b1);     step_sz = 4'd1; end // 2.0X ：每2帧1帧
        3'd4: begin step_now = 1'b1;                     step_sz = 4'd1; end // 4.0X ：每帧1帧
        default: begin step_now = (div_cnt[1:0] == 2'd3); step_sz = 4'd1; end
        endcase
    end
    2'd1: begin // 30fps 素材
        case(speed)
        3'd0: begin step_now = (div_cnt[2:0] == 3'd7);   step_sz = 4'd1; end // 0.25X：每8帧1帧
        3'd1: begin step_now = (div_cnt[1:0] == 2'd3);   step_sz = 4'd1; end // 0.5X ：每4帧1帧
        3'd2: begin step_now = (div_cnt[0] == 1'b1);     step_sz = 4'd1; end // 1.0X ：每2帧1帧
        3'd3: begin step_now = 1'b1;                     step_sz = 4'd1; end // 2.0X ：每帧1帧
        3'd4: begin step_now = 1'b1;                     step_sz = 4'd2; end // 4.0X ：每帧2帧
        default: begin step_now = (div_cnt[0] == 1'b1);  step_sz = 4'd1; end
        endcase
    end
    default: begin // 60fps 素材
        case(speed)
        3'd0: begin step_now = (div_cnt[1:0] == 2'd3);   step_sz = 4'd1; end // 0.25X：每4帧1帧
        3'd1: begin step_now = (div_cnt[0] == 1'b1);     step_sz = 4'd1; end // 0.5X ：每2帧1帧
        3'd2: begin step_now = 1'b1;                     step_sz = 4'd1; end // 1.0X ：每帧1帧
        3'd3: begin step_now = 1'b1;                     step_sz = 4'd2; end // 2.0X ：每帧2帧
        3'd4: begin step_now = 1'b1;                     step_sz = 4'd4; end // 4.0X ：每帧4帧
        default: begin step_now = 1'b1;                  step_sz = 4'd1; end
        endcase
    end
    endcase
end

assign  step_off = (step_sz == 4'd8) ? (FRAME_BYTES*8) :
                   (step_sz == 4'd4) ? (FRAME_BYTES*4) :
                   (step_sz == 4'd2) ? (FRAME_BYTES*2) : FRAME_BYTES;
assign  play_fwd = play_base + step_off;
assign  play_bwd = play_base - step_off;
assign  play_nxt = dir ? ((play_base >= (RING_BASE + step_off)) ?
                                        play_bwd : (play_end - FRAME_BYTES))
                       : ((play_base <  (play_end - step_off)) ?
                                        play_fwd : RING_BASE);

always@(posedge sys_clk or negedge sys_rst_n)
    if(sys_rst_n == 1'b0)
        begin
            dir       <= 1'b0;
            speed     <= 3'd2;
            div_cnt   <= 4'd0;
            play_base <= RING_BASE;
            play_end  <= RING_BASE;
        end
    else
        begin
            //KEY4：回放效果(仅回放态、非对比)
            if(state == S_PLAY)
                begin
                    if((frz_act == 1'b0) && (cmp_act == 1'b0))
                        begin
                            if(key4_long == 1'b1)
                                dir <= ~dir;                    //! 正放/倒放
                            else if(key4_short == 1'b1)
                                begin
                                    speed   <= (speed == 3'd4) ? 3'd0 : (speed + 1'b1);  //! 5 档循环
                                    div_cnt <= 4'd0;            //! 换档从相位 0 开始
                                end
                        end
                    //! 冻结/对比期间保持 dir/speed，倒放冻结完仍回倒放
                end
            else
                begin
                    //! 离开回放才回 1.0X / 正放（KEY1/KEY2 回实时、对比结束回实时）
                    speed   <= 3'd2;
                    dir     <= 1'b0;
                    div_cnt <= 4'd0;
                end
            //回放窗口与基址(进入回放时锁定窗口)
            if(enter_play == 1'b1)
                begin
                    play_base <= RING_BASE;
                    play_end  <= rec_end_base;
                    dir       <= 1'b0;
                    speed     <= 3'd2;
                    div_cnt   <= 4'd0;
                end
            else
                begin
                    if(tick_en == 1'b1)
                        div_cnt <= div_cnt + 1'b1;
                    if((tick_en == 1'b1) && (step_now == 1'b1))
                        play_base <= play_nxt;
                end
        end

//--------------------------- 最新帧锁存 ---------------------------
always@(posedge sys_clk or negedge sys_rst_n)
    if(sys_rst_n == 1'b0)
        begin
            lat_ping_base <= PING2;         //! 上电时读端读 PING2，写端写 PING0，互不冲突
            lat_ring_base <= RING_BASE;
            lat_ring_v    <= 1'b0;
        end
    else
        begin
            if(key1_new == 1'b1)
                lat_ring_v <= 1'b0;                 //新片段：录像最新帧失效
            if(ping_frame_done == 1'b1)
                lat_ping_base <= wr_base;           //实时最新帧
            if(ring_frame_done == 1'b1)
                begin
                    lat_ring_base <= wr_base;       //录像最新帧
                    lat_ring_v    <= 1'b1;
                end
        end

//--------------------------- 写基址(帧边界提交) ---------------------------
//ping_idx_nxt / ring_ptr_nxt：把"本拍要写的下一帧"提前算出来，避免与寄存器更新
//发生在同一拍的竞争(否则会重复写同一槽位)
assign  ping_idx_nxt = ping_frame_done ? ((ping_idx == 2'd2) ? 2'd0 : (ping_idx + 1'b1)) : ping_idx;
assign  ping_base_nxt = (ping_idx_nxt == 2'd0) ? PING0 :
                        (ping_idx_nxt == 2'd1) ? PING1 : PING2;
assign  ring_ptr_nxt = ring_frame_done ? (rec_end_base + FRAME_BYTES) : rec_end_base;

always@(*)
    begin
        if(snap_pending == 1'b1)
            next_wr_base = snap_cur_base;               //! 抓拍：下一帧写快照槽
        else if((state == S_REC) && (ring_full == 1'b0) && (rec_cnt < RING_SLOTS))
            next_wr_base = ring_ptr_nxt;                //! 录像：录像区顺序推进
        else
            next_wr_base = ping_base_nxt;               //! 其余：3 槽实时轮转
    end

always@(posedge sys_clk or negedge sys_rst_n)
    if(sys_rst_n == 1'b0)
        wr_base <= PING0;
    else if(wr_frame_done == 1'b1)
        wr_base <= next_wr_base;

//ping_idx：实时乒乓下一目标槽(0->1->2->0)
always@(posedge sys_clk or negedge sys_rst_n)
    if(sys_rst_n == 1'b0)
        ping_idx <= 2'd0;
    else if(ping_frame_done == 1'b1)
        ping_idx <= ping_idx_nxt;

//--------------------------- 读基址(帧边界提交) ---------------------------
always@(posedge sys_clk or negedge sys_rst_n)
    if(sys_rst_n == 1'b0)
        rd_base <= PING2;
    else if(rd_frame_done == 1'b1)
        begin
            if(cmp_act == 1'b1)
                rd_base <= cmp_base;                            //! 多帧对比
            else if(frz_disp == 1'b1)
                rd_base <= frz_base_disp;                       //! 帧冻结(快照已就绪)
            else if(state == S_PLAY)
                rd_base <= (step_now == 1'b1) ? play_nxt : play_base;  //! 回放/倒放
            else if((state == S_REC) || (state == S_REC_P))
                rd_base <= (lat_ring_v == 1'b1) ? lat_ring_base : lat_ping_base;  //! 录像跟随最新帧
            else
                rd_base <= lat_ping_base;                       //! 实时
        end

//--------------------------- OSD 内容(帧边界更新) ---------------------------
//osd_upd：OSD 数据更新节拍。正常按 rd_frame_done(整帧边界)提交；
//   另加 ~16ms 兜底节拍，即使帧完成脉冲异常也能看到当前状态，便于上板调试。
reg [20:0] osd_tk;
always@(posedge sys_clk or negedge sys_rst_n)
    if(sys_rst_n == 1'b0)       osd_tk <= 21'd0;
    else if(osd_upd == 1'b1)    osd_tk <= 21'd0;
    else                        osd_tk <= osd_tk + 1'b1;

assign  osd_upd = (rd_frame_done == 1'b1) || (osd_tk == 21'd1600000-1);

always@(posedge sys_clk or negedge sys_rst_n)
    if(sys_rst_n == 1'b0)
        begin
            osd_state <= 4'd0;
            osd_num   <= 16'd0;
            osd_speed <= 3'd2;
            osd_rem   <= REM30;
            osd_tog   <= 1'b0;
        end
    else if(osd_upd == 1'b1)
        begin
            //状态名
            if(cmp_act == 1'b1)
                osd_state <= 4'd5;                          //! 多帧对比
            else if(frz_disp == 1'b1)
                osd_state <= 4'd6 + {2'b00, frz_disp_idx};  //! 帧冻结1..4(只显示这一处)
            else if(state == S_REC)
                osd_state <= 4'd1;                          //! 录像中
            else if(state == S_REC_P)
                osd_state <= 4'd2;                          //! 录像暂停
            else if(state == S_PLAY)
                osd_state <= dir ? 4'd4 : 4'd3;             //! 倒放/回放
            else
                osd_state <= 4'd0;                          //! 实时
            //帧号(仅多帧对比显示 1..4；osd_mgr 里 +1)
            if(cmp_act == 1'b1)
                osd_num <= {13'd0, cmp_idx + 3'd1};
            else
                osd_num <= rec_cnt_bcd;
            osd_speed <= speed;
            osd_rem   <= rem_bcd;
            osd_tog   <= ~osd_tog;                          //! 数据更新握手
        end

//--------------------------- 指示灯 ---------------------------
always@(posedge sys_clk or negedge sys_rst_n)
    if(sys_rst_n == 1'b0)
        blink_cnt <= 28'd0;
    else
        blink_cnt <= blink_cnt + 1'b1;

assign  led[0] = (state == S_LIVE) && (cmp_act == 1'b0);   //! LED1: 实时
assign  led[1] = (state == S_REC)       ? blink_cnt[26] :                      //! LED2: 录像中(闪)
                 (state == S_REC_P)     ? blink_cnt[27] :                      //!      暂停(慢闪)
                 (rec_open && (rec_cnt == RING_SLOTS));                        //!      录满(常亮)
assign  led[2] = (state == S_PLAY) && (cmp_act == 1'b0);                        //! LED3: 回放
assign  led[3] = cmp_act;                                                      //! LED4: 多帧对比

endmodule
