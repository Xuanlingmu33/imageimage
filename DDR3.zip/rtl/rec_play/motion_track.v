`timescale 1ns/1ns
////////////////////////////////////////////////////////////////////////
//   ★ 本模块是完全独立的旁路(bypass)模块：
//       · 只吃一路视频流(r/g/b + de/hs/vs)，只吐一路视频流；
//       · 不读写、不修改任何既有模块的内部信号；
//       · en = 0 时输出 = 输入(仅整体延迟 4 拍，数据/同步关系不变)，
//         即对原工程"零功能影响"。
//       · 唯一的外部输入是 1bit 电平开关 en(高=开启)，
//         另加回放状态(与 osd_mgr 相同的翻转握手)用来做"仅在回放/倒放显示"的门控。
//              亮度 L = (R + 2G + B)/4
//              -> 8x8 像素块内求亮度均值，与"片内 BRAM 里上一帧同块均值"作差
//                 (差值 > THRESH 判为运动块)              ...... 等价 Diff_frame
//              -> 块级 3x3 计数去噪(≥3/9)                ...... v2：去孤立噪点
//              -> 行/列投影门限 + first/last             ...... v2：等价 find_box，
//                                                            但不再被离群噪点撑大
//              -> 最小框 + 每帧限速                       ...... v2：不跳、不忽大忽小
//              -> 下一帧把这个矩形画成红框                ...... 等价 find_box 的 edg_*_d1
//
//
//   显示节奏说明：
//     1080p 显示 60Hz、录像源 30fps，同一帧会被连续显示两次，
//     帧差在"重复帧"上为 0；0.25x 慢放时一帧会显示 8 次。
//     ⇒ 若每帧都清框会 30Hz / 8Hz 闪烁，故无运动时框保持 HOLD_FRAMES 帧再消失。
//
//   打点(LED/调试可接)：o_motion = 当前正在跟踪(有框)。
//
////////////////////////////////////////////////////////////////////////

module motion_track #(
    parameter integer HACT        = 1920,   //! 行有效像素
    parameter integer VACT        = 1080,   //! 场有效行数
    parameter integer ADDR_W      = 15,     //! 帧存深度 = 2^ADDR_W (需 >= BXMAX*BYMAX)
    parameter integer THRESH      = 8,      //! 块均值差阈值(0~255)，越小越灵敏
    parameter integer BW          = 4,      //! 框线宽(像素)
    parameter integer HOLD_FRAMES = 30,     //! 无运动时框保持的帧数(防重复帧闪烁)
    parameter integer GATE_PLAY   = 0,      //! 1=仅在回放/倒放(state 3/4)显示；0=只要 en=1
    parameter integer REJECT_BIG  = 1,      //! 1=整屏突变(换帧/跳帧/环回)不算目标
    parameter integer DENOISE     = 1,      //! 1=3x3 计数去噪(去掉孤立噪声块)
    parameter integer HIST_TH     = 3,      //! 行/列投影门限(每列/行至少几个运动块才算)
    parameter integer SLEW        = 3,      //! 框每条边每帧最多移动几个块(0=不限速)
    parameter integer MIN_BLOCKS  = 6,      //! 一帧里少于这么多运动块就当噪点不出框
    parameter integer MIN_BOX_W   = 32,     //! 出框的最小宽度(像素)，0=不设下限
    parameter integer MIN_BOX_H   = 32      //! 出框的最小高度(像素)，0=不设下限
)(
    input  wire        clk      ,   //! 像素时钟 hdmi_tx_slow_clk (148.5MHz)
    input  wire        rst_n    ,   //! 复位，低有效

    //---- 视频输入(正极性，来自 debayer/边缘钳位)----
    input  wire [7:0]  i_r      ,
    input  wire [7:0]  i_g      ,
    input  wire [7:0]  i_b      ,
    input  wire        i_de     ,
    input  wire        i_hs     ,
    input  wire        i_vs     ,

    //---- 开关 ----
    input  wire        en       ,   //! 动态目标追踪总开关：高=开，低=关(纯直通)
    //---- 回放状态(core 时钟域，与 osd_mgr 同一套翻转握手)----
    input  wire [3:0]  play_state,  //! 3=回放 4=倒放
    input  wire        play_tog  ,

    //---- 视频输出(整体延迟 4 拍，时序参数不变)----
    output reg  [7:0]  o_r      ,
    output reg  [7:0]  o_g      ,
    output reg  [7:0]  o_b      ,
    output reg         o_de     ,
    output reg         o_hs     ,
    output reg         o_vs     ,

    output wire        o_motion ,   //! 1 = 本帧正在显示追踪框
    output wire [9:0]  o_blkcnt     //! 上一帧检测到的运动块数(调试/上位机观测用)
);

//********************************************************************//
//******************* 0) 常量 ****************************************//
//********************************************************************//
localparam integer BLK   = 8;               //! 块边长(固定 8，便于移位)
localparam integer BXMAX = HACT / BLK;      //! 240 个块/行
localparam integer BYMAX = VACT / BLK;      //! 135 个块/场
localparam [11:0]  HLAST = HACT - 1;
localparam [11:0]  VLAST = VACT - 1;
localparam [7:0]   TH8   = THRESH;          //! 阈值取低 8 位
localparam integer BIGW  = (BXMAX * 85) / 100;   //! 判"整屏突变"的宽(块)
localparam integer BIGH  = (BYMAX * 85) / 100;   //! 判"整屏突变"的高(块)

localparam [7:0]   BOX_R = 8'hFF;           //! 框色 = 纯红
localparam [7:0]   BOX_G = 8'h00;
localparam [7:0]   BOX_B = 8'h00;

localparam [11:0]  BWM1  = BW - 1;          //! 框线宽-1
localparam [4:0]   HOLDC = HOLD_FRAMES;     //! 保持帧数

//! 常数函数：求 ceil(log2(v))，用于"每列部分和 RAM"的地址位宽
function integer clog2;
    input integer v;
    integer i;
    begin
        clog2 = 0;
        for (i = 0; (2**i) < v; i = i + 1)
            clog2 = i + 1;
    end
endfunction
localparam integer PADDR_W = clog2(BXMAX);  //! 240 -> 8

//********************************************************************//
//******************* 1) 回放状态跨时钟域握手 ************************//
//   与 osd_mgr 完全相同的做法：数据在 core 域帧边界更新，翻转标志打 3 拍，
//   检出翻转沿时数据已稳定，直接采样即可。
//********************************************************************//
reg  [2:0] tog_s;
reg  [3:0] st_r;
wire       tog_ev = tog_s[2] ^ tog_s[1];

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        tog_s <= 3'd0;
        st_r  <= 4'd0;
    end else begin
        tog_s <= {tog_s[1:0], play_tog};
        if(tog_ev == 1'b1)
            st_r <= play_state;
    end

//! en 是 core 时钟域里 KEY2 长按翻转出来的慢变电平，进像素域先打两拍再使用
reg  [1:0] en_s;
always @(posedge clk or negedge rst_n)
    if(!rst_n) en_s <= 2'b00;
    else       en_s <= {en_s[0], en};
wire en_q = en_s[1];

//! 画框许可：en 为总开关；GATE_PLAY=1 时再与"回放/倒放"相与
wire draw_on = en_q & ((GATE_PLAY == 1) ? ((st_r == 4'd3) || (st_r == 4'd4)) : 1'b1);

//********************************************************************//
//******************* 2) 亮度 + 显示坐标 *****************************//
//********************************************************************//
//! L = (R + 2G + B) / 4 ，最大 255
wire [9:0] lum_rg  = {2'b00, i_r} + {1'b0, i_g, 1'b0};
wire [9:0] lum_all = lum_rg + {2'b00, i_b};
wire [7:0] lum     = lum_all[9:2];

reg  [11:0] x_cnt, y_cnt;
reg         vs_d;
wire        vs_rise = i_vs & ~vs_d;

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        x_cnt <= 12'd0;
        y_cnt <= 12'd0;
        vs_d  <= 1'b0;
    end else begin
        vs_d <= i_vs;
        if(vs_rise == 1'b1) begin
            x_cnt <= 12'd0;
            y_cnt <= 12'd0;
        end else if(i_de == 1'b1) begin
            if(x_cnt == HLAST) begin
                x_cnt <= 12'd0;
                y_cnt <= (y_cnt == VLAST) ? 12'd0 : (y_cnt + 12'd1);
            end else
                x_cnt <= x_cnt + 12'd1;
        end else
            x_cnt <= 12'd0;          //! 行消隐期间列计数归零
    end

//********************************************************************//
//******************* 3) 流水 S1：亮度/坐标/同步 *********************//
//********************************************************************//
reg  [7:0]  lum_1, r_1, g_1, b_1;
reg         de_1, hs_1, vs_1;
reg  [11:0] x_1, y_1;

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        lum_1 <= 8'd0;
        r_1 <= 8'd0;  g_1 <= 8'd0;  b_1 <= 8'd0;
        de_1 <= 1'b0; hs_1 <= 1'b0; vs_1 <= 1'b0;
        x_1  <= 12'd0; y_1 <= 12'd0;
    end else begin
        lum_1 <= lum;
        r_1 <= i_r;  g_1 <= i_g;  b_1 <= i_b;
        de_1 <= i_de; hs_1 <= i_hs; vs_1 <= i_vs;
        x_1  <= x_cnt; y_1 <= y_cnt;
    end


//********************************************************************//
reg  [10:0] row_acc;      //! 本块本行已累加(8 像素)
reg  [10:0] row_sum8;     //! 寄存的 8 像素行和
reg  [7:0]  cur_bx;       //! 当前块列
reg  [7:0]  cur_by;       //! 当前块行
reg  [2:0]  cur_y3;       //! 块内行号(0..7)
reg         col_end_r;    //! 8 像素结束(寄存后有效)

wire [10:0] row_now = row_acc + {3'b000, lum_1};
wire        col_end = (x_1[2:0] == 3'd7);

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        row_acc   <= 11'd0;
        row_sum8  <= 11'd0;
        cur_bx    <= 8'd0;
        cur_by    <= 8'd0;
        cur_y3    <= 3'd0;
        col_end_r <= 1'b0;
    end else if(vs_1 == 1'b1) begin
        row_acc   <= 11'd0;
        col_end_r <= 1'b0;
    end else if(de_1 == 1'b1) begin
        row_acc <= (col_end == 1'b1) ? 11'd0 : row_now;
        if(col_end == 1'b1) begin
            row_sum8  <= row_now;
            cur_bx    <= x_1[11:3];
            cur_by    <= y_1[10:3];
            cur_y3    <= y_1[2:0];
            col_end_r <= 1'b1;
        end else
            col_end_r <= 1'b0;
    end else
        col_end_r <= 1'b0;

//! 该列的部分和(本帧、本块行内累计到上一行)
wire [13:0] p_rdata;
//! 本行列和 = 之前几行的部分和 + 本行 8 像素和
wire [13:0] tot_c = p_rdata + {3'b000, row_sum8};

reg              p_re, p_we;
reg [PADDR_W-1:0] p_raddr, p_waddr;
reg  [13:0]      p_wdata;
reg              ce_d1, ce_d2;
reg              blk_last;

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        p_re <= 1'b0;  p_we <= 1'b0;
        p_raddr <= {PADDR_W{1'b0}};  p_waddr <= {PADDR_W{1'b0}};
        p_wdata <= 14'd0;
        ce_d1 <= 1'b0;  ce_d2 <= 1'b0;
        blk_last <= 1'b0;
    end else if(vs_1 == 1'b1) begin
        p_re <= 1'b0;  p_we <= 1'b0;
        ce_d1 <= 1'b0;  ce_d2 <= 1'b0;
    end else begin
        p_re    <= col_end_r;              //! +1 拍：发起读
        p_raddr <= cur_bx[PADDR_W-1:0];
        ce_d1   <= col_end_r;
        ce_d2   <= ce_d1;

        p_we    <= ce_d2;                  //! +3 拍：写(此时数据已就绪)
        p_waddr <= p_raddr;
        p_wdata <= blk_last ? 14'd0 : tot_c;
        blk_last<= (cur_y3 == 3'd7);
    end

//! 本行列和 = 之前 7 行的部分和 + 本行 8 像素和
simple_dual_port_ram #(
    .DATA_WIDTH  (14      ),
    .ADDR_WIDTH  (PADDR_W ),
    .OUTPUT_REG  ("FALSE" ),
    .RAM_INIT_FILE(""     )
) u_psum_ram (
    .wdata (p_wdata ),
    .waddr (p_waddr ),
    .we    (p_we    ),
    .wclk  (clk     ),
    .raddr (p_raddr ),
    .re    (p_re    ),
    .rclk  (clk     ),
    .rdata (p_rdata )
);

//! 块均值：第 8 行 + 前 7 行部分和，右移 6 位(64 个像素)
reg         blk_end;        //! 块结束脉冲(寄存后有效)
reg  [7:0]  blk_mean;
reg  [7:0]  blk_bx, blk_by;

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        blk_end <= 1'b0;
        blk_mean<= 8'd0;
        blk_bx  <= 8'd0;
        blk_by  <= 8'd0;
    end else begin
        blk_end <= ce_d2 & blk_last;
        if((ce_d2 == 1'b1) && (blk_last == 1'b1)) begin
            blk_mean <= tot_c[13:6];
            blk_bx   <= cur_bx;
            blk_by   <= cur_by;
        end
    end

//********************************************************************//
//******************* 5) 上一帧块均值帧存 + 帧差 *********************//
//   同一时钟域，一拍读一拍写，地址相同也不会打架：
//     N   : blk_end 有效(块均值就绪)
//     N+1 : 发起读(fb_re)
//     N+2 : 读到上一帧同块均值，同时把本帧均值写回
//********************************************************************//
wire [ADDR_W-1:0] blk_addr = blk_by * BXMAX + blk_bx;

reg              fb_re, fb_we;
reg [ADDR_W-1:0] fb_raddr, fb_waddr;
reg  [7:0]       fb_wdata;
reg              cmp_v;
reg  [7:0]       blk_hold;
reg  [7:0]       cmp_bx, cmp_by;

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        fb_re    <= 1'b0;   fb_we   <= 1'b0;
        fb_raddr <= {ADDR_W{1'b0}};  fb_waddr <= {ADDR_W{1'b0}};
        fb_wdata <= 8'd0;   blk_hold<= 8'd0;
        cmp_v    <= 1'b0;   cmp_bx  <= 8'd0;  cmp_by <= 8'd0;
    end else begin
        fb_re    <= blk_end;
        fb_raddr <= blk_addr;
        blk_hold <= blk_mean;

        fb_we    <= fb_re;          //! 写延后一拍 ⇒ 读在前、写在后
        fb_waddr <= fb_raddr;
        fb_wdata <= blk_hold;

        cmp_v    <= fb_re;          //! N+2 有效
        cmp_bx   <= blk_bx;
        cmp_by   <= blk_by;
    end

wire [7:0] fb_rdata;

simple_dual_port_ram #(
    .DATA_WIDTH  (8       ),
    .ADDR_WIDTH  (ADDR_W  ),
    .OUTPUT_REG  ("FALSE" ),    //! 1 拍读出
    .RAM_INIT_FILE(""     )
) u_fb_ram (
    .wdata (fb_wdata),
    .waddr (fb_waddr),
    .we    (fb_we   ),
    .wclk  (clk     ),
    .raddr (fb_raddr),
    .re    (fb_re   ),
    .rclk  (clk     ),
    .rdata (fb_rdata)
);

//! 帧差：|当前块均值 - 上一帧同块均值| > THRESH ⇒ 该块有运动
wire [7:0] diff_v = (fb_wdata > fb_rdata) ? (fb_wdata - fb_rdata)
                                          : (fb_rdata - fb_wdata);
wire       mv_v   = cmp_v & (diff_v > TH8);     //! 每块 1 拍

//********************************************************************//
//******************* 6) 块级 3x3 计数去噪 ***************************//
//********************************************************************//
localparam integer MOFF = (DENOISE != 0) ? 1 : 0;

wire mv_filt;

generate
if (DENOISE == 0) begin : g_nodn
    assign mv_filt = mv_v;
end else begin : g_dn
    mt_win3x3 #(.W(BXMAX), .CW(8), .MODE(2), .THR(3)) u_dn (
        .clk  (clk     ),
        .rst_n(rst_n   ),
        .v    (cmp_v   ),
        .din  (mv_v    ),
        .bx   (cmp_bx  ),
        .by   (cmp_by  ),
        .dout (mv_filt )
    );
end
endgenerate

//********************************************************************//
//******************* 7) 行/列投影 -> 鲁棒外接矩形 *******************//
//     1) 每个运动块给"所在列"和"所在行"各投 1 票（片内 RAM 直方图）；
//     2) 帧末扫描：票数 >= HIST_TH 的列/行才算"真的在动"，
//        取这些列/行的 first/last 作粗框 —— 零星噪点票数只有 1，直接出局；
//     3) 最小框 MIN_BOX；4) 每条边每帧最多移动 SLEW 个块，
//        框不会跳、不会忽大忽小；但新旧框完全不重叠(换了目标)时直接跳过去。
//********************************************************************//
localparam [7:0] HTH   = HIST_TH;            //! 投影门限(票数)
localparam [7:0] SLW   = SLEW;               //! 每帧限速(块)
localparam [7:0] MINWB = MIN_BOX_W / 8;      //! 最小框宽度(块)
localparam [7:0] MINHB = MIN_BOX_H / 8;      //! 最小框高度(块)
localparam [7:0] BXR   = BXMAX - 1;          //! 最右块列
localparam [7:0] BYR   = BYMAX - 1;          //! 最下块行

//------------------------- 声明区 -------------------------//
reg  [7:0]  rb_l, rb_r, rb_t, rb_b;          //! 本帧粗框(块坐标)
reg         rb_v;                            //! 本帧有有效粗框
reg  [7:0]  p_bl, p_br, p_bt, p_bb;          //! 已提交框(块坐标，用于限速)
reg  [11:0] p_l0, p_l1, p_r0, p_r1;          //! 左右边框的列范围(像素)
reg  [11:0] p_t0, p_t1, p_b0, p_b1;          //! 上下边框的行范围(像素)
reg         c_valid;                         //! 有框
reg  [4:0]  hold_cnt;
reg  [2:0]  frame_cnt;

reg  [9:0]  blk_cnt, blk_lat;                //! 本帧运动块总数(去噪后)/帧边界锁存
reg         col_any, row_any;
reg  [7:0]  col_l, col_r, row_t, row_b;
reg  [7:0]  sc_addr;
reg  [2:0]  sc_st;                           //! 0=idle 1=扫列 2=扫行 3=取粗框 4=提交

//! 去噪后的块坐标(因果窗口补偿)
wire [7:0] dbx    = (cmp_bx >= MOFF) ? (cmp_bx - MOFF) : 8'd0;
wire [7:0] dby    = (cmp_by >= MOFF) ? (cmp_by - MOFF) : 8'd0;
wire       mv_upd = cmp_v & mv_filt;

//! 粗框 -> 最小框外扩
wire [7:0] rb_w = rb_r - rb_l + 8'd1;
wire [7:0] rb_h = rb_b - rb_t + 8'd1;
//! 左右(上下)各扩多少：把不足的部分两边分开补，保证总宽高一定达到 MIN_BOX
wire [7:0] dxw  = (rb_w < MINWB) ? (MINWB - rb_w) : 8'd0;
wire [7:0] dxh  = (rb_h < MINHB) ? (MINHB - rb_h) : 8'd0;
wire [7:0] exa  = dxw >> 1;                  //! 往左扩
wire [7:0] exb  = dxw - exa;                 //! 往右扩
wire [7:0] eya  = dxh >> 1;                  //! 往上扩
wire [7:0] eyb  = dxh - eya;                 //! 往下扩
wire [7:0] e_l  = (rb_l > exa) ? (rb_l - exa) : 8'd0;
wire [7:0] e_t  = (rb_t > eya) ? (rb_t - eya) : 8'd0;
wire [7:0] e_r  = ((rb_r + exb) > BXR) ? BXR : (rb_r + exb);
wire [7:0] e_b  = ((rb_b + eyb) > BYR) ? BYR : (rb_b + eyb);

//! 整屏突变(换帧/跳帧/环回)不算运动目标
wire big_w  = ((e_r - e_l) > BIGW);
wire big_h  = ((e_b - e_t) > BIGH);
wire box_ok = (REJECT_BIG == 0) ? 1'b1 : ~(big_w & big_h);

//! 每条边每帧最多移动 st 个块
function [7:0] slew8;
    input [7:0] cur;
    input [7:0] nv;
    input [7:0] st;
    begin
        if(nv > (cur + st))      slew8 = cur + st;
        else if((nv + st) < cur) slew8 = cur - st;
        else                     slew8 = nv;
    end
endfunction

//! 首次出框 / 新旧框完全不重叠 -> 直接跳过去；否则限速跟随
wire       no_ovl = (e_l > p_br) || (e_r < p_bl) || (e_t > p_bb) || (e_b < p_bt);
wire       direct = (~c_valid) | no_ovl;
wire [7:0] f_l = direct ? e_l : slew8(p_bl, e_l, SLW);
wire [7:0] f_r = direct ? e_r : slew8(p_br, e_r, SLW);
wire [7:0] f_t = direct ? e_t : slew8(p_bt, e_t, SLW);
wire [7:0] f_b = direct ? e_b : slew8(p_bb, e_b, SLW);

//! 块坐标 -> 像素坐标
wire [11:0] f_lpx = {4'b0000, f_l} << 3;
wire [11:0] f_rpx = ({4'b0000, f_r} << 3) + 12'd7;
wire [11:0] f_tpx = {4'b0000, f_t} << 3;
wire [11:0] f_bpx = ({4'b0000, f_b} << 3) + 12'd7;

//--------------------------------------------------------------------//
// 7.1 直方图 RAM（列 240 x 8bit / 行 135 x 8bit，各占 1 个 RAM10）
//--------------------------------------------------------------------//
wire [7:0] col_rdata, row_rdata;

reg        c_re, c_we, r_re, r_we;
reg [7:0]  c_raddr, c_waddr, c_wdata;
reg [7:0]  r_raddr, r_waddr, r_wdata;

reg        c_swe, r_swe;                     //! 扫描时"清零"写口(寄存)
reg [7:0]  c_swaddr, r_swaddr;

wire       scan_busy  = (sc_st != 3'd0);
//! 扫描读口用组合地址：拍 n 发起读 n，拍 n+1 就能拿到 n 的数据
wire       sc_col_re  = (sc_st == 3'd1);
wire       sc_row_re  = (sc_st == 3'd2);
wire [7:0] sc_raddr   = sc_addr;

simple_dual_port_ram #(
    .DATA_WIDTH(8), .ADDR_WIDTH(8),
    .OUTPUT_REG("FALSE"), .RAM_INIT_FILE("")
) u_col_hist (
    .wdata (scan_busy ? 8'd0     : c_wdata ),
    .waddr (scan_busy ? c_swaddr : c_waddr ),
    .we    (scan_busy ? c_swe    : c_we    ),
    .wclk  (clk    ),
    .raddr (scan_busy ? sc_raddr  : c_raddr),
    .re    (scan_busy ? sc_col_re : c_re   ),
    .rclk  (clk    ),
    .rdata (col_rdata)
);

simple_dual_port_ram #(
    .DATA_WIDTH(8), .ADDR_WIDTH(8),
    .OUTPUT_REG("FALSE"), .RAM_INIT_FILE("")
) u_row_hist (
    .wdata (scan_busy ? 8'd0     : r_wdata ),
    .waddr (scan_busy ? r_swaddr : r_waddr ),
    .we    (scan_busy ? r_swe    : r_we    ),
    .wclk  (clk    ),
    .raddr (scan_busy ? sc_raddr  : r_raddr),
    .re    (scan_busy ? sc_row_re : r_re   ),
    .rclk  (clk    ),
    .rdata (row_rdata)
);

//! 投票：读 -> 加一 -> 写回，3 拍完成（块间隔 8 拍，来得及）
reg  [1:0] we_pipe;
reg  [7:0] cad_p0, cad_p1, rad_p0, rad_p1;

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        c_re <= 1'b0;  c_we <= 1'b0;  c_raddr <= 8'd0;  c_waddr <= 8'd0;  c_wdata <= 8'd0;
        r_re <= 1'b0;  r_we <= 1'b0;  r_raddr <= 8'd0;  r_waddr <= 8'd0;  r_wdata <= 8'd0;
        we_pipe <= 2'd0;
        cad_p0 <= 8'd0; cad_p1 <= 8'd0;
        rad_p0 <= 8'd0; rad_p1 <= 8'd0;
    end else begin
        c_re    <= mv_upd;
        c_raddr <= dbx;
        r_re    <= mv_upd;
        r_raddr <= dby;

        cad_p0  <= dbx;
        cad_p1  <= cad_p0;
        rad_p0  <= dby;
        rad_p1  <= rad_p0;
        we_pipe <= {we_pipe[0], mv_upd};

        c_we    <= we_pipe[1];
        c_waddr <= cad_p1;
        c_wdata <= (col_rdata == 8'hFF) ? 8'hFF : (col_rdata + 8'd1);

        r_we    <= we_pipe[1];
        r_waddr <= rad_p1;
        r_wdata <= (row_rdata == 8'hFF) ? 8'hFF : (row_rdata + 8'd1);
    end

//! 运动块总数：帧边界清零，同时锁存上一帧的总数给提交拍用
always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        blk_cnt <= 10'd0;
        blk_lat <= 10'd0;
    end else if(vs_rise == 1'b1) begin
        blk_cnt <= 10'd0;
        blk_lat <= blk_cnt;
    end else if(mv_upd == 1'b1)
        blk_cnt <= (blk_cnt == 10'h3FF) ? blk_cnt : (blk_cnt + 10'd1);

//--------------------------------------------------------------------//
// 7.2 帧末扫描（找 first/last，顺便把直方图清零）
//     拍 n：发起读 n、清零 n-1、处理 n-1（读回的数据延迟 1 拍）
//--------------------------------------------------------------------//
always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        sc_st <= 3'd0;   sc_addr <= 8'd0;
        c_swe <= 1'b0;   c_swaddr <= 8'd0;
        r_swe <= 1'b0;   r_swaddr <= 8'd0;
        col_any <= 1'b0; row_any <= 1'b0;
        col_l <= 8'd0;   col_r <= 8'd0;   row_t <= 8'd0;     row_b <= 8'd0;
        rb_l  <= 8'd0;   rb_r  <= 8'd0;   rb_t  <= 8'd0;     rb_b  <= 8'd0;
        rb_v  <= 1'b0;
        p_bl  <= 8'd0;   p_br  <= 8'd0;   p_bt  <= 8'd0;     p_bb  <= 8'd0;
        p_l0  <= 12'd0;  p_l1  <= 12'd0;  p_r0  <= 12'd0;    p_r1  <= 12'd0;
        p_t0  <= 12'd0;  p_t1  <= 12'd0;  p_b0  <= 12'd0;    p_b1  <= 12'd0;
        c_valid  <= 1'b0;
        hold_cnt <= 5'd0;
        frame_cnt<= 3'd0;
    end else case(sc_st)
    3'd0: begin                                   //! 等场同步
        c_swe <= 1'b0;
        r_swe <= 1'b0;
        if(vs_rise == 1'b1) begin
            sc_st   <= 3'd1;
            sc_addr <= 8'd0;
            col_any <= 1'b0;
            row_any <= 1'b0;
            if(frame_cnt != 3'd7)
                frame_cnt <= frame_cnt + 3'd1;    //! 预热 2 帧
        end
    end
    3'd1: begin                                   //! 扫列
        c_swe    <= (sc_addr != 8'd0);
        c_swaddr <= sc_addr - 8'd1;
        if((sc_addr != 8'd0) && (col_rdata >= HTH)) begin
            if(col_any == 1'b0) begin
                col_any <= 1'b1;
                col_l   <= sc_addr - 8'd1;
            end
            col_r <= sc_addr - 8'd1;
        end
        sc_addr <= sc_addr + 8'd1;
        if(sc_addr == BXMAX) begin
            sc_st   <= 3'd2;
            sc_addr <= 8'd0;              //! 行扫描从 0 重新开始
        end
    end
    3'd2: begin                                   //! 扫行
        c_swe <= 1'b0;
        r_swe <= (sc_addr != 8'd0);
        r_swaddr <= sc_addr - 8'd1;
        if((sc_addr != 8'd0) && (row_rdata >= HTH)) begin
            if(row_any == 1'b0) begin
                row_any <= 1'b1;
                row_t   <= sc_addr - 8'd1;
            end
            row_b <= sc_addr - 8'd1;
        end
        sc_addr <= sc_addr + 8'd1;
        if(sc_addr == BYMAX) sc_st <= 3'd3;
    end
    3'd3: begin                                   //! 取粗框
        c_swe <= 1'b0;
        r_swe <= 1'b0;
        rb_l  <= col_l;  rb_r <= col_r;
        rb_t  <= row_t;  rb_b <= row_b;
        rb_v  <= col_any & row_any;
        sc_st <= 3'd4;
    end
    3'd4: begin                                   //! 最小框/拒绝/限速 -> 提交
        if((rb_v == 1'b1) && (box_ok == 1'b1) && (blk_lat >= MIN_BLOCKS) &&
           (frame_cnt >= 3'd2)) begin
            p_bl <= f_l;  p_br <= f_r;  p_bt <= f_t;  p_bb <= f_b;
            p_l0 <= f_lpx;  p_l1 <= f_lpx + BWM1;
            p_r1 <= f_rpx;  p_r0 <= (f_rpx > BWM1) ? (f_rpx - BWM1) : 12'd0;
            p_t0 <= f_tpx;  p_t1 <= f_tpx + BWM1;
            p_b1 <= f_bpx;  p_b0 <= (f_bpx > BWM1) ? (f_bpx - BWM1) : 12'd0;
            c_valid  <= draw_on;
            hold_cnt <= HOLDC;
        end else if(hold_cnt != 5'd0)
            hold_cnt <= hold_cnt - 5'd1;          //! 重复帧/暂停：框先保持
        else
            c_valid <= 1'b0;
        sc_st <= 3'd0;
    end
    endcase


//********************************************************************//
//******************* 8) 流水 S2/S3 + 边框判定 ***********************//
//********************************************************************//
reg  [7:0]  r_2, g_2, b_2;
reg         de_2, hs_2, vs_2;
reg  [11:0] x_2, y_2;

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        r_2 <= 8'd0;  g_2 <= 8'd0;  b_2 <= 8'd0;
        de_2<= 1'b0;  hs_2<= 1'b0;  vs_2<= 1'b0;
        x_2 <= 12'd0; y_2 <= 12'd0;
    end else begin
        r_2 <= r_1;  g_2 <= g_1;  b_2 <= b_1;
        de_2<= de_1; hs_2<= hs_1; vs_2<= vs_1;
        x_2 <= x_1;  y_2 <= y_1;
    end

wire on_ht = ((y_2 >= p_t0) && (y_2 <= p_t1));   //! 压在上边框
wire on_hb = ((y_2 >= p_b0) && (y_2 <= p_b1));   //! 压在下边框
wire on_vl = ((x_2 >= p_l0) && (x_2 <= p_l1));   //! 压在左边框
wire on_vr = ((x_2 >= p_r0) && (x_2 <= p_r1));   //! 压在右边框
wire in_x  = ((x_2 >= p_l0) && (x_2 <= p_r1));   //! 横向在框内
wire in_y  = ((y_2 >= p_t0) && (y_2 <= p_b1));   //! 纵向在框内

wire edge_2 = c_valid & (((on_ht | on_hb) & in_x) | ((on_vl | on_vr) & in_y));

reg  [7:0]  r_3, g_3, b_3;
reg         de_3, hs_3, vs_3;
reg         edge_3;

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        r_3 <= 8'd0;  g_3 <= 8'd0;  b_3 <= 8'd0;
        de_3<= 1'b0;  hs_3<= 1'b0;  vs_3<= 1'b0;
        edge_3 <= 1'b0;
    end else begin
        r_3 <= r_2;  g_3 <= g_2;  b_3 <= b_2;
        de_3<= de_2; hs_3<= hs_2; vs_3<= vs_2;
        edge_3 <= edge_2;
    end

//********************************************************************//
//******************* 9) 输出：红框叠加(其余像素逐像素直通) **********//
//********************************************************************//
always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        o_r <= 8'd0;  o_g <= 8'd0;  o_b <= 8'd0;
        o_de<= 1'b0;  o_hs<= 1'b0;  o_vs<= 1'b0;
    end else begin
        o_r <= (edge_3 & draw_on) ? BOX_R : r_3;
        o_g <= (edge_3 & draw_on) ? BOX_G : g_3;
        o_b <= (edge_3 & draw_on) ? BOX_B : b_3;
        o_de<= de_3;
        o_hs<= hs_3;
        o_vs<= vs_3;
    end

assign o_motion = c_valid & draw_on;
assign o_blkcnt = blk_cnt;

endmodule


////////////////////////////////////////////////////////////////////////
// Module Name   : mt_win3x3
// Description   : 块级 1bit 3x3 邻域(腐蚀/膨胀通用)
//
//   流式输入：每个有效拍送来一个块的运动标志，按光栅顺序(bx 0..W-1)，
//   内部用 2 根 W bit 移位寄存器做行延迟 + 2 拍列延迟，构成 3x3 窗口。
//   窗口是"因果窗口"：当前块 = 窗口右下角，输出对应中心 (bx-1,by-1)，
//   所以外面取外接矩形时按级数减回 1/2 个块(见 motion_track 的 MOFF)。
//   边界(块坐标 bx<2 / by<2)按 0 填充，避免在画面边缘凭空凑出运动。
//
//   MODE=0 : 9 点与(腐蚀)   MODE=1 : 9 点或(膨胀)   MODE=2 : 9 点计数 >= THR
////////////////////////////////////////////////////////////////////////
module mt_win3x3 #(
    parameter integer W    = 240,
    parameter integer CW   = 8,
    parameter integer MODE = 0,
    parameter integer THR  = 3
)(
    input  wire          clk  ,
    input  wire          rst_n,
    input  wire          v    ,   //! 采样使能(每块 1 拍)
    input  wire          din  ,   //! 本块运动标志
    input  wire [CW-1:0] bx   ,   //! 块列号
    input  wire [CW-1:0] by   ,   //! 块行号
    output wire          dout
);

reg [W-1:0] lb1, lb2;         //! 上一行 / 上上行
reg [1:0]   t1, t2, dc;       //! 三行的列延迟

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        lb1 <= {W{1'b0}};
        lb2 <= {W{1'b0}};
        t1  <= 2'b00;
        t2  <= 2'b00;
        dc  <= 2'b00;
    end else if(v == 1'b1) begin
        lb1 <= {lb1[W-2:0], din};
        lb2 <= {lb2[W-2:0], lb1[W-1]};
        t1  <= {t1[0], lb1[W-1]};
        t2  <= {t2[0], lb2[W-1]};
        dc  <= {dc[0], din};
    end

wire        p1  = lb1[W-1];                     //! (by-1, bx)
wire        p2  = lb2[W-1];                     //! (by-2, bx)
wire        ge1 = (bx >= {{(CW-1){1'b0}}, 1'b1});//! bx >= 1
wire        ge2 = (bx >= {{(CW-2){1'b0}}, 2'd2});//! bx >= 2
wire        by0 = (by == {CW{1'b0}});           //! by == 0

//! 边界按 0 填充(不存在的邻块不算"有运动")：
//!   计数去噪时不会在画面边缘凭空凑够阈值；膨胀时也不会被虚点撑大。
wire [2:0] r_cur = { (ge2 ? dc[1] : 1'b0),
                     (ge1 ? dc[0] : 1'b0),
                     din };
wire [2:0] r_p1w = { (ge2 ? t1[1] : 1'b0),
                     (ge1 ? t1[0] : 1'b0),
                     p1 };
wire [2:0] r_p2w = { (ge2 ? t2[1] : 1'b0),
                     (ge1 ? t2[0] : 1'b0),
                     p2 };

wire [2:0] r_p1  = by0        ? 3'b000 : r_p1w;
wire [2:0] r_p2  = (by <= 1)  ? 3'b000 : r_p2w;

wire and9 = (&r_cur) & (&r_p1) & (&r_p2);
wire or9  = (|r_cur) | (|r_p1) | (|r_p2);

wire [3:0] cnt9 = {3'b000, r_cur[0]} + {3'b000, r_cur[1]} + {3'b000, r_cur[2]} +
                  {3'b000, r_p1[0]}  + {3'b000, r_p1[1]}  + {3'b000, r_p1[2]}  +
                  {3'b000, r_p2[0]}  + {3'b000, r_p2[1]}  + {3'b000, r_p2[2]};

assign dout = (MODE == 0) ? and9 :
              (MODE == 1) ? or9  :
                            (cnt9 >= THR);

endmodule
