//////////////////////////////////////////////////////////////////////////////
//  ru_image_switch.v
//
//  Efinix Titanium Ti60F225 —— 内部重配置(Internal Reconfiguration / Remote
//  Update) 双镜像切换：长按按键 -> 跳到 flash 里的另一个镜像。
//
//  同一份代码放进两个工程，只改参数：
//      m8_4      (image 0 / golden) : SELF_IMAGE = 2'd0, NEXT_IMAGE = 2'd1
//      deep_move (image 1)          : SELF_IMAGE = 2'd1, NEXT_IMAGE = 2'd0
//
//  Interface Designer > Configuration > Remote Update:
//      [v] Enable Internal Reconfiguration Interface
//      Clock Pin Name              = core_clk      (与下面 .clk 一致)
//      Image Selector [1:0] Bus    = cfg_CBSEL
//      Image Selector Capture Pin  = cfg_ENA
//      Configuration Control Pin   = cfg_CONFIG
//      Error Status Pin            = cfg_ERROR
//      Remote Update Retries       = 6 (默认)
//
//  动作序列：按键稳定按下 HOLD_MS -> cfg_CBSEL 先摆好 -> 等 16 拍 ->
//            cfg_CONFIG 拉高并保持（设备开始重配置，本镜像随即停止运行）
//////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module ru_image_switch #(
    parameter [1:0] NEXT_IMAGE   = 2'd1,          // 长按后要跳去的镜像号
    parameter [1:0] SELF_IMAGE   = 2'd0,          // 本镜像自己的镜像号
    parameter integer CLK_HZ     = 100_000_000,   // clk 的实际频率
    parameter integer DEBOUNCE_MS = 20,           // 按键消抖时间
    parameter integer HOLD_MS     = 3000          // 长按判定时间
                                                  // （两边原有 1s 长按动作，故取 3s 区分）
)(
    input  wire       clk,           // 必须与 Clock Pin Name 完全一致
    input  wire       rstn,          // 低有效复位
    input  wire       key_pressed,   // 1 = 按下（板上低有效，外面取反后进来）
    input  wire       cfg_ERROR,     // 配置块输出：1 = 正常，0 = 出错
    output reg  [1:0] cfg_CBSEL,     // 镜像号
    output reg        cfg_CONFIG,    // 触发重配置
    output wire       cfg_ENA,       // 常高：允许配置块采样 cfg_CBSEL
    output wire       cfg_error_n,   // = ~cfg_ERROR，可点灯
    output wire       busy           // 长按计时中，可点灯/抓波形
);

    localparam integer DEB_CYC  = (CLK_HZ / 1000) * DEBOUNCE_MS;
    localparam integer HOLD_CYC = (CLK_HZ / 1000) * HOLD_MS;

    //------------------------------------------------------------------
    // 1. 按键同步 + 消抖
    //------------------------------------------------------------------
    reg [2:0] key_sync;
    always @(posedge clk or negedge rstn) begin
        if (!rstn) key_sync <= 3'b000;
        else       key_sync <= {key_sync[1:0], key_pressed};
    end

    reg        key_stable;
    reg [31:0] deb_cnt;
    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            key_stable <= 1'b0;
            deb_cnt    <= 32'd0;
        end else if (key_sync[2] != key_stable) begin
            if (deb_cnt >= (DEB_CYC - 1)) begin
                key_stable <= key_sync[2];
                deb_cnt    <= 32'd0;
            end else begin
                deb_cnt    <= deb_cnt + 32'd1;
            end
        end else begin
            deb_cnt <= 32'd0;
        end
    end

    //------------------------------------------------------------------
    // 2. 上电后必须先“看到松开”一次才允许触发
    //    否则新镜像启动时如果按键还按着，会马上又切回去，来回震荡
    //------------------------------------------------------------------
    reg armed;
    always @(posedge clk or negedge rstn) begin
        if (!rstn)            armed <= 1'b0;
        else if (!key_stable) armed <= 1'b1;
    end

    //------------------------------------------------------------------
    // 3. 长按计时（松手清零，到点饱和）
    //------------------------------------------------------------------
    reg [31:0] hold_cnt;
    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            hold_cnt <= 32'd0;
        end else if (!armed || !key_stable) begin
            hold_cnt <= 32'd0;
        end else if (hold_cnt < HOLD_CYC) begin
            hold_cnt <= hold_cnt + 32'd1;
        end
    end

    wire fire = armed && key_stable && (hold_cnt >= (HOLD_CYC - 1));

    assign busy = (hold_cnt != 32'd0) && (hold_cnt < HOLD_CYC);
    assign cfg_ENA = 1'b1;
    assign cfg_error_n = ~cfg_ERROR;

    //------------------------------------------------------------------
    // 4. 触发序列：先摆 CBSEL，等 16 拍让配置块采样到，再拉 CONFIG
    //    （CONFIG 一旦拉高就开始重配置，不需要再拉低）
    //------------------------------------------------------------------
    localparam [1:0] S_IDLE = 2'd0,
                     S_SET  = 2'd1,
                     S_TRIG = 2'd2,
                     S_DONE = 2'd3;

    reg [1:0] state;
    reg [4:0] gap_cnt;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            state      <= S_IDLE;
            gap_cnt    <= 5'd0;
            cfg_CBSEL  <= SELF_IMAGE;
            cfg_CONFIG <= 1'b0;
        end else begin
            case (state)
                S_IDLE: begin
                    cfg_CBSEL  <= SELF_IMAGE;   // 平时停在“本镜像”
                    cfg_CONFIG <= 1'b0;
                    if (fire) begin
                        cfg_CBSEL <= NEXT_IMAGE;
                        gap_cnt   <= 5'd0;
                        state     <= S_SET;
                    end
                end

                S_SET: begin
                    cfg_CBSEL <= NEXT_IMAGE;
                    if (gap_cnt == 5'd15) begin
                        gap_cnt <= 5'd0;
                        state   <= S_TRIG;
                    end else begin
                        gap_cnt <= gap_cnt + 5'd1;
                    end
                end

                S_TRIG: begin
                    cfg_CONFIG <= 1'b1;         // 上升沿：开始重配置
                    state      <= S_DONE;
                end

                S_DONE: begin
                    cfg_CONFIG <= 1'b1;         // 保持高，直到被重新配置掉
                end

                default: state <= S_IDLE;
            endcase
        end
    end

endmodule
