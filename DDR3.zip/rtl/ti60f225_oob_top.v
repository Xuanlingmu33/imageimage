
/////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2013-2021 Efinix Inc. All rights reserved.
//
// Description:
// Example top file for ti60f225 dev kit OOB design
//
// Language:  Verilog 2001
//Ti60f225_sc431hai2hdmi_v6：
//使用了最新版本的framebuffer_v3;
// ------------------------------------------------------------------------------

/////////////////////////////////////////////////////////////////////////////////
//`define SOFT_TAP 1
`include "ddr3_controller/ddr3_parameter.vh"
// `include "define.v"

module ti60f225_oob_top #(

	parameter                       RANK_RATIO         = 1,       // # of unique CS outputs per rank
	parameter                       ASYN_AXI_CLK       = `ASYN_AXI_CLK, 
	parameter                       RANKS              = `RANKS,
	parameter                       CK_WIDTH           = `CK_WIDTH,       // # of CK/CK# outputs to memory   
	parameter                       CKE_WIDTH          = `CKE_WIDTH,       // # of cke outputs
	parameter                       CS_WIDTH           = `CS_WIDTH,       // # of unique CS outputs
	parameter                       BANK_WIDTH         = `BANK_WIDTH,       // # of bank bits
	parameter                       ROW_WIDTH          = `ROW_WIDTH,       // DRAM address bus width
	parameter                       COL_WIDTH          = `COL_WIDTH,      // column address width
	parameter                       DM_WIDTH           = `DM_WIDTH,       // # of DM (data mask)
	parameter                       DQS_WIDTH          = `DQS_WIDTH,       // # of DQS (strobe)
	parameter                       DQ_WIDTH           = `DQ_WIDTH,      // # of DQ (data)
	parameter                       ODT_WIDTH          = `ODT_WIDTH,
	parameter                       DQ_CNT_WIDTH       = `DQ_CNT_WIDTH,       // = ceil(log2(DQ_WIDTH))
	parameter                       DQS_CNT_WIDTH      = `DQS_CNT_WIDTH,       // = ceil(log2(DQS_WIDTH))  
	parameter                       DRAM_WIDTH         = `DRAM_WIDTH,       // # of DQ per DQS   
	parameter                       DATA_WIDTH         = `DATA_WIDTH,
	parameter                       ADDR_WIDTH         = `ADDR_WIDTH,    
	parameter                       AXI_ID_WIDTH       = `AXI_ID_WIDTH,
	parameter                       AXI_ADDR_WIDTH     = `AXI_ADDR_WIDTH,
	parameter                       AXI_DATA_WIDTH     = `AXI_DATA_WIDTH
)
(

  (* syn_peri_port = 0 *) input jtag_inst1_CAPTURE,
  (* syn_peri_port = 0 *) input jtag_inst1_DRCK,
  (* syn_peri_port = 0 *) input jtag_inst1_RESET,
  (* syn_peri_port = 0 *) input jtag_inst1_RUNTEST,
  (* syn_peri_port = 0 *) input jtag_inst1_SEL,
  (* syn_peri_port = 0 *) input jtag_inst1_SHIFT,
  (* syn_peri_port = 0 *) input jtag_inst1_TCK,
  (* syn_peri_port = 0 *) input jtag_inst1_TDI,
  (* syn_peri_port = 0 *) input jtag_inst1_TMS,
  (* syn_peri_port = 0 *) input jtag_inst1_UPDATE,
  (* syn_peri_port = 0 *) output jtag_inst1_TDO,

   //Clocks 
	input	wire	[3:0]	key_i,       // ★按键 {KEY4,KEY3,KEY2,KEY1} = {GPIOL_03,GPIOR_21,GPIOR_22,GPIOL_07}
    input	wire	i_mipi_rx_pclk,
    input wire  vid_clk_dvi2,
    input wire hdmi_tx_slow_clk,
    input wire CLK_5M,
    input  wire CLK_25M,
	output  wire    pll_inst1_RSTN,
	input	wire	i_pll_locked,
	input 	wire  	pll_locked,
	output  wire    pll_inst4_RSTN,
	input   wire    pll_inst4_LOCKED,
	output  wire  	USER_PLL_RSTN,
    output 	wire 	DDR3_PLL_RSTN,
	input 	wire  	user_pll_locked,
    //CSI Interface
    input	 wire		io_cam_sda_IN,
    output wire   io_cam_sda_OUT,
    output wire		io_cam_sda_OE,

    output io_cam_scl_OUT,
    input io_cam_scl_IN,
    output io_cam_scl_OE,

    output	wire		o_cam_rst_p,
    
    input	wire		i_cam_ck_LP_P_IN,
    input	wire		i_cam_ck_LP_N_IN,
    output	wire		o_cam_ck_HS_TERM,
    output	wire		o_cam_ck_HS_ENA,
    input	wire		i_cam_ck_CLKOUT,
    
    input	wire	[7:0]			cam_d0_HS_IN,
    input	  wire		      cam_d0_LP_P_IN,
    input	  wire		      cam_d0_LP_N_IN,
    output	wire		      cam_d0_HS_TERM,
    output	wire		      cam_d0_HS_ENA,
    output	wire		      cam_d0_RST,
    output	wire		      cam_d0_FIFO_RD,
    input	  wire		      cam_d0_FIFO_EMPTY,
    
    input 	wire	[7:0]			cam_d1_HS_IN,
    input	  wire		        cam_d1_LP_P_IN,
    input	  wire		        cam_d1_LP_N_IN,
    output	wire		        cam_d1_HS_TERM,
    output	wire		        cam_d1_HS_ENA,
    output	wire		        cam_d1_RST,
    output	wire		        cam_d1_FIFO_RD,
    input	  wire		        cam_d1_FIFO_EMPTY,
    
    input 	wire	[7:0]			cam_d2_HS_IN,
    input	  wire		        cam_d2_LP_P_IN,
    input	  wire		        cam_d2_LP_N_IN,
    output	wire		        cam_d2_HS_TERM,
    output	wire		        cam_d2_HS_ENA,
    output	wire		        cam_d2_RST,
    output	wire		        cam_d2_FIFO_RD,
    input	  wire		        cam_d2_FIFO_EMPTY,  
   
    input 	wire	[7:0]			cam_d3_HS_IN,
    input	  wire		        cam_d3_LP_P_IN,
    input	  wire		        cam_d3_LP_N_IN,
    output	wire		        cam_d3_HS_TERM,
    output	wire		        cam_d3_HS_ENA,
    output	wire		        cam_d3_RST,
    output	wire		        cam_d3_FIFO_RD,
    input	  wire		        cam_d3_FIFO_EMPTY,

	
	input 					tx_cal_clk_90edge,
  	input 					rx_cal_clk,
  	input 					tx_cal_clk,
	input                              core_clk,     // CORE CLK @ 100MHz
	input                              sdram_clk,    // SDRAM CK @ 400MHz
	// PLL status flags  
	output [2:0]                       pll_shift,  
	output [4:0]                       pll_shift_sel,
	output                             pll_shift_ena,  
	// memory interface ports
	output                             ddr_ck_hi,
	output                             ddr_ck_lo,
	output                             ddr_reset_n,
	output [CKE_WIDTH-1:0]             ddr_cke,     
	output [ROW_WIDTH-1:0]             ddr_addr,
	output [BANK_WIDTH-1:0]            ddr_ba,
	output                             ddr_cas_n,
 
	output [CS_WIDTH*RANK_RATIO-1:0]   ddr_cs_n,
	output                             ddr_ras_n,
	output                             ddr_we_n,
	
	input  [DQS_WIDTH-1:0]             ddr_dqs_in_hi,
	input  [DQS_WIDTH-1:0]             ddr_dqs_in_lo,
	input  [DQ_WIDTH-1:0]              ddr_dq_in_hi,
	input  [DQ_WIDTH-1:0]              ddr_dq_in_lo,
	
	output [DQS_WIDTH-1:0]             ddr_dqs_oe,
	output [DQS_WIDTH-1:0]             ddr_dqs_oe_n,
	output [DQ_WIDTH-1:0]              ddr_dq_oe,  
	output [DQS_WIDTH-1:0]             ddr_dqs_out_hi,
	output [DQS_WIDTH-1:0]             ddr_dqs_out_lo,
	output [DQ_WIDTH-1:0]              ddr_dq_out_hi,
	output [DQ_WIDTH-1:0]              ddr_dq_out_lo,
	output [DM_WIDTH-1:0]              ddr_dm_hi,
	output [DM_WIDTH-1:0]              ddr_dm_lo,
	output [ODT_WIDTH-1:0]             ddr_odt,

       //LED
       output [7:0] led,

       // MIPI DSI
       input	wire	                     i_mipi_tx_pclk		,
       output	wire	                     mipi_dp_clk_LP_P_OUT		,
       output	wire	                     mipi_dp_clk_LP_N_OUT		,
       output	wire	[7:0] 	              mipi_dp_clk_HS_OUT		,
       output	wire	                     mipi_dp_clk_HS_OE		,
       output	wire	                     mipi_dp_data3_LP_P_OUT	,
       output	wire	                     mipi_dp_data2_LP_P_OUT	,
       output	wire	                     mipi_dp_data1_LP_P_OUT	,
       output	wire	                     mipi_dp_data0_LP_P_OUT	,
       output	wire	                     mipi_dp_data3_LP_N_OUT	,
       output	wire	                     mipi_dp_data2_LP_N_OUT	,
       output	wire	                     mipi_dp_data1_LP_N_OUT	,
       output	wire	                     mipi_dp_data0_LP_N_OUT	,
       output	wire	[7:0] 	              mipi_dp_data0_HS_OUT	       ,
       output	wire	[7:0] 	              mipi_dp_data1_HS_OUT	       ,
       output	wire	[7:0] 	              mipi_dp_data2_HS_OUT	       ,
       output	wire	[7:0] 	              mipi_dp_data3_HS_OUT	       ,
       output	wire	                     mipi_dp_data3_HS_OE		,
       output	wire	                     mipi_dp_data2_HS_OE		,
       output	wire	                     mipi_dp_data1_HS_OE		,
       output	wire	                     mipi_dp_data0_HS_OE		,

       output	wire	                     mipi_dp_clk_RST		,
       output	wire	                     mipi_dp_data0_RST		,
       output	wire	                     mipi_dp_data1_RST		,
       output	wire	                     mipi_dp_data2_RST		,
       output	wire	                     mipi_dp_data3_RST		,
       output	wire	                     mipi_dp_clk_LP_P_OE		,
       output	wire	                     mipi_dp_clk_LP_N_OE		,
       output	wire	                     mipi_dp_data3_LP_P_OE	,
       output	wire	                     mipi_dp_data3_LP_N_OE	,
       output	wire	                     mipi_dp_data2_LP_P_OE	,
       output	wire	                     mipi_dp_data2_LP_N_OE	,
       output	wire	                     mipi_dp_data1_LP_P_OE	,
       output	wire	                     mipi_dp_data1_LP_N_OE	,
       output	wire	                     mipi_dp_data0_LP_P_OE	,
       output	wire	                     mipi_dp_data0_LP_N_OE	,

       input  wire	                     mipi_dp_data0_LP_P_IN	,
       input  wire	                     mipi_dp_data0_LP_N_IN	,
       output	wire	                     LCD_RST_P			,
       output wire                        LCD_POWER			,

       // hdmi interface

    output tmds_tx_clk_TX_OE,
    output [9:0] tmds_tx_clk_TX_DATA,
    output tmds_tx_clk_TX_RST,
    output tmds_tx_data0_TX_OE,
    output [9:0] tmds_tx_data0_TX_DATA,
    output tmds_tx_data0_TX_RST,
    output tmds_tx_data1_TX_OE,
    output [9:0] tmds_tx_data1_TX_DATA,
    output tmds_tx_data1_TX_RST,
    output tmds_tx_data2_TX_OE,
    output [9:0] tmds_tx_data2_TX_DATA,
    output tmds_tx_data2_TX_RST,

    //==== 内部重配置(三镜像切换) —— 片内信号，不分配封装引脚 ====
    (* syn_peri_port = 0 *) output wire [1:0] cfg_CBSEL,
    (* syn_peri_port = 0 *) output wire       cfg_CONFIG,
    (* syn_peri_port = 0 *) output wire       cfg_ENA,
    (* syn_peri_port = 0 *) input  wire       cfg_ERROR
);

function integer log2;
	input	integer	val;
	integer	i;
	begin
		log2 = 0;
		for (i=0; 2**i<val; i=i+1)
			log2 = i+1;
	end
endfunction


//===============================================================================
//localparam
//===============================================================================
localparam WR_FIFO_DEPTH  = 1024;
localparam RD_FIFO_DEPTH  = 1024;
localparam HACT     = 1920;
localparam HFP      = 88;
localparam HSP      = 44;
localparam HBP      = 148;

localparam VACT     = 1080;
localparam VFP      = 4;
localparam VSP      = 5;
localparam VBP      = 36;
//===============================================================================
//signal
//===============================================================================
   
wire                              app_sr_active;
wire                              app_ref_ack;
wire                              app_zq_ack;
wire                              cal_done;

// Slave Interface Write Address Ports
wire [AXI_ID_WIDTH-1:0]           s_axi_awid;
wire [AXI_ADDR_WIDTH-1:0]         s_axi_awaddr;
wire [7:0]                        s_axi_awlen;
wire [2:0]                        s_axi_awsize;
wire [1:0]                        s_axi_awburst;
wire [0:0]                        s_axi_awlock;
wire [3:0]                        s_axi_awcache;
wire [2:0]                        s_axi_awprot;
wire                              s_axi_awvalid;
wire                              s_axi_awready;
// Slave Interface Write Data Ports
wire [AXI_DATA_WIDTH-1:0]         s_axi_wdata;
wire [(AXI_DATA_WIDTH/8)-1:0]     s_axi_wstrb;
wire                              s_axi_wlast;
wire                              s_axi_wvalid;
wire                              s_axi_wready;
// Slave Interface Write Response Ports
wire                              s_axi_bready;
wire [AXI_ID_WIDTH-1:0]           s_axi_bid;
wire [1:0]                        s_axi_bresp;
wire                              s_axi_bvalid;
// Slave Interface Read Address Ports
wire [AXI_ID_WIDTH-1:0]           s_axi_arid;
wire [AXI_ADDR_WIDTH-1:0]         s_axi_araddr;
wire [7:0]                        s_axi_arlen;
wire [2:0]                        s_axi_arsize;
wire [1:0]                        s_axi_arburst;
wire [0:0]                        s_axi_arlock;
wire [3:0]                        s_axi_arcache;
wire [2:0]                        s_axi_arprot;
wire                              s_axi_arvalid;
wire                              s_axi_arready;
// Slave Interface Read Data Ports
wire                              s_axi_rready;
wire [AXI_ID_WIDTH-1:0]           s_axi_rid;
wire [AXI_DATA_WIDTH-1:0]         s_axi_rdata;
wire [1:0]                        s_axi_rresp;
wire                              s_axi_rlast;
wire                              s_axi_rvalid;




////////////////////////////////////////////////////////////////
// System & Debugger
wire    w_arstn;
// ★ 关键：i_arstn 原来在 m6 里是“wire i_arstn = 1'b1;”，本顶层改 PLL 复位时
//   把这一行删掉了，但 CSI RX 的 reset_n / reset_byte_HS_n、LCD_POWER、
//   mipi_dp_*_RST 还在用它 ⇒ 变成了未驱动的隐式 wire（综合成 0/z），
//   MIPI RX 一直被按在复位里 ⇒ w_mipi_rx_vs/hs/de 全 0 ⇒ ddr_frame_len 恒 0。
wire    i_arstn = 1'b1;

//===================================================================================================
// 三镜像切换(image2 = deep_move) —— 长按 K0(GPIOL_07) 约 3s -> 回到 image0(m8_4)
// 说明：K0 在本镜像里有 1s "回实时"长按，所以这里用 3s 区分
//===================================================================================================
ru_image_switch #(
    .NEXT_IMAGE  (2'd0),          // 长按 -> image0 (CBSEL=00, m8_4)
    .SELF_IMAGE  (2'd2),          // 本镜像号 = 2
    .CLK_HZ      (100_000_000),   // core_clk = 100MHz
    .HOLD_MS     (3000)           // 3s 判定长按
) u_ru_image_switch (
    .clk         (core_clk),
    .rstn        (i_pll_locked),
    .key_pressed (~key_i[0]),     // K0(GPIOL_07) 低有效
    .cfg_ERROR   (cfg_ERROR),
    .cfg_CBSEL   (cfg_CBSEL),
    .cfg_CONFIG  (cfg_CONFIG),
    .cfg_ENA     (cfg_ENA),
    .cfg_error_n (),
    .busy        ()
);
wire    [3:0] rec_led;      //★ 提前声明：原文件在 383 行就用了，594 行才声明，部分工具直接报错
// wire	w_sysclk_mcu_arstn;
// wire	w_sysclk_mcu_arst;
wire	w_mipi_rx_pclk_arstn;
wire	w_mipi_rx_pclk_arst;

wire		       w_mipi_rx_vs;
wire		       w_mipi_rx_hs;
wire	       w_mipi_rx_de;
wire	[63:0]			w_mipi_rx_data	;

wire					io_systemReset;



//===================================================================================================
//reset module
//===================================================================================================

assign w_arstn  		       = i_pll_locked & pll_locked & user_pll_locked;
// ★四个 PLL 的复位改为"纯上电复位"：不再挂按键，RSTN 常置无效，
//   PLL 依靠上电自锁；逻辑复位仍由 w_arstn(所有 PLL 锁定) 产生。
assign pll_inst1_RSTN  		= 1'b1;
assign USER_PLL_RSTN      	= 1'b1;
assign mipi_dsi_tx_pll_RSTN = 1'b1;
assign DDR3_PLL_RSTN 		= 1'b1;

// ★ 像素域复位：CSI RX 的 clk_pixel 改用 core_clk 后，reset_pixel_n 也必须在
//   core_clk 域同步释放，避免异步复位跨域。
reg  [2:0] core_rst_sync = 3'd0;
always @(posedge core_clk or negedge w_arstn)
    if(!w_arstn) core_rst_sync <= 3'd0;
    else         core_rst_sync <= {core_rst_sync[1:0], 1'b1};
wire core_rst_n = core_rst_sync[2];

reset_ctrl
#(
	.NUM_RST		(2),
	.CYCLE			(1),
	.IN_RST_ACTIVE	(4'b00),
	.OUT_RST_ACTIVE	(4'b10)
)
inst_reset_ctrl
(
	.i_arst		({2{w_arstn}}),//({{4{i_pll_locked}},                  {2{i_arstn}}}),
	.i_clk			({2{i_mipi_rx_pclk}}),
	.o_srst		({w_mipi_rx_pclk_arst, w_mipi_rx_pclk_arstn})
);



reg [25:0] cnt = 'd0;
always @( posedge core_clk)
begin 
       cnt <= cnt + 1'b1;
end
// LED 分配统一挪到文件后部“小灯 Debug 链”，那里所有被观测信号都已声明

//========================================================================================================
//MIPI RX
//========================================================================================================
wire i_mipi_clk ;
assign i_mipi_clk = core_clk;

		assign	cam_d0_RST		= 1'b0;
		assign	cam_d1_RST		= 1'b0;
		assign  cam_d2_RST = 1'b0;
    assign  cam_d3_RST = 1'b0;
	
wire [15:0] mipi_debug_out;
		

		csi_rx_controller inst_efx_csi2_rx
		(
              .reset_n			(i_arstn),
              .clk				(i_mipi_clk),
              .reset_byte_HS_n	(i_arstn),
              .clk_byte_HS		  (i_cam_ck_CLKOUT),
              .reset_pixel_n		(core_rst_n),
              .clk_pixel			  (core_clk),
              
              .Rx_LP_CLK_P		  (i_cam_ck_LP_P_IN),
              .Rx_LP_CLK_N		  (i_cam_ck_LP_N_IN),
              .Rx_HS_enable_C		(o_cam_ck_HS_ENA),
              .LVDS_termen_C		(o_cam_ck_HS_TERM),
              
              .Rx_LP_D_P			({cam_d3_LP_P_IN, cam_d2_LP_P_IN, cam_d1_LP_P_IN, cam_d0_LP_P_IN}),//(r_mipi_rx_data_LP_P_IN_2P),
              .Rx_LP_D_N			({cam_d3_LP_N_IN, cam_d2_LP_N_IN, cam_d1_LP_N_IN, cam_d0_LP_N_IN}),//(r_mipi_rx_data_LP_N_IN_2P),
              .Rx_HS_D_0			(cam_d0_HS_IN),//(r_mipi_rx_data_HS_IN_2P[0*8+:8]),
              .Rx_HS_D_1			(cam_d1_HS_IN),//(r_mipi_rx_data_HS_IN_2P[1*8+:8]),
              .Rx_HS_D_2			(cam_d2_HS_IN),
              .Rx_HS_D_3			(cam_d3_HS_IN),
              .Rx_HS_D_4			(),
              .Rx_HS_D_5			(),
              .Rx_HS_D_6			(),
              .Rx_HS_D_7			(),
              .Rx_HS_enable_D		({cam_d3_HS_ENA    ,cam_d2_HS_ENA    ,cam_d1_HS_ENA    ,cam_d0_HS_ENA    }),//( w_cam_d_HS_ENA),
              .LVDS_termen_D		({cam_d3_HS_TERM   ,cam_d2_HS_TERM   ,cam_d1_HS_TERM   ,cam_d0_HS_TERM   }),
              .fifo_rd_enable		({cam_d3_FIFO_RD   ,cam_d2_FIFO_RD   ,cam_d1_FIFO_RD   ,cam_d0_FIFO_RD   }),
              .fifo_rd_empty		({cam_d3_FIFO_EMPTY,cam_d2_FIFO_EMPTY,cam_d1_FIFO_EMPTY,cam_d0_FIFO_EMPTY}),
              .DLY_enable_D		       (),
              .DLY_inc_D			(),
              .u_dly_enable_D		(),
              .u_dly_inc_D		       (),
              
              .axi_clk			(1'b0),
              .axi_reset_n		       (1'b0),
              .axi_awaddr			(6'b0),
              .axi_awvalid		       (1'b0),
              .axi_awready		       (),
              .axi_wdata			(32'b0),
              .axi_wvalid			(1'b0),
              .axi_wready			(),
              
              .axi_bvalid			(),
              .axi_bready			(1'b0),
              .axi_araddr			(6'b0),
              .axi_arvalid		       (1'b0),
              .axi_arready		       (),
              .axi_rdata			(),
              .axi_rvalid			(),
              .axi_rready			(1'b1),
              
              .hsync_vc0			(w_mipi_rx_hs),
              .hsync_vc1			(),
              .hsync_vc2			(),
              .hsync_vc3			(),
              .vsync_vc0			(w_mipi_rx_vs),
              .vsync_vc1			(),
              .vsync_vc2			(),
              .vsync_vc3			(),
              .vc				(),
              .word_count			(),
              .shortpkt_data_field        (),
              .datatype			(),
              .pixel_per_clk		(),
              .pixel_data			(w_mipi_rx_data),
              .pixel_data_valid	       (w_mipi_rx_de),
              .irq				(),
              .mipi_debug_out(mipi_debug_out)
		);

wire		      w1_mipi_rx_vs;
wire		      w1_mipi_rx_hs;
wire	        w1_mipi_rx_de;
wire	[39:0]	w1_mipi_rx_data	;
sensor_clipper  sensor_clipper_inst (
    .clk(core_clk),
    .i_vs(w_mipi_rx_vs),
    .i_hs(w_mipi_rx_hs),
    .i_de(w_mipi_rx_de),
    .i_dat({w_mipi_rx_data[9:2],w_mipi_rx_data[19:12],w_mipi_rx_data[29:22],w_mipi_rx_data[39:32]}),//(w_mipi_rx_data[39:0]),

    .o_hs(w1_mipi_rx_hs),
    .o_vs(w1_mipi_rx_vs),
    .o_de(w1_mipi_rx_de),
    .o_dat(w1_mipi_rx_data)
   
  );

  vid_info_det # (
    .CLK_FREQ(100000000)
  )
  vid_info_det_inst (
    .clk(core_clk),
    .rst_n(1'b1),
    .i_vs(w1_mipi_rx_vs),
    .i_hs(w1_mipi_rx_hs),
    .i_de(w1_mipi_rx_de),
    .frame_cnt_o(frame_cnt_o),
    .frame_rate(frame_rate),
    .frame_stable(frame_stable),
    .neg_vs_sync(),
    .neg_hs_sync(),
    .o_h_act(),
    .h_active_error(),
    .o_v_act(),
    .v_active_error(),
    .o_v_total(),
    .v_total_error(),
    .o_h_total(),
    .h_total_error(),
    .h_sync_error()
  );

wire mdebug_pixel_fifo_full     = mipi_debug_out[0] ;
wire mdebug_pixel_fifo_empty    = mipi_debug_out[1] ;
wire mdebug_crc_error           = mipi_debug_out[2] ;
wire mdebug_ecc_1bit_error      = mipi_debug_out[3] ;
wire mdebug_ecc_2bit_error      = mipi_debug_out[4] ;
wire mdebug_undersize_pkt_error = mipi_debug_out[5] ;
wire mdebug_line_vc0_error      = mipi_debug_out[6] ;
wire mdebug_frame_vc0_error    = mipi_debug_out[10];   
wire mdebug_receive_error      = mipi_debug_out[14];


//========================================================================================================
//
//========================================================================================================
		

//*************** imx219 config********************/
// mipi_config_imx219_top u_config_imx219(
// 										.i_sys_clk(CLK_5M)    	,    /////48M 
// 										.sys_rstn(vid_rst_n )    ,
// 										.o_sen_rst_n(o_cam_rstn)  	,
										
										// .o_iic_sda_OE(io_cam_sda_OE) ,
										// .i_iic_sda(io_cam_sda_IN)   	,
										// .o_iic_sda(io_cam_sda_OUT)   	,
										// .o_iic_scl(io_cam_scl)    	
										// ); 	

wire scl_padoen_o;
wire sda_padoen_o;

// ★ I2C 时钟改用 core_clk 分频（100MHz/20 = 5MHz），不再依赖 PLL4 的 CLK_5M。
//   PLL4/CLK_5M 若没起来，I2C 就永远不跑，sensor 永远不会开流 —— 这是本次上板
//   D2/D3 全灭的一个重点怀疑对象。I2C 是慢速外设，fabric 分频时钟完全够用。
reg  [3:0] i2c_div = 4'd0;
reg        i2c_clk_r = 1'b0;
always @(posedge core_clk)
begin
    if(i2c_div == 4'd9) begin
        i2c_div   <= 4'd0;
        i2c_clk_r <= ~i2c_clk_r;
    end else begin
        i2c_div   <= i2c_div + 1'b1;
    end
end
wire i2c_clk = i2c_clk_r;

reg [12:0] i2c_rst_cnt = '0;

always @( posedge i2c_clk or negedge w_arstn )
begin
    if( !w_arstn )
       i2c_rst_cnt <= 'd0;
    else 
       i2c_rst_cnt <= i2c_rst_cnt[12] ? i2c_rst_cnt : i2c_rst_cnt + 1'b1;
end
wire i2c_rst_n = i2c_rst_cnt[12];

i2c_master_ctrl_top u2_i2c_master_ctrl_top(
  /*i*/.clk			(i2c_clk		),
  /*i*/.rst_n			(i2c_rst_n		),
  /*i*/.scl_pad_i     (io_cam_scl_IN),//(1'b1),
  /*o*/.scl_pad_o     (io_cam_scl_OUT),
  /*o*/.scl_padoen_o  (scl_padoen_o),
  /*i*/.sda_pad_i     (io_cam_sda_IN),
  /*o*/.sda_pad_o     (io_cam_sda_OUT),
  /*o*/.sda_padoen_o  (sda_padoen_o)
  
  );
assign o_cam_rst_p = ~w_arstn;
assign io_cam_scl_OE = ~scl_padoen_o;
assign io_cam_sda_OE = ~sda_padoen_o;

//=====================================================================================
//frame buffer
//=====================================================================================

wire [7:0]    ch0_cvo_dout;
wire ch0_cvo_vs;
wire ch0_cvo_hs;
wire ch0_cvo_de;

wire  [16-1:0] m_axis_tdata;
wire           m_axis_tvalid;
wire           m_axis_tready;
wire           m_axis_tlast;
wire           m_axis_tuser;
wire  fifo_rd_period;

//=====================================================================================
// 录像/回放 槽位控制 + OSD
//=====================================================================================
wire            wr_frame_done;      // 一帧写完(帧缓存给出，core_clk 域)
wire            rd_frame_done;      // 一帧读完(帧缓存给出，core_clk 域)
wire   [31:0]   rec_wr_base;        // rec_play_ctrl 指定的下一写帧基址
wire   [31:0]   rec_rd_base;        // rec_play_ctrl 指定的下一显示帧基址
wire   [31:0]   frame_len_dbg;      // frame_buffer 实测一帧 beat 数(小灯 D6 用)

wire   [3:0]    osd_state;
wire   [15:0]   osd_num;
wire   [2:0]    osd_speed;
wire   [7:0]    osd_rem;
wire            osd_tog;

wire   [7:0]    osd_r, osd_g, osd_b;
wire            osd_de, osd_hs, osd_vs;

// frame buffer (1920x1080@60, 1px/拍)
  frame_buffer #(
.I_VID_WIDTH         (32),
.O_VID_WIDTH         (8),
.START_ADDR          (32'h00000        ),
.AXI_DATA_WIDTH      ( AXI_DATA_WIDTH	),
.AXI_ADDR_WIDTH      ( AXI_ADDR_WIDTH	),
.WR_FIFO_DEPTH	      ( 1024		),    
.RD_FIFO_DEPTH 	      ( 1024 	),
.BURST_LEN  	        (127),
.FB_NUM	              (3),
.MAX_VID_WIDTH	      (1920) ,    // 1px/拍：bank 内部步长按 1920 像素/行；ext_sel=1 时只用外部基址
.MAX_VID_HIGHT	      (1080),     // 1080 行
.O_FRAME_WIDTH      (1920),       // = H_VALID/PIXEL_NUM = 1920/1 = 1920 字/行
.O_FRAME_HEIGHT     (1080)        // 每帧 1920x1080 字 = 一整帧

)checker0(
       .axi_clk		(core_clk 	        ),
       .rst_n			(vid_rst_n   ),

/*i*/.i_clk			(core_clk             ),
/*i*/.i_vs			(w1_mipi_rx_vs	),
/*i*/.i_de			(w1_mipi_rx_de              ),
/*i*/.vin 			(w1_mipi_rx_data),//({w1_mipi_rx_data[39:32],w1_mipi_rx_data[29:22],w_mipi_rx_data[19:12],w_mipi_rx_data[9:2]}	),
                     
/*i*/.o_clk			(hdmi_tx_slow_clk),// 显示像素时钟 148.5MHz（1080p60 1px/拍）
/*i*/.fifo_rd_period(fifo_rd_period),//(fifo_rd_period  ),

    .ext_sel            (1'b1              ),// ★外部槽位选择使能(rec_play_ctrl 接管读写基址)
    .ext_wr_base        (rec_wr_base       ),
    .ext_rd_base        (rec_rd_base       ),
    .o_wr_frame_done    (wr_frame_done     ),
    .o_rd_frame_done    (rd_frame_done     ),
    .o_frame_len        (frame_len_dbg     ),

    .m_axis_tdata  (m_axis_tdata),
    .m_axis_tvalid (m_axis_tvalid),
    .m_axis_tready (m_axis_tready),
    .m_axis_tuser  (m_axis_tuser),
    .m_axis_tlast  (m_axis_tlast),
	

       .awid			(s_axi_awid	),      
       .awaddr		(s_axi_awaddr	),
       .awlen			(s_axi_awlen	),
       .awsize		(s_axi_awsize	),
       .awburst		(s_axi_awburst),
       .awprot    (s_axi_awprot ),
       .awcache   (s_axi_awcache),
       .awlock		(s_axi_awlock	),
       .awvalid		(s_axi_awvalid),
       .awready		(s_axi_awready),

       .arid			(s_axi_arid	  ),
       .araddr		(s_axi_araddr	),
       .arlen			(s_axi_arlen	),
       .arsize		(s_axi_arsize	),
       .arburst 	(s_axi_arburst),

       .arprot    (s_axi_arprot ),
       .arcache   (s_axi_arcache),
       .arlock 		(s_axi_arlock	),
       .arvalid		(s_axi_arvalid),
       .arready		(s_axi_arready),

       .wdata			(s_axi_wdata	),
       .wstrb			(s_axi_wstrb	),
       .wlast			(s_axi_wlast	),
       .wvalid		(s_axi_wvalid	),
       .wready		(s_axi_wready	),


       .rid			  (s_axi_rid	),
       .rdata			(s_axi_rdata	),
       .rlast			(s_axi_rlast	),
       .rvalid 		(s_axi_rvalid	),
       .rready		(s_axi_rready	),
       .rresp			(s_axi_rresp	),

       .bid			  (s_axi_bid	),
       .bvalid		(s_axi_bvalid	),
       .bready	  (s_axi_bready	)
);

		    
		    
cvo_axi # (
    .SYMBOL_WIDTH(8),
    .SYMBOL_NUM(1),
    .PIXEL_NUM(1),                 // 1 像素/拍 (DATA_WIDTH = 8)，1080p60 由 148.5MHz 提供
    .HSYNC_POL(1),                 // ★cvo 输出用【正极性】：debayer(rgb_gain/line_buffer/raw_to_rgb)
    .VSYNC_POL(1),                 //   都靠 vs 高电平做帧/行复位与行bank轮转；负极性会让行 bank
                                   //   永远停在 bank0 ⇒ mid/up 从没写入 ⇒ 去马赛克全 0 ⇒ 黑屏
                                   //   负极性在送入 dvi_encoder 前由 hdmi_tx_hs/vs 取反得到
    .FIFO_DEPTH(1024),
    .FIFO_ALMOST_FULL(1000),
    .MAX_H_VALID(1920),
    .MAX_V_VALID(1080)
  )
  cvo_axi_inst (
    .o_clk          (hdmi_tx_slow_clk),
    .rst_n          (vid_rst_n      ),
    .fifo_rd_period (fifo_rd_period ),
    .s_axi_clk      (hdmi_tx_slow_clk),
    .s_axis_tdata   (m_axis_tdata   ),
    .s_axis_tvalid  (m_axis_tvalid  ),
    .s_axis_tready  (m_axis_tready  ),
    .s_axis_tlast   (m_axis_tlast   ),
    .s_axis_tuser   (m_axis_tuser   ),
    .H_FRONT_PORCH  (HFP            ),
    .H_SYNC         (HSP            ),
    .H_VALID        (HACT           ),
    .H_BACK_PORCH   (HBP            ),
    .V_FRONT_PORCH  (VFP            ),
    .V_SYNC         (VSP            ),
    .V_VALID        (VACT           ),
    .V_BACK_PORCH   (VBP            ),
     .vout          (ch0_cvo_dout  ),
    .o_hs           (ch0_cvo_hs         ),
    .o_vs           (ch0_cvo_vs         ),
    .o_de           (ch0_cvo_de         )
  );		       


ddr3_top                 u_ddr3_top
(

.axi_clk                (core_clk            ),
.core_clk               (core_clk            ),
.sdram_clk              (sdram_clk           ),  
.rx_cal_clk             (rx_cal_clk          ),
.tx_cal_clk             (tx_cal_clk          ),
.tx_cal_clk_90edge      (tx_cal_clk_90edge   ),
.rstn                   (w_arstn             ),      
.pll_shift              (pll_shift           ),
.pll_shift_sel          (pll_shift_sel       ),
.pll_shift_ena          (pll_shift_ena       ),       
///////////////DDR BUS
.ddr_ck_hi              (ddr_ck_hi           ),
.ddr_ck_lo              (ddr_ck_lo           ),
.ddr_cke                (ddr_cke             ),    
.ddr_reset_n            (ddr_reset_n         ),
.ddr_cs_n               (ddr_cs_n            ),
.ddr_ras_n              (ddr_ras_n           ),
.ddr_cas_n              (ddr_cas_n           ),
.ddr_we_n               (ddr_we_n            ),     
.ddr_addr               (ddr_addr            ),
.ddr_ba                 (ddr_ba              ),

.ddr_dqs_oe             (ddr_dqs_oe          ),
.ddr_dqs_oe_n           (ddr_dqs_oe_n        ),
.ddr_dq_oe              (ddr_dq_oe           ),
.ddr_dqs_in_hi          (ddr_dqs_in_hi       ),
.ddr_dqs_in_lo          (ddr_dqs_in_lo       ),
.ddr_dq_in_hi           (ddr_dq_in_hi        ),
.ddr_dq_in_lo           (ddr_dq_in_lo        ),

.ddr_dqs_out_hi         (ddr_dqs_out_hi      ),
.ddr_dqs_out_lo         (ddr_dqs_out_lo      ),
.ddr_dq_out_hi          (ddr_dq_out_hi       ),
.ddr_dq_out_lo          (ddr_dq_out_lo       ),

.ddr_dm_hi              (ddr_dm_hi           ),
.ddr_dm_lo              (ddr_dm_lo           ),
.ddr_odt                (ddr_odt             ),

// Application interface ports
.app_sr_req                     (1'b0),
.app_ref_req                    (1'b0),
.app_zq_req                     (1'b0),
.app_sr_active                  (app_sr_active),
.app_ref_ack                    (app_ref_ack),
.app_zq_ack                     (app_zq_ack),

// Slave Interface Write Address Ports
.s_axi_awid                     (s_axi_awid        ),
.s_axi_awaddr                   (s_axi_awaddr      ),
.s_axi_awlen                    (s_axi_awlen       ),
.s_axi_awsize                   (s_axi_awsize      ),
.s_axi_awburst                  (s_axi_awburst     ),
.s_axi_awlock                   (s_axi_awlock      ),
.s_axi_awcache                  (s_axi_awcache     ),
.s_axi_awprot                   (s_axi_awprot      ),
.s_axi_awqos                    (4'h0              ),
.s_axi_awvalid                  (s_axi_awvalid     ),
.s_axi_awready                  (s_axi_awready     ),
// Slave Interface Write Data Ports
.s_axi_wdata                    (s_axi_wdata       ),
.s_axi_wstrb                    (s_axi_wstrb       ),
.s_axi_wlast                    (s_axi_wlast       ),
.s_axi_wvalid                   (s_axi_wvalid      ),
.s_axi_wready                   (s_axi_wready      ),
// Slave Interface Write Response Ports
.s_axi_bid                      (s_axi_bid         ),
.s_axi_bresp                    (s_axi_bresp       ),
.s_axi_bvalid                   (s_axi_bvalid      ),
.s_axi_bready                   (s_axi_bready      ),
// Slave Interface Read Address Ports
.s_axi_arid                     (s_axi_arid        ),
.s_axi_araddr                   (s_axi_araddr      ),
.s_axi_arlen                    (s_axi_arlen       ),
.s_axi_arsize                   (s_axi_arsize      ),
.s_axi_arburst                  (s_axi_arburst     ),
.s_axi_arlock                   (s_axi_arlock      ),
.s_axi_arcache                  (s_axi_arcache     ),
.s_axi_arprot                   (s_axi_arprot      ),
.s_axi_arqos                    (4'h0              ),
.s_axi_arvalid                  (s_axi_arvalid     ),
.s_axi_arready                  (s_axi_arready     ),
// Slave Interface Read Data Ports
.s_axi_rid                      (s_axi_rid         ),
.s_axi_rdata                    (s_axi_rdata       ),
.s_axi_rresp                    (s_axi_rresp       ),
.s_axi_rlast                    (s_axi_rlast       ),
.s_axi_rvalid                   (s_axi_rvalid      ),
.s_axi_rready                   (s_axi_rready      ),
//DEBUG       
.wrlvl_dq_check                 (wrlvl_dq_check    ) ,
.rd_level_dqs_check             (rd_level_dqs_check) ,
.init_cur_state                 (init_cur_state    ) ,
.idelay_ld                      (idelay_ld         ) ,
.mpr_rdlvl_dly                  (mpr_rdlvl_dly     ) ,
.cal_done                       (cal_done          ) 
);

//***************************************************************************
// debayer
//***************************************************************************


wire        rgb_vs;
wire        rgb_hs;
wire        rgb_de;
wire        rgb_valid;
wire [7:0]  rgb_r;
wire [7:0]  rgb_g;
wire [7:0]  rgb_b;
wire [15:0] r_gain;
wire [15:0] g_gain;
wire [15:0] b_gain;



debayer_top_2to1 #(.CFA_RB_SWAP(1'b0)) debayer_top
(
	.in_pclk		  (hdmi_tx_slow_clk),// 显示像素时钟 148.5MHz
	.in_rstn		  (vid_rst_n	),
	
	.raw_vs_i		  (ch0_cvo_vs		      ),
	.raw_hs_i		  (ch0_cvo_hs		      ),
	.raw_de_i		  (ch0_cvo_de		      ),
	.raw_valid_i	(ch0_cvo_de	        ),
	.raw_data_i		(ch0_cvo_dout     ),// 1px/拍, 直接给出（无需字节交换）
	.r_gain       (16'd255 ),   // 和 shibei 一样，debayer 前不做事先增益
  .g_gain       (16'd255 ),
  .b_gain       (16'd255 ),
	.rgb_vs_o		  (rgb_vs         ),
	.rgb_hs_o		  (rgb_hs         ),
	.rgb_de_o		  (rgb_de         ),
	.rgb_valid_o	(rgb_valid      ),
	.rgb_rout			(rgb_r          ),
	.rgb_gout			(rgb_g          ),
	.rgb_bout			(rgb_b          )
);
localparam [9:0] CAM_GAIN_Q8 = 10'd512;   // 2.0x，和 shibei 一致
localparam [9:0] WB_G_Q8     = 10'd180;   // 0.70x，进一步去绿

function [7:0] scale_q8;
    input [7:0] v;
    input [9:0] g;
    reg [17:0] t;
    begin
        t = v * g;
        t = t >> 8;
        if (t > 18'd255)
            scale_q8 = 8'hFF;
        else
            scale_q8 = t[7:0];
    end
endfunction

wire [7:0] rgb_r_b  = scale_q8(rgb_r, CAM_GAIN_Q8);
wire [7:0] rgb_g_b  = scale_q8(rgb_g, CAM_GAIN_Q8);
wire [7:0] rgb_b_b  = scale_q8(rgb_b, CAM_GAIN_Q8);
wire [7:0] rgb_g_wb = scale_q8(rgb_g_b, WB_G_Q8);

//=============================================================================
// 右边缘 8 列钳位：debayer 3x3 在行尾的右邻会取到下一行/blanking，
// 最右 8 列会呈现一条彩色竖带。这里对最后 8 个有效像素保持前一像素颜色，
// 用图像自身的边缘色盖住这条带（不改 DDR/录像，只改显示）。
// 1080p：行有效 1920 像素，列计数需 11bit。
//=============================================================================
localparam integer EDGE_CLAMP = 8;
reg [10:0] disp_x = 11'd0;
reg [7:0] hold_r = 8'd0, hold_g = 8'd0, hold_b = 8'd0;
wire edge_clamp = rgb_de && (disp_x >= (1920 - EDGE_CLAMP));

always @(posedge hdmi_tx_slow_clk or negedge vid_rst_n)
begin
    if(!vid_rst_n) begin
        disp_x <= 11'd0;
        hold_r <= 8'd0; hold_g <= 8'd0; hold_b <= 8'd0;
    end else if(rgb_de) begin
        disp_x <= (disp_x == 11'd1919) ? 11'd0 : (disp_x + 1'b1);
        if(disp_x < (1920 - EDGE_CLAMP)) begin
            hold_r <= rgb_r_b;
            hold_g <= rgb_g_wb;
            hold_b <= rgb_b_b;
        end
    end else begin
        disp_x <= 11'd0;
    end
end

wire [7:0] disp_r = edge_clamp ? hold_r : rgb_r_b;
wire [7:0] disp_g = edge_clamp ? hold_g : rgb_g_wb;
wire [7:0] disp_b = edge_clamp ? hold_b : rgb_b_b;


localparam        TRACK_EN_LEVEL = 1'b1;      // ★上电默认：1=追踪开，0=关机(纯直通)
wire              track_en;                   // ★追踪总开关(高=开)，KEY2 长按翻转

wire [7:0] trk_r;
wire [7:0] trk_g;
wire [7:0] trk_b;
wire       trk_de, trk_hs, trk_vs;
wire       trk_motion;                        // 1=当前帧正在显示追踪框(可接 LED)
wire [9:0] trk_blkcnt;                        // ★上一帧运动块数：调试时最有用的一根线
                                              //   =0 说明这一帧根本没检测到运动(要调 THRESH)
                                              //   很大(几千)说明整屏都在动(换帧/曝光跳变)

motion_track #(
    .HACT        (1920),        // 行有效像素
    .VACT        (1080),        // 场有效行数
    .ADDR_W      (15),          // 帧存 32768 深 x 8bit(实用 240x135=32400)
    .THRESH      (8),           // ★块均值差阈值：8x8 块均值只要变化 >8/255 就算运动
                                //   (原 24 太钝：慢走目标的运动月牙只覆盖块内两三成，
                                //    再乘室内低对比度，块均值常只变 10~15，全被丢掉)
    .BW          (4),           // 框线宽 4 像素
    .HOLD_FRAMES (30),          // 无运动时框保持 30 帧(60Hz 下 0.5s，防重复帧闪烁)
    .GATE_PLAY   (0),           // ★0=实时/录像/回放/倒放全都显示(演示从开机就能看到)
                                //   1=只在回放/倒放显示
    .REJECT_BIG  (1),           // 1=整屏突变(换帧/跳帧/环回)不算目标
    //---- 以下 4 个是"框得准、不跳变"的关键(算法迭代 v2) ----
    .DENOISE     (1),           // 3x3 计数去噪：孤立单块(噪声)直接去掉
    .HIST_TH     (3),           // 行/列投影门限：一列/一行至少有 3 个运动块才算数
                                //   → 零星噪点票数是 1，进不来；真实目标远远够
    .SLEW        (3),           // 每条边每帧最多移动 3 个块(24px)，框不跳、不忽大忽小
    .MIN_BLOCKS  (6),           // 一帧里少于 6 个运动块(去噪后)当噪点，不出框
    .MIN_BOX_W   (32),          // 框最小宽度(像素)：防止只动一块时画出 8x8 的小点儿
    .MIN_BOX_H   (32)           // 框最小高度(像素)
    ) u_motion_track (
    .clk        (hdmi_tx_slow_clk),
    .rst_n      (vid_rst_n       ),
    .i_r        (disp_r          ),
    .i_g        (disp_g          ),
    .i_b        (disp_b          ),
    .i_de       (rgb_de          ),
    .i_hs       (rgb_hs          ),
    .i_vs       (rgb_vs          ),
    .en         (track_en        ),
    .play_state (osd_state       ),
    .play_tog   (osd_tog         ),
    .o_r        (trk_r           ),
    .o_g        (trk_g           ),
    .o_b        (trk_b           ),
    .o_de       (trk_de          ),
    .o_hs       (trk_hs          ),
    .o_vs       (trk_vs          ),
    .o_motion   (trk_motion      ),
    .o_blkcnt   (trk_blkcnt      )
);

// ★1px/拍：debayer 输出直接进 gamma/encoder（同一 148.5MHz 时钟域，无 2:1 拆包）
// ★OSD 叠加：插在 debayer 与 gamma/encoder 之间，只做像素替换 + 三拍对齐延迟，
//   不改变任何行/场时序参数（hs/vs/de 原样延迟）。
osd_mgr #(
    .HACT       (1920),
    .VACT       (1080),
    .CS         (32),          // 字格 32x32(中文) / 16x32(ASCII)
    .X0         (32),          // OSD 左上角起点
    .Y0         (48),
    .Y1         (96),
    .LINE_CELLS (14),
    .N_ASCII    (14),
    .CLK_FREQ   (148500000)
    ) u_osd_mgr (
    .clk         (hdmi_tx_slow_clk),
    .rst_n       (vid_rst_n       ),
    .i_r         (trk_r           ),
    .i_g         (trk_g           ),
    .i_b         (trk_b           ),
    .i_de        (trk_de          ),
    .i_hs        (trk_hs          ),
    .i_vs        (trk_vs          ),
    .osd_state   (osd_state       ),
    .osd_num     (osd_num         ),
    .osd_speed   (osd_speed       ),
    .osd_rem     (osd_rem         ),
    .osd_tog     (osd_tog         ),
    .o_r         (osd_r           ),
    .o_g         (osd_g           ),
    .o_b         (osd_b           ),
    .o_de        (osd_de          ),
    .o_hs        (osd_hs          ),
    .o_vs        (osd_vs          )
);

wire [7:0] hdmi_tx_rdata = osd_r;
wire [7:0] hdmi_tx_gdata = osd_g;
wire [7:0] hdmi_tx_bdata = osd_b;
wire       hdmi_tx_vs    = ~osd_vs;   // ★喂给 encoder 前取反：1080p60 需要【负极性】同步
wire       hdmi_tx_hs    = ~osd_hs;   //   （debayer/OSD 内部仍用正极性的 vs/hs）
wire       hdmi_tx_de    = osd_de;

//=====================================================================================
// 录像/回放控制(槽位基址 + OSD 数据)
//=====================================================================================
rec_play_ctrl #(
    .FRAME_BYTES     (2073600     ),   // 1920*1080*1B = 0x1FA400
    .RING_SLOTS      (120         ),   // 256MiB DDR3 扣 7 个乒乓/快照槽后的安全值；30fps 下约 4.0s
    .CLK_FREQ        (100000000   ),   // core_clk 100MHz
    .KEY_ACTIVE_LOW  (1'b1        ),
    .FRZ_HOLD_MS     (150         ),   // 帧冻结画面保持 0.15s 后自动回原状态
    .TRACK_DEFAULT   (TRACK_EN_LEVEL)  // ★上电时追踪默认开/关
) u_rec_play_ctrl (
    .sys_clk        (core_clk        ),
    .sys_rst_n      (vid_rst_n       ),
    .init_end       (w_arstn & cal_done),
    .key_in         (key_i           ),
    .wr_frame_done  (wr_frame_done   ),
    .rd_frame_done  (rd_frame_done   ),
    .wr_base        (rec_wr_base     ),
    .rd_base        (rec_rd_base     ),
    .osd_state      (osd_state       ),
    .osd_num        (osd_num         ),
    .osd_speed      (osd_speed       ),
    .osd_rem        (osd_rem         ),
    .osd_tog        (osd_tog         ),
    .track_on       (track_en        ),
    .led            (rec_led         )
);

reg  [7:0] dbg_wr_done_cnt;
reg  [7:0] dbg_rd_done_cnt;
reg  [3:0] dbg_key_r0, dbg_key_r1;

always @(posedge core_clk or negedge vid_rst_n)
    if(!vid_rst_n)                 dbg_wr_done_cnt <= 8'd0;
    else if(wr_frame_done == 1'b1) dbg_wr_done_cnt <= dbg_wr_done_cnt + 1'b1;

always @(posedge core_clk or negedge vid_rst_n)
    if(!vid_rst_n)                 dbg_rd_done_cnt <= 8'd0;
    else if(rd_frame_done == 1'b1) dbg_rd_done_cnt <= dbg_rd_done_cnt + 1'b1;

always @(posedge core_clk or negedge vid_rst_n)
    if(!vid_rst_n) begin
        dbg_key_r0 <= 4'hF;
        dbg_key_r1 <= 4'hF;
    end else begin
        dbg_key_r0 <= key_i;
        dbg_key_r1 <= dbg_key_r0;
    end

// ★pclk 域心跳：i_mipi_rx_pclk 若根本没有时钟，该计数器恒为 0(上电值为 0，无复位)
//   触发 dbg_pclk_cnt != 0 触发不到 ⇒ CSI 像素时钟没在跑
reg  [7:0] dbg_pclk_cnt;
always @(posedge i_mipi_rx_pclk)
    dbg_pclk_cnt <= dbg_pclk_cnt + 1'b1;
//==============================================================================
// MIPI DSI
//==============================================================================
// signal 

reg		[25:0]	r_rst_cnt;

wire	[31:0]	w_axi_rdata;
wire			w_axi_awready;
wire			w_axi_wready;
wire			w_axi_arready;
wire			w_axi_rvalid;
wire			w_axi_bvalid;

wire	[6:0]	w_axi_awaddr;
wire			w_axi_awvalid;
wire	[31:0]	w_axi_wdata;
wire			w_axi_wvalid;
wire			w_axi_bready;
wire	[6:0]	w_axi_araddr;
wire			w_axi_arvalid;
wire			w_axi_rready;

wire			w_confdone;
assign w_confdone = 1'b1;

assign  LCD_POWER 			= i_arstn;
assign	LCD_RST_P	      = ~w_arstn;//~r_rst_cnt[23]; LCD复位先释放，然后再释放MIPI 的复位
assign	mipi_dp_clk_RST		= ~i_arstn;
assign	mipi_dp_data0_RST	= ~i_arstn;
assign	mipi_dp_data1_RST	= ~i_arstn;
assign	mipi_dp_data2_RST	= ~i_arstn;
assign	mipi_dp_data3_RST	= ~i_arstn;
////////////////////////////////////////////////////////////////
always@(posedge i_mipi_clk or  negedge w_arstn )
begin
  if ( !w_arstn ) begin
    r_rst_cnt	<= 'd0;
  end else 		
    r_rst_cnt	<= r_rst_cnt[25] ? r_rst_cnt :r_rst_cnt + 1'b1;
end

wire axi_rst_n = r_rst_cnt[25];

reg [26:0] dly_cnt = 'd0;

always @( posedge vid_clk_dvi2 or negedge w_arstn )
begin
  if( !w_arstn )
    dly_cnt <= 'd0;
  else if( w_confdone )
    dly_cnt <= dly_cnt[24] ? dly_cnt :(dly_cnt + 1'b1);
  else 
    dly_cnt <= 'd0;
end 

assign vid_rst_n = dly_cnt[24];




wire hs;
wire vs;
wire de;
  
  // color_bar_rgb #(
  // .HS_POLORY 		(1'b1		),
  // .VS_POLORY 		(1'b1		),
  // .H_FRONT_PORCH 	(HFP		),///2
  // .H_SYNC 		(HSP		),//
  // .H_VALID 		(MAX_HRES	),//
  // .H_BACK_PORCH 	(HBP		),//
  // .V_FRONT_PORCH 	(VFP		),
  // .V_SYNC 		(VSP		),
  // .V_VALID 		(MAX_VRES	),
  // .V_BACK_PORCH 	(VBP		),
  // .TEST_MODE 		(2'd2)
  // )u_color_bar_rgb1(
  // /*i*/.clk	(vid_clk_dvi2),//(vid_clk),
  // /*i*/.rst_n	(vid_rst_n),
  // /*o*/.hs	(hs),
  // /*o*/.vs	(vs),
  // /*o*/.de	(de),
  // // /*O*/.h_cnt (h_cnt),
  // // /*O*/.v_cnt (v_cnt),
  // /*o*/.rgb_r	(rgb_r),    //像素数据、红色分量
  // /*o*/.rgb_g	(rgb_g),    //像素数据、绿色分量
  // /*o*/.rgb_b (rgb_b)    //像素数据、蓝色分量
  
  // );

//=================================================================================
//hdmi tx ctrl 
//=================================================================================
wire                            video_hs;
wire                            video_vs;
wire                            video_de;
wire[7:0]                       video_r;
wire[7:0]                       video_g;
wire[7:0]                       video_b;

assign tmds_tx_data0_TX_OE = 1'b1;
assign tmds_tx_data1_TX_OE = 1'b1;
assign tmds_tx_data2_TX_OE = 1'b1;
assign tmds_tx_clk_TX_OE   = 1'b1;

assign tmds_tx_data0_TX_RST = 1'b0;
assign tmds_tx_data1_TX_RST = 1'b0;
assign tmds_tx_data2_TX_RST = 1'b0;
assign tmds_tx_clk_TX_RST   = 1'b0;

// 	  color_bar color_bar_m0(
// 	.clk(hdmi_tx_slow_clk),
// 	.rst(~vid_rst_n),
// 	.hs(video_hs),
// 	.vs(video_vs),
// 	.de(video_de),
// 	.rgb_r(video_r),
// 	.rgb_g(video_g),
// 	.rgb_b(video_b)
// );

wire [9:0] tmds_data0;
wire [9:0] tmds_data1;
wire [9:0] tmds_data2;
wire [9:0] tmds_clk ;
wire [7:0] gamma_rdata ;
wire [7:0] gamma_gdata ;
wire [7:0] gamma_bdata ;
wire gamma_valid;
wire gamma_hs;
wire gamma_vs;
wire gamma_sel;

wire [7:0] con_rdata ;
wire [7:0] con_gdata ;
wire [7:0] con_bdata ;
wire con_de;
wire con_hs;
wire con_vs;
wire con_sel;

wire [7:0] BRIGHT_SIG    ;
wire CONTRAST_SIG_G;
wire CONTRAST_SIG_R;
wire [7:0] CONTRAST_G    ;
wire CONTRAST_SIG_B;
wire [7:0] BRIGHT        ;
wire [7:0] CONTRAST_R    ;


wire CONTRAST_B    ;


gamma_correction
#(
	.DATA_WIDTH		(8),
	.GAMMA_CURVE	("./rtl/gamma_conrrection/2P2.mem")
)
inst_gamma_correction
(
	.i_pclk		(hdmi_tx_slow_clk),
	.i_rstn		(vid_rst_n),
	
	.i_red		(hdmi_tx_rdata),//(con_rdata  ),//
	.i_green	(hdmi_tx_gdata),//(con_gdata  ),//
	.i_blue		(hdmi_tx_bdata),//(con_bdata  ),//
  .i_valid	(hdmi_tx_de   ),//(con_de     ),//
  .i_hs     (hdmi_tx_hs   ),//(con_hs     ),//
  .i_vs     (hdmi_tx_vs   ),//(con_vs     ),//
	.o_blue		(gamma_bdata		),
  .o_green	(gamma_gdata	  ),
	.o_red		(gamma_rdata		),
	.o_valid	(gamma_valid	  ),
  .o_hs     (gamma_hs       ),
  .o_vs     (gamma_vs       )
);

dvi_encoder dvi_encoder_m0
(
	.pixelclk      		(hdmi_tx_slow_clk          ),// system clock
	.rst_p         		(~vid_rst_n      ),// reset
	.i_bdata      		(gamma_sel ? gamma_bdata	: hdmi_tx_bdata 	),//(hdmi_tx_rdata ),//(video_b            ),//(bdata_in	),   //
	.i_gdata     		  (gamma_sel ? gamma_gdata	: hdmi_tx_gdata   ),//(hdmi_tx_gdata ),//(video_g            ),//(gdata_in	),   //   
	.i_rdata       		(gamma_sel ? gamma_rdata	: hdmi_tx_rdata 	),//(hdmi_tx_bdata ),//(video_r            ),//(rdata_in	),   //   
  .i_de            	(gamma_sel ? gamma_valid	: hdmi_tx_de      ),//(hdmi_tx_de    ),//(video_de           ),//(rx_de		  ),   //
	.i_hs         		(gamma_sel ? gamma_hs	    : hdmi_tx_hs    ),//(video_hs           ),//(rx_hsync	),   //   
	.i_vs         		(gamma_sel ? gamma_vs	    : hdmi_tx_vs    ),//(video_vs           ),//(rx_vsync	),   //  
	
  .video_format     (video_format), //// 00 = RGB, 01 = YCbCr 4:2:2, 10 = YCbCr 4:4:4
  .video_VIC        (0),
	.audio_L			    (audio_L),
  .audio_R			    (audio_R),
  .audio_valid		  (audio_valid),
  .audio_N                (6144),     //(20'h01880),//     
  .audio_CTS              (148500),      // 148.5MHz 像素时钟 (148.5e6*6144/6144000)
  .audio_sample_frequency (audio_samp_freq),    //(3'b000),// 
  .audio_word_length      ({audio_samp_word_len,audio_max_word_length}),//(4'b1011),//

	.tmds_data0    		(tmds_data0),
  .tmds_data1    		(tmds_data1),
  .tmds_data2    		(tmds_data2),
  .tmds_clk      	  (tmds_clk  )
);
assign tmds_tx_clk_TX_DATA   = ~tmds_clk;
assign tmds_tx_data0_TX_DATA = ~tmds_data0;
assign tmds_tx_data1_TX_DATA = ~tmds_data1;
assign tmds_tx_data2_TX_DATA = ~tmds_data2;

//=====================================================================================
// ★ 小灯 Debug 链（DEBUG_LED=1）
//   按 D0→D7 顺序逐级判断，第一个不亮的灯就是故障点。
//   D0 core_clk 心跳        : 约 1.5Hz 闪
//   D1 w_arstn              : 常亮（所有 PLL 锁定）
//   D2 i_cam_ck_CLKOUT 活动 : 约 3~20Hz 闪（sensor MIPI 字节时钟）
//   D3 i_mipi_rx_pclk 活动  : 约 3~20Hz 闪（RX 像素时钟）
//   D4 w_mipi_rx_vs 0.67s 内出现过 : 常亮（CSI RX 收到帧）
//   D5 w_mipi_rx_de 且 data≠0 0.67s 内出现过 : 常亮（收到有效像素）
//   D6 frame_len_dbg == 129600 : 常亮（一帧 beat 数正确）
//   D7 s_axi_awvalid 活动   : 闪/常亮（DDR 写真正发生）
//=====================================================================================
localparam DEBUG_LED = 1'b1;   // 1=小灯 Debug 链；0=原来的录像状态灯

// D0: core_clk 心跳
wire led_d0 = cnt[25];

// D1: 所有 PLL 锁定 / 逻辑复位释放
wire led_d1 = w_arstn;

// D2: MIPI 字节时钟活动（直接用分频位闪：闪=时钟活，灭=时钟死）
reg  [23:0] camck_cnt;
always @(posedge i_cam_ck_CLKOUT)
    camck_cnt <= camck_cnt + 1'b1;
wire camck_blink = camck_cnt[23];
reg  [2:0] camck_bsync;
always @(posedge core_clk)
    camck_bsync <= {camck_bsync[1:0], camck_blink};
wire led_d2 = camck_bsync[1];

// D3: I2C 配置有没有跑过（SCL 有过跳变就锁存；常亮=配置已执行）
reg  scl_d;
reg  i2c_seen = 1'b0;
always @(posedge core_clk)
begin
    scl_d <= io_cam_scl_OUT;
    if(io_cam_scl_OUT ^ scl_d)
        i2c_seen <= 1'b1;
end
wire led_d3 = i2c_seen;

// D4: CSI RX 有没有输出 VS（0.17s 内出现过就常亮）
//     CSI RX 的 clk_pixel 已改成 core_clk，这里也在 core_clk 域采样。
reg  vs_d;
always @(posedge core_clk)
    vs_d <= w_mipi_rx_vs;
wire vs_pulse = w_mipi_rx_vs & ~vs_d;
reg  [24:0] vs_age;
always @(posedge core_clk)
    if(vs_pulse)              vs_age <= 25'd0;
    else if(!vs_age[24])      vs_age <= vs_age + 1'b1;
wire led_d4 = ~vs_age[24];

// D5: 有没有 DE 且像素数据非 0（只有 DE、数据全 0 也会判失败）
//     这里看的是真正送进 frame_buffer 的 i_de = w1_mipi_rx_de（不再与 HS 相与）
wire de_data = w1_mipi_rx_de & (|w1_mipi_rx_data[31:0]);
reg  de_data_d;
always @(posedge core_clk)
    de_data_d <= de_data;
wire de_data_pulse = de_data & ~de_data_d;
reg  [24:0] de_age;
always @(posedge core_clk)
    if(de_data_pulse)         de_age <= 25'd0;
    else if(!de_age[24])      de_age <= de_age + 1'b1;
wire led_d5 = ~de_age[24];

// D6: frame_pix_num 换算出的 AXI beat 数是否等于 1920*1080/16 = 129600
reg  frame_len_ok;
always @(posedge core_clk)
    frame_len_ok <= (frame_len_dbg == 32'd129600);
wire led_d6 = frame_len_ok;

// D7: DDR 写地址通道有没有活动（写引擎真正在发 burst）
reg  [25:0] aw_age;
always @(posedge core_clk)
    if(s_axi_awvalid)         aw_age <= 26'd0;
    else if(!aw_age[25])      aw_age <= aw_age + 1'b1;
wire led_d7 = ~aw_age[25];

wire [7:0] led_dbg = {led_d7, led_d6, led_d5, led_d4, led_d3, led_d2, led_d1, led_d0};

// 原来的运行状态灯（DEBUG_LED=0 时使用）
//   D8 = 追踪开关状态(KEY2 长按切换)，D7 = 当前是否正在出框
wire [7:0] led_run;
assign led_run[0]   = cal_done ? cnt[24] : 1'b0;
assign led_run[4:1] = rec_led;
assign led_run[5]   = 1'b0;
assign led_run[6]   = trk_motion;   //! 正在显示追踪框
assign led_run[7]   = track_en;     //! 追踪总开关(高=开)

assign led = DEBUG_LED ? led_dbg : led_run;

debug_edb_top debug_edb_top_inst (
    .bscan_CAPTURE      ( jtag_inst1_CAPTURE  ),
    .bscan_DRCK         ( jtag_inst1_DRCK     ),
    .bscan_RESET        ( jtag_inst1_RESET    ),
    .bscan_RUNTEST      ( jtag_inst1_RUNTEST  ),
    .bscan_SEL          ( jtag_inst1_SEL      ),
    .bscan_SHIFT        ( jtag_inst1_SHIFT    ),
    .bscan_TCK          ( jtag_inst1_TCK      ),
    .bscan_TDI          ( jtag_inst1_TDI      ),
    .bscan_TMS          ( jtag_inst1_TMS      ),
    .bscan_UPDATE       ( jtag_inst1_UPDATE   ),
    .bscan_TDO          ( jtag_inst1_TDO      ),
    .vio0_clk           ( vid_clk_dvi2        ),
    .vio0_r_gain        ( r_gain              ),
    .vio0_g_gain        ( g_gain              ),
    .vio0_b_gain        ( b_gain              ),

    .vio0_gamma_sel     (gamma_sel),
    .la0_clk            ( vid_clk_dvi2        ),
    .la0_ch0_g          ( ch0_cvo_dout        ),  // ★帧缓存读出的像素数据(8bit) —— 最关键：全 0 即没数据
    .la0_ch0_b          ( rgb_g               ),  // ★去马赛克输出 G（配合 ch0_g 判 debayer 是否工作）
    .la0_ch0_de         ( ch0_cvo_de          ),  // cvo 输出 DE（有脉冲=显示时序在跑）
    .la0_cal_done       ( cal_done            )   // DDR3 校准完成
);

endmodule
