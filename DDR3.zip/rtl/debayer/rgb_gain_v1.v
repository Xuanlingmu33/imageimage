//=============================================================================
// rgb_gain_v1  --  1 像素/拍 通道增益（1080p60 版）
//
// CFA 默认 RGGB（左上角 R）；CFA_RB_SWAP=0 时按 BGGR：
//   RGGB: 偶行偶列 R，偶行奇列 G，奇行偶列 G，奇行奇列 B
//   BGGR: 偶行偶列 B，偶行奇列 G，奇行偶列 G，奇行奇列 R
// 结果带饱和（>255 截到 255）。
//=============================================================================
module rgb_gain_v1
#(
	parameter	P_DEPTH			= 8,
	parameter	Q_WIDTH			= 16,	// Q8.8 定点
	parameter	CFA_RB_SWAP		= 1'b0	// 0=BGGR(默认) 1=RGGB
)
(
	input						i_pclk,
	input						i_arstn,

	input						i_hs,
	input						i_vs,
	input						i_de,
	input						i_valid,
	input	[P_DEPTH-1:0]		i_data,

	input	[Q_WIDTH-1:0]		gain_r,
	input	[Q_WIDTH-1:0]		gain_g,
	input	[Q_WIDTH-1:0]		gain_b,

	output	reg					o_hs,
	output	reg					o_vs,
	output	reg					o_de,
	output	reg					o_valid,
	output	reg	[P_DEPTH-1:0]	o_data
);

	//-------------------------------------------------------------------------
	// 行/列奇偶跟踪（组合用于当前像素，故与像素同拍）
	//-------------------------------------------------------------------------
	reg		r_de_r;
	reg		r_cp;		// 列奇偶（当前像素）
	reg		r_rp;		// 行奇偶（当前行）

	wire	w_de_fall	= r_de_r & ~i_de;
	wire	w_de_rise	= ~r_de_r & i_de;

	always@(posedge i_pclk or negedge i_arstn)
	begin
		if (~i_arstn)
		begin
			r_de_r	<= 1'b0;
			r_cp	<= 1'b0;
			r_rp	<= 1'b0;
		end
		else
		begin
			r_de_r	<= i_de;

			if (i_vs)
			begin
				r_cp	<= 1'b0;
				r_rp	<= 1'b0;
			end
			else if (w_de_rise)
			begin
				r_cp	<= 1'b0;
			end
			else if (w_de_fall)
			begin
				r_cp	<= 1'b0;
				r_rp	<= ~r_rp;		// 行尾翻转行奇偶
			end
			else if (i_de)
			begin
				r_cp	<= ~r_cp;		// 下一像素列号翻转
			end
		end
	end

	//-------------------------------------------------------------------------
	// 增益选择 + Q8.8 乘法 + 饱和
	//-------------------------------------------------------------------------
	wire	[Q_WIDTH-1:0]	gain_sel	= CFA_RB_SWAP ?
										  ((r_rp == 1'b0 && r_cp == 1'b0) ? gain_r :
										   (r_rp == 1'b1 && r_cp == 1'b1) ? gain_b : gain_g) :
										  ((r_rp == 1'b0 && r_cp == 1'b0) ? gain_b :
										   (r_rp == 1'b1 && r_cp == 1'b1) ? gain_r : gain_g);
	wire	[Q_WIDTH+P_DEPTH-1:0]	mul		= i_data * gain_sel;
	wire	[P_DEPTH-1:0]	out		= (|mul[Q_WIDTH+P_DEPTH-1:P_DEPTH+8]) ?
									  {P_DEPTH{1'b1}} : mul[P_DEPTH+7:8];

	always@(posedge i_pclk or negedge i_arstn)
	begin
		if (~i_arstn)
		begin
			o_hs	<= 1'b0;
			o_de	<= 1'b0;
			o_vs	<= 1'b0;
			o_valid	<= 1'b0;
			o_data	<= {P_DEPTH{1'b0}};
		end
		else
		begin
			o_hs	<= i_hs;
			o_de	<= i_de;
			o_vs	<= i_vs;
			o_valid	<= i_valid;
			o_data	<= out;
		end
	end

endmodule
