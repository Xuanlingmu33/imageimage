//=============================================================================
// debayer_top  --  1 像素/拍 RAW(RGGB) -> RGB888（1080p60 版）
//   结构：rgb_gain_v1 -> line_buffer(延迟1/2行) -> raw_to_rgb(3x3 双线性)
//   CFA_RB_SWAP=1 按 RGGB（与 Ti60f225_sc431hai2hdmi_isp_v1 一致）；
//   =0 按 BGGR。若画面 R/B 反了，改这个参数即可。
//   输出：每拍 1 个像素 RGB888，行/帧同步与输入同形（垂直方向滞后约 1 行）
//   1080p：列号 0..1919，行缓冲/列计数位宽 10 -> 11。
//=============================================================================
module debayer_top_2to1
#(
	parameter	CFA_RB_SWAP		= 1'b0		// 0=BGGR(默认) 1=RGGB
)
(
	input			in_pclk,
	input			in_rstn,

	input			raw_vs_i,
	input			raw_hs_i,
	input			raw_de_i,
	input			raw_valid_i,
	input	[7:0]	raw_data_i,
	input	[15:0]	r_gain,
	input	[15:0]	g_gain,
	input	[15:0]	b_gain,

	output			rgb_vs_o,
	output			rgb_hs_o,
	output			rgb_de_o,
	output			rgb_valid_o,
	output	[7:0]	rgb_rout,
	output	[7:0]	rgb_gout,
	output	[7:0]	rgb_bout,
	output	[23:0]	rgb_data_o		// {b,g,r}
);

	//----------------------------------------------------------------------
	// 1. 通道增益
	//----------------------------------------------------------------------
	wire			w_gain_vs;
	wire			w_gain_hs;
	wire			w_gain_de;
	wire			w_gain_valid;
	wire	[7:0]	w_gain_data;

	rgb_gain_v1
	#(
		.P_DEPTH(8),
		.Q_WIDTH(16),
		.CFA_RB_SWAP(CFA_RB_SWAP)
	)
	inst_rgb_gain
	(
		.i_pclk		(in_pclk		),
		.i_arstn	(in_rstn		),
		.i_hs		(raw_hs_i		),
		.i_vs		(raw_vs_i		),
		.i_de		(raw_de_i		),
		.i_valid	(raw_valid_i	),
		.i_data		(raw_data_i		),

		.gain_r		(r_gain			),
		.gain_g		(g_gain			),
		.gain_b		(b_gain			),

		.o_hs		(w_gain_hs		),
		.o_vs		(w_gain_vs		),
		.o_de		(w_gain_de		),
		.o_valid	(w_gain_valid	),
		.o_data		(w_gain_data	)
	);

	//----------------------------------------------------------------------
	// 2. 行缓冲：给出 第 n-1 行(mid) 与 第 n-2 行(up)
	//----------------------------------------------------------------------
	wire			w_lb_vs;
	wire			w_lb_hs;
	wire			w_lb_de;
	wire			w_lb_valid;
	wire	[7:0]	w_lb_mid;
	wire	[7:0]	w_lb_up;
	wire	[10:0]	w_lb_x;
	wire			w_lb_rowpar;

	line_buffer
	#(
		.P_DEPTH		(8),
		.PW				(8),
		.X_CNT_WIDTH	(11)
	)
	inst_line_buffer
	(
		.i_arstn	(in_rstn		),
		.i_pclk		(in_pclk		),

		.i_vs		(w_gain_vs		),
		.i_hs		(w_gain_hs		),
		.i_de		(w_gain_de		),
		.i_valid	(w_gain_valid	),
		.i_p		(w_gain_data	),

		.o_vs		(w_lb_vs		),
		.o_hs		(w_lb_hs		),
		.o_de		(w_lb_de		),
		.o_valid	(w_lb_valid		),
		.o_mid		(w_lb_mid		),
		.o_up		(w_lb_up		),
		.o_x		(w_lb_x			),
		.o_row_par	(w_lb_rowpar	)
	);

	//----------------------------------------------------------------------
	// 3. 去马赛克（3x3 双线性）
	//----------------------------------------------------------------------
	wire	[10:0]	w_x;
	wire	[10:0]	w_y;

	raw_to_rgb
	#(
		.P_DEPTH		(8),
		.PW				(8),
		.X_CNT_WIDTH	(11),
		.LEGACY			(1'b1),
		.CFA_RB_SWAP	(CFA_RB_SWAP)
	)
	inst_raw_to_rgb
	(
		.i_arstn	(in_rstn		),
		.i_pclk		(in_pclk		),

		.i_vsync	(w_lb_vs		),
		.i_hsync	(w_lb_hs		),
		.i_de		(w_lb_de		),
		.i_valid	(w_lb_valid		),
		.i_p		(w_gain_data	),	// 第 n   行（下行）
		.i_mid		(w_lb_mid		),	// 第 n-1 行（中行）
		.i_up		(w_lb_up		),	// 第 n-2 行（上行）
		.i_row_par	(w_lb_rowpar	),
		.i_x		(w_lb_x			),

		.o_vsync	(rgb_vs_o		),
		.o_hsync	(rgb_hs_o		),
		.o_de		(rgb_de_o		),
		.o_valid	(rgb_valid_o	),
		.o_x_cnt	(w_x			),
		.o_y_cnt	(w_y			),
		.o_r		(rgb_rout		),
		.o_g		(rgb_gout		),
		.o_b		(rgb_bout		)
	);

	assign	rgb_data_o	= {rgb_bout, rgb_gout, rgb_rout};

endmodule
