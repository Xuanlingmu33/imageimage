//=============================================================================
// line_buffer  --  1 像素/拍 行缓冲（1080p60 版）
//
// 功能：把输入的原始像素流延迟 1 行 / 2 行，同时给出：
//   o_mid = 第 n-1 行（当前输入行 n 的上一行，即去马赛克窗口的【中间行】）
//   o_up  = 第 n-2 行（窗口的【上行】）
//   当前行（下行）由调用者直接用 i_p 接到 raw_to_rgb。
//   三者列号对齐（同一列），随 o_x 输出列号、o_row_par 输出中间行行号奇偶。
//
// 实现：3 个单口 RAM（simple_dual_port_ram）按行号 mod 3 轮转：
//   第 n   行写入 bank(n mod 3)
//   第 n-1 行读  bank((n-1) mod 3)
//   第 n-2 行读  bank((n-2) mod 3)
//   三个 bank 互不相同 ⇒ 每拍每个 RAM 至多 1 次操作，单口即可。
//   1080p：X_CNT_WIDTH=11，每 bank 2048x8。
//=============================================================================
module line_buffer
#(
	parameter	P_DEPTH			= 8,
	parameter	PW				= P_DEPTH,
	parameter	X_CNT_WIDTH		= 11
)
(
	input						i_arstn,
	input						i_pclk,

	input						i_vs,
	input						i_hs,
	input						i_de,
	input						i_valid,
	input	[PW-1:0]			i_p,

	output						o_vs,
	output						o_hs,
	output						o_de,
	output						o_valid,
	output	[PW-1:0]			o_mid,		// 第 n-1 行
	output	[PW-1:0]			o_up,		// 第 n-2 行
	output	[X_CNT_WIDTH-1:0]	o_x,		// 与 o_mid/o_up 对齐的列号
	output						o_row_par	// 第 n-1 行的行号奇偶
);

	//-------------------------------------------------------------------------
	// 列计数：i_de 期间逐像素 +1，行尾（de 下降）归零
	//-------------------------------------------------------------------------
	reg	[X_CNT_WIDTH-1:0]	r_x;
	reg						r_de_r;
	wire					w_de_fall	= r_de_r & ~i_de;
	wire					w_de_rise	= ~r_de_r & i_de;

	always@(posedge i_pclk or negedge i_arstn)
	begin
		if (~i_arstn)
			r_x	<= {X_CNT_WIDTH{1'b0}};
		else if (i_de)
			r_x	<= r_x + 1'b1;
		else
			r_x	<= {X_CNT_WIDTH{1'b0}};
	end

	// de 打一拍，用于检测行首/行尾
	always@(posedge i_pclk or negedge i_arstn)
	begin
		if (~i_arstn)
			r_de_r	<= 1'b0;
		else
			r_de_r	<= i_de;
	end

	//-------------------------------------------------------------------------
	// 行号奇偶（= 当前输入行 n 的奇偶）；de 下降沿翻转
	//-------------------------------------------------------------------------
		reg						r_row_par_n;	// 第 n 行奇偶
	always@(posedge i_pclk or negedge i_arstn)
	begin
		if (~i_arstn)
			r_row_par_n	<= 1'b0;
		else if (i_vs)				// 帧首复位
			r_row_par_n	<= 1'b0;
		else if (w_de_fall)
			r_row_par_n	<= ~r_row_par_n;
	end

	//-------------------------------------------------------------------------
	// bank 轮转 0->1->2->0（每行一次，de 下降沿）
	//-------------------------------------------------------------------------
	reg	[1:0]				r_bank;		// = n mod 3
	always@(posedge i_pclk or negedge i_arstn)
	begin
		if (~i_arstn)
			r_bank	<= 2'd0;
		else if (i_vs)
			r_bank	<= 2'd0;
		else if (w_de_fall)
			r_bank	<= (r_bank == 2'd2) ? 2'd0 : (r_bank + 1'b1);
	end

	// 中间行 bank = (n-1) mod 3 ；上行 bank = (n-2) mod 3
	wire	[1:0]	w_mid_bank	= (r_bank == 2'd0) ? 2'd2 : (r_bank - 1'b1);
	wire	[1:0]	w_up_bank	= (r_bank == 2'd2) ? 2'd0 : (r_bank + 1'b1);

	//-------------------------------------------------------------------------
	// 3 个单口 RAM 的读写使能 / 数据
	//-------------------------------------------------------------------------
	wire				w_wr		= i_de & i_valid;
	wire [X_CNT_WIDTH-1:0]	w_addr	= r_x;

	wire				w_wr_b0		= w_wr & (r_bank   == 2'd0);
	wire				w_wr_b1		= w_wr & (r_bank   == 2'd1);
	wire				w_wr_b2		= w_wr & (r_bank   == 2'd2);

	wire				w_rd_b0		= (w_mid_bank == 2'd0) | (w_up_bank == 2'd0);
	wire				w_rd_b1		= (w_mid_bank == 2'd1) | (w_up_bank == 2'd1);
	wire				w_rd_b2		= (w_mid_bank == 2'd2) | (w_up_bank == 2'd2);

	wire	[PW-1:0]	w_dout0, w_dout1, w_dout2;

	simple_dual_port_ram
	#(.DATA_WIDTH(PW), .ADDR_WIDTH(X_CNT_WIDTH), .OUTPUT_REG("FALSE"), .RAM_INIT_FILE(""))
	u_bank0 (
		.wdata	(i_p		), .waddr	(w_addr	), .we	(w_wr_b0	),
		.wclk	(i_pclk		),
		.rclk	(i_pclk		), .re	(w_rd_b0	), .raddr	(w_addr	),
		.rdata	(w_dout0	)
	);

	simple_dual_port_ram
	#(.DATA_WIDTH(PW), .ADDR_WIDTH(X_CNT_WIDTH), .OUTPUT_REG("FALSE"), .RAM_INIT_FILE(""))
	u_bank1 (
		.wdata	(i_p		), .waddr	(w_addr	), .we	(w_wr_b1	),
		.wclk	(i_pclk		),
		.rclk	(i_pclk		), .re	(w_rd_b1	), .raddr	(w_addr	),
		.rdata	(w_dout1	)
	);

	simple_dual_port_ram
	#(.DATA_WIDTH(PW), .ADDR_WIDTH(X_CNT_WIDTH), .OUTPUT_REG("FALSE"), .RAM_INIT_FILE(""))
	u_bank2 (
		.wdata	(i_p		), .waddr	(w_addr	), .we	(w_wr_b2	),
		.wclk	(i_pclk		),
		.rclk	(i_pclk		), .re	(w_rd_b2	), .raddr	(w_addr	),
		.rdata	(w_dout2	)
	);

	// 输出选择（RAM 读延迟 1 拍 ⇒ 与打 1 拍的同步信号对齐）
	assign	o_mid	= (w_mid_bank == 2'd0) ? w_dout0 :
					  (w_mid_bank == 2'd1) ? w_dout1 : w_dout2;
	assign	o_up	= (w_up_bank  == 2'd0) ? w_dout0 :
					  (w_up_bank  == 2'd1) ? w_dout1 : w_dout2;

	//-------------------------------------------------------------------------
	// 同步信号 / 列号 / 行奇偶 打 1 拍（与 RAM 读延迟对齐）
	//-------------------------------------------------------------------------
	reg		r_vs_1P, r_hs_1P, r_de_1P, r_valid_1P;
	reg	[X_CNT_WIDTH-1:0] r_x_1P;
	reg		r_row_par_1P;

	always@(posedge i_pclk or negedge i_arstn)
	begin
		if (~i_arstn)
		begin
			r_vs_1P		<= 1'b0;
			r_hs_1P		<= 1'b0;
			r_de_1P		<= 1'b0;
			r_valid_1P	<= 1'b0;
			r_x_1P		<= {X_CNT_WIDTH{1'b0}};
			r_row_par_1P<= 1'b0;
		end
		else
		begin
			r_vs_1P		<= i_vs;
			r_hs_1P		<= i_hs;
			r_de_1P		<= i_de;
			r_valid_1P	<= i_valid;
			r_x_1P		<= r_x;
			r_row_par_1P<= r_row_par_n;		// 对齐当前行，raw_to_rgb 内再做 1 行偏移
		end
	end

	assign	o_vs		= r_vs_1P;
	assign	o_hs		= r_hs_1P;
	assign	o_de		= r_de_1P;
	assign	o_valid		= r_valid_1P;
	assign	o_x		= r_x_1P;
	// 中间行 = 第 n-1 行 ⇒ 行号奇偶取反（与 o_mid 数据同拍）
	assign	o_row_par	= ~r_row_par_1P;

endmodule
