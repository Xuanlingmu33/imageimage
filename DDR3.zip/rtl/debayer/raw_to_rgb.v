//=============================================================================
// raw_to_rgb  --  1 像素/拍 去马赛克（1080p60 版）
//
// CFA 默认 RGGB（左上角为 R）：
//   偶行(行号&1==0)：R G R G ...   奇行(行号&1==1)：G B G B ...
//   CFA_RB_SWAP=0 时按 BGGR（左上角 B）解析。
//
// 内部按 BGGR 的 3x3 双线性重建，CFA_RB_SWAP=1 时把 R/B 输出交换，
// 等价于把 BGGR 的 R/B 对调成 RGGB。
//
// 输入 3 行（同一列对齐）：
//   i_p   = 第 n   行（窗口中【下】行）
//   i_mid = 第 n-1 行（窗口中【中】行，line_buffer 延迟 1 行）
//   i_up  = 第 n-2 行（窗口中【上】行，line_buffer 延迟 2 行）
// 内部再用移位寄存器取出每行的 左/中/右 三列 ⇒ 构成 3x3 窗口。
// 输出像素 = 【中行】第 (X-2) 列（X = 本拍 i_p 的列号）。
//
// 双线性重建：
//   B 位点(偶行偶列): B=中 ; G=(左+右+上+下)/4 ; R=(四对角)/4
//   G 位点(偶行奇列): G=中 ; B=水平两邻/2     ; R=垂直两邻/2
//   G 位点(奇行偶列): G=中 ; R=水平两邻/2     ; B=垂直两邻/2
//   R 位点(奇行奇列): R=中 ; G=(左+右+上+下)/4 ; B=(四对角)/4
//=============================================================================
module raw_to_rgb
#(
	parameter	P_DEPTH			= 8,
	parameter	PW				= P_DEPTH,
	parameter	X_CNT_WIDTH		= 11,
	parameter	LEGACY			= 1'b1,
	parameter	CFA_RB_SWAP		= 1'b0		// 0=BGGR(默认) 1=RGGB
)
(
	input						i_arstn,
	input						i_pclk,

	input						i_vsync,
	input						i_hsync,
	input						i_de,
	input						i_valid,
	input	[PW-1:0]			i_p,		// 第 n   行
	input	[PW-1:0]			i_mid,		// 第 n-1 行
	input	[PW-1:0]			i_up,		// 第 n-2 行
	input						i_row_par,	// 中(=n-1)行行号奇偶
	input	[X_CNT_WIDTH-1:0]	i_x,		// 与 i_mid 对齐的列号

	output						o_vsync,
	output						o_hsync,
	output						o_de,
	output						o_valid,
	output	[X_CNT_WIDTH-1:0]	o_x_cnt,
	output	[X_CNT_WIDTH-1:0]	o_y_cnt,
	output	reg	[PW-1:0]		o_r,
	output	reg	[PW-1:0]		o_g,
	output	reg	[PW-1:0]		o_b
);

	//-------------------------------------------------------------------------
	// 每行的 3 列移位寄存器（左/中/右）
	//  i_p   : i_p(T)=X(右) , d1=X-1 , d2=X-2(中) , d3=X-3(左)
	//  i_mid : i_mid(T)=X-1(右) , m1=X-2(中) , m2=X-3(左)
	//  i_up  : i_up(T)=X-1(右)  , u1=X-2(中) , u2=X-3(左)
	//-------------------------------------------------------------------------
	reg	[PW-1:0]	r_d1, r_d2, r_d3;
	reg	[PW-1:0]	r_m1, r_m2;
	reg	[PW-1:0]	r_u1, r_u2;

	always@(posedge i_pclk or negedge i_arstn)
	begin
		if (~i_arstn) begin
			r_d1 <= {PW{1'b0}}; r_d2 <= {PW{1'b0}}; r_d3 <= {PW{1'b0}};
			r_m1 <= {PW{1'b0}}; r_m2 <= {PW{1'b0}};
			r_u1 <= {PW{1'b0}}; r_u2 <= {PW{1'b0}};
		end else begin
			r_d1 <= i_p;   r_d2 <= r_d1;  r_d3 <= r_d2;
			r_m1 <= i_mid; r_m2 <= r_m1;
			r_u1 <= i_up;  r_u2 <= r_u1;
		end
	end

	wire	[PW-1:0]	d_l = r_d3, d_c = r_d2, d_r = r_d1;
	wire	[PW-1:0]	m_l = r_m2, m_c = r_m1, m_r = i_mid;
	wire	[PW-1:0]	u_l = r_u2, u_c = r_u1, u_r = i_up;

	//-------------------------------------------------------------------------
	// 奇偶：行用 i_row_par（中行）；列用 i_x-1（i_x 对齐 i_mid=X-1 ⇒ 中列=X-2）
	//-------------------------------------------------------------------------
	wire	rp		= i_row_par;			// 0 = B G B G , 1 = G R G R
	wire	cp		= ~i_x[0];			// 中列 (X-2) 的列奇偶

	//-------------------------------------------------------------------------
	// 双线性重建（组合）
	//-------------------------------------------------------------------------
	wire	[P_DEPTH+2:0]	axis_sum	= {2'b00,m_l} + {2'b00,m_r} + {2'b00,u_c} + {2'b00,d_c};
	wire	[P_DEPTH+2:0]	diag_sum	= {2'b00,u_l} + {2'b00,u_r} + {2'b00,d_l} + {2'b00,d_r};
	wire	[P_DEPTH+1:0]	horz_sum	= {1'b0,m_l} + {1'b0,m_r};
	wire	[P_DEPTH+1:0]	vert_sum	= {1'b0,u_c} + {1'b0,d_c};

	wire	[PW-1:0]	axis_avg	= axis_sum[P_DEPTH+1:2];
	wire	[PW-1:0]	diag_avg	= diag_sum[P_DEPTH+1:2];
	wire	[PW-1:0]	horz_avg	= horz_sum[P_DEPTH:1];
	wire	[PW-1:0]	vert_avg	= vert_sum[P_DEPTH:1];

	reg		[PW-1:0]	w_r_sel, w_g_sel, w_b_sel;
	always@(*)
	begin
		if (rp == 1'b0 && cp == 1'b0)			// B 位点（偶行偶列）
		begin
			w_b_sel	= m_c;
			w_g_sel	= axis_avg;
			w_r_sel	= diag_avg;
		end
		else if (rp == 1'b0 && cp == 1'b1)		// G 位点（偶行奇列）
		begin
			w_g_sel	= m_c;
			w_b_sel	= horz_avg;		// 水平两邻 = B
			w_r_sel	= vert_avg;		// 垂直两邻 = R
		end
		else if (rp == 1'b1 && cp == 1'b0)		// G 位点（奇行偶列）
		begin
			w_g_sel	= m_c;
			w_r_sel	= horz_avg;		// 水平两邻 = R
			w_b_sel	= vert_avg;		// 垂直两邻 = B
		end
		else									// R 位点（奇行奇列）
		begin
			w_r_sel	= m_c;
			w_g_sel	= axis_avg;
			w_b_sel	= diag_avg;
		end
	end

	//-------------------------------------------------------------------------
	// 同步流水：de/hs/vs/valid 打 3 拍（数据在 T+1 输出，对应列 X-2，
	// 而 i_de 在 T-2 才对应列 X-2 ⇒ 共需滞后 3 拍）
	//-------------------------------------------------------------------------
	reg		r_de_1P, r_de_2P, r_de_3P;
	reg		r_hs_1P, r_hs_2P, r_hs_3P;
	reg		r_vs_1P, r_vs_2P, r_vs_3P;
	reg		r_valid_1P, r_valid_2P, r_valid_3P;

	always@(posedge i_pclk or negedge i_arstn)
	begin
		if (~i_arstn) begin
			r_de_1P <= 1'b0; r_de_2P <= 1'b0; r_de_3P <= 1'b0;
			r_hs_1P <= 1'b0; r_hs_2P <= 1'b0; r_hs_3P <= 1'b0;
			r_vs_1P <= 1'b0; r_vs_2P <= 1'b0; r_vs_3P <= 1'b0;
			r_valid_1P <= 1'b0; r_valid_2P <= 1'b0; r_valid_3P <= 1'b0;
		end else begin
			r_de_1P <= i_de;    r_de_2P <= r_de_1P;  r_de_3P <= r_de_2P;
			r_hs_1P <= i_hsync; r_hs_2P <= r_hs_1P;  r_hs_3P <= r_hs_2P;
			r_vs_1P <= i_vsync; r_vs_2P <= r_vs_1P;  r_vs_3P <= r_vs_2P;
			r_valid_1P <= i_valid; r_valid_2P <= r_valid_1P; r_valid_3P <= r_valid_2P;
		end
	end

	//-------------------------------------------------------------------------
	// 输出寄存器
	//-------------------------------------------------------------------------
	always@(posedge i_pclk or negedge i_arstn)
	begin
		if (~i_arstn)
		begin
			o_r <= {PW{1'b0}};
			o_g <= {PW{1'b0}};
			o_b <= {PW{1'b0}};
		end
		else
		begin
			o_r <= CFA_RB_SWAP ? w_b_sel : w_r_sel;
			o_g <= w_g_sel;
			o_b <= CFA_RB_SWAP ? w_r_sel : w_b_sel;
		end
	end

	assign	o_vsync	= r_vs_3P;
	assign	o_hsync	= r_hs_3P;
	assign	o_de	= r_de_3P;
	assign	o_valid	= r_valid_3P;

	//-------------------------------------------------------------------------
	// 列/行计数（仅供观测，未参与算法）
	//-------------------------------------------------------------------------
	reg	[X_CNT_WIDTH-1:0]	r_x_cnt;
	reg	[X_CNT_WIDTH-1:0]	r_y_cnt;
	reg		r_de_4P;

	always@(posedge i_pclk or negedge i_arstn)
	begin
		if (~i_arstn) begin
			r_x_cnt <= {X_CNT_WIDTH{1'b0}};
			r_de_4P <= 1'b0;
		end else begin
			r_de_4P <= r_de_3P;
			if (r_de_3P)
				r_x_cnt <= r_x_cnt + 1'b1;
			else
				r_x_cnt <= {X_CNT_WIDTH{1'b0}};
		end
	end

	always@(posedge i_pclk or negedge i_arstn)
	begin
		if (~i_arstn)
			r_y_cnt <= {X_CNT_WIDTH{1'b0}};
		else if (r_vs_3P)
			r_y_cnt <= {X_CNT_WIDTH{1'b0}};
		else if (~r_de_3P & r_de_4P)
			r_y_cnt <= r_y_cnt + 1'b1;
	end

	assign	o_x_cnt	= r_x_cnt;
	assign	o_y_cnt	= r_y_cnt;

endmodule
