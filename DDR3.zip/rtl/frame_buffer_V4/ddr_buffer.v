

`timescale 1ps/1ps
module ddr_buffer #(
parameter AXI_DATA_WIDTH = 512, //!AXI接口位宽
parameter AXI_ADDR_WIDTH = 33,  //!AXI地址位宽
parameter WR_FIFO_DEPTH	= 1024, //!Write fifo depth   
parameter RD_FIFO_DEPTH = 1024, //!read fifo depth
parameter FB_NUM			= 	3,//2 buffer ,3 buffer   
parameter MAX_VID_WIDTH		=	1920 ,//video width 
parameter MAX_VID_HIGHT		=	1080 ,//wideo height
parameter START_ADDR				=	33'h000201900,
parameter BURST_LEN       = 8'd15,
parameter I_VID_WIDTH = 16,
parameter AXI_STRB_WIDTH = AXI_DATA_WIDTH/8//!总共的字节数量，= AXI_DATA_WIDTH/8

) (

input 											axi_clk,
input                       wr_clk_rst_n,
input                       axi_clk_rst_n,
input                       rd_clk_rst_n,
input 											rd_start,
input											wr_start, // pulse signal 

//! 外部槽位选择(录像/回放控制)：ext_sel=1 时读写基址由 rec_play_ctrl 指定
input											ext_sel,
input		[31:0]								ext_wr_base,
input		[31:0]								ext_rd_base,
output											o_wr_frame_done,   //! 摄像头帧边界事件(单周期, VSYNC)
output											o_rd_frame_done,   //! 显示帧边界事件(单周期, VSYNC)

// input		[AXI_ADDR_WIDTH-1:0]				start_wr_addr,
// input		[AXI_ADDR_WIDTH-1:0]				start_rd_addr,
input 		[31:0] 								wr_busrt_len,
input 		[31:0] 								rd_burst_len,
output		[7:0] test_cnt ,

input                     wr_fifo_rst_p,
input											wr_fifo_wrclk,
input											wr_fifo_wren,
output											wr_fifo_wrfull,
input	 [AXI_DATA_WIDTH-1:0]					wr_fifo_wrdata, 
input											rd_fifo_rdclk,
input                       rd_fifo_rst_p,
output											rd_fifo_rdvalid,
output	 [AXI_DATA_WIDTH-1:0] 					rd_fifo_rddata,
output wire										rd_fifo_rdempty,
input	 wire									rd_fifo_rden,

output 	[5:0] 									awid,
output  [AXI_ADDR_WIDTH-1:0] 					awaddr,
output  [8-1:0] 					awlen,
output  [2:0] 									awsize,
output  [1:0] 									awburst,
output  [3:0] 									awcache,
output [2:0]                    awprot,
output  										awlock,
output  										awvalid,
output  										awcobuf,
output  										awapcmd,
output  										awallstrb,
output  										awqos,
input 											awready,

output [5:0] 									arid,
output  [AXI_ADDR_WIDTH-1:0] 					araddr,
output  [8-1:0] 					arlen,
output  [2:0] 									arsize,
output  [1:0] 									arburst,
output  										arlock,
output  										arvalid,
output  										arapcmd,
output 											arqos,
input 											arready,
output  [3:0] 									arcache,
output [2:0]                    arprot,
output  [AXI_DATA_WIDTH-1:0] 					wdata,  
output	[31:0]									test_wdata,
output	[31:0]									test_rdata,
output  [AXI_STRB_WIDTH-1:0] 					wstrb,
output  										wlast,
output  										wvalid,
input 											wready,

input [5:0] 									rid,
input [AXI_DATA_WIDTH-1:0] 						rdata,
input 											rlast,
input 											rvalid,
output  										rready,
input [1:0] 									rresp,
output[31:0]									wr_fifo_rd_data_test,
input [5:0] 									bid,
input 											bvalid,
output  										bready,

output [7:0] test_BURST_LEN
);
assign test_BURST_LEN = BURST_LEN;

//=============================================================
//reg define 
//=============================================================   


//=============================================================
//wire define 
//============================================================= 



wire		                        wr_sw_ack           ;
wire		                        wr_sw_eng           ;
wire		                        rd_sw_eng           ;
wire		                        rd_sw_ack           ;
wire		[1:0]					wr_bank             ;
wire		[1:0]					rd_bank             ;
wire		[AXI_ADDR_WIDTH-1:0]		wr_start_addr       ;
wire		[AXI_ADDR_WIDTH-1:0]    rd_start_addr       ; 

//=============================================================================
//  ★ 帧边界事件改用【摄像头 VSYNC / 显示 VSYNC】，不再依赖 DDR 读写引擎的
//    “最后一拍”脉冲。原因：引擎的 done 脉冲一旦因 burst 长度/帧长/跨时钟域
//    出现偏差，rec_play_ctrl 就收不到帧事件，表现为“实时读未写槽 = 花屏、
//    KEY2/3/4 全死”。改用 VSYNC 后，地址调度与 DDR 数据搬运彻底解耦。
//
//    写侧：摄像头 VSYNC 时上一帧已经写完（消隐期远大于 307KB 的 DDR 写入时间），
//          此刻 rec_play 更新下一帧基址；写引擎的 start 再延迟 EVT_DLY 拍，
//          保证它采样到的是新基址（不是旧基址）。
//    读侧：显示 VSYNC 时读引擎已经采样了本帧基址；把给 rec_play 的事件再延迟
//          EVT_DLY 拍，保证新基址只作用于下一帧，不会让本帧跳帧。
//=============================================================================
localparam integer EVT_DLY = 16;

// 摄像头 VSYNC -> axi_clk 单拍
reg [2:0] wr_vs_sync;
always @(posedge axi_clk or negedge axi_clk_rst_n)
    if(!axi_clk_rst_n) wr_vs_sync <= 3'd0;
    else               wr_vs_sync <= {wr_vs_sync[1:0], wr_start};
wire wr_vs_axi = (wr_vs_sync[2:1] == 2'b01);

// 第一个 VSYNC 时还没有“已完成帧”，抑制一次，避免开机把 PING0 误判为已录
reg wr_evt_ok;
always @(posedge axi_clk or negedge axi_clk_rst_n)
    if(!axi_clk_rst_n) wr_evt_ok <= 1'b0;
    else if(wr_vs_axi) wr_evt_ok <= 1'b1;
wire wr_evt = wr_vs_axi & wr_evt_ok;

// 写引擎 start 延迟 EVT_DLY 拍，等 rec_play/bank_switch 把新基址提交完
reg [EVT_DLY-1:0] wr_start_dly;
always @(posedge axi_clk or negedge axi_clk_rst_n)
    if(!axi_clk_rst_n) wr_start_dly <= {EVT_DLY{1'b0}};
    else               wr_start_dly <= {wr_start_dly[EVT_DLY-2:0], wr_vs_axi};
wire wr_start_eng = wr_start_dly[EVT_DLY-1];

// 显示 VSYNC -> axi_clk 单拍
reg [2:0] rd_vs_sync;
always @(posedge axi_clk or negedge axi_clk_rst_n)
    if(!axi_clk_rst_n) rd_vs_sync <= 3'd0;
    else               rd_vs_sync <= {rd_vs_sync[1:0], rd_start};
wire rd_vs_axi = (rd_vs_sync[2:1] == 2'b01);

// 给 rec_play 的读事件延迟到读引擎采样之后
reg [EVT_DLY-1:0] rd_evt_dly;
always @(posedge axi_clk or negedge axi_clk_rst_n)
    if(!axi_clk_rst_n) rd_evt_dly <= {EVT_DLY{1'b0}};
    else               rd_evt_dly <= {rd_evt_dly[EVT_DLY-2:0], rd_vs_axi};
wire rd_evt = rd_evt_dly[EVT_DLY-1];

//=============================================================  
//RTL                                                     
//=============================================================  



ddr_wr_buffer1 # (
    .AXI_DATA_WIDTH(AXI_DATA_WIDTH),
    .AXI_ADDR_WIDTH(AXI_ADDR_WIDTH),
    .WR_FIFO_DEPTH(WR_FIFO_DEPTH),
    .BURST_LEN (BURST_LEN        )
  )

  u_ddr_wr_buffer (//_inst
    .axi_clk(axi_clk),
    .rst_n(axi_clk_rst_n),//(rst_n),
    .start(wr_start_eng),
    .start_addr(wr_start_addr),//(0),//
    .total_burst_len(wr_busrt_len),
/*i*/.bank_sw_ack	(wr_sw_ack   	),
/*o*/.bank_sw 		  (wr_sw_eng 	 	),
    .test_cnt(test_cnt),
    .wr_fifo_rst_p(wr_fifo_rst_p),
    .wr_fifo_wrclk(wr_fifo_wrclk),
    .wr_fifo_wren(wr_fifo_wren),
    .wr_fifo_wrfull(wr_fifo_wrfull),
    .wr_fifo_wrdata(wr_fifo_wrdata),
    .awid(awid),
    .awaddr(awaddr),
    .awlen(awlen),
    .awsize(awsize),
    .awburst(awburst),
    .awcache(awcache),
    .awlock(awlock),
    .awvalid(awvalid),
    .awcobuf(awcobuf),
    .awapcmd(awapcmd),
    .awallstrb(awallstrb),
    .awprot (awprot ),
    .awqos(awqos),
    .awready(awready),
    .wdata(wdata),
    .wstrb(wstrb),
    .wlast(wlast),
    .wvalid(wvalid),
    .wready(wready),
	  .bid	( bid			),
    .bvalid	( bvalid		),
    .bready	( bready		)
  );


assign test_wdata = wdata[32:0];
assign test_rdata = rdata[32:0];
//=============================================================================================
// FIFO RD_PROCESSING
//=============================================================================================
ddr_rd_buffer # (
    .AXI_DATA_WIDTH(AXI_DATA_WIDTH),
    .AXI_ADDR_WIDTH(AXI_ADDR_WIDTH),
    .RD_FIFO_DEPTH(RD_FIFO_DEPTH),
    .BURST_LEN (BURST_LEN        )
  )
  ddr_rd_buffer_inst (
    .axi_clk(axi_clk),
    .axi_clk_rst_n(axi_clk_rst_n),
    .start(rd_start),
    .start_addr(rd_start_addr),//(0),//
    .burst_len(rd_burst_len),
    .rd_fifo_rdclk(rd_fifo_rdclk),
    .rd_fifo_rst_p (rd_fifo_rst_p),
    .rd_fifo_rdvalid(rd_fifo_rdvalid),
    .rd_fifo_rddata(rd_fifo_rddata),
    .rd_fifo_rdempty(rd_fifo_rdempty),
    .rd_fifo_rden(rd_fifo_rden),
/*i*/.bank_sw_ack	(rd_sw_ack   	),
/*o*/.bank_sw 		  (rd_sw_eng 	 	),
    .arid(arid),
    .araddr(araddr),
    .arlen(arlen),
    .arsize(arsize),
    .arburst(arburst),
    .arlock(arlock),
    .arvalid(arvalid),
    .arapcmd(arapcmd),
    .arqos(arqos),
    .arready(arready),
    .arprot (arprot ),
    .arcache(arcache),
    .rid(rid),
    .rdata(rdata),
    .rlast(rlast),
    .rvalid(rvalid),
    .rready(rready),
    .rresp(rresp),
    .wr_fifo_rd_data_test(wr_fifo_rd_data_test)
  );
//===================================================================================== 
//
//===================================================================================== 
  


bank_switch #(
		.FB_NUM					( FB_NUM),
		.MAX_VID_WIDTH 	( MAX_VID_WIDTH),
		.MAX_VID_HIGHT 	( MAX_VID_HIGHT),
		.START_ADDR			(	START_ADDR 	),
		.VID_DATA_WIDTH	(I_VID_WIDTH	),
		.AXI_DATA_WIDTH (AXI_DATA_WIDTH )
)
  u_bank_sw
(
/*i*/.ddr_clk		(axi_clk	),
/*i*/.rst_n			(axi_clk_rst_n),
              	
/*i*/.wr_sw			(wr_evt),
/*i*/.rd_sw			(rd_evt),
/*i*/.ext_sel		(ext_sel),
/*i*/.ext_wr_base	(ext_wr_base),
/*i*/.ext_rd_base	(ext_rd_base),
                
/*o*/.wr_bank		(wr_bank	),
/*o*/.rd_bank		(rd_bank	),
/*o*/.rd_sw_ack	(rd_sw_ack),
/*o*/.wr_sw_ack (wr_sw_ack),
/*o*/.rd_start_addr(rd_start_addr),
/*o*/.wr_start_addr(wr_start_addr)
);

//! 帧边界事件(摄像头/显示 VSYNC 域)给 rec_play_ctrl
assign	o_wr_frame_done = wr_evt;
assign	o_rd_frame_done = rd_evt;

endmodule