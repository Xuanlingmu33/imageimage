//============================================================================
// gamma_correction.v
//   Synchronous 256->1024 gamma lookup table.
//
//   The original v9 implementation built a 1024x10 *distributed* RAM
//   (r_gamma_2P) so the synthesizer used ~20k LUTs / ~8k FFs.  This version
//   uses the existing 1024x10 block RAM directly and pipelines valid/hs/vs
//   by the same two cycles as the RAM read.
//============================================================================
module gamma_correction
#(
	parameter	DATA_WIDTH	= 10,
	parameter 	GAMMA_CURVE	= "2P2.mem"
)
(
	input						i_pclk,
	input						i_rstn,
			
	input 						i_valid,
	input 						i_hs,
	input 						i_vs,
	input 	[DATA_WIDTH-1:0]	i_red,
	input 	[DATA_WIDTH-1:0]	i_green,
	input 	[DATA_WIDTH-1:0]	i_blue,
		
	output	reg[DATA_WIDTH-1:0]	o_red,
	output	reg[DATA_WIDTH-1:0]	o_green,
	output	reg[DATA_WIDTH-1:0]	o_blue,
	output	reg					o_valid,
	output  reg  				o_hs,
	output 	reg 				o_vs
);

	wire	[9:0]	w_gamma_r;
	wire	[9:0]	w_gamma_g;
	wire	[9:0]	w_gamma_b;

	reg		[9:0]	r_addr_r;
	reg		[9:0]	r_addr_g;
	reg		[9:0]	r_addr_b;
	reg		[1:0]	r_vld_sr;
	reg		[1:0]	r_hs_sr;
	reg		[1:0]	r_vs_sr;

	// 8-bit pixel -> 10-bit table address (repeat the two MSBs, same as v9)
	wire [9:0] a_r = (DATA_WIDTH == 10) ? i_red   : {i_red,   i_red[7:6]};
	wire [9:0] a_g = (DATA_WIDTH == 10) ? i_green : {i_green, i_green[7:6]};
	wire [9:0] a_b = (DATA_WIDTH == 10) ? i_blue  : {i_blue,  i_blue[7:6]};

	true_dual_port_ram
	#(
		.DATA_WIDTH(10),
		.ADDR_WIDTH(10),
		.WRITE_MODE_1("WRITE_FIRST"),
		.WRITE_MODE_2("WRITE_FIRST"),
		.OUTPUT_REG_1("FALSE"),
		.OUTPUT_REG_2("FALSE"),
		.RAM_INIT_FILE(GAMMA_CURVE)
	)
	inst_gamma_r
	(
		.we1(1'b0), .we2(1'b0),
		.clka(i_pclk), .clkb(1'b0),
		.din1(10'b0), .din2(10'b0),
		.addr1(r_addr_r), .addr2(10'b0),
		.dout1(w_gamma_r), .dout2()
	);

	true_dual_port_ram
	#(
		.DATA_WIDTH(10),
		.ADDR_WIDTH(10),
		.WRITE_MODE_1("WRITE_FIRST"),
		.WRITE_MODE_2("WRITE_FIRST"),
		.OUTPUT_REG_1("FALSE"),
		.OUTPUT_REG_2("FALSE"),
		.RAM_INIT_FILE(GAMMA_CURVE)
	)
	inst_gamma_g
	(
		.we1(1'b0), .we2(1'b0),
		.clka(i_pclk), .clkb(1'b0),
		.din1(10'b0), .din2(10'b0),
		.addr1(r_addr_g), .addr2(10'b0),
		.dout1(w_gamma_g), .dout2()
	);

	true_dual_port_ram
	#(
		.DATA_WIDTH(10),
		.ADDR_WIDTH(10),
		.WRITE_MODE_1("WRITE_FIRST"),
		.WRITE_MODE_2("WRITE_FIRST"),
		.OUTPUT_REG_1("FALSE"),
		.OUTPUT_REG_2("FALSE"),
		.RAM_INIT_FILE(GAMMA_CURVE)
	)
	inst_gamma_b
	(
		.we1(1'b0), .we2(1'b0),
		.clka(i_pclk), .clkb(1'b0),
		.din1(10'b0), .din2(10'b0),
		.addr1(r_addr_b), .addr2(10'b0),
		.dout1(w_gamma_b), .dout2()
	);

	always @(posedge i_pclk or negedge i_rstn)
	begin
		if (!i_rstn)
		begin
			r_addr_r <= 10'd0;
			r_addr_g <= 10'd0;
			r_addr_b <= 10'd0;
			r_vld_sr <= 2'd0;
			r_hs_sr  <= 2'd0;
			r_vs_sr  <= 2'd0;
			o_red    <= {DATA_WIDTH{1'b0}};
			o_green  <= {DATA_WIDTH{1'b0}};
			o_blue   <= {DATA_WIDTH{1'b0}};
			o_valid  <= 1'b0;
			o_hs     <= 1'b0;
			o_vs     <= 1'b0;
		end
		else
		begin
			r_addr_r <= a_r;
			r_addr_g <= a_g;
			r_addr_b <= a_b;

			r_vld_sr <= {r_vld_sr[0], i_valid};
			r_hs_sr  <= {r_hs_sr[0],  i_hs};
			r_vs_sr  <= {r_vs_sr[0],  i_vs};

			o_valid <= r_vld_sr[1];
			o_hs    <= r_hs_sr[1];
			o_vs    <= r_vs_sr[1];

			if (DATA_WIDTH == 10)
			begin
				o_red   <= w_gamma_r;
				o_green <= w_gamma_g;
				o_blue  <= w_gamma_b;
			end
			else
			begin
				o_red   <= w_gamma_r[9:2];
				o_green <= w_gamma_g[9:2];
				o_blue  <= w_gamma_b[9:2];
			end
		end
	end

endmodule
