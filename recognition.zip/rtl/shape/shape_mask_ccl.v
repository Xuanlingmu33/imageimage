//============================================================================
// shape_mask_ccl.v
//   Binary mask (320x240, 2x2 downsample) + connected-component analysis.
//
//   * Camera pixel -> luma threshold -> 2x2 OR -> 1 bit mask
//   * Mask is packed 8 pixels / byte in a 9600x8 block RAM.
//   * At every frame start a small FSM scans the previous frame's mask:
//       - row run-length extraction
//       - row-run matching to objects (area, bbox, first/last run width,
//         number of runs)
//       - pruning by area/size/ROI
//       - classification by fill ratio + run profile (circle / triangle /
//         rectangle / plus).  A hollow circle (ring) is detected by the
//         two-runs-per-row signature.
//       - pick the four largest objects for the display overlay.
//
//   Scan is 200 rows x 40 bytes x 8 bits; it finishes in ~3.2 ms at 25.2 MHz,
//   which is much faster than the camera writes a frame, so a single mask
//   bank is enough (the scan stays ahead of the write pointer).
//============================================================================
module shape_mask_ccl #(
    parameter MASK_W       = 320,
    parameter MASK_H       = 240,
    parameter SCAN_ROWS    = 200,   // ignore the bottom part (digits area)
    parameter DARK_THRESH  = 96,
    parameter AUTO_THRESH  = 1,     // 1 = adaptive threshold from scene average
    parameter THR_MIN      = 40,
    parameter THR_MAX      = 180,
    parameter THR_OFFSET   = 50,    // auto threshold = avg_luma - offset
    parameter MIN_RUN      = 2,     // ignore 1-pixel runs (sensor noise)
    parameter MIN_AREA     = 260,
    parameter MIN_DIM      = 10,
    parameter MAX_DIM      = 180,   // reject giant blobs (full-screen false box)
    parameter MAX_AREA     = 24000,
    parameter MAX_OBJ      = 16,
    parameter ROI_Y1       = 200
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire [7:0]  r,
    input  wire [7:0]  g,
    input  wire [7:0]  b,
    input  wire        de,
    input  wire        hs,
    input  wire        vs,
    input  wire [9:0]  x,
    input  wire [9:0]  y,

    output reg  [43:0] shp0,
    output reg  [43:0] shp1,
    output reg  [43:0] shp2,
    output reg  [43:0] shp3,
    output reg  [3:0]  det_count
);

    localparam BYTES_PER_ROW = MASK_W / 8;        // 40
    localparam MASK_BYTES    = MASK_H * BYTES_PER_ROW; // 9600

    //------------------------------------------------------------------
    // mask generation
    //------------------------------------------------------------------
    wire [15:0] luma_sum = (r * 16'd77) + (g * 16'd150) + (b * 16'd29);
    wire [7:0]  luma     = luma_sum[15:8];

    // Adaptive threshold: track the scene average luma with a slow IIR and
    // use (average - offset) as the black-object threshold.  This keeps a
    // margin on low-contrast paper (grey shape on off-white paper), while
    // still sitting between the black shape and the white background.
    reg  [7:0]  avg_luma;
    wire [8:0]  avg_minus = (avg_luma > THR_OFFSET) ?
                            (avg_luma - THR_OFFSET) : 9'd0;
    wire [7:0]  auto_thr = (avg_minus < THR_MIN) ? THR_MIN :
                           (avg_minus > THR_MAX) ? THR_MAX : avg_minus[7:0];
    wire [7:0]  dark_thr = AUTO_THRESH ? auto_thr : DARK_THRESH;
    wire        dark     = (luma < dark_thr);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            avg_luma <= 8'd128;
        else if (de && (x[1:0] == 2'b00)) begin
            if (luma > avg_luma)
                avg_luma <= avg_luma + ((luma - avg_luma) >> 4);
            else
                avg_luma <= avg_luma - ((avg_luma - luma) >> 4);
        end
    end

    reg         dark_d;
    reg [319:0] row_even;
    reg [7:0]   mask_byte;

    reg         mask_we;
    reg [13:0]  mask_waddr;
    reg [7:0]   mask_wdata;

    wire [8:0]  block_x = x[9:1];       // 0..319
    wire [8:0]  block_y = y[9:1];       // 0..239
    wire        block_dark = row_even[block_x] | dark_d | dark;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            dark_d     <= 1'b0;
            mask_byte  <= 8'd0;
            mask_we    <= 1'b0;
            mask_waddr <= 14'd0;
            mask_wdata <= 8'd0;
            row_even   <= 320'd0;
        end else begin
            mask_we <= 1'b0;

            if (de) begin
                dark_d <= dark;
                if (!x[0]) begin
                    if (!y[0])
                        row_even[block_x] <= dark;
                end else begin
                    mask_byte[block_x[2:0]] <= block_dark;
                    if (block_x[2:0] == 3'd7) begin
                        mask_we    <= 1'b1;
                        mask_waddr <= (block_y * BYTES_PER_ROW) + block_x[8:3];
                        mask_wdata <= {block_dark, mask_byte[6:0]};
                    end
                end
            end
        end
    end

    //------------------------------------------------------------------
    // mask RAM: one write port (camera), one read port (scanner)
    //------------------------------------------------------------------
    (* syn_ramstyle = "block_ram" *) reg [7:0] mask_mem [0:MASK_BYTES-1];

    always @(posedge clk) begin
        if (mask_we)
            mask_mem[mask_waddr] <= mask_wdata;
    end

    // scanner state
    reg  [8:0]  row;
    reg  [5:0]  byte_i;
    reg  [2:0]  bit_i;
    wire [13:0] scan_addr = (row * BYTES_PER_ROW) + byte_i;
    reg  [7:0]  scan_data;

    always @(posedge clk) begin
        scan_data <= mask_mem[scan_addr];
    end

    //------------------------------------------------------------------
    // object arrays
    //------------------------------------------------------------------
    reg [8:0]  ox0 [0:MAX_OBJ-1];
    reg [8:0]  ox1 [0:MAX_OBJ-1];
    reg [8:0]  oy0 [0:MAX_OBJ-1];
    reg [8:0]  oy1 [0:MAX_OBJ-1];
    reg [8:0]  owf [0:MAX_OBJ-1];   // width of first run
    reg [8:0]  owl [0:MAX_OBJ-1];   // width of last run
    reg [8:0]  omxw[0:MAX_OBJ-1];   // max run width
    reg [8:0]  omxr[0:MAX_OBJ-1];   // row of max run width
    reg [8:0]  owup[0:MAX_OBJ-1];   // rows where width increased
    reg [8:0]  owdn[0:MAX_OBJ-1];   // rows where width decreased
    reg [8:0]  orn [0:MAX_OBJ-1];   // number of runs
    reg [17:0] oar [0:MAX_OBJ-1];   // area
    reg [8:0]  ols [0:MAX_OBJ-1];   // last row
    reg [2:0]  ocl [0:MAX_OBJ-1];   // class
    reg [MAX_OBJ-1:0] ova;

    reg        run;
    reg [8:0]  run_x0;

    //------------------------------------------------------------------
    // classification function
    //------------------------------------------------------------------
    function [2:0] classify;
        input [17:0] area;
        input [9:0]  w;
        input [9:0]  h;
        input [9:0]  wf;
        input [9:0]  wl;
        input [8:0]  runs;
        input [9:0]  mxw;
        input        max_low;
        input [8:0]  up;
        input [8:0]  dn;
        reg [31:0] wh;
        reg [31:0] a20;
        reg [9:0]  changes;
        reg [9:0]  diff;
        begin
            wh  = w * h;
            a20 = area * 20;
            changes = up + dn;
            diff    = (up > dn) ? (up - dn) : (dn - up);
            if ((runs * 4 > h * 5) && (w * 20 > h * 13) && (a20 < wh * 17))
                classify = 3'd1;                     // hollow ring (1.25h..1.5h runs)
            else if (a20 > wh * 17)
                classify = 3'd3;                     // rectangle / square (fill > 0.85)
            else if (a20 > wh * 14)
                classify = 3'd1;                     // filled circle / ellipse (fill > 0.70)
            else if ((a20 > wh * 7) && (a20 < wh * 13) &&
                     (runs * 2 < h * 3) &&
                     (((changes * 2 > h) && (diff * 20 > h * 7)) ||
                      ((changes * 5 > h * 4) && (diff * 10 > h))))
                classify = 3'd2;                     // triangle, tolerant to rotation
            else if ((runs * 2 < h * 3) &&
                     (wf * 6 > w) && (wl * 6 > w))
                classify = 3'd4;                     // plus: one-run-per-row, arms wide
            else
                classify = 3'd0;                     // unknown: diamond/star/blob/text
        end
    endfunction

    //------------------------------------------------------------------
    // add a row run to the object list
    //------------------------------------------------------------------
    task add_run;
        input [8:0] rx0;
        input [8:0] rx1;
        input [8:0] rrow;
        integer ti;
        reg found;
        reg [4:0] idx;
        reg [17:0] a;
        reg [8:0] nx0, nx1, ny0, ny1;
        reg [8:0] nwf, nwl;
        reg [8:0] nmxw, nmxr;
        reg [8:0] nup, ndn;
        reg       up_inc, dn_inc;
        reg [8:0] rlen;
        reg [8:0] nrn;
        begin
            rlen = rx1 - rx0 + 9'd1;
            a   = rlen;
            nx0 = rx0;
            nx1 = rx1;
            ny0 = rrow;
            ny1 = rrow;
            nwf = rlen;
            nwl = rlen;
            nmxw = rlen;
            nmxr = rrow;
            nup = 9'd0;
            ndn = 9'd0;
            up_inc = 1'b0;
            dn_inc = 1'b0;
            nrn = 9'd1;
            found = 1'b0;
            idx   = 5'd0;

            for (ti = 0; ti < MAX_OBJ; ti = ti + 1) begin
                if (ova[ti] &&
                    ((ols[ti] == rrow) || (ols[ti] + 9'd1 == rrow)) &&
                    (rx1 >= ox0[ti]) && (rx0 <= ox1[ti])) begin
                    a = a + oar[ti];
                    nrn = nrn + orn[ti];
                    nup = nup + owup[ti];
                    ndn = ndn + owdn[ti];
                    if (omxw[ti] > nmxw) begin
                        nmxw = omxw[ti];
                        nmxr = omxr[ti];
                    end
                    if (ox0[ti] < nx0) nx0 = ox0[ti];
                    if (ox1[ti] > nx1) nx1 = ox1[ti];
                    if (oy0[ti] < ny0) ny0 = oy0[ti];
                    if (oy1[ti] > ny1) ny1 = oy1[ti];
                    if (!found) begin
                        found = 1'b1;
                        idx   = ti[4:0];
                        nwf   = owf[ti];
                        if (rrow == ols[ti] + 9'd1) begin
                            if (rlen > owl[ti])
                                up_inc = 1'b1;
                            else if (rlen < owl[ti])
                                dn_inc = 1'b1;
                        end
                    end else begin
                        ova[ti] <= 1'b0;
                    end
                end
            end

            nup = nup + up_inc;
            ndn = ndn + dn_inc;

            if (found) begin
                ox0[idx] <= nx0;
                ox1[idx] <= nx1;
                oy0[idx] <= ny0;
                oy1[idx] <= ny1;
                owf[idx] <= nwf;
                owl[idx] <= nwl;
                omxw[idx] <= nmxw;
                omxr[idx] <= nmxr;
                owup[idx] <= nup;
                owdn[idx] <= ndn;
                orn[idx] <= nrn;
                oar[idx] <= a;
                ols[idx] <= rrow;
                ova[idx] <= 1'b1;
            end else begin
                found = 1'b0;
                for (ti = 0; ti < MAX_OBJ; ti = ti + 1) begin
                    if (!ova[ti] && !found) begin
                        found = 1'b1;
                        idx   = ti[4:0];
                    end
                end
                if (found) begin
                    ox0[idx] <= rx0;
                    ox1[idx] <= rx1;
                    oy0[idx] <= rrow;
                    oy1[idx] <= rrow;
                    owf[idx] <= rx1 - rx0 + 9'd1;
                    owl[idx] <= rx1 - rx0 + 9'd1;
                    omxw[idx] <= rx1 - rx0 + 9'd1;
                    omxr[idx] <= rrow;
                    owup[idx] <= 9'd0;
                    owdn[idx] <= 9'd0;
                    orn[idx] <= 9'd1;
                    oar[idx] <= rx1 - rx0 + 9'd1;
                    ols[idx] <= rrow;
                    ova[idx] <= 1'b1;
                    ocl[idx] <= 3'd0;
                end
            end
        end
    endtask

    //------------------------------------------------------------------
    // scanner FSM
    //------------------------------------------------------------------
    localparam S_IDLE      = 4'd0;
    localparam S_ROW       = 4'd1;
    localparam S_READ      = 4'd2;
    localparam S_BITS      = 4'd3;
    localparam S_EOR       = 4'd4;
    localparam S_PRUNE     = 4'd5;
    localparam S_CLS       = 4'd6;
    localparam S_SORT_ST   = 4'd7;
    localparam S_SORT_INIT = 4'd8;
    localparam S_SORT_SCAN = 4'd9;
    localparam S_SORT_TAKE = 4'd10;
    localparam S_DONE      = 4'd11;

    reg [3:0]  state;
    reg        vs_d;

    integer ci;
    integer pi;
    integer si;
    reg [2:0]  sk;
    reg [4:0]  best;
    reg [17:0] best_area;
    reg [15:0] sel;
    reg [9:0]  cw, ch;
    reg [17:0] ca;
    reg [2:0]  ccls;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state     <= S_IDLE;
            vs_d      <= 1'b0;
            row       <= 9'd0;
            byte_i    <= 6'd0;
            bit_i     <= 3'd0;
            run       <= 1'b0;
            run_x0    <= 9'd0;
            ova       <= {MAX_OBJ{1'b0}};
            shp0      <= 44'd0;
            shp1      <= 44'd0;
            shp2      <= 44'd0;
            shp3      <= 44'd0;
            det_count <= 4'd0;
            for (ci = 0; ci < MAX_OBJ; ci = ci + 1) begin
                ox0[ci] <= 9'd0;
                ox1[ci] <= 9'd0;
                oy0[ci] <= 9'd0;
                oy1[ci] <= 9'd0;
                owf[ci] <= 9'd0;
                owl[ci] <= 9'd0;
                omxw[ci] <= 9'd0;
                omxr[ci] <= 9'd0;
                owup[ci] <= 9'd0;
                owdn[ci] <= 9'd0;
                orn[ci] <= 9'd0;
                oar[ci] <= 18'd0;
                ols[ci] <= 9'd0;
                ocl[ci] <= 3'd0;
            end
        end else begin
            vs_d <= vs;

            case (state)
                S_IDLE: begin
                    if (vs && !vs_d) begin
                        row       <= 9'd0;
                        byte_i    <= 6'd0;
                        bit_i     <= 3'd0;
                        run       <= 1'b0;
                        ova       <= {MAX_OBJ{1'b0}};
                        // Keep the previous frame's shp0..3/det_count until the
                        // new detection finishes.  The stabilizer samples them
                        // at this vs edge; clearing here would make it see 0.
                        state     <= S_ROW;
                    end
                end

                S_ROW: begin
                    if (row >= SCAN_ROWS) begin
                        state <= S_PRUNE;
                    end else begin
                        byte_i <= 6'd0;
                        bit_i  <= 3'd0;
                        run    <= 1'b0;
                        state  <= S_READ;
                    end
                end

                S_READ: begin
                    state <= S_BITS;
                end

                S_BITS: begin
                    if (scan_data[bit_i]) begin
                        if (!run) begin
                            run    <= 1'b1;
                            run_x0 <= {byte_i[5:0], bit_i};
                        end
                    end else if (run) begin
                        if (({byte_i[5:0], bit_i} - run_x0) >= MIN_RUN)
                            add_run(run_x0, {byte_i[5:0], bit_i} - 9'd1, row);
                        run <= 1'b0;
                    end

                    if (bit_i == 3'd7) begin
                        if (byte_i == BYTES_PER_ROW - 1) begin
                            state <= S_EOR;
                        end else begin
                            byte_i <= byte_i + 6'd1;
                            bit_i  <= 3'd0;
                            state  <= S_READ;
                        end
                    end else begin
                        bit_i <= bit_i + 3'd1;
                    end
                end

                S_EOR: begin
                    if (run && ((9'd320 - run_x0) >= MIN_RUN))
                        add_run(run_x0, 9'd319, row);
                    run   <= 1'b0;
                    row   <= row + 9'd1;
                    state <= S_ROW;
                end

                S_PRUNE: begin
                    for (pi = 0; pi < MAX_OBJ; pi = pi + 1) begin
                        cw = ox1[pi] - ox0[pi] + 9'd1;
                        ch = oy1[pi] - oy0[pi] + 9'd1;
                        ca = oar[pi];
                        if (ova[pi] &&
                            (ca >= MIN_AREA) &&
                            (cw >= MIN_DIM) && (ch >= MIN_DIM) &&
                            (cw <= MAX_DIM) && (ch <= MAX_DIM) &&
                            (ca <= MAX_AREA) &&
                            !((ox0[pi] <= 9'd2) && (ox1[pi] >= MASK_W - 3)) &&
                            (oy0[pi] < ROI_Y1) &&
                            (cw * 3 >= ch) && (ch * 3 >= cw))   // Aspect <= 3:1
                            ocl[pi] <= 3'd0;
                        else if (ova[pi])
                            ova[pi] <= 1'b0;
                    end
                    state <= S_CLS;
                end

                S_CLS: begin
                    for (pi = 0; pi < MAX_OBJ; pi = pi + 1) begin
                        cw = ox1[pi] - ox0[pi] + 9'd1;
                        ch = oy1[pi] - oy0[pi] + 9'd1;
                        ca = oar[pi];
                        if (ova[pi]) begin
                            ccls = classify(ca, cw, ch, {1'b0, owf[pi]}, {1'b0, owl[pi]}, orn[pi],
                                            {1'b0, omxw[pi]},
                                            (((omxr[pi] - oy0[pi]) * 2) > ch),
                                            owup[pi], owdn[pi]);
                            if (ccls == 3'd0)
                                ova[pi] <= 1'b0;     // reject unknown disturbance
                            else
                                ocl[pi] <= ccls;
                        end
                    end
                    state <= S_SORT_ST;
                end

                S_SORT_ST: begin
                    sk        <= 3'd0;
                    sel       <= 16'd0;
                    det_count <= 4'd0;
                    shp0      <= 44'd0;
                    shp1      <= 44'd0;
                    shp2      <= 44'd0;
                    shp3      <= 44'd0;
                    state     <= S_SORT_INIT;
                end

                S_SORT_INIT: begin
                    best      <= 5'd0;
                    best_area <= 18'd0;
                    si        <= 0;
                    state     <= S_SORT_SCAN;
                end

                S_SORT_SCAN: begin
                    if (si >= MAX_OBJ) begin
                        state <= S_SORT_TAKE;
                    end else begin
                        if (ova[si] && !sel[si] && (oar[si] > best_area)) begin
                            best      <= si[4:0];
                            best_area <= oar[si];
                        end
                        si <= si + 1;
                    end
                end

                S_SORT_TAKE: begin
                    if (best_area != 18'd0) begin
                        case (sk)
                            3'd0: shp0 <= {1'b1, ocl[best], 1'b0, ox0[best], 1'b0, oy0[best], 1'b0, ox1[best], 1'b0, oy1[best]};
                            3'd1: shp1 <= {1'b1, ocl[best], 1'b0, ox0[best], 1'b0, oy0[best], 1'b0, ox1[best], 1'b0, oy1[best]};
                            3'd2: shp2 <= {1'b1, ocl[best], 1'b0, ox0[best], 1'b0, oy0[best], 1'b0, ox1[best], 1'b0, oy1[best]};
                            3'd3: shp3 <= {1'b1, ocl[best], 1'b0, ox0[best], 1'b0, oy0[best], 1'b0, ox1[best], 1'b0, oy1[best]};
                            default: ;
                        endcase
                        sel[best] <= 1'b1;
                        det_count <= {1'b0, sk} + 4'd1;
                        if (sk == 3'd3)
                            state <= S_DONE;
                        else begin
                            sk    <= sk + 3'd1;
                            state <= S_SORT_INIT;
                        end
                    end else begin
                        state <= S_DONE;
                    end
                end

                S_DONE: begin
                    state <= S_IDLE;
                end

                default: state <= S_IDLE;
            endcase
        end
    end

endmodule
