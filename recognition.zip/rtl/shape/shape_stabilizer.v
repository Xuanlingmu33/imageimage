//============================================================================
// shape_stabilizer.v
//   3-frame class confirmation for the recognition overlay.
//
//   The detector updates shp0..3 once per frame (during the frame).  At each
//   vsync we compare the new class of each slot with the previous class:
//     - same class for 3 consecutive frames -> commit the new bbox/class
//     - class changed / missing -> hold the last committed result
//     - missing for 3 consecutive frames -> clear the slot
//
//   This removes single-frame false positives and makes the box/label stop
//   flickering.  It is intentionally slot-based (not a full multi-target
//   tracker): the demo has a few static shapes and area-sorted slots.
//============================================================================
module shape_stabilizer (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        vs,          // frame sync (active high, 2 lines)
    input  wire [43:0] shp0,
    input  wire [43:0] shp1,
    input  wire [43:0] shp2,
    input  wire [43:0] shp3,
    input  wire [3:0]  det_count,   // raw detection count (debug / unused)

    output reg  [43:0] stb0,
    output reg  [43:0] stb1,
    output reg  [43:0] stb2,
    output reg  [43:0] stb3,
    output reg  [3:0]  stb_count
);

    reg        vs_d;

    reg [43:0] shp [0:3];
    reg [43:0] stb [0:3];
    reg [2:0]  last_cls [0:3];
    reg [1:0]  same_cnt [0:3];   // 0..3
    reg [1:0]  miss_cnt [0:3];   // 0..3

    integer i;

    always @* begin
        shp[0] = shp0;
        shp[1] = shp1;
        shp[2] = shp2;
        shp[3] = shp3;
    end

    // combinational stable count
    always @* begin
        stb_count = {1'b0, stb0[43]} + {1'b0, stb1[43]} +
                    {1'b0, stb2[43]} + {1'b0, stb3[43]};
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            vs_d <= 1'b0;
            for (i = 0; i < 4; i = i + 1) begin
                stb[i]      <= 44'd0;
                last_cls[i] <= 3'd0;
                same_cnt[i] <= 2'd0;
                miss_cnt[i] <= 2'd0;
            end
            stb0 <= 44'd0;
            stb1 <= 44'd0;
            stb2 <= 44'd0;
            stb3 <= 44'd0;
        end else begin
            vs_d <= vs;

            if (vs && !vs_d) begin
                for (i = 0; i < 4; i = i + 1) begin
                    if (shp[i][43]) begin
                        miss_cnt[i] <= 2'd0;

                        if (last_cls[i] == shp[i][42:40]) begin
                            if (same_cnt[i] < 2'd3)
                                same_cnt[i] <= same_cnt[i] + 2'd1;

                            // 3 consecutive frames (count reaches 3)
                            if (same_cnt[i] >= 2'd2)
                                stb[i] <= shp[i];
                        end else begin
                            last_cls[i] <= shp[i][42:40];
                            same_cnt[i] <= 2'd1;
                        end
                    end else begin
                        last_cls[i] <= 3'd0;
                        same_cnt[i] <= 2'd0;

                        if (miss_cnt[i] >= 2'd2)
                            stb[i] <= 44'd0;          // 3rd consecutive miss
                        else
                            miss_cnt[i] <= miss_cnt[i] + 2'd1;
                    end
                end
            end

            stb0 <= stb[0];
            stb1 <= stb[1];
            stb2 <= stb[2];
            stb3 <= stb[3];
        end
    end

    // det_count is kept in the port list for debug/optional use
    wire [3:0] unused_det_count = det_count;

endmodule
