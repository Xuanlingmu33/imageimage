//============================================================================
// edge_detect_640.v
//   Full-resolution binary edge map used for the "white contour" display.
//   A pixel is an edge when it is dark and at least one 4-neighbour is light.
//   Three 640-bit line buffers are used.  The edge pixel is produced one line
//   and two pixels late; for a 640x480 demo this is visually negligible.
//============================================================================
module edge_detect_640 (
    input  wire       clk,
    input  wire       rst_n,
    input  wire [7:0] r,
    input  wire [7:0] g,
    input  wire [7:0] b,
    input  wire       de,
    input  wire [9:0] x,
    input  wire [9:0] y,
    output wire       is_edge
);

    // integer luma, 8 bit
    wire [15:0] luma_sum = (r * 16'd77) + (g * 16'd150) + (b * 16'd29);
    wire [7:0]  luma     = luma_sum[15:8];
    wire        dark     = (luma < 8'd96);

    reg [639:0] line1, line2, line3;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            line1 <= 640'd0;
            line2 <= 640'd0;
            line3 <= 640'd0;
        end else if (de) begin
            line1 <= {line1[638:0], dark};
            line2 <= line1;
            line3 <= line2;
        end
    end

    wire center = line2[1];
    wire left   = line2[2];
    wire right  = line2[0];
    wire up     = line3[0];
    wire down   = line1[2];

    assign is_edge = de && (x >= 10'd2) && (y >= 10'd1) &&
                  center && ~(left & right & up & down);

endmodule
