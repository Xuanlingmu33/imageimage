//============================================================================
// shape_overlay.v
//   Draws transparent bounding boxes and Chinese labels on top of the
//   camera/edge image.  Colors follow the reference screenshot:
//       circle    = yellow
//       triangle  = magenta
//       rectangle = cyan
//       plus      = light grey
//
//   Label glyphs are 24x24, two characters (48x24) per shape.
//============================================================================
module shape_overlay (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [9:0]  x,
    input  wire [9:0]  y,
    input  wire [23:0] rgb_in,
    input  wire        is_edge,
    input  wire        view_mode,     // 0: camera + white contour, 1: black + contour
    input  wire [43:0] shp0,
    input  wire [43:0] shp1,
    input  wire [43:0] shp2,
    input  wire [43:0] shp3,
    output reg  [23:0] rgb_out
);

    localparam [23:0] C_WHITE  = 24'hFFFFFF;
    localparam [23:0] C_BLACK  = 24'h000000;
    localparam [23:0] C_CIRCLE = 24'hFFFF00;
    localparam [23:0] C_TRI    = 24'hFF00FF;
    localparam [23:0] C_RECT   = 24'h00FFFF;
    localparam [23:0] C_PLUS   = 24'hC0C0C0;

    // The reference screenshot draws boxes only for circle / triangle /
    // rectangle.  Set DRAW_PLUS=1 to also annotate the plus sign.
    localparam DRAW_PLUS = 1'b0;

    reg [43:0] sa [0:3];
    always @* begin
        sa[0] = shp0;
        sa[1] = shp1;
        sa[2] = shp2;
        sa[3] = shp3;
    end

    function [23:0] cls_color;
        input [2:0] c;
        begin
            case (c)
                3'd1:    cls_color = C_CIRCLE;
                3'd2:    cls_color = C_TRI;
                3'd3:    cls_color = C_RECT;
                3'd4:    cls_color = C_PLUS;
                default: cls_color = C_WHITE;
            endcase
        end
    endfunction

    integer i;
    reg [9:0] sx0, sy0, sx1, sy1;
    reg [9:0] lx, ly;
    reg [4:0] gx, gy;
    reg       char_sel;
    reg [2:0] char_code;
    reg [7:0] faddr;
    reg [4:0] fcol;
    reg [23:0] fcolor;
    reg       label_any;
    reg       box_any;
    reg [23:0] box_color;
    reg       box_hit;
    reg       in_lbl;
    reg [9:0] dx, dy;

    // selected font output
    wire [23:0] font_data;
    wire        glyph = font_data[23 - fcol];

    shape_font_rom u_font (
        .addr (faddr),
        .data (font_data)
    );

    always @* begin
        // defaults
        label_any = 1'b0;
        box_any   = 1'b0;
        box_color = C_WHITE;
        faddr     = 8'd0;
        fcol      = 5'd0;
        fcolor    = C_WHITE;

        // loop downwards so shape0 wins if labels overlap
        for (i = 3; i >= 0; i = i - 1) begin
            sx0 = sa[i][39:30] << 1;
            sy0 = sa[i][29:20] << 1;
            sx1 = (sa[i][19:10] << 1) + 10'd1;
            sy1 = (sa[i][9:0]   << 1) + 10'd1;

            // ---- label rectangle ----
            lx = (sx0 > 10'd592) ? 10'd592 : sx0;
            ly = (sy0 >= 10'd26) ? (sy0 - 10'd26) : (sy0 + 10'd2);
            in_lbl = (x >= lx) && (x < lx + 10'd48) &&
                     (y >= ly) && (y < ly + 10'd24);
            if (sa[i][43] && (DRAW_PLUS || (sa[i][42:40] != 3'd4)) && in_lbl) begin
                dx  = x - lx;
                dy  = y - ly;
                char_sel = (dx >= 10'd24);
                gx  = char_sel ? (dx - 10'd24) : dx;
                gy  = dy[4:0];
                case (sa[i][42:40])
                    3'd1: char_code = {2'b00, char_sel};
                    3'd2: char_code = {2'b01, char_sel};
                    3'd3: char_code = {2'b10, char_sel};
                    default: char_code = {2'b11, char_sel};
                endcase
                faddr  = {char_code, gy};
                fcol   = gx;
                fcolor = cls_color(sa[i][42:40]);
                label_any = 1'b1;
            end

            // ---- bounding box (2 pixels thick) ----
            box_hit = (x >= sx0) && (x <= sx1) && (y >= sy0) && (y <= sy1) &&
                      ((y <= sy0 + 10'd1) || (y + 10'd1 >= sy1) ||
                       (x <= sx0 + 10'd1) || (x + 10'd1 >= sx1));
            if (sa[i][43] && (DRAW_PLUS || (sa[i][42:40] != 3'd4)) && box_hit) begin
                box_any   = 1'b1;
                box_color = cls_color(sa[i][42:40]);
            end
        end
    end

    wire [23:0] base = view_mode ? (is_edge ? C_WHITE : C_BLACK)
                                 : (is_edge ? C_WHITE : rgb_in);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            rgb_out <= 24'd0;
        else if (label_any && glyph)
            rgb_out <= fcolor;
        else if (box_any)
            rgb_out <= box_color;
        else
            rgb_out <= base;
    end

endmodule
