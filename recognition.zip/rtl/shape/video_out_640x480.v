//============================================================================
// video_out_640x480.v
//   cvo_axi (2 Bayer pixels / clock) + debayer (2 RGB pixels / clock)
//   -> double-bank line buffer -> 1 RGB pixel / clock at 640x480@60
//
//   All logic runs at the display pixel clock (25.2 MHz with the new PLL).
//   cvo_axi is stretched to a 800-clock line by using a large H back porch
//   (HBP = 848 pixel units => 424 cvo clocks).  The active data therefore
//   arrives late in the line and is stored into the line buffer while the
//   previous line is being read out.
//
//   Read timing:
//       h_cnt 144 .. 782 (even) : issue line-buffer word read
//       h_cnt 146 .. 785        : 640 active pixels
//   This gives standard 640x480 timing:
//       H: 96 sync + 50 back porch + 640 active + 14 front porch = 800
//       V: 2 sync + 33 back porch + 480 active + 10 front porch = 525
//============================================================================
module video_out_640x480 (
    input  wire        clk,
    input  wire        rst_n,

    // timing reference from cvo_axi (must have an 800-clock line / 525 lines)
    input  wire        hs_in,
    input  wire        vs_in,

    // debayer output: two RGB pixels per clock, {B1,G1,R1,B0,G0,R0}
    input  wire [47:0] rgb2_in,
    input  wire        rgb2_de,

    output reg  [23:0] pix_out,
    output reg         pix_de,
    output reg         pix_hs,
    output reg         pix_vs,
    output reg  [9:0]  pix_x,
    output reg  [9:0]  pix_y
);

    localparam H_TOTAL = 800;
    localparam H_SYNC  = 96;
    localparam H_ACT   = 640;
    localparam V_TOTAL = 525;
    localparam V_SYNC  = 2;
    localparam V_BP    = 33;
    localparam V_ACT   = 480;

    reg  [9:0] h_cnt;
    reg  [9:0] v_cnt;
    reg        hs_d, vs_d;
    reg        line_bank;

    wire hs_rise = hs_in & ~hs_d;
    wire vs_rise = vs_in & ~vs_d;
    wire v_active = (v_cnt >= V_BP) && (v_cnt < V_BP + V_ACT);

    //------------------------------------------------------------------
    // display timing counters, re-synchronised by cvo hsync/vsync
    //------------------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            h_cnt     <= 10'd0;
            v_cnt     <= 10'd0;
            hs_d      <= 1'b0;
            vs_d      <= 1'b0;
            line_bank <= 1'b0;
        end else begin
            hs_d <= hs_in;
            vs_d <= vs_in;

            if (hs_rise)
                h_cnt <= 10'd0;
            else if (h_cnt == H_TOTAL - 1)
                h_cnt <= 10'd0;
            else
                h_cnt <= h_cnt + 10'd1;

            if (vs_rise)
                v_cnt <= 10'd0;
            else if (h_cnt == H_TOTAL - 1)
                v_cnt <= (v_cnt == V_TOTAL - 1) ? 10'd0 : v_cnt + 10'd1;

            if (vs_rise)
                line_bank <= 1'b0;
            else if (h_cnt == H_TOTAL - 1)
                line_bank <= ~line_bank;
        end
    end

    //------------------------------------------------------------------
    // write side: two RGB pixels per clock into bank line_bank
    //------------------------------------------------------------------
    reg  [8:0]  wr_addr;
    wire        wr_en   = rgb2_de && (wr_addr < 10'd320);
    wire [9:0]  wr_word_addr = {line_bank, wr_addr};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            wr_addr <= 9'd0;
        else if (!rgb2_de)
            wr_addr <= 9'd0;
        else if (wr_addr < 9'd320)
            wr_addr <= wr_addr + 9'd1;
    end

    // 640 words x 48 bit (two banks of 320 words)
    (* syn_ramstyle = "block_ram" *) reg [47:0] line_buf [0:639];

    always @(posedge clk) begin
        if (wr_en)
            line_buf[wr_word_addr] <= rgb2_in;
    end

    //------------------------------------------------------------------
    // read side: one 48-bit word (2 pixels) every two clocks
    //------------------------------------------------------------------
    reg  [8:0]  rd_addr;
    reg         rd_en;
    reg  [47:0] rd_data;
    wire        rd_bank = ~line_bank;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rd_addr <= 9'd0;
            rd_en   <= 1'b0;
        end else begin
            if (v_active && (h_cnt >= 10'd144) && (h_cnt <= 10'd782) && ~h_cnt[0]) begin
                rd_en   <= 1'b1;
                rd_addr <= (h_cnt - 10'd144) >> 1;
            end else begin
                rd_en <= 1'b0;
            end
        end
    end

    always @(posedge clk) begin
        if (rd_en)
            rd_data <= line_buf[{rd_bank, rd_addr}];
    end

    //------------------------------------------------------------------
    // output pixels, counted from h_cnt = 146
    //------------------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pix_out <= 24'd0;
            pix_de  <= 1'b0;
            pix_hs  <= 1'b0;
            pix_vs  <= 1'b0;
            pix_x   <= 10'd0;
            pix_y   <= 10'd0;
        end else begin
            pix_hs <= (h_cnt < H_SYNC);
            pix_vs <= (v_cnt < V_SYNC);

            if (v_active && (h_cnt >= 10'd146) && (h_cnt <= 10'd785)) begin
                pix_de <= 1'b1;
                pix_x  <= h_cnt - 10'd146;
                pix_y  <= v_cnt - V_BP;
                // first active line has no previous-frame line ready: black
                if (v_cnt == V_BP)
                    pix_out <= 24'd0;
                else if (h_cnt[0])
                    // debayer word is {B1,G1,R1,B0,G0,R0} -> convert to RGB
                    pix_out <= {rd_data[31:24], rd_data[39:32], rd_data[47:40]};
                else
                    pix_out <= {rd_data[ 7: 0], rd_data[15: 8], rd_data[23:16]};
            end else begin
                pix_de  <= 1'b0;
                pix_out <= 24'd0;
                pix_x   <= 10'd0;
                pix_y   <= 10'd0;
            end
        end
    end

endmodule
