#!/usr/bin/env python3
"""Quantitative evaluation for the simple shape recognizer.

Runs the parameterized Python model (detector.py) over dataset.py cases and
reports:
  - per-class precision / recall / F1
  - confusion matrix
  - bbox IoU
  - rejection false-positive rate on diamond/star/text/touching cases
  - accuracy vs. degradation axis
  - 5-frame stability (3-frame class hold + bbox jitter)
  - CSV + failure PNGs
  - optional parameter grid search

Usage:
  python sim/eval.py --out sim/results/baseline
  python sim/eval.py --grid quick --out sim/results/grid
  python sim/eval.py --emit-rtl 6 --out sim/results/rtl_cases
"""
import argparse
import csv
import json
import os
import sys
from collections import Counter, defaultdict

import numpy as np
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, os.path.dirname(__file__))
import cam_sim as C
import dataset as D
from detector import Params, make_mask, detect

CLASSES = {1: "circle", 2: "triangle", 3: "rectangle", 4: "plus"}
CMAP = {1: (255, 220, 0), 2: (0, 255, 255), 3: (255, 0, 255), 4: (0, 255, 0)}


def iou(a, b):
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b
    ix0, iy0 = max(ax0, bx0), max(ay0, by0)
    ix1, iy1 = min(ax1, bx1), min(ay1, by1)
    if ix1 < ix0 or iy1 < iy0:
        return 0.0
    inter = (ix1 - ix0 + 1) * (iy1 - iy0 + 1)
    ua = (ax1 - ax0 + 1) * (ay1 - ay0 + 1)
    ub = (bx1 - bx0 + 1) * (by1 - by0 + 1)
    return inter / float(ua + ub - inter)


def match(dets, expected, thr=0.25):
    """Greedy one-to-one match by class + IoU. Returns (pairs, unmatched_exp,
    unmatched_det)."""
    pairs = []
    used_d = set()
    for ei, (name, x0, y0, x1, y1) in enumerate(expected):
        cls = {"circle": 1, "triangle": 2, "rectangle": 3, "plus": 4}[name]
        best, best_iou = -1, 0.0
        for di, d in enumerate(dets):
            if di in used_d or d["cls"] != cls:
                continue
            v = iou((d["x0"], d["y0"], d["x1"], d["y1"]),
                    (x0, y0, x1, y1))
            if v > best_iou:
                best_iou, best = v, di
        if best >= 0 and best_iou >= thr:
            pairs.append((ei, best, best_iou))
            used_d.add(best)
    um_e = [i for i in range(len(expected)) if i not in {p[0] for p in pairs}]
    um_d = [i for i in range(len(dets)) if i not in used_d]
    return pairs, um_e, um_d


def axis_of(case):
    p = case.degrade
    keys = []
    if p.get("bayer"):
        keys.append("bayer")
    if p.get("noise", 0) > 0:
        keys.append("noise")
    if p.get("blur", 0) > 0:
        keys.append("blur")
    if p.get("exposure", 1.0) != 1.0:
        keys.append("exposure")
    if p.get("gamma", 1.0) != 1.0:
        keys.append("gamma")
    if p.get("wb", (1, 1, 1))[1] != 1.0:
        keys.append("wb")
    if p.get("vignette", 0) > 0:
        keys.append("vignette")
    if p.get("distort", 0) > 0:
        keys.append("distort")
    if p.get("motion", 0) > 0:
        keys.append("motion")
    if p.get("shadow", 0) > 0:
        keys.append("shadow")
    if p.get("reflect", 0) > 0:
        keys.append("reflect")
    if p.get("grad", (0, 0)) != (0, 0):
        keys.append("grad")
    if p.get("black_level", 0) > 0:
        keys.append("black")
    if p.get("shape_gray", 18) > 40:
        keys.append("contrast")
    if len(keys) == 0:
        return "clean"
    if len(keys) > 2:
        return "combined"
    return "+".join(keys)


def draw_overlay(frame, case, dets):
    img = Image.fromarray(frame)
    d = ImageDraw.Draw(img)
    try:
        f = ImageFont.truetype(r"C:\Windows\Fonts\arial.ttf", 16)
    except Exception:
        f = ImageFont.load_default()
    for name, x0, y0, x1, y1 in case.expected:
        d.rectangle([x0 * 2, y0 * 2, x1 * 2, y1 * 2], outline=(180, 180, 180), width=1)
    for det in dets:
        x0, y0, x1, y1 = det["x0"], det["y0"], det["x1"], det["y1"]
        col = CMAP.get(det["cls"], (255, 255, 255))
        d.rectangle([x0 * 2, y0 * 2, x1 * 2, y1 * 2], outline=col, width=2)
        d.text((x0 * 2 + 2, max(0, y0 * 2 - 18)),
               CLASSES.get(det["cls"], "?"), fill=col, font=f)
    return img


def evaluate(cases, p: Params, outdir, save_fail=True, verbose=True):
    os.makedirs(outdir, exist_ok=True)
    faildir = os.path.join(outdir, "failures")
    if save_fail:
        os.makedirs(faildir, exist_ok=True)

    rows = []
    cm = {c: Counter() for c in (0, 1, 2, 3, 4)}
    tp = Counter(); fp = Counter(); fn = Counter()
    reject_total = reject_clean = 0
    ious = []
    fail_reasons = Counter()
    axis_stat = defaultdict(lambda: [0, 0])   # axis -> [correct targets, total]
    axis_rej = defaultdict(lambda: [0, 0])

    for ci, case in enumerate(cases):
        rng = np.random.default_rng(case.seed)
        frames, expected = C.make_frames(case, rng, n=1)
        frame = frames[0]
        mask, thr = make_mask(frame, p)
        dets = detect(mask, p)

        if case.reject:
            reject_total += 1
            rej_ok = len(dets) == 0
            reject_clean += int(rej_ok)
            axis_rej[axis_of(case)][0] += int(rej_ok)
            axis_rej[axis_of(case)][1] += 1
            for d in dets:
                fp[d["cls"]] += 1
                fail_reasons["reject_fp"] += 1
            if not rej_ok:
                for d in dets:
                    fail_reasons["reject_fp"] += 1
            row_ok = rej_ok
            row_tp = 0
            row_fp = len(dets)
            row_fn = 0
            mean_iou = 0.0
        else:
            pairs, um_e, um_d = match(dets, expected)
            row_tp = len(pairs)
            row_fp = len(um_d)
            row_fn = len(um_e)
            row_ok = row_fn == 0 and row_fp == 0
            mean_iou = float(np.mean([p_[2] for p_ in pairs])) if pairs else 0.0
            if pairs:
                ious.append(mean_iou)
            for _, di, _ in pairs:
                d = dets[di]
                tp[d["cls"]] += 1
            for di in um_d:
                fp[dets[di]["cls"]] += 1
            for ei in um_e:
                name = expected[ei][0]
                cls = {"circle": 1, "triangle": 2, "rectangle": 3, "plus": 4}[name]
                fn[cls] += 1
                # reason: wrong class overlapping, or missed
                ex = expected[ei][1:]
                best = max((iou((d["x0"], d["y0"], d["x1"], d["y1"]), ex)
                            for d in dets), default=0.0)
                if best > 0.25:
                    fail_reasons["wrong_class"] += 1
                elif best > 0.05:
                    fail_reasons["low_iou"] += 1
                else:
                    fail_reasons["miss"] += 1
            # confusion matrix: one entry per expected target
            for ei, di, _ in pairs:
                name = expected[ei][0]
                cls = {"circle": 1, "triangle": 2, "rectangle": 3, "plus": 4}[name]
                cm[cls][dets[di]["cls"]] += 1
            for ei in um_e:
                name = expected[ei][0]
                cls = {"circle": 1, "triangle": 2, "rectangle": 3, "plus": 4}[name]
                cm[cls][0] += 1
            for di in um_d:
                cm[0][dets[di]["cls"]] += 1

        ax = axis_of(case)
        axis_stat[ax][0] += row_tp
        axis_stat[ax][1] += row_tp + row_fn

        rows.append(dict(
            name=case.name, scene=case.scene, axis=ax, reject=int(case.reject),
            expected=len(expected), detected=len(dets),
            tp=row_tp, fp=row_fp, fn=row_fn, iou=round(mean_iou, 3),
            ok=int(row_ok), thr=int(thr),
            det=";".join(f"{CLASSES.get(d['cls'],'?')}:{d['x0']},{d['y0']},{d['x1']},{d['y1']}"
                         for d in dets),
        ))

        if save_fail and not row_ok:
            img = draw_overlay(frame, case, dets)
            img.save(os.path.join(faildir, f"{case.name}.png"))

        if verbose and (ci + 1) % 10 == 0:
            print(f"  evaluated {ci+1}/{len(cases)}")

    # ---- metrics ----
    total_tp = sum(tp.values())
    total_fp = sum(fp.values())
    total_fn = sum(fn.values())
    macro_p = []
    macro_r = []
    for c in (1, 2, 3, 4):
        p_c = tp[c] / max(1, tp[c] + fp[c])
        r_c = tp[c] / max(1, tp[c] + fn[c])
        macro_p.append(p_c); macro_r.append(r_c)
    macro_p = float(np.mean(macro_p))
    macro_r = float(np.mean(macro_r))
    micro_p = total_tp / max(1, total_tp + total_fp)
    micro_r = total_tp / max(1, total_tp + total_fn)

    # ---- write CSV ----
    csv_path = os.path.join(outdir, "cases.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

    # ---- write confusion ----
    conf_path = os.path.join(outdir, "confusion.csv")
    with open(conf_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["expected\\pred", "missed", "circle", "triangle", "rectangle", "plus", "extra_fp"])
        for c in (1, 2, 3, 4):
            w.writerow([CLASSES[c], cm[c][0], cm[c][1], cm[c][2], cm[c][3], cm[c][4],
                        fp[c]])
        w.writerow(["reject_fp", "", "", "", "", "", total_fp])

    # ---- summary ----
    lines = []
    lines.append(f"cases={len(cases)}  params={p}")
    lines.append(f"targets: TP={total_tp} FP={total_fp} FN={total_fn}")
    lines.append(f"micro precision={micro_p:.3f} recall={micro_r:.3f}")
    lines.append(f"macro precision={macro_p:.3f} recall={macro_r:.3f}")
    lines.append("per-class:")
    for c in (1, 2, 3, 4):
        p_c = tp[c] / max(1, tp[c] + fp[c])
        r_c = tp[c] / max(1, tp[c] + fn[c])
        lines.append(f"  {CLASSES[c]:9s} TP={tp[c]:4d} FP={fp[c]:4d} FN={fn[c]:4d} "
                     f"P={p_c:.3f} R={r_c:.3f}")
    lines.append(f"bbox IoU mean={np.mean(ious):.3f}" if ious else "bbox IoU mean=n/a")
    lines.append(f"reject cases: {reject_clean}/{reject_total} clean = "
                 f"{100.0*reject_clean/max(1,reject_total):.1f}%")
    lines.append("degradation axis (target recall):")
    for ax, (a, b) in sorted(axis_stat.items()):
        lines.append(f"  {ax:14s} {a}/{b} = {100.0*a/max(1,b):.1f}%")
    lines.append("rejection by axis:")
    for ax, (a, b) in sorted(axis_rej.items()):
        lines.append(f"  {ax:14s} {a}/{b} = {100.0*a/max(1,b):.1f}%")
    lines.append("failure reasons:")
    for k, v in fail_reasons.most_common():
        lines.append(f"  {k}: {v}")

    summary = "\n".join(lines)
    with open(os.path.join(outdir, "summary.txt"), "w", encoding="utf-8") as f:
        f.write(summary + "\n")
    with open(os.path.join(outdir, "params.json"), "w", encoding="utf-8") as f:
        json.dump(p.__dict__, f, indent=2)

    if verbose:
        print(summary)
    return dict(micro_p=micro_p, micro_r=micro_r, macro_p=macro_p, macro_r=macro_r,
                tp=total_tp, fp=total_fp, fn=total_fn,
                reject_clean=reject_clean, reject_total=reject_total)


def sequence_stability(cases, p, outdir):
    rows = []
    for case in cases:
        if case.frames < 2:
            continue
        rng = np.random.default_rng(case.seed)
        frames, expected = C.make_frames(case, rng, n=case.frames)
        last_cls = [0] * 4
        same = [0] * 4
        miss = [0] * 4
        stable = [None] * 4
        centers = defaultdict(list)
        classes_per_frame = []
        for fi, frame in enumerate(frames):
            mask, _ = make_mask(frame, p)
            dets = detect(mask, p)
            classes_per_frame.append([d["cls"] for d in dets])
            for i in range(4):
                if i < len(dets):
                    d = dets[i]
                    cls = d["cls"]
                    if cls == last_cls[i]:
                        same[i] = min(3, same[i] + 1)
                    else:
                        same[i] = 1; last_cls[i] = cls
                    miss[i] = 0
                    if same[i] >= 3:
                        stable[i] = d
                    key = (d["cls"], i)
                    centers[key].append(((d["x0"] + d["x1"]) / 2,
                                         (d["y0"] + d["y1"]) / 2))
                else:
                    miss[i] += 1
                    same[i] = 0
                    if miss[i] >= 3:
                        stable[i] = None
        exp_cls = sorted({"circle": 1, "triangle": 2, "rectangle": 3, "plus": 4}[e[0]]
                         for e in expected)
        stable_cls = sorted(s["cls"] for s in stable if s)
        ok = stable_cls == exp_cls
        jit = []
        for key, pts in centers.items():
            if len(pts) >= 2:
                xs = [q[0] for q in pts]; ys = [q[1] for q in pts]
                jit.append(float(np.std(xs) + np.std(ys)))
        rows.append(dict(name=case.name, expected=stable_cls, stable=stable_cls,
                         ok=int(ok), jitter=round(float(np.mean(jit)) if jit else 0.0, 2),
                         frames=";".join("".join(map(str, c)) for c in classes_per_frame)))
    path = os.path.join(outdir, "stability.csv")
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["name", "expected", "stable", "ok", "jitter", "frames"])
        w.writeheader(); w.writerows(rows)
    if rows:
        print(f"stability: {sum(r['ok'] for r in rows)}/{len(rows)} sequences stable, "
              f"mean bbox jitter={np.mean([r['jitter'] for r in rows]):.2f} px")
    return rows


def grid_search(cases, base: Params, outdir, quick=True):
    grid = []
    areas = (180, 240, 300)
    circs = (0.68, 0.70, 0.72)
    runs = (1, 2)
    thrs = (40, 50, 60)
    for a in areas:
        for c in circs:
            for r in runs:
                for off in thrs:
                    p = Params(**base.__dict__)
                    p.min_area = a; p.fill_circ = c; p.min_run = r
                    p.thr_offset = off
                    grid.append(p)
    if quick:
        grid = grid[::3]
    print(f"grid search {len(grid)} combos")
    best, best_score, best_res = None, -1, None
    for i, p in enumerate(grid):
        res = evaluate(cases, p, os.path.join(outdir, "tmp"), save_fail=False, verbose=False)
        # macro recall + rejection, penalize false positives
        score = res["macro_r"] + (res["reject_clean"] / max(1, res["reject_total"])) \
                - 0.3 * (res["fp"] / max(1, len(cases)))
        if score > best_score:
            best_score, best, best_res = score, p, res
        if (i + 1) % 10 == 0:
            print(f"  {i+1}/{len(grid)} best={best_score:.3f}")
    print(f"BEST score={best_score:.3f} params={best}")
    with open(os.path.join(outdir, "best_params.json"), "w", encoding="utf-8") as f:
        json.dump(best.__dict__, f, indent=2)
    with open(os.path.join(outdir, "best_summary.txt"), "w", encoding="utf-8") as f:
        f.write(str(best) + "\n" + str(best_res) + "\n")
    return best


def emit_rtl(cases, n, outdir):
    """Write RGB565 .hex + expected manifest for the first n target cases."""
    os.makedirs(outdir, exist_ok=True)
    chosen = [c for c in cases if not c.reject][:n]
    manifest = []
    for c in chosen:
        rng = np.random.default_rng(c.seed)
        frames, exp = C.make_frames(c, rng, n=1)
        arr = frames[0]
        r = (arr[:, :, 0] >> 3).astype(np.uint16)
        g = (arr[:, :, 1] >> 2).astype(np.uint16)
        b = (arr[:, :, 2] >> 3).astype(np.uint16)
        v = ((r << 11) | (g << 5) | b).reshape(-1)
        path = os.path.join(outdir, f"{c.name}.hex")
        with open(path, "w") as f:
            for w in v:
                f.write(f"{int(w):04x}\n")
        manifest.append(dict(name=c.name, expected=exp, degrade=c.degrade))
        Image.fromarray(arr).save(os.path.join(outdir, f"{c.name}.png"))
    with open(os.path.join(outdir, "manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)
    print(f"emitted {len(chosen)} RTL cases to {outdir}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="sim/results/baseline")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--grid", action="store_true")
    ap.add_argument("--grid-full", action="store_true")
    ap.add_argument("--emit-rtl", type=int, default=0)
    ap.add_argument("--no-fail-images", action="store_true")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    cases = D.build(seed=args.seed)
    if args.limit:
        cases = cases[:args.limit]
    os.makedirs(args.out, exist_ok=True)

    p = Params()
    if args.emit_rtl:
        emit_rtl(cases, args.emit_rtl, args.out)
        return

    res = evaluate(cases, p, args.out, save_fail=not args.no_fail_images)
    sequence_stability([c for c in cases if c.frames > 1], p, args.out)
    if args.grid:
        # grid on non-sequence cases for speed
        grid_cases = [c for c in cases if c.frames == 1]
        grid_search(grid_cases, p, args.out, quick=not args.grid_full)


if __name__ == "__main__":
    main()
