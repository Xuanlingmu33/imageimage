#!/usr/bin/env python3
"""Run a small RTL batch through tb_image.v and compare with the Python model.

Input directory is produced by:
  python sim/eval.py --emit-rtl 6 --out sim/results/rtl_cases

For each case:
  - copy <case>.hex to sim/case.hex (tb_image reads this fixed name)
  - run vvp sim/tb_image.vvp
  - parse frame 4 stable shapes
  - run detector.py on <case>.png and compare classes / bbox IoU

This is intentionally a *small* batch: one RTL run takes about a minute in
Icarus because five full 640x480 frames are streamed.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(__file__))
from detector import Params, make_mask, detect

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SIM = os.path.join(ROOT, "sim")
CLASSES = {1: "circle", 2: "triangle", 3: "rectangle", 4: "plus"}
CMAP = {"circle": 1, "triangle": 2, "rectangle": 3, "plus": 4}


def compile_tb():
    cmd = [
        r"C:\iverilog\bin\iverilog.exe", "-o", os.path.join(SIM, "tb_image.vvp"),
        os.path.join(SIM, "tb_image.v"),
        os.path.join(ROOT, "rtl", "shape", "shape_mask_ccl.v"),
        os.path.join(ROOT, "rtl", "shape", "shape_stabilizer.v"),
    ]
    subprocess.run(cmd, check=True, cwd=ROOT)


def run_rtl(hex_path):
    shutil.copyfile(hex_path, os.path.join(SIM, "case.hex"))
    p = subprocess.run([r"C:\iverilog\bin\vvp.exe", os.path.join(SIM, "tb_image.vvp")],
                       cwd=ROOT, capture_output=True, text=True, timeout=600)
    out = p.stdout + p.stderr
    # use only the last frame block (frame 4)
    tail = out[out.rfind("===== frame 4"):] if "===== frame 4" in out else out
    shapes = []
    for m in re.finditer(r"shape(\d): class=(\d) bbox=\((\d+),(\d+)\)-\((\d+),(\d+)\)", tail):
        shapes.append((int(m.group(2)), int(m.group(3)), int(m.group(4)),
                       int(m.group(5)), int(m.group(6))))
    return shapes, out


def iou(a, b):
    ax0, ay0, ax1, ay1 = a; bx0, by0, bx1, by1 = b
    ix0, iy0 = max(ax0, bx0), max(ay0, by0)
    ix1, iy1 = min(ax1, bx1), min(ay1, by1)
    if ix1 < ix0 or iy1 < iy0:
        return 0.0
    inter = (ix1 - ix0 + 1) * (iy1 - iy0 + 1)
    ua = (ax1 - ax0 + 1) * (ay1 - ay0 + 1)
    ub = (bx1 - bx0 + 1) * (by1 - by0 + 1)
    return inter / float(ua + ub - inter)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default="sim/results/rtl_cases")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()
    d = os.path.join(ROOT, args.dir)
    with open(os.path.join(d, "manifest.json")) as f:
        manifest = json.load(f)
    if args.limit:
        manifest = manifest[:args.limit]

    compile_tb()
    p = Params()
    rows = []
    for item in manifest:
        name = item["name"]
        rtl, raw = run_rtl(os.path.join(d, f"{name}.hex"))
        img = np.asarray(Image.open(os.path.join(d, f"{name}.png")))
        mask, _ = make_mask(img, p)
        det = detect(mask, p)
        gold = [(x["cls"], x["x0"], x["y0"], x["x1"], x["y1"]) for x in det]
        # compare stable RTL list with golden list by class/IoU
        match = 0
        used = set()
        for r in rtl:
            best, bi = 0.0, -1
            for gi, g in enumerate(gold):
                if gi in used or g[0] != r[0]:
                    continue
                v = iou(r[1:], g[1:])
                if v > best:
                    best, bi = v, gi
            if bi >= 0 and best > 0.25:
                used.add(bi); match += 1
        rows.append((name, len(rtl), len(gold), match, rtl, gold))
        print(f"{name}: rtl={len(rtl)} gold={len(gold)} matched={match}")
        print(f"  RTL : {rtl}")
        print(f"  GOLD: {gold}")
    if rows:
        print(f"consistency: {sum(r[3] for r in rows)}/{sum(r[2] for r in rows)} "
              f"golden detections matched by RTL")


if __name__ == "__main__":
    main()
