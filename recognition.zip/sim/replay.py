#!/usr/bin/env python3
"""Convert a real 640x480 frame (PNG/JPG) to the RGB565 .hex stream used by
tb_image.v, optionally run the RTL replay.

Examples:
  python sim/replay.py --image real_frame.png --out sim/case.hex
  python sim/replay.py --image real_frame.png --run

For a frame captured on the board, export one 640x480 RGB frame as PNG/JPG,
then run this script and tb_image.  This is the same path used by the synthetic
dataset, so no RTL change is needed for real-frame replay.
"""
import argparse
import os
import subprocess
import sys

import numpy as np
from PIL import Image


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--out", default="sim/case.hex")
    ap.add_argument("--run", action="store_true")
    args = ap.parse_args()

    img = Image.open(args.image).convert("RGB")
    if img.size != (640, 480):
        img = img.resize((640, 480), Image.LANCZOS)
    arr = np.asarray(img)
    r = (arr[:, :, 0] >> 3).astype(np.uint16)
    g = (arr[:, :, 1] >> 2).astype(np.uint16)
    b = (arr[:, :, 2] >> 3).astype(np.uint16)
    v = ((r << 11) | (g << 5) | b).reshape(-1)
    with open(args.out, "w") as f:
        for w in v:
            f.write(f"{int(w):04x}\n")
    print(f"wrote {len(v)} pixels to {args.out}")

    if args.run:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        sim = os.path.join(root, "sim")
        subprocess.run([r"C:\iverilog\bin\iverilog.exe", "-o",
                        os.path.join(sim, "tb_image.vvp"),
                        os.path.join(sim, "tb_image.v"),
                        os.path.join(root, "rtl", "shape", "shape_mask_ccl.v"),
                        os.path.join(root, "rtl", "shape", "shape_stabilizer.v")],
                       check=True, cwd=root)
        p = subprocess.run([r"C:\iverilog\bin\vvp.exe",
                            os.path.join(sim, "tb_image.vvp")],
                           cwd=root, capture_output=True, text=True)
        print(p.stdout[-2000:])


if __name__ == "__main__":
    main()
