#!/usr/bin/env python3
"""Layered synthetic camera simulator for the shape recognizer.

Renders clean white-paper/black-shape scenes, then applies a configurable
pipeline of realistic degradations:

  geometry: scale, rotation, translation, partial out-of-frame
  optics:   blur, motion blur, radial distortion, vignetting
  sensor:   Bayer mosaic + simple demosaic, exposure, gamma, white balance,
            read noise + shot noise, black level / contrast
  light:    illumination gradient, local shadow, paper reflection
  scenes:   four targets, single shape, multi-target, text

The expected classes/bboxes are produced from the clean geometry (mask coords,
i.e. 320x240), so eval.py can compute recall/precision/IoU.
"""
from dataclasses import dataclass, field
import math
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H = 640, 480
S = 2  # supersample factor for anti-aliased shapes
FONT_PATH = r"C:\Windows\Fonts\simhei.ttf"


@dataclass
class Case:
    name: str
    scene: str
    shapes: list = field(default_factory=list)
    degrade: dict = field(default_factory=dict)
    expected: list = field(default_factory=list)   # (class, x0,y0,x1,y1) mask coords
    reject: bool = False
    frames: int = 1
    seed: int = 0


def _font(size):
    try:
        return ImageFont.truetype(FONT_PATH, size)
    except Exception:
        return ImageFont.load_default()


def _ellipse_pts(cx, cy, rx, ry, rot=0, n=64):
    pts = []
    cr, sr = math.cos(math.radians(rot)), math.sin(math.radians(rot))
    for k in range(n):
        a = 2 * math.pi * k / n
        x, y = rx * math.cos(a), ry * math.sin(a)
        pts.append((cx + x * cr - y * sr, cy + x * sr + y * cr))
    return pts


def _rect_pts(cx, cy, hw, hh, rot=0):
    cr, sr = math.cos(math.radians(rot)), math.sin(math.radians(rot))
    pts = []
    for x, y in [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)]:
        pts.append((cx + x * cr - y * sr, cy + x * sr + y * cr))
    return pts


def _plus_pts(cx, cy, arm, th, rot=0):
    pts = [(-th, -arm), (th, -arm), (th, -th), (arm, -th),
           (arm, th), (th, th), (th, arm), (-th, arm),
           (-th, th), (-arm, th), (-arm, -th), (-th, -th)]
    cr, sr = math.cos(math.radians(rot)), math.sin(math.radians(rot))
    return [(cx + x * cr - y * sr, cy + x * sr + y * cr) for x, y in pts]


def _star_pts(cx, cy, r, rot=0):
    pts = []
    for k in range(10):
        a = -math.pi / 2 + k * math.pi / 5 + math.radians(rot)
        rr = r if k % 2 == 0 else 0.45 * r
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    return pts


def _blob_pts(cx, cy, r, rng, rot=0):
    pts = []
    n = 10
    for k in range(n):
        a = 2 * math.pi * k / n
        rr = r * rng.uniform(0.55, 1.15)
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    return pts


def _bbox_of_pts(pts):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def _mask_bbox(x0, y0, x1, y1, clip=True):
    if clip:
        x0, x1 = max(0, x0), min(W * S, x1)
        y0, y1 = max(0, y0), min(H * S, y1)
    return (int(x0 / (2 * S)), int(y0 / (2 * S)),
                int(x1 / (2 * S)), int(y1 / (2 * S)))


def render(case: Case, rng):
    """Render high-res clean image + expected mask bboxes."""
    bg = case.degrade.get("bg", 232)
    black = case.degrade.get("shape_gray", 18)
    img = Image.new("RGB", (W * S, H * S), (int(bg), int(bg), int(bg)))
    d = ImageDraw.Draw(img)
    expected = []

    for sp in case.shapes:
        t = sp["type"]
        cx, cy = sp["cx"] * S, sp["cy"] * S
        r = sp.get("r", 80) * S
        rx, ry = sp.get("rx", sp.get("r", 80)) * S, sp.get("ry", sp.get("r", 80)) * S
        rot = sp.get("rot", 0)
        fill = (int(black), int(black), int(black))

        if t in ("circle_solid", "circle_ring", "ellipse"):
            pts = _ellipse_pts(cx, cy, rx, ry, rot)
            d.polygon(pts, fill=fill)
            if t == "circle_ring":
                inner = sp.get("inner", 0.58) * min(rx, ry)
                ipts = _ellipse_pts(cx, cy, inner, inner, rot)
                d.polygon(ipts, fill=(int(bg), int(bg), int(bg)))
            bx = _bbox_of_pts(pts)
            expected.append(("circle", *_mask_bbox(*bx)))
        elif t == "triangle":
            base = sp.get("base", 1.6 * sp.get("r", 80)) * S
            hei = sp.get("height", 1.8 * sp.get("r", 80)) * S
            pts0 = [(-base / 2, hei / 2), (base / 2, hei / 2), (0, -hei / 2)]
            cr, sr = math.cos(math.radians(rot)), math.sin(math.radians(rot))
            pts = [(cx + x * cr - y * sr, cy + x * sr + y * cr) for x, y in pts0]
            d.polygon(pts, fill=fill)
            expected.append(("triangle", *_mask_bbox(*_bbox_of_pts(pts))))
        elif t in ("rectangle", "square"):
            hw = sp.get("hw", sp.get("r", 80)) * S
            hh = sp.get("hh", sp.get("r", 80)) * S
            pts = _rect_pts(cx, cy, hw, hh, rot)
            d.polygon(pts, fill=fill)
            expected.append(("rectangle", *_mask_bbox(*_bbox_of_pts(pts))))
        elif t == "plus":
            arm = sp.get("arm", sp.get("r", 80)) * S
            th = sp.get("th", 0.28 * sp.get("r", 80)) * S
            pts = _plus_pts(cx, cy, arm, th, rot)
            d.polygon(pts, fill=fill)
            expected.append(("plus", *_mask_bbox(*_bbox_of_pts(pts))))
        elif t == "diamond":
            pts = [(cx, cy - r), (cx + r, cy), (cx, cy + r), (cx - r, cy)]
            d.polygon(pts, fill=fill)
        elif t == "star":
            pts = _star_pts(cx, cy, r, rot)
            d.polygon(pts, fill=fill)
        elif t == "thin_line":
            hw = sp.get("hw", sp.get("r", 80)) * S
            hh = sp.get("hh", 7) * S
            pts = _rect_pts(cx, cy, hw, hh, rot)
            d.polygon(pts, fill=fill)
        elif t == "blob":
            pts = _blob_pts(cx, cy, r, rng, rot)
            d.polygon(pts, fill=fill)
        elif t == "text":
            text = sp.get("text", "0")
            fs = int(sp.get("size", 180) * S)
            f = _font(fs)
            bb = d.textbbox((0, 0), text, font=f)
            tw, th = bb[2] - bb[0], bb[3] - bb[1]
            d.text((cx - tw / 2, cy - th / 2), text, font=f, fill=fill)
            expected.append(("text", *_mask_bbox(cx - tw/2, cy - th/2,
                                                 cx + tw/2, cy + th/2)))
        else:
            raise ValueError(t)

    img = img.resize((W, H), Image.LANCZOS)
    return img, expected


def apply_bayer(img, pattern="rggb", rng=None):
    """Mosaic + simple 8-neighbour bilinear demosaic (approximate but adds
    the colour fringing / resolution loss of a real CFA pipeline)."""
    a = np.asarray(img).astype(np.float32)
    R, G, B = a[:, :, 0], a[:, :, 1], a[:, :, 2]
    m = np.zeros_like(R)
    if pattern == "rggb":
        m[0::2, 0::2] = R[0::2, 0::2]
        m[0::2, 1::2] = G[0::2, 1::2]
        m[1::2, 0::2] = G[1::2, 0::2]
        m[1::2, 1::2] = B[1::2, 1::2]
        mr = np.zeros_like(R); mg = np.zeros_like(R); mb = np.zeros_like(R)
        mr[0::2, 0::2] = 1; mg[0::2, 1::2] = 1; mg[1::2, 0::2] = 1; mb[1::2, 1::2] = 1
    else:  # bggr
        m[0::2, 0::2] = B[0::2, 0::2]
        m[0::2, 1::2] = G[0::2, 1::2]
        m[1::2, 0::2] = G[1::2, 0::2]
        m[1::2, 1::2] = R[1::2, 1::2]
        mr = np.zeros_like(R); mg = np.zeros_like(R); mb = np.zeros_like(R)
        mb[0::2, 0::2] = 1; mg[0::2, 1::2] = 1; mg[1::2, 0::2] = 1; mr[1::2, 1::2] = 1

    def fill(mask):
        out = m * mask
        known = mask.copy()
        for _ in range(2):
            s = np.zeros_like(out); c = np.zeros_like(out)
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    if dx == 0 and dy == 0:
                        continue
                    s += np.roll(np.roll(out, dy, axis=0), dx, axis=1)
                    c += np.roll(np.roll(known, dy, axis=0), dx, axis=1)
            new = np.where(known > 0, out, s / np.maximum(c, 1))
            out = np.where((known == 0) & (c > 0), new, out)
            known = (known > 0) | (c > 0)
        return out

    rr, gg, bb = fill(mr), fill(mg), fill(mb)
    return np.clip(np.stack([rr, gg, bb], axis=2), 0, 255).astype(np.uint8)


def _gaussian_blob(shape, cx, cy, sx, sy, amp):
    yy, xx = np.mgrid[0:shape[0], 0:shape[1]]
    return amp * np.exp(-(((xx - cx) ** 2) / (2 * sx * sx) +
                          ((yy - cy) ** 2) / (2 * sy * sy)))


def degrade(img, p, rng):
    """p is a dict of degradation parameters; missing keys = no effect."""
    a = np.asarray(img).astype(np.float32)

    # paper/background black level & contrast
    black = p.get("black_level", 0.0)
    a = (a - black) * p.get("contrast", 1.0) + black

    # white balance (camera-side channel gains)
    wb = p.get("wb", (1.0, 1.0, 1.0))
    a[:, :, 0] *= wb[0]; a[:, :, 1] *= wb[1]; a[:, :, 2] *= wb[2]

    # exposure / gamma
    a *= p.get("exposure", 1.0)
    a += p.get("offset", 0.0)
    a = np.clip(a, 0, 255)
    g = p.get("gamma", 1.0)
    if g != 1.0:
        a = 255.0 * np.power(np.clip(a, 0, 255) / 255.0, g)

    # illumination gradient (left-right / top-bottom)
    gy, gx = p.get("grad", (0.0, 0.0))
    if gx or gy:
        yy, xx = np.mgrid[0:H, 0:W]
        illum = 1.0 + gx * (xx / W - 0.5) + gy * (yy / H - 0.5)
        a *= illum[:, :, None]

    # local shadow / reflection
    if p.get("shadow", 0):
        blob = _gaussian_blob((H, W), p.get("shadow_x", W*0.3),
                              p.get("shadow_y", H*0.5),
                              p.get("shadow_sx", 90), p.get("shadow_sy", 90),
                              p["shadow"])
        a *= np.clip(1.0 + blob, 0, 2)[:, :, None]
    if p.get("reflect", 0):
        blob = _gaussian_blob((H, W), p.get("reflect_x", W*0.7),
                              p.get("reflect_y", H*0.4),
                              p.get("reflect_sx", 30), p.get("reflect_sy", 30),
                              p["reflect"])
        a += blob[:, :, None]

    # vignetting
    v = p.get("vignette", 0.0)
    if v:
        yy, xx = np.mgrid[0:H, 0:W]
        r2 = ((xx - W/2) / (W/2)) ** 2 + ((yy - H/2) / (H/2)) ** 2
        a *= np.clip(1.0 - v * r2, 0, 1)[:, :, None]

    # radial lens distortion (nearest resample)
    k = p.get("distort", 0.0)
    if k:
        yy, xx = np.mgrid[0:H, 0:W]
        nx = (xx - W/2) / (W/2); ny = (yy - H/2) / (H/2)
        r2 = nx*nx + ny*ny
        sx = (nx * (1 + k*r2) * (W/2) + W/2).astype(np.int32)
        sy = (ny * (1 + k*r2) * (H/2) + H/2).astype(np.int32)
        sx = np.clip(sx, 0, W-1); sy = np.clip(sy, 0, H-1)
        a = a[sy, sx]

    # general blur
    blur = p.get("blur", 0.0)
    if blur:
        a = np.asarray(Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))
                       .filter(ImageFilter.GaussianBlur(blur))).astype(np.float32)

    # motion blur (shift-average)
    ml = p.get("motion", 0.0)
    if ml:
        ang = math.radians(p.get("motion_angle", 0.0))
        dx, dy = math.cos(ang), math.sin(ang)
        acc = np.zeros_like(a)
        n = max(1, int(ml))
        for t in range(-n, n + 1):
            sx = int(round(dx * t)); sy = int(round(dy * t))
            acc += np.roll(np.roll(a, sy, axis=0), sx, axis=1)
        a = acc / (2 * n + 1)

    # Bayer + demosaic (after optics, before noise/gamma? approximate)
    if p.get("bayer", False):
        a = apply_bayer(Image.fromarray(np.clip(a, 0, 255).astype(np.uint8)),
                        p.get("bayer_pattern", "rggb"), rng).astype(np.float32)

    # unsharp / sharpening
    sh = p.get("sharpen", 0.0)
    if sh:
        blur_img = np.asarray(Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))
                              .filter(ImageFilter.GaussianBlur(1.0))).astype(np.float32)
        a = a + sh * (a - blur_img)

    # read noise + shot noise
    noise = p.get("noise", 0.0)
    if noise:
        shot = np.sqrt(np.clip(a, 0, 255)) * p.get("shot", 0.7)
        a += rng.normal(0, noise, a.shape) + rng.normal(0, 1.0, a.shape) * shot

    # JPEG-ish / quantisation not simulated; clip
    return np.clip(a, 0, 255).astype(np.uint8)


def make_frames(case: Case, rng, n=None):
    n = n or case.frames
    base, exp = render(case, rng)
    frames = []
    for i in range(n):
        # small per-frame jitter (translation + tiny rotation)
        p = dict(case.degrade)
        jx = p.get("jitter", 0.0)
        if jx:
            p["offset"] = p.get("offset", 0.0) + rng.uniform(-jx, jx)
        f = degrade(base, p, rng)
        frames.append(f)
        if i == 0:
            case.expected = exp
    return frames, exp


# ---------------------------------------------------------------------------
# Case builders
# ---------------------------------------------------------------------------
def _shape(t, cx, cy, **kw):
    d = dict(type=t, cx=cx, cy=cy)
    d.update(kw)
    return d


def target4_case(scale=1.0, rot=(0, 0, 0, 0), **deg):
    s = scale
    shapes = [
        _shape("circle_ring", 110, 165, rx=58*s, ry=82*s, rot=rot[0]),
        _shape("triangle", 250, 160, r=92*s, rot=rot[1]),
        _shape("rectangle", 430, 160, hw=52*s, hh=88*s, rot=rot[2]),
        _shape("plus", 570, 165, arm=60*s, th=17*s, rot=rot[3]),
    ]
    c = Case("target4", "target4", shapes, deg, frames=1)
    return c


def single_case(kind, cx=320, cy=240, r=100, rot=0, **deg):
    s = r / 100.0
    if kind == "circle_solid":
        sp = _shape("circle_solid", cx, cy, rx=r, ry=r, rot=rot)
    elif kind == "circle_ring":
        sp = _shape("circle_ring", cx, cy, rx=r, ry=r*1.25, inner=0.58, rot=rot)
    elif kind == "ellipse":
        sp = _shape("ellipse", cx, cy, rx=r*1.3, ry=r*0.7, rot=rot)
    elif kind == "triangle":
        sp = _shape("triangle", cx, cy, r=r, rot=rot)
    elif kind == "rectangle":
        sp = _shape("rectangle", cx, cy, hw=r*0.75, hh=r*1.1, rot=rot)
    elif kind == "square":
        sp = _shape("square", cx, cy, hw=r*0.85, hh=r*0.85, rot=rot)
    elif kind == "plus":
        sp = _shape("plus", cx, cy, arm=r, th=r*0.26, rot=rot)
    elif kind == "diamond":
        sp = _shape("diamond", cx, cy, r=r)
    elif kind == "star":
        sp = _shape("star", cx, cy, r=r, rot=rot)
    elif kind == "thin_line":
        sp = _shape("thin_line", cx, cy, hw=r*1.4, hh=7)
    elif kind == "blob":
        sp = _shape("blob", cx, cy, r=r)
    elif kind == "text":
        sp = _shape("text", cx, cy, text="8", size=r*1.6)
    else:
        raise ValueError(kind)
    c = Case(kind, "single", [sp], deg, frames=1)
    if kind in ("diamond", "star", "thin_line", "blob", "text"):
        c.reject = True
    return c


def multi_case(kind="multi", **deg):
    # two/three separated targets, or touching (reject)
    if kind == "multi":
        shapes = [
            _shape("circle_solid", 170, 160, rx=75, ry=75),
            _shape("triangle", 320, 160, r=85),
            _shape("rectangle", 470, 160, hw=55, hh=85),
        ]
        c = Case("multi", "multi", shapes, deg, frames=1)
        return c
    if kind == "touching":
        shapes = [
            _shape("circle_solid", 270, 170, rx=70, ry=70),
            _shape("rectangle", 350, 170, hw=60, hh=80),
        ]
        c = Case("touching", "multi", shapes, deg, frames=1)
        c.reject = True
        return c
    raise ValueError(kind)
