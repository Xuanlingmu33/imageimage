@echo off
rem Full realistic-degradation evaluation (66 cases, 5-frame sequences)
setlocal
set ROOT=%~dp0..
cd /d "%ROOT%"
python sim\eval.py --out sim\results\latest %*
endlocal
