`timescale 1ns/1ps
module tb_debayer;
    reg clk=0; always #19.841 clk=~clk;
    reg rst_n=0;
    reg hs=0,vs=0,de=0;
    reg [15:0] raw=0;
    wire rgb_vs,rgb_hs,rgb_de,rgb_valid;
    wire [47:0] rgb2;

    debayer_top_2to1 u(
        .in_pclk(clk), .in_rstn(rst_n),
        .raw_vs_i(vs), .raw_hs_i(hs), .raw_de_i(de), .raw_valid_i(de),
        .raw_datax4_i(raw),
        .r_gain(16'd256), .g_gain(16'd256), .b_gain(16'd256),
        .rgb_vs_o(rgb_vs), .rgb_hs_o(rgb_hs), .rgb_de_o(rgb_de), .rgb_valid_o(rgb_valid),
        .rgb_datax2_o(rgb2)
    );

    integer lc,hc, first_de=-1, last_de=-1, first_hs=-1;
    reg rgb_de_d=0, rgb_hs_d=0;
    always @(posedge clk) begin
        if (rgb_de != rgb_de_d) $display("rgb_de %b at lc=%0d hc=%0d", rgb_de, lc, hc);
        if (rgb_hs != rgb_hs_d) $display("rgb_hs %b at lc=%0d hc=%0d", rgb_hs, lc, hc);
        rgb_de_d <= rgb_de; rgb_hs_d <= rgb_hs;
    end
    initial begin
        repeat(10) @(posedge clk);
        rst_n=1;
        for (lc=0; lc<6; lc=lc+1) begin
            for (hc=0; hc<800; hc=hc+1) begin
                hs=(hc<48); vs=(lc<2); de=(hc>=480); raw=hc[15:0];
                @(posedge clk);
                if (lc==3) begin
                    if (rgb_de && first_de<0) first_de=hc;
                    if (!rgb_de && first_de>=0 && last_de<0) last_de=hc-1;
                    if (rgb_hs && first_hs<0) first_hs=hc;
                end
            end
        end
        $display("input de=480..799; observed debayer de first=%0d last=%0d hs_first=%0d", first_de, last_de, first_hs);
        $finish;
    end
endmodule
