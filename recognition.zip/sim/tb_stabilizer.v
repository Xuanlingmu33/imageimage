`timescale 1ns/1ps
//============================================================================
// tb_stabilizer.v - 3-frame class confirmation check
//============================================================================
module tb_stabilizer;
    reg clk = 0;
    always #19.841 clk = ~clk;

    reg rst_n = 0;
    reg vs = 0;
    reg [43:0] shp0, shp1, shp2, shp3;
    wire [43:0] stb0, stb1, stb2, stb3;
    wire [3:0] stb_count;
    integer errors = 0;

    shape_stabilizer u (
        .clk(clk), .rst_n(rst_n), .vs(vs),
        .shp0(shp0), .shp1(shp1), .shp2(shp2), .shp3(shp3),
        .det_count(4'd1),
        .stb0(stb0), .stb1(stb1), .stb2(stb2), .stb3(stb3),
        .stb_count(stb_count)
    );

    task shape(input valid, input [2:0] cls, input [9:0] x0, y0, x1, y1,
               output [43:0] s);
        begin
            s = {valid, cls, x0, y0, x1, y1};
        end
    endtask

    task frame(input [43:0] s0, s1, s2, s3);
        begin
            shp0 = s0; shp1 = s1; shp2 = s2; shp3 = s3;
            @(posedge clk);
            vs = 1;
            @(posedge clk);
            @(posedge clk);
            vs = 0;
            repeat (3) @(posedge clk);
        end
    endtask

    task check(input [43:0] got, input [43:0] exp, input [127:0] name);
        begin
            if (got !== exp) begin
                $display("FAIL %0s: got=%h exp=%h", name, got, exp);
                errors = errors + 1;
            end else
                $display("PASS %0s: %h", name, got);
        end
    endtask

    reg [43:0] s1, s2, s3, s4, s1_old, zero;
    initial begin
        shp0 = 0; shp1 = 0; shp2 = 0; shp3 = 0;
        zero = 44'd0;
        repeat (10) @(posedge clk);
        rst_n = 1;

        shape(1, 3'd1, 10'd20, 10'd30, 10'd80, 10'd100, s1);  // circle
        shape(1, 3'd2, 10'd100, 10'd30, 10'd160, 10'd100, s2); // triangle
        shape(1, 3'd3, 10'd190, 10'd30, 10'd240, 10'd100, s3); // rectangle
        shape(1, 3'd4, 10'd260, 10'd30, 10'd318, 10'd92, s4);  // plus

        // frame 0/1/2: same list -> stable after frame 2
        frame(s1, s2, s3, s4);
        check(stb0, zero, "frame0 hold");
        frame(s1, s2, s3, s4);
        check(stb0, zero, "frame1 hold");
        frame(s1, s2, s3, s4);
        check(stb0, s1, "frame2 stable circle");
        check(stb1, s2, "frame2 stable triangle");
        check(stb2, s3, "frame2 stable rect");
        check(stb3, s4, "frame2 stable plus");

        // class change: hold old for 2 frames, update on 3rd
        s1_old = s1;
        shape(1, 3'd2, 10'd20, 10'd30, 10'd80, 10'd100, s1);
        frame(s1, s2, s3, s4);
        check(stb0, s1_old, "class change frame0 hold");
        frame(s1, s2, s3, s4);
        check(stb0, s1_old, "class change frame1 hold");
        frame(s1, s2, s3, s4);
        check(stb0, s1, "class change frame2 update");

        // missing: hold for 2 frames, clear on 3rd
        s1_old = s1;
        frame(zero, s2, s3, s4);
        check(stb0, s1_old, "miss frame0 hold");
        frame(zero, s2, s3, s4);
        check(stb0, s1_old, "miss frame1 hold");
        frame(zero, s2, s3, s4);
        check(stb0, zero, "miss frame2 clear");

        if (errors == 0)
            $display("RESULT: PASS (stabilizer)");
        else
            $display("RESULT: FAIL (%0d errors)", errors);
        $finish;
    end
endmodule
