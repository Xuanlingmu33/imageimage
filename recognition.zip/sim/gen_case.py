#!/usr/bin/env python3
"""Generate a controlled 640x480 synthetic "SC431-like" camera frame.

Outputs:
  sim/case.png       visual check
  sim/case.hex       one 640x480 RGB565 frame, one 16-bit hex word per pixel
  sim/case.txt       expected classes/bboxes (mask coordinates)

Target shapes:
  target4      four shapes (ring, triangle, rectangle, plus) - original scene
  solid_circle filled circle
  ring         hollow ellipse ring
  square       filled square (class: rectangle)
  rectangle    filled wide rectangle (class: rectangle)
  triangle     filled triangle
  plus         filled plus
  diamond      rotated square - should be rejected as unknown
  star         5-point star - should be rejected as unknown
  blob         random blob - should be rejected as unknown
  thin_line    thin bar - should be rejected as unknown

Examples:
  python sim/gen_case.py --name clear
  python sim/gen_case.py --name circle --shape solid_circle --noise 7 --green 1.15
  python sim/gen_case.py --name diamond --shape diamond --noise 5
"""
import argparse
import math
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

W, H = 640, 480
MASK_W, MASK_H = 320, 240
BLACK = (18, 18, 18)
UNKNOWN = {"diamond", "star", "blob", "thin_line"}


def _finish(img, noise, blur, green, brightness, rotate):
    cx, cy = W / 2, H / 2
    bg = 232.0 * brightness
    if rotate:
        img = img.rotate(rotate, center=(cx, cy), resample=Image.BILINEAR,
                         fillcolor=(int(bg), int(bg), int(bg)))
    if blur > 0:
        img = img.filter(ImageFilter.GaussianBlur(blur))

    arr = np.asarray(img, dtype=np.float32)
    if noise > 0:
        shot = np.sqrt(np.clip(arr, 0, 255)) * 0.7
        arr = arr + np.random.normal(0, noise, arr.shape) + \
              np.random.normal(0, 1.0, arr.shape) * shot

    arr[:, :, 1] *= green
    arr *= brightness
    return np.clip(arr, 0, 255).astype(np.uint8)


def _draw_target4(d, bg, scale):
    cx, cy = W / 2, H / 2

    def P(x, y):
        return (cx + (x - cx) * scale, cy + (y - cy) * scale)

    o0, o1 = P(50, 90), P(170, 250)
    i0, i1 = P(75, 125), P(145, 215)
    d.ellipse([int(o0[0]), int(o0[1]), int(o1[0]), int(o1[1])], fill=BLACK)
    d.ellipse([int(i0[0]), int(i0[1]), int(i1[0]), int(i1[1])],
              fill=(int(bg), int(bg), int(bg)))

    tri = [P(250, 65), P(185, 255), P(315, 255)]
    d.polygon([(int(x), int(y)) for x, y in tri], fill=BLACK)

    r0, r1 = P(380, 75), P(485, 255)
    d.rectangle([int(r0[0]), int(r0[1]), int(r1[0]), int(r1[1])], fill=BLACK)

    pc = P(575, 165)
    arm, th = 58 * scale, 17 * scale
    d.rectangle([int(pc[0]-th), int(pc[1]-arm), int(pc[0]+th), int(pc[1]+arm)], fill=BLACK)
    d.rectangle([int(pc[0]-arm), int(pc[1]-th), int(pc[0]+arm), int(pc[1]+th)], fill=BLACK)


def _draw_single(d, bg, shape, scale):
    cx, cy = W / 2, H / 2
    R = 110 * scale

    def box(x0, y0, x1, y1):
        return [int(cx + x0), int(cy + y0), int(cx + x1), int(cy + y1)]

    if shape in ("solid_circle", "ring"):
        d.ellipse(box(-R, -R, R, R), fill=BLACK)
        if shape == "ring":
            d.ellipse(box(-0.58*R, -0.58*R, 0.58*R, 0.58*R),
                      fill=(int(bg), int(bg), int(bg)))
    elif shape == "square":
        d.rectangle(box(-R, -R, R, R), fill=BLACK)
    elif shape == "rectangle":
        d.rectangle(box(-1.15*R, -0.75*R, 1.15*R, 0.75*R), fill=BLACK)
    elif shape == "triangle":
        d.polygon([(int(cx), int(cy-R)), (int(cx-R), int(cy+R)),
                   (int(cx+R), int(cy+R))], fill=BLACK)
    elif shape == "plus":
        arm, th = R, 0.28 * R
        d.rectangle(box(-th, -arm, th, arm), fill=BLACK)
        d.rectangle(box(-arm, -th, arm, th), fill=BLACK)
    elif shape == "diamond":
        d.polygon([(int(cx), int(cy-R)), (int(cx+R), int(cy)),
                   (int(cx), int(cy+R)), (int(cx-R), int(cy))], fill=BLACK)
    elif shape == "star":
        pts = []
        for k in range(10):
            ang = -math.pi/2 + k * math.pi/5
            r = R if k % 2 == 0 else 0.45 * R
            pts.append((int(cx + r*math.cos(ang)), int(cy + r*math.sin(ang))))
        d.polygon(pts, fill=BLACK)
    elif shape == "blob":
        pts = []
        for k in range(10):
            ang = 2*math.pi*k/10
            r = R * (0.65 + 0.45*((k*37) % 11)/10.0)
            pts.append((int(cx + r*math.cos(ang)), int(cy + r*math.sin(ang))))
        d.polygon(pts, fill=BLACK)
    elif shape == "thin_line":
        th = 7 * scale
        d.polygon([(int(cx-R), int(cy-th)), (int(cx+R), int(cy-th)),
                   (int(cx+R), int(cy+th)), (int(cx-R), int(cy+th))], fill=BLACK)
    else:
        raise ValueError(f"unknown shape {shape}")


def draw_scene(scale=1.0, noise=4.0, blur=0.8, green=1.0, brightness=1.0,
               rotate=0.0, shape="target4"):
    bg = 232.0 * brightness
    img = Image.new("RGB", (W, H), (int(bg), int(bg), int(bg)))
    d = ImageDraw.Draw(img)

    if shape == "target4":
        _draw_target4(d, bg, scale)
    else:
        _draw_single(d, bg, shape, scale)

    return _finish(img, noise, blur, green, brightness, rotate)


def expected(scale=1.0, shape="target4"):
    cx, cy = W / 2, H / 2

    def m(x, y):
        return (int((cx + (x - cx) * scale) / 2),
                int((cy + (y - cy) * scale) / 2))

    if shape == "target4":
        ring0 = m(45, 80);  ring1 = m(175, 260)
        tri0 = m(180, 60);  tri1 = m(320, 260)
        rect0 = m(375, 70); rect1 = m(490, 260)
        plus0 = m(510, 90); plus1 = m(640, 245)
        return [
            ("circle", ring0[0], ring0[1], ring1[0], ring1[1]),
            ("triangle", tri0[0], tri0[1], tri1[0], tri1[1]),
            ("rectangle", rect0[0], rect0[1], rect1[0], rect1[1]),
            ("plus", plus0[0], plus0[1], plus1[0], plus1[1]),
        ]

    if shape in UNKNOWN:
        return []

    R = 110 * scale
    if shape in ("solid_circle", "ring"):
        return [("circle", int((cx-R)/2), int((cy-R)/2),
                 int((cx+R)/2), int((cy+R)/2))]
    if shape == "square":
        return [("rectangle", int((cx-R)/2), int((cy-R)/2),
                 int((cx+R)/2), int((cy+R)/2))]
    if shape == "rectangle":
        return [("rectangle", int((cx-1.15*R)/2), int((cy-0.75*R)/2),
                 int((cx+1.15*R)/2), int((cy+0.75*R)/2))]
    if shape == "triangle":
        return [("triangle", int((cx-R)/2), int((cy-R)/2),
                 int((cx+R)/2), int((cy+R)/2))]
    if shape == "plus":
        return [("plus", int((cx-R)/2), int((cy-R)/2),
                 int((cx+R)/2), int((cy+R)/2))]
    raise ValueError(shape)


def rgb565_hex(arr):
    r = (arr[:, :, 0] >> 3).astype(np.uint16)
    g = (arr[:, :, 1] >> 2).astype(np.uint16)
    b = (arr[:, :, 2] >> 3).astype(np.uint16)
    return (r << 11) | (g << 5) | b


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", default="case")
    ap.add_argument("--shape", default="target4",
                    choices=["target4", "solid_circle", "ring", "square",
                             "rectangle", "triangle", "plus", "diamond",
                             "star", "blob", "thin_line"])
    ap.add_argument("--scale", type=float, default=1.0)
    ap.add_argument("--noise", type=float, default=4.0)
    ap.add_argument("--blur", type=float, default=0.8)
    ap.add_argument("--green", type=float, default=1.0)
    ap.add_argument("--brightness", type=float, default=1.0)
    ap.add_argument("--rotate", type=float, default=0.0)
    ap.add_argument("--outdir", default="sim")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    np.random.seed(1234)

    arr = draw_scene(args.scale, args.noise, args.blur, args.green,
                     args.brightness, args.rotate, args.shape)
    Image.fromarray(arr).save(os.path.join(args.outdir, f"{args.name}.png"))

    words = rgb565_hex(arr).reshape(-1)
    with open(os.path.join(args.outdir, f"{args.name}.hex"), "w") as f:
        for w in words:
            f.write(f"{int(w):04x}\n")

    with open(os.path.join(args.outdir, f"{args.name}.txt"), "w") as f:
        f.write(f"name={args.name} shape={args.shape} scale={args.scale} "
                f"noise={args.noise} blur={args.blur} green={args.green} "
                f"brightness={args.brightness} rotate={args.rotate}\n")
        ex = expected(args.scale, args.shape)
        if not ex:
            f.write("unknown\n")
        for name, x0, y0, x1, y1 in ex:
            f.write(f"{name} {x0} {y0} {x1} {y1}\n")
    print(os.path.join(args.outdir, f"{args.name}.hex"))


if __name__ == "__main__":
    main()
