#!/usr/bin/env python3
"""Deterministic case list for the realistic-degradation evaluation.

The dataset is intentionally organized as controlled variables: each group
changes one or two degradation axes, so eval.py can plot accuracy vs. noise,
blur, exposure, rotation, scale, etc.  A few combined / severe cases are also
included, plus 5-frame sequences for stability.
"""
import numpy as np
import cam_sim as C


def _deg(**kw):
    d = dict(bg=232, shape_gray=18)
    d.update(kw)
    return d


def build(seed=2026):
    rng = np.random.default_rng(seed)
    cases = []

    def add(case):
        case.seed = int(rng.integers(0, 1 << 30))
        cases.append(case)

    # ------------------------------------------------------------------
    # clean / geometry baseline
    # ------------------------------------------------------------------
    for sc in (0.55, 0.75, 1.0):
        add(C.target4_case(sc, **_deg()))

    single = [
        ("circle_solid", 0), ("circle_ring", 0), ("ellipse", 0),
        ("triangle", 0), ("triangle", 15), ("triangle", 30), ("triangle", 45),
        ("rectangle", 0), ("rectangle", 15), ("rectangle", 30),
        ("square", 0), ("plus", 0), ("plus", 15),
    ]
    for kind, rot in single:
        add(C.single_case(kind, rot=rot, r=100, **_deg()))

    # reject / disturbance shapes
    for kind in ("diamond", "star", "thin_line", "blob", "text"):
        add(C.single_case(kind, r=100, **_deg()))

    # multi-target and touching targets
    add(C.multi_case("multi", **_deg()))
    add(C.multi_case("touching", **_deg()))

    # ------------------------------------------------------------------
    # controlled degradation axes (target4)
    # ------------------------------------------------------------------
    for v in (2, 6, 10):
        add(C.target4_case(1.0, noise=v, **_deg()))
    for v in (0.6, 1.4, 2.2):
        add(C.target4_case(1.0, blur=v, **_deg()))
    for v in (0.65, 1.35):
        add(C.target4_case(1.0, exposure=v, **_deg()))
    for v in (0.75, 1.25):
        add(C.target4_case(1.0, gamma=v, **_deg()))
    for v in (1.12, 1.22):
        add(C.target4_case(1.0, wb=(1.0, v, 1.0), **_deg()))
    add(C.target4_case(1.0, bayer=True, **_deg()))
    for v in (0.2, 0.4):
        add(C.target4_case(1.0, vignette=v, **_deg()))
    for v in (0.08, 0.15):
        add(C.target4_case(1.0, distort=v, **_deg()))
    for v in (4, 8):
        add(C.target4_case(1.0, motion=v, motion_angle=20, **_deg()))
    for v in (0.3, 0.5):
        add(C.target4_case(1.0, shadow=v, shadow_x=180, shadow_y=160,
                           shadow_sx=90, shadow_sy=90, **_deg()))
    for v in (40, 80):
        add(C.target4_case(1.0, reflect=v, reflect_x=470, reflect_y=170,
                           reflect_sx=25, reflect_sy=25, **_deg()))
    for v in (0.25, 0.45):
        add(C.target4_case(1.0, grad=(v, 0.0), **_deg()))
    for v in (20, 40):
        add(C.target4_case(1.0, black_level=v, **_deg()))
    for v in (60, 100):
        add(C.target4_case(1.0, **_deg(shape_gray=v, bg=180)))

    # combined "severe" cases: noise + blur + WB + exposure + Bayer
    for k in range(6):
        add(C.target4_case(
            1.0,
            noise=float(rng.uniform(6, 11)),
            blur=float(rng.uniform(1.2, 2.0)),
            exposure=float(rng.uniform(0.8, 1.2)),
            gamma=float(rng.uniform(0.85, 1.15)),
            wb=(1.0, float(rng.uniform(1.1, 1.22)), 1.0),
            bayer=bool(k % 2),
            vignette=float(rng.uniform(0.1, 0.3)),
            **_deg()))
    # combined shadow + gradient + low contrast
    for k in range(4):
        add(C.target4_case(
            1.0,
            black_level=float(rng.uniform(10, 30)),
            shadow=float(rng.uniform(0.2, 0.5)),
            shadow_x=float(rng.uniform(100, 540)),
            shadow_y=float(rng.uniform(80, 400)),
            grad=(float(rng.uniform(0.15, 0.4)), 0.0),
            noise=float(rng.uniform(2, 7)),
            **_deg(shape_gray=70, bg=185)))

    # ------------------------------------------------------------------
    # 5-frame sequences (jitter + independent noise) for stability
    # ------------------------------------------------------------------
    for k in range(4):
        c = C.target4_case(
            0.9,
            noise=float(rng.uniform(2, 6)),
            blur=float(rng.uniform(0.4, 1.2)),
            jitter=2.0,
            **_deg())
        c.frames = 5
        add(c)

    # name every case uniquely
    for i, c in enumerate(cases):
        c.name = f"{i:03d}_{c.scene}_{c.name}"
    return cases


def summarize(cases):
    print(f"cases={len(cases)}")
    from collections import Counter
    print(Counter(c.scene for c in cases))
    print(Counter(c.reject for c in cases))


if __name__ == "__main__":
    summarize(build())
