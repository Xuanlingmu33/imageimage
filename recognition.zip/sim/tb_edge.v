`timescale 1ns/1ps
module tb_edge;
    reg clk=0; always #10 clk=~clk;
    reg rst_n=0;
    reg [9:0] x=0,y=0;
    reg de=0;
    reg [7:0] r,g,b;
    wire is_edge;
    integer i,j;

    edge_detect_640 u(.clk(clk),.rst_n(rst_n),.r(r),.g(g),.b(b),.de(de),.x(x),.y(y),.is_edge(is_edge));

    task pix(input [9:0] xx, input [9:0] yy, input dark);
        begin
            x=xx; y=yy;
            if (dark) {r,g,b}=24'h000000; else {r,g,b}=24'hFFFFFF;
            de=1;
            @(posedge clk); #1;
        end
    endtask

    initial begin
        {r,g,b}=24'hFFFFFF;
        repeat(5) @(posedge clk);
        rst_n=1;
        for (j=0;j<5;j=j+1) begin
            for (i=0;i<20;i=i+1) begin
                pix(i,j,(i>=5 && i<15));
            end
            de=0;
            repeat(3) @(posedge clk);
        end
        // now feed row 5 and observe
        for (i=0;i<20;i=i+1) begin
            pix(i,5,(i>=5 && i<15));
            $display("i=%0d edge=%b L1=%b L2=%b L3=%b c=%b l=%b r=%b u=%b d=%b", i, is_edge, u.line1[2:0], u.line2[2:0], u.line3[2:0], u.center, u.left, u.right, u.up, u.down);
        end
        $finish;
    end
endmodule
