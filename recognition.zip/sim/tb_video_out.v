`timescale 1ns/1ps
//============================================================================
// tb_video_out.v - checks the 2px -> 1px line buffer / 640x480 timing
//============================================================================
module tb_video_out;
    reg clk = 0;
    always #19.841 clk = ~clk;   // 25.2 MHz

    reg rst_n = 0;
    reg hs = 0, vs = 0, cvo_de = 0;
    reg [47:0] rgb2 = 0;
    wire [23:0] pix;
    wire pix_de, pix_hs, pix_vs;
    wire [9:0] pix_x, pix_y;

    video_out_640x480 u (
        .clk(clk), .rst_n(rst_n),
        .hs_in(hs), .vs_in(vs),
        .rgb2_in(rgb2), .rgb2_de(cvo_de),
        .pix_out(pix), .pix_de(pix_de), .pix_hs(pix_hs), .pix_vs(pix_vs),
        .pix_x(pix_x), .pix_y(pix_y)
    );

    integer lc, hc, errors = 0, de_cnt = 0;
    integer xv;
    integer last_x = -1;

    // clock the cvo timing: 800 clocks/line, 525 lines
    initial begin
        repeat (10) @(posedge clk);
        rst_n = 1;
        for (lc = 0; lc < 10; lc = lc + 1) begin
            for (hc = 0; hc < 800; hc = hc + 1) begin
                hs = (hc < 48);
                vs = (lc < 2);
                cvo_de = (hc >= 480);
                if (hc >= 480) begin
                    xv = (hc-480)*2;
                    // debayer word is {B,G,R}; put the test value in B so
                    // that the RGB output has it in pix[7:0]
                    rgb2[23:0]  = {xv[7:0], 8'h00, 8'h00};
                    rgb2[47:24] = {xv[7:0] + 8'd1, 8'h00, 8'h00};
                end
                @(posedge clk);
            end
        end
        $display("video_out test: errors=%0d", errors);
        $finish;
    end

    // check the output stream
    always @(posedge clk) begin
        if (pix_de) begin
            de_cnt = de_cnt + 1;
            if (pix_x != de_cnt - 1) begin
                $display("ERROR x: pix_x=%0d expected=%0d at y=%0d", pix_x, de_cnt - 1, pix_y);
                errors = errors + 1;
            end
            // Only the first active line is black; later lines carry data.
            if (pix_y > 0) begin
                if (pix[7:0] != (pix_x[7:0])) begin
                    $display("ERROR data: y=%0d x=%0d pix=%06x", pix_y, pix_x, pix);
                    errors = errors + 1;
                end
            end
        end else begin
            if (de_cnt != 0) de_cnt = 0;
        end
    end
endmodule
