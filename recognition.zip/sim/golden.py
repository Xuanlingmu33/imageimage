#!/usr/bin/env python3
"""Fast per-shape CLI using the same detector model as eval.py.

For the full realistic-degradation dataset use eval.py.  This file is kept for
quick single-shape checks and backwards-compatible commands.

  python sim/golden.py --n 30 --shape solid_circle
  python sim/golden.py --n 30 --shape diamond
"""
import argparse
import sys, os
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
from gen_case import draw_scene, expected, UNKNOWN  # noqa: E402
from detector import Params, make_mask, detect      # noqa: E402

CLS = {"circle": 1, "triangle": 2, "rectangle": 3, "plus": 4}


def iou(a, b):
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b
    ix0, iy0 = max(ax0, bx0), max(ay0, by0)
    ix1, iy1 = min(ax1, bx1), min(ay1, by1)
    if ix1 < ix0 or iy1 < iy0:
        return 0.0
    inter = (ix1 - ix0 + 1) * (iy1 - iy0 + 1)
    ua = (ax1 - ax0 + 1) * (ay1 - ay0 + 1)
    ub = (bx1 - bx0 + 1) * (by1 - by0 + 1)
    return inter / float(ua + ub - inter)


def run(scale, noise, blur, green, bright, shape, p):
    arr = draw_scene(scale, noise, blur, green, bright, shape=shape,
                     rotate=0.0)
    mask, thr = make_mask(arr, p)
    det = detect(mask, p)
    exp = expected(scale, shape)
    return det, exp, thr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=30)
    ap.add_argument("--shape", default="target4",
                    choices=["target4", "solid_circle", "ring", "square",
                             "rectangle", "triangle", "plus", "diamond",
                             "star", "blob", "thin_line"])
    ap.add_argument("--scale", type=float, default=None)
    ap.add_argument("--noise", type=float, default=None)
    ap.add_argument("--blur", type=float, default=None)
    ap.add_argument("--green", type=float, default=None)
    ap.add_argument("--brightness", type=float, default=None)
    ap.add_argument("--seed", type=int, default=1)
    args = ap.parse_args()

    np.random.seed(args.seed)
    p = Params()
    is_rej = args.shape in UNKNOWN

    if is_rej:
        clean = 0
        for k in range(args.n):
            rng = np.random
            scale = args.scale or rng.uniform(0.55, 1.0)
            noise = args.noise if args.noise is not None else rng.uniform(0, 9)
            blur = args.blur if args.blur is not None else rng.uniform(0, 1.3)
            green = args.green if args.green is not None else rng.uniform(0.9, 1.2)
            bright = args.brightness if args.brightness is not None else rng.uniform(0.75, 1.15)
            det, _, _ = run(scale, noise, blur, green, bright, args.shape, p)
            clean += int(len(det) == 0)
        print(f"shape={args.shape} cases={args.n} rejected={clean} "
              f"rejection={100.0*clean/max(1,args.n):.1f}%")
        return

    total = correct = 0
    per = {1: [0, 0], 2: [0, 0], 3: [0, 0], 4: [0, 0]}
    fails = []
    for k in range(args.n):
        rng = np.random
        scale = args.scale or rng.uniform(0.55, 1.0)
        noise = args.noise if args.noise is not None else rng.uniform(0, 9)
        blur = args.blur if args.blur is not None else rng.uniform(0, 1.3)
        green = args.green if args.green is not None else rng.uniform(0.9, 1.2)
        bright = args.brightness if args.brightness is not None else rng.uniform(0.75, 1.15)
        det, exp, thr = run(scale, noise, blur, green, bright, args.shape, p)
        used = set()
        ok = 0
        for name, x0, y0, x1, y1 in exp:
            cls = CLS[name]
            best, best_iou = -1, 0.0
            for i, d in enumerate(det):
                if i in used or d["cls"] != cls:
                    continue
                v = iou((d["x0"], d["y0"], d["x1"], d["y1"]), (x0, y0, x1, y1))
                if v > best_iou:
                    best_iou, best = v, i
            if best >= 0 and best_iou > 0.25:
                used.add(best); ok += 1
                per[cls][0] += 1
            per[cls][1] += 1
        total += len(exp); correct += ok
        if ok != len(exp):
            fails.append((k, round(scale, 2), round(noise, 1), round(blur, 2),
                          round(green, 2), thr,
                          [(d["cls"], d["x0"], d["y0"], d["x1"], d["y1"]) for d in det]))
    print(f"shape={args.shape} cases={args.n} expected={total} matched={correct} "
          f"accuracy={100.0*correct/max(1,total):.1f}%")
    for c in (1, 2, 3, 4):
        a, b = per[c]
        print(f"  class {c}: {a}/{b} = {100.0*a/max(1,b):.1f}%")
    for f in fails[:5]:
        print("FAIL", f)


if __name__ == "__main__":
    main()
