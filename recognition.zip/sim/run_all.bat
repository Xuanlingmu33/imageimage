@echo off
rem ============================================================
rem  Run the self-checking testbenches with Icarus Verilog
rem  Usage:  sim\run_all.bat
rem ============================================================
setlocal
set ROOT=%~dp0..
set IVERILOG=C:\iverilog\bin\iverilog.exe
set VVP=C:\iverilog\bin\vvp.exe
cd /d "%ROOT%"

if not exist "%IVERILOG%" (
    echo [ERROR] Icarus Verilog not found at %IVERILOG%
    echo         Edit this script or add iverilog to PATH.
    exit /b 1
)

echo ==== tb_video_out : 2px/clk -> 1px/clk line buffer ====
"%IVERILOG%" -o "%ROOT%\sim\tb_video_out.vvp" ^
  "%ROOT%\sim\tb_video_out.v" ^
  "%ROOT%\rtl\shape\video_out_640x480.v" || exit /b 1
"%VVP%" "%ROOT%\sim\tb_video_out.vvp" || exit /b 1

echo.
echo ==== tb_shape : mask + CCL + classification + overlay ====
"%IVERILOG%" -o "%ROOT%\sim\tb_shape.vvp" ^
  "%ROOT%\sim\tb_shape.v" ^
  "%ROOT%\rtl\shape\shape_mask_ccl.v" ^
  "%ROOT%\rtl\shape\edge_detect_640.v" ^
  "%ROOT%\rtl\shape\shape_overlay.v" ^
  "%ROOT%\rtl\shape\shape_font_rom.v" || exit /b 1
"%VVP%" "%ROOT%\sim\tb_shape.vvp" || exit /b 1

echo.
echo ==== tb_stabilizer : 3-frame class confirmation ====
"%IVERILOG%" -o "%ROOT%\sim\tb_stabilizer.vvp" ^
  "%ROOT%\sim\tb_stabilizer.v" ^
  "%ROOT%\rtl\shape\shape_stabilizer.v" || exit /b 1
"%VVP%" "%ROOT%\sim\tb_stabilizer.vvp" || exit /b 1

echo.
echo ==== tb_edge : full-resolution contour detector ====
"%IVERILOG%" -o "%ROOT%\sim\tb_edge.vvp" ^
  "%ROOT%\sim\tb_edge.v" ^
  "%ROOT%\rtl\shape\edge_detect_640.v" || exit /b 1
"%VVP%" "%ROOT%\sim\tb_edge.vvp" || exit /b 1

if exist "%ROOT%\sim\case.hex" (
    echo.
    echo ==== tb_image : synthetic 640x480 frame -> recognition ====
    "%IVERILOG%" -o "%ROOT%\sim\tb_image.vvp" ^
      "%ROOT%\sim\tb_image.v" ^
      "%ROOT%\rtl\shape\shape_mask_ccl.v" ^
      "%ROOT%\rtl\shape\shape_stabilizer.v" || exit /b 1
    "%VVP%" "%ROOT%\sim\tb_image.vvp" || exit /b 1
)

echo.
echo All simulations finished.
endlocal
exit /b 0
