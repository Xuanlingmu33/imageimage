`timescale 1ns/1ps
//============================================================================
// tb_shape.v - synthetic 640x480 scene for shape_mask_ccl + shape_overlay
//   Scene (same layout as the reference photo):
//     hollow ellipse, filled triangle, filled rectangle, plus sign
//   Digits are placed below the detection ROI.
//============================================================================
module tb_shape;

    reg clk = 0;
    always #19.841 clk = ~clk;   // 25.2 MHz

    reg rst_n = 0;

    reg [9:0] x = 0, y = 0;
    reg hs = 0, vs = 0, de = 0;
    reg [7:0] r, g, b;

    wire [43:0] shp0, shp1, shp2, shp3;
    wire [3:0]  det_count;
    wire        is_edge;
    wire [23:0] ov_rgb;

    integer frame = 0;
    integer yy, xx;
    integer dx, dy;

    //------------------------------------------------------------------
    // synthetic image
    //------------------------------------------------------------------
    reg dark;
    always @* begin
        dark = 1'b0;
        dx = x - 100;
        dy = y - 130;
        // hollow ellipse ring
        if ((dx*dx*75*75 + dy*dy*55*55 <= 55*55*75*75) &&
            (dx*dx*55*55 + dy*dy*35*35 >  35*35*55*55))
            dark = 1'b1;
        // filled triangle
        if (y >= 60 && y <= 200) begin
            if (x >= (250 - (y - 60) * 60 / 140) &&
                x <= (250 + (y - 60) * 60 / 140))
                dark = 1'b1;
        end
        // filled rectangle
        if (x >= 380 && x <= 480 && y >= 60 && y <= 200)
            dark = 1'b1;
        // plus
        if (((x >= 565 && x <= 595) && (y >= 75 && y <= 185)) ||
            ((x >= 525 && x <= 635) && (y >= 115 && y <= 145)))
            dark = 1'b1;
        // digits below ROI (should not be detected)
        if (y >= 410 && y <= 470 && x >= 40 && x <= 600)
            if ((x % 100) < 35)
                dark = 1'b1;

        if (dark)
            {r, g, b} = 24'h000000;
        else
            {r, g, b} = 24'h50A0DC;
    end

    //------------------------------------------------------------------
    // 640x480@60 timing
    //------------------------------------------------------------------
    task run_line;
        begin
            hs = 1'b1;
            for (xx = 0; xx < 800; xx = xx + 1) begin
                x  = (xx >= 146 && xx <= 785) ? (xx - 146) : 10'd0;
                de = (xx >= 146 && xx <= 785) && (y >= 35 && y < 515);
                hs = (xx < 96);
                @(posedge clk);
            end
            hs = 1'b0;
            de = 1'b0;
            @(posedge clk);
        end
    endtask

    //------------------------------------------------------------------
    // DUTs
    //------------------------------------------------------------------
    shape_mask_ccl dut (
        .clk (clk),
        .rst_n (rst_n),
        .r (r), .g (g), .b (b),
        .de (de), .hs (hs), .vs (vs),
        .x (x), .y (y),
        .shp0 (shp0), .shp1 (shp1), .shp2 (shp2), .shp3 (shp3),
        .det_count (det_count)
    );

    edge_detect_640 u_edge (
        .clk (clk), .rst_n (rst_n),
        .r (r), .g (g), .b (b),
        .de (de), .x (x), .y (y),
        .is_edge (is_edge)
    );

    shape_overlay u_ov (
        .clk (clk), .rst_n (rst_n),
        .x (x), .y (y),
        .rgb_in ({r, g, b}),
        .is_edge (is_edge),
        .view_mode (1'b1),
        .shp0 (shp0), .shp1 (shp1), .shp2 (shp2), .shp3 (shp3),
        .rgb_out (ov_rgb)
    );

    //------------------------------------------------------------------
    // checks
    //------------------------------------------------------------------
    task show_shape;
        input [43:0] s;
        input integer n;
        begin
            if (s[43])
                $display("  shape%0d: class=%0d bbox=(%0d,%0d)-(%0d,%0d)",
                         n, s[42:40], s[39:30], s[29:20], s[19:10], s[9:0]);
            else
                $display("  shape%0d: empty", n);
        end
    endtask

    integer ycnt, ccnt, tcnt, rcnt, pcnt, ecnt;
    integer edgecnt;
    reg de_d;
    always @(posedge clk) de_d <= de;

    initial begin
        rst_n = 0;
        r = 0; g = 0; b = 0;
        repeat (20) @(posedge clk);
        rst_n = 1;

        for (frame = 0; frame < 4; frame = frame + 1) begin
            // vertical blank before active
            vs = 1'b1;
            y = 0;
            run_line; run_line;
            vs = 1'b0;

            for (yy = 2; yy < 525; yy = yy + 1) begin
                y = (yy >= 35 && yy < 515) ? (yy - 35) : 10'd0;
                if (yy >= 35 && yy < 515) begin
                    y = yy - 35;
                    run_line;
                end else begin
                    de = 0;
                    repeat (800) @(posedge clk);
                end
            end
            // wait for detector to finish
            repeat (200000) @(posedge clk);

            $display("===== after frame %0d, det_count=%0d =====", frame, det_count);
            $display("raw: %h %h %h %h", shp0, shp1, shp2, shp3);
            show_shape(shp0, 0);
            show_shape(shp1, 1);
            show_shape(shp2, 2);
            show_shape(shp3, 3);

            // count overlay colors over next active area (quick check)
            ycnt = 0; ccnt = 0; tcnt = 0; rcnt = 0; pcnt = 0; ecnt = 0; edgecnt = 0;
            for (yy = 0; yy < 480; yy = yy + 1) begin
                y = yy;
                de = 0;
                repeat (146) @(posedge clk);
                de = 1;
                for (xx = 0; xx < 640; xx = xx + 1) begin
                    x = xx;
                    @(posedge clk);
                    if (de_d) begin
                        if (is_edge) edgecnt = edgecnt + 1;
                        if (ov_rgb == 24'hFFFF00) ycnt = ycnt + 1;
                        if (ov_rgb == 24'h00FFFF) ccnt = ccnt + 1;
                        if (ov_rgb == 24'hFF00FF) tcnt = tcnt + 1;
                        if (ov_rgb == 24'hC0C0C0) pcnt = pcnt + 1;
                        if (ov_rgb == 24'hFFFFFF) ecnt = ecnt + 1;
                    end
                end
                de = 0;
                repeat (14) @(posedge clk);
            end
            $display("overlay pixels: yellow=%0d cyan=%0d magenta=%0d plus=%0d white=%0d edge_raw=%0d",
                     ycnt, ccnt, tcnt, pcnt, ecnt, edgecnt);
        end

        if (det_count >= 3)
            $display("RESULT: PASS (detected %0d shapes)", det_count);
        else
            $display("RESULT: FAIL (only %0d shapes)", det_count);
        $finish;
    end

endmodule
