#!/usr/bin/env python3
"""Parameterized Python model of shape_mask_ccl.v.

Used by eval.py for fast dataset sweeps and grid search.  Keep this file in
sync with the RTL when a parameter is promoted to hardware.
"""
from dataclasses import dataclass
import numpy as np


@dataclass
class Params:
    thr_mode: str = "avg_minus"  # avg_minus / auto / fixed
    thr_fixed: int = 96
    thr_num: int = 1            # auto threshold = avg * num / den
    thr_den: int = 2
    thr_offset: int = 50        # avg_minus mode: avg - offset
    thr_min: int = 40
    thr_max: int = 180
    min_area: int = 260
    min_dim: int = 10
    max_dim: int = 180
    max_area: int = 24000
    fill_rect: float = 0.85
    fill_circ: float = 0.70
    tri_wf_factor: int = 2
    plus_wf_factor: int = 6
    min_run: int = 2


def luma_of(arr):
    a = arr.astype(np.int32)
    return (a[:, :, 0] * 77 + a[:, :, 1] * 150 + a[:, :, 2] * 29) >> 8


def make_mask(arr, p: Params):
    luma = luma_of(arr)
    if p.thr_mode == "auto":
        avg = int(luma[::2, ::2].mean())
        thr = int(avg * p.thr_num / max(1, p.thr_den))
        thr = max(p.thr_min, min(p.thr_max, thr))
    elif p.thr_mode == "avg_minus":
        avg = int(luma[::2, ::2].mean())
        thr = max(p.thr_min, min(p.thr_max, avg - p.thr_offset))
    else:
        thr = p.thr_fixed
    b = luma < thr
    m = (b[0::2, 0::2] | b[1::2, 0::2] |
         b[0::2, 1::2] | b[1::2, 1::2])
    return m.astype(np.uint8), thr


def row_runs(row, min_run=1):
    runs = []
    x, n = 0, len(row)
    while x < n:
        if row[x]:
            x0 = x
            while x < n and row[x]:
                x += 1
            if x - x0 >= min_run:
                runs.append((x0, x - 1))
        else:
            x += 1
    return runs


def classify(area, w, h, wf, wl, runs, mxw, max_low, up, dn, p: Params):
    wh = max(1, w * h)
    fill = area / wh
    if runs * 4 > h * 5 and w * 20 > h * 13 and fill < p.fill_rect:
        return 1                                   # hollow ring
    if fill > p.fill_rect:
        return 3                                   # rectangle / square
    if fill > p.fill_circ:
        return 1                                   # filled circle / ellipse
    changes = up + dn
    diff = abs(up - dn)
    tri_a = changes * 2 > h and diff * 20 > h * 7      # small shapes
    tri_b = changes * 5 > h * 4 and diff * 10 > h     # larger rotations
    if (0.35 < fill < 0.65 and runs * 2 < h * 3 and (tri_a or tri_b)):
        return 2                                   # triangle (rotation tolerant)
    if (runs * 2 < h * 3 and wf * p.plus_wf_factor > w and
            wl * p.plus_wf_factor > w):
        return 4                                   # plus
    return 0                                       # unknown


def detect(mask, p: Params, debug=False):
    H, W = mask.shape
    objs = []

    for y in range(H):
        for x0, x1 in row_runs(mask[y], p.min_run):
            length = x1 - x0 + 1
            matches = []
            for i, o in enumerate(objs):
                if o is None:
                    continue
                if o["last"] >= y - 1 and x1 >= o["x0"] and x0 <= o["x1"]:
                    matches.append(i)
            if not matches:
                objs.append(dict(x0=x0, x1=x1, y0=y, y1=y, area=length,
                                 last=y, wf=length, wl=length, runs=1,
                                 mxw=length, mxr=y, up=0, dn=0))
            else:
                base = matches[0]
                o = objs[base]
                area = o["area"] + length
                nx0, nx1 = min(o["x0"], x0), max(o["x1"], x1)
                ny0, ny1 = min(o["y0"], y), max(o["y1"], y)
                nwf = o["wf"]
                nrn = o["runs"] + 1
                nmxw, nmxr = o["mxw"], o["mxr"]
                nup, ndn = o["up"], o["dn"]
                if y == o["last"] + 1:
                    if length > o["wl"]:
                        nup += 1
                    elif length < o["wl"]:
                        ndn += 1
                if length > nmxw:
                    nmxw, nmxr = length, y
                for j in matches[1:]:
                    oo = objs[j]
                    area += oo["area"]
                    nx0 = min(nx0, oo["x0"]); nx1 = max(nx1, oo["x1"])
                    ny0 = min(ny0, oo["y0"]); ny1 = max(ny1, oo["y1"])
                    nrn += oo["runs"]
                    nup += oo["up"]; ndn += oo["dn"]
                    if oo["mxw"] > nmxw:
                        nmxw, nmxr = oo["mxw"], oo["mxr"]
                    objs[j] = None
                o.update(x0=nx0, x1=nx1, y0=ny0, y1=ny1,
                         area=area, last=y, wf=nwf, wl=length, runs=nrn,
                         mxw=nmxw, mxr=nmxr, up=nup, dn=ndn)

    out = []
    for o in objs:
        if o is None:
            continue
        w = o["x1"] - o["x0"] + 1
        h = o["y1"] - o["y0"] + 1
        a = o["area"]
        if a < p.min_area or w < p.min_dim or h < p.min_dim:
            continue
        if w > p.max_dim or h > p.max_dim or a > p.max_area:
            continue
        if w * 3 < h or h * 3 < w:
            continue
        if o["x0"] <= 2 and o["x1"] >= 318:
            continue
        max_low = (o["mxr"] - o["y0"]) * 2 > h
        if debug:
            print("OBJ", w, h, a, o["wf"], o["wl"], o["runs"], o["mxw"],
                  max_low, o["up"], o["dn"], "fill", round(a / (w * h), 3))
        cls = classify(a, w, h, o["wf"], o["wl"], o["runs"],
                       o["mxw"], max_low, o["up"], o["dn"], p)
        if cls == 0:
            continue
        out.append(dict(cls=cls, x0=o["x0"], y0=o["y0"],
                        x1=o["x1"], y1=o["y1"], area=a,
                        w=w, h=h, wf=o["wf"], wl=o["wl"],
                        runs=o["runs"], mxw=o["mxw"], mxr=o["mxr"],
                        up=o["up"], dn=o["dn"]))
    out.sort(key=lambda t: -t["area"])
    return out[:4]
